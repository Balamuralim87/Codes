# -*- coding: utf-8 -*-
"""
Created on Wed Apr 15 11:55:11 2020

@author: 206011
"""

import cv2
from PIL import Image, ImageSequence, TiffImagePlugin
import glob
import os 

    
    
def resize_img_using_PIL(in_path,out_path):
    try:
        print('Resizing TIF pages....')
        pages = []
        imagehandler = Image.open(in_path)
        img_dpi = imagehandler.info['dpi']
        for page in ImageSequence.Iterator(imagehandler):
            new_size = (2500, 3300)
            page = page.resize(new_size, Image.ANTIALIAS)
            pages.append(page)        
        print('Writing multipage TIF....')
        with TiffImagePlugin.AppendingTiffWriter(out_path, True) as tf:
            for page in pages:
                page.save(tf, dpi=img_dpi)
                tf.newFrame()
        imagehandler.close()
        print("Image resized successfully!!!")
    except Exception as e:
        print(e)
            
            
