import shutil
import os
import datetime
import time
import resize_image
from PIL import Image
import glob
import subprocess
from optparse import OptionParser
os.umask(0x000)
parser = OptionParser()
parser.add_option("-a", "--path1", dest="mpath", help='ML Model Folder', default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/In")
parser.add_option("-b", "--path2", dest="ppath", help='PIPE Model Folder', default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/3_pipe/In")
parser.add_option("-c", "--path3", dest="fpath", help='File Watcher Folder', default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/1_FileWatcher/In/")
parser.add_option("-d", "--path4", dest="resized_image_path", help='Resized Image Folder', default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/1_FileWatcher/Temp")
parser.add_option("-e", "--path5", dest="backup_original_image_path", help='Backup of Original Image Folder', default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/1_FileWatcher/Backup")
(options, args) = parser.parse_args()
path = options.fpath

if __name__ == "__main__":
    print("\nBucket 1: Pre-Process\n")
    while True:
        time.sleep(10)
        for File in glob.glob(path+'*.tif'):
            TIFF_File=os.path.basename(File)
            inFile = os.path.join(path , TIFF_File)
            mysubproces1 = subprocess.Popen(["sudo","chmod", "777",inFile])
            mysubproces1.wait()
            if os.path.isfile(inFile) :
                try:
                    ############################################
                    ## main process
                    startTime = str(datetime.datetime.now())
                    errFile = inFile.replace(".tif", ".err")
                    print('*************************************')
                    print('File Name: ' + str(TIFF_File) )
                    print('Start : ' + str(datetime.datetime.now()))
                    model_folder = os.path.join(options.mpath , TIFF_File)
                    pipe_folder = os.path.join(options.ppath , TIFF_File)
                    resize_folder = os.path.join(options.resized_image_path , TIFF_File)
                    backup_folder = os.path.join(options.backup_original_image_path , TIFF_File)
                    imagehandler = Image.open(inFile)
                    if(imagehandler.size[0]>4000 or imagehandler.size[1]>4000):
                        try:
                            resize_image.resize_img_using_PIL(inFile,resize_folder)
                        except:
                            print("error occured in resize_image.resize_img_using_PIL ")
                        if os.path.isfile(resize_folder) : 
                            shutil.copyfile(resize_folder, model_folder)
                            shutil.copyfile(resize_folder, pipe_folder)
                    else:
                        if os.path.isfile(inFile) :
                            shutil.copyfile(inFile, model_folder)
                            shutil.copyfile(inFile, pipe_folder)
                    if os.path.isfile(inFile)  and (os.path.exists(backup_folder)==False):
                            shutil.move(inFile, backup_folder)
                    imagehandler.close()
                    if os.path.isfile(inFile) and (os.path.exists(inFile)):
                        os.remove(inFile)
                    if os.path.isfile(resize_folder) and (os.path.exists(inFile)):
                        os.remove(resize_folder)
                    print('End   :  ' + str(datetime.datetime.now()))
                    print('*************************************\n')

                except Exception as e:

                    ############################################
                    ## Exception log
                    file = open(errFile, 'w')
                    file.write(str(e))
                    file.close()
                    print(e)
                    ############################################