import os
import requests
import pandas as pd

IP = '10.253.242.212'  # change accordingly
PORT = 8602  # port of ecrash engine server container.

# how to connect E-crash ML server 
def __json_to_dataframe(result_json):
    all_pg_list = []    
    for k,v in result_json.items():
        all_pg_list.extend(v)
    result_df = pd.DataFrame(all_pg_list)    
    column_order = ["filename", "label", "score", "xmin", "ymin", "xmax", "ymax", "img_width", "img_height"]
    result_df = result_df[column_order]
    return result_df

def __tiff_2_model(path_to_tiff,model_name):
    url = "http://{}:{}/predict".format(IP, PORT)  # https may not work
    session=requests.Session()
    session.trust_env=False
    with open(path_to_tiff, "rb") as f:
        tiff_obj = f.read()  # pdf is a byte obeject
    # the payload must have the following fields: "tiff": bytes object, "filename": string object
    # *******************************************************************************************
    payload = {"tiff": tiff_obj,"filename":os.path.basename(path_to_tiff), "model_name": model_name}
    # *******************************************************************************************

    result = session.post(url=url, files=payload).json()
    total_pages = str(len(result['data']))
    try:
        print('Process : Pages_' + total_pages)
    except KeyError:
        print(result['exception'])
    result_data = result['data']
    result_df = __json_to_dataframe(result_data)
    return result_df, total_pages

def model_invoker(tif_path, model_name):
    print('Process : Model Prediction')
    df, total_pages = __tiff_2_model(tif_path,model_name)
    return df, total_pages


