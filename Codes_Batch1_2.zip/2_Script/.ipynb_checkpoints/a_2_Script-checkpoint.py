import glob
import Model_2_CSV
import os
import shutil
import time
import datetime
import sys, traceback
import warnings
import pandas as pd
import requests
warnings.filterwarnings('ignore')
import psutil
os.umask(0x000)



input_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/In/"
output_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Out/"
temp_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Temp/"
log_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Log/"
error_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Final_Output/ERROR/Error_Script_2/"

current_platform = ''
if sys.platform == 'win32': current_platform = 'win'
if current_platform == 'win':
    input_path = r"E:\Samples\8_ECRASH\Texas\infolder/"
    output_path = r"E:\Samples\8_ECRASH\Texas\outfolder/"
    temp_path = r"E:\Samples\8_ECRASH\Texas\temp/"
    log_file_path = r"E:\Samples\8_ECRASH\Texas\log/"
    error_file_path = r"E:\Samples\8_ECRASH\Texas\error/"


state_dict ={'TX':'texas_model', 'PA':'pennsylvania_model', 'OH':'ohio_model', 'TN':'tennessee_model', 'WI':'wisconsin_model'}


url_error = "http://alawpctx329.noam.lnrm.net:8080/ecrash_api/public/api/update-failed-report"
def __error_response_in_json(tif_path):
    payload = {"fileName": os.path.basename(tif_path), "errorDesc":'invalid file received'}
    try:
        session=requests.Session()
        session.trust_env=False
        print('Process : sending error response to API')
        response = session.request("POST", url_error, data=payload)
        print(response.text)
    except Exception as e:
        print('Error : unable to send error_response to API')
        print(e)



if __name__ == "__main__":
    print("\nBucket 2 - Model 2 CSV Started!\n")
    while True:
        time.sleep(1)
        today = datetime.datetime.today()
        error_file_path_today = os.path.join(error_file_path, 'main_model', str(today.day) + '_' + str(today.month) + '_' + str(today.year))
        img_list = glob.glob(input_path + '*.tif')
        file_count = 1
        for img_path in img_list:
            file_log = ''
            try:
                start_time = str(datetime.datetime.now())
                file_state = os.path.splitext(os.path.basename(img_path))[0].split('_')[-1]

                if file_state not in state_dict:
                    file_count += 1
                    continue

                model_name = state_dict[file_state]


                print('*************************************')
                print('Process : Model 2 CSV')
                print('Process : ' + str(os.path.basename(img_path).split('.')[0]))
                print('Process : State - ' + file_state)
                print('Process : Start Time ' + start_time)

                file_log += 'Process : ' + str(os.path.basename(img_path).split('.')[0]) + '\n'

                if os.path.isfile(img_path) :
                    img_name = os.path.basename(img_path).split('.')[0]
                    new_img_path = os.path.join(temp_path, img_name)
                    if not os.path.exists(new_img_path):
                        oldmask=os.umask(0x000)
                        os.mkdir(new_img_path,0o777)
                        os.umask(oldmask)
                    shutil.copy(img_path, new_img_path)

                    TX_predicted_df = pd.DataFrame()
                    try:
                        TX_predicted_df, total_pages = Model_2_CSV.model_invoker(os.path.join(new_img_path, os.path.basename(img_path)),model_name)
                        file_log += "Process : Total Pages - " + str(total_pages) + '\n'
                    except:
                        print("Exception occured in Model_2_CSV.model_invoker")
                        file_log += "Process : Exception occured in Model_2_CSV.model_invoker\n"
                    if len(TX_predicted_df) >= 50:
                        TX_predicted_df.to_csv(os.path.join(output_path, str(os.path.basename(img_path).split('.')[0]) + '.csv'))
                        print('Process : CSV created')
                        if os.path.exists(img_path):
                            shutil.move(img_path, os.path.join(output_path, os.path.basename(img_path)))
                            print('Process : File moved to out folder')
                    else:
                        # =======================================
                        # Model not predicted, possibly non-crash forms
                        if not os.path.exists(error_file_path_today): os.makedirs(error_file_path_today)
                        f = open(error_file_path_today + '/' + str(os.path.basename(img_path).split('.')[0]) + '.err', "a")
                        f.write(str(today.time()) + ': Model not predicted fields in the image')
                        f.close()
                        shutil.move(img_path, os.path.join(error_file_path_today, os.path.basename(img_path)))
                        print('Error Message : Unable to predict fields')
                        __error_response_in_json(img_path)
                        file_log += 'Process : Model not predicted fields in the image\n'
                        # =======================================
                end_time = str(datetime.datetime.now())

                print('Process : End Time ' + end_time)


                file_log += 'Process : Start Time ' + str(start_time) + '\n'
                file_log += 'Process : End Time ' + str(end_time) + '\n'
                file_log += 'Process : Current Time ' + str(datetime.datetime.now()) + '\n'

                processx = psutil.Process(os.getpid())
                print('Memory consumption in GB :',(processx.memory_info().rss)/(1024**3))
                print('*************************************\n')
                file_count += 1

            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                print(str(traceback.format_tb(exc_traceback)))
                if not os.path.exists(error_file_path_today): os.makedirs(error_file_path_today)
                shutil.move(img_path, os.path.join(error_file_path_today, os.path.basename(img_path)))
                f = open(error_file_path_today + '/' + str(os.path.basename(img_path).split('.')[0]) + '.err',"a")
                f.write(str(traceback.format_tb(exc_traceback)))
                f.close()
                print('Error Message : ' + img_path)
                __error_response_in_json(img_path)
                file_log += str(traceback.format_tb(exc_traceback)) + '\n'

            save_log = log_file_path + str(today.day) + '_' + str(today.month) + '_' + str(today.year)
            if not os.path.exists(save_log):
                oldmask = os.umask(0x000)
                os.mkdir(save_log, 0o777)
                os.umask(oldmask)
            f = open(save_log + '/' + str(os.path.basename(img_path).split('.')[0]) + '.log', "a")
            f.write(str(file_log))
            f.close()