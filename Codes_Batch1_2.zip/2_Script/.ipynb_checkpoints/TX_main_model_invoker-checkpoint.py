import Model_2_Csv
import os
import requests
#url="http://alawpctx319.noam.lnrm.net:8080/ecrash_api/public/api/store-auto-extracted-data"
url = " "
def model_invoker(tif_path, model_name,file_info,csv_path):
    print('Model Prediction..')
    file_info.write('Model Prediction')
    df,flag=Model_2_Csv.tiff_detection(tif_path,model_name)
    print('flag is ',flag)
    if flag ==0:
        df.to_csv(csv_path+'.csv')
        print('csv is created ')
    elif flag==1:
        print('encountered non texas file')
        payload = {"fileName": os.path.basename(tif_path), "entryData":'invalid file received'}
        try:
            session=requests.Session()
            session.trust_env=False
            print('error response is being sent')
            response = session.request("POST", url, data=payload)
            print(response.text)
        except Exception as e:
            print('Error response is not sent')
            print(e)
