import glob
import TX_main_model_invoker
import os
import shutil
import time
import logging
import datetime
import warnings
warnings.filterwarnings('ignore')
from optparse import OptionParser
os.umask(0x000)
parser = OptionParser()

parser.add_option("-a", "--in_path", dest="input_path", help='Tif image folder path',
                  default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/In/")
parser.add_option("-b", "--out_path", dest="output_path", help='Output folder path',
                  default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Out/")
parser.add_option("-c", "--temp_path", dest="temp_path", help='Temporary folder path',
                  default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Temp/")
parser.add_option("-d", "--model_path", dest="model_path", help='ML model path',
                  default=r"/home/developer/texas_deployment/Field_Extraction_Model/frozen_inference_graph.pb")
parser.add_option("-e", "--label_map_path", dest="label_map_path", help='Label map path',
                  default=r"/home/developer/texas_deployment/Field_Extraction_Model/label_map.pbtxt")
parser.add_option("-f", "--log_file_path", dest="log_file_path", help='Log file path',
                  default=r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Log/")



(options, args) = parser.parse_args()
input_path = options.input_path
output_path = options.output_path
temp_path = options.temp_path
model_path = options.model_path
label_map_path = options.label_map_path
log_file_path = options.log_file_path

formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')


def setup_logger(name, log_file, level=logging.INFO):
     handler = logging.FileHandler(log_file)
     handler.setFormatter(formatter)
     logger = logging.getLogger(name)
     logger.setLevel(level)
     logger.addHandler(handler)
     return logger,handler
def remove_logger(logger,handler):
    logger.removeHandler(handler)
    del logger,handler

if __name__ == "__main__":
    while True:
        time.sleep(1)
        today = datetime.datetime.today()
        
        info_log_path =  os.path.join(log_file_path,'info_log', str(today.year), str(today.month), str(today.day) + '/')
        error_log_path =  os.path.join(log_file_path, 'error_log', str(today.year), str(today.month), str(today.day)+ '/')
        if not os.path.exists(info_log_path):
            oldmask=os.umask(0x000)
            os.makedirs(info_log_path,0o777)
            os.umask(oldmask)
        if not os.path.exists(error_log_path):
            oldmask=os.umask(0x000)
            os.makedirs(error_log_path,0o777)
            os.umask(oldmask)
        info_log_path =  (os.path.join(info_log_path, 'info_log.log'))
        error_log_path =  (os.path.join(error_log_path, 'error_log.log'))
        info_logger ,info_handler= setup_logger('info_logger', info_log_path)
        error_logger ,error_handler= setup_logger('error_logger', error_log_path)
        img_list = glob.glob(input_path + '*.tif')
        if len(img_list) > 0:
            print('Processing files get started..')
            file_count = 1
            for img_path in img_list:
                try:
                    start_time = time.time()
                    info_logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                    info_logger.info('Processing file: ' + str(os.path.basename(img_path).split('.')[0]))
                    print('Files processing: ' + str(file_count) + '/' + str(len(img_list)))
                    print('Processing file: ' + str(os.path.basename(img_path).split('.')[0]))
                    if os.path.isfile(img_path) :
                        img_name = os.path.basename(img_path).split('.')[0]
                        new_img_path = os.path.join(temp_path, img_name)
                        if not os.path.exists(new_img_path):
                            oldmask=os.umask(0x000)
                            os.mkdir(new_img_path,0o777)
                            os.umask(oldmask)
                        shutil.copy(img_path, new_img_path)
                        try:
                            TX_main_model_invoker.model_invoker(os.path.join(new_img_path, os.path.basename(img_path)),
                                 "texas_model",info_logger,os.path.join(output_path, str(os.path.basename(img_path).split('.')[0])))
                        except:
                            print(" Exception occured in TX_main_model_invoker.model_invoker")
                        if os.path.exists(img_path):
                            shutil.move(img_path, os.path.join(output_path, os.path.basename(img_path)))
                            print('File moved to output..')
                            info_logger.info('File moved to output')
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    info_logger.info('Elapsed Time: ' + str(elapsed_time))
                    info_logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

                    if not file_count == len(img_list):
                        print('Next file picking..')
                    file_count += 1
                    
                except Exception as e:
                        error_file_path = os.path.join(os.path.dirname(img_path), "Error")
                        if not os.path.exists(error_file_path):
                            os.makedirs(error_file_path)
                        shutil.move(img_path, os.path.join(error_file_path, os.path.basename(img_path)))
                        info_logger.error('Error Occurred: ' + str(os.path.basename(img_path).split('.')[0]))
                        info_logger.error('File moved to error folder: ' + os.path.join(error_file_path, os.path.basename(img_path)))
                        info_logger.error('Error Message: ' + str(e))
                        info_logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                        error_logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                        error_logger.info('Error Occurred: ' + str(os.path.basename(img_path).split('.')[0]))
                        error_logger.info('File moved to error folder: ' + os.path.join(error_file_path, os.path.basename(img_path)))
                        error_logger.error('Error Message: ' + str(e))
                        error_logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                remove_logger(info_logger,info_handler)
                remove_logger(error_logger,error_handler)
        else:
            pass
        
