import glob
import psutil
import os
import shutil
import time
import datetime
import sys, traceback
import requests

import ocr_fed
import pipe_model_invoker

os.umask(0x000)

state_dict ={'TX':'TEXAS','OH':'OHIO'}


input_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/3_pipe/In/"
temp_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/3_pipe/Temp/"
log_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/3_pipe/Log/"
error_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Final_Output/ERROR/Error_Script_3/"
ocr_inter_path = []
ocr_inter_path.append(r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_1/")
ocr_inter_path.append(r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_2/")
ocr_inter_path.append(r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_3/")
ocr_inter_path.append(r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_4/")
ocr_inter_path.append(r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_5/")



if sys.platform == 'win32':
    input_path = r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\in/"
    temp_path = r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\temp/"
    log_file_path = r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\log/"
    error_file_path = r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\error/"
    ocr_inter_path = []
    ocr_inter_path.append(r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\o1/")
    ocr_inter_path.append(r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\o2/")
    ocr_inter_path.append(r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\o3/")
    ocr_inter_path.append(r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\o4/")
    ocr_inter_path.append(r"E:\Samples\8_ECRASH\!PIPELINE\PIPE_REMOVAL\o5/")


url_error = "http://alawpctx329.noam.lnrm.net:8080/ecrash_api/public/api/update-failed-report"
def error_response_in_json(tif_path, file_log):
    payload = {"fileName": os.path.basename(tif_path), "errorDesc":'invalid file received'}
    try:
        session=requests.Session()
        session.trust_env=False
        print('Process : sending error response to API')
        response = session.request("POST", url_error, data=payload)
    except Exception as e:
        print('Error : unable to send error_response to API')
        print(e)
    today = datetime.datetime.today()
    error_file_path_today = os.path.join(error_file_path, 'pipe_model', str(today.day) + '_' + str(today.month) + '_' + str(today.year))
    if not os.path.exists(error_file_path_today): os.makedirs(error_file_path_today)
    f = open(error_file_path_today + '/' + str(os.path.basename(img_path).split('.')[0]) + '.err', "a")
    f.write(file_log)
    f.close()
    shutil.move(img_path, os.path.join(error_file_path_today, os.path.basename(img_path)))

def __save_log(file_log, img_path):
    today = datetime.datetime.today()
    save_log = log_file_path + str(today.day) + '_' + str(today.month) + '_' + str(today.year)
    if not os.path.exists(save_log):
        oldmask = os.umask(0x000)
        os.mkdir(save_log, 0o777)
        os.umask(oldmask)
    f = open(save_log + '/' + str(os.path.basename(img_path).split('.')[0]) + '.log', "a")
    f.write(str(file_log))
    f.close()

if __name__ == "__main__":
    print("\nBucket 3 - Deep Cleaning!\n")
    while True:
        time.sleep(5)
        img_list = glob.glob(input_path + '*.tif')


        for img_path in img_list:
            file_log = ''
            try:

                if os.path.isfile(img_path) :
                    start_time = str(datetime.datetime.now())
                    print('*************************************')
                    print("Process : OCR-Improvement")
                    print("Process : ", str(os.path.basename(img_path).split('.')[0]))
                    file_log += 'Process : ' + str(os.path.basename(img_path).split('.')[0]) + '\n'

                    ocr_path = ocr_fed.ocr_feed(ocr_inter_path)
                    file_state = os.path.splitext(os.path.basename(img_path))[0].split('_')[-1]
                    if file_state not in state_dict:
                        shutil.move(img_path, os.path.join(ocr_path, os.path.basename(img_path)))
                        print("Process : Move files to OCR")
                        print('*************************************\n')
                        file_log += "Process : Move files to OCR\n"
                        continue
                    #else:
                        #print("Type : TX or OH")
                        #continue

                    model_name = state_dict[file_state]
                    img_name = os.path.basename(img_path).split('.')[0]
                    new_img_path = os.path.join(temp_path, img_name)
                    if not os.path.exists(new_img_path):
                        oldmask = os.umask(0x000)
                        os.mkdir(new_img_path,0o777)
                        os.umask(oldmask)
                    shutil.copy(img_path, new_img_path)


                    try:
                        print("Process : Deep Cleaning" )
                        pipe_model_name = "pipe_model"
                        if model_name == 'TEXAS':
                            pipe_model_name = "pipe_model"
                        if model_name == 'OHIO':
                            pipe_model_name = "ohio_pipe_model"
                            
                        print("Process : " + model_name + " main process\n")
                        file_log += "Process : " + model_name + " main process\n"
                        predicted_pipes_df = pipe_model_invoker.model_invoker(os.path.join(new_img_path, os.path.basename(img_path)), pipe_model_name ,ocr_path)
                    except:
                        print("error occured during " + model_name + " pipe model invoke\n")
                        file_log += "error occured during " + model_name + " pipe model invoke\n"
                      
                        if model_name == 'OHIO':
                            shutil.move(img_path, os.path.join(ocr_path, os.path.basename(img_path)))
                            file_log += "Unable to predict pipe " + model_name + "\n"
                            print("Unable to predict pipe " + model_name + "\n")
                            __save_log(file_log, img_path)
                            continue
                        
                    if len(predicted_pipes_df) >= 50:
                        print(img_path)
                        os.remove(img_path)
                    else:
                        file_log += "Model not predicted fields in the image\n"
                        print('Error : Model not predicted fields in the image\n')
                        error_response_in_json(img_path, file_log)

                    end_time = str(datetime.datetime.now())
                    file_log += 'Process : Start Time ' + str(start_time) + '\n'
                    file_log += 'Process : End Time ' + str(end_time) + '\n'
                    file_log += 'Process : Current Time ' + str(datetime.datetime.now()) + '\n'

            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                file_log += "Error occured during main process\n"
                file_log += str(traceback.format_tb(exc_traceback)) + '\n'
                error_response_in_json(img_path, file_log)

            __save_log(file_log, img_path)
            processx = psutil.Process(os.getpid())
            print('Memory consumption in GB :',(processx.memory_info().rss)/(1024**3))
            print('*************************************\n')