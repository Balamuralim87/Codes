import os
import glob
import cv2
from tqdm import tqdm
import preproceesor
import shutil
import remove_pipes
import Model_2_Csv


def model_invoker(tif_path,model_name, clean_tif_folder,info_logger):
    out_jpg_dir = os.path.join(os.path.dirname(tif_path), "jpg")
    if not os.path.exists(out_jpg_dir):
        os.makedirs(out_jpg_dir)
    print('Converting TIF to JPG..')
    info_logger.info('Converting TIF to JPG')
    try:
        preproceesor.tiff_to_jpg(tif_path, out_jpg_dir)
    except:
        print('Exception in TX_pipe_model_invoker.preproceesor.tiff_to_jpg')
    print('pipe Model Prediction..')
    info_logger.info('pipe Model Prediction')
    try:
        predicted_pipes_df=Model_2_Csv.tiff_detection(tif_path,model_name)
    except:
        print(' Exception occured in TX_pipe_model_invoker.Model_2_Csv.tiff_detection')
    predicted_pipes_df.rename(columns={'label':'classes'},inplace=True)
    predicted_pipes_df['image_path'] = predicted_pipes_df['filename'].apply(lambda x: os.path.join(out_jpg_dir,x.split('.')[0]+'_'+x.split('_')[-1]+'.jpg'))
    predicted_pipes_df['x1']=predicted_pipes_df['xmin']*predicted_pipes_df['img_width']
    predicted_pipes_df['y1']=predicted_pipes_df['ymin']*predicted_pipes_df['img_height']
    predicted_pipes_df['x2']=predicted_pipes_df['xmax']*predicted_pipes_df['img_width']
    predicted_pipes_df['y2']=predicted_pipes_df['ymax']*predicted_pipes_df['img_height']
    try:
        remove_pipes.image_remove_pipes_pill(predicted_pipes_df, clean_tif_folder,os.path.basename(tif_path))
    except:
        print('Exception in TX_pipe_model_invoker.remove_pipes.image_remove_pipes_pill')
