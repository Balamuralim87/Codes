# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 16:31:01 2020

@author: 206011
"""


import os

def ocr_feed(inter_dir):
    ocr_fol_dict = dict.fromkeys([inter_dir[0],inter_dir[1],inter_dir[2],inter_dir[3],inter_dir[4]])
    for k,v in ocr_fol_dict.items():
        ocr_fol_dict[k] = len(os.listdir(k))
    ocr_fol_list = sorted(ocr_fol_dict.items(),key=lambda x:x[1])
    current_folder = ocr_fol_list[0][0]
    return(current_folder)