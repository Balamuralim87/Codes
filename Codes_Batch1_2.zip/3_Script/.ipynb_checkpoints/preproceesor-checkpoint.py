import os
import subprocess
import glob
import cv2

"""---------------------------- TIF TO JPG CONVERTION - STARTS ---------------------------------------"""

"""
Convert the given tiff image with multiple pages into individual jpg image.
Args:
tif_path: String
          Path of the input tif image.
out_jpg_dir: String
             Path where the output jpg images are saved.

Returns:
JPG images are created and saved in corresponding folder.
Nothing is returned to calling function.
"""
def tiff_to_jpg(tiff_path, out_jpg_dir):
    im=cv2.imreadmulti(tiff_path)
    no_of_frames=len(im[1])
    input_img = os.path.basename(tiff_path).split('.')[0]
    for i in range(no_of_frames):
        upd_i = i + 1
        im_name = input_img + "_" + str(upd_i) + ".jpg"
        im_name = os.path.join(out_jpg_dir, im_name)
        try:
            cv2.imwrite(im_name,im[1][i])
        except Exception as e:
            print(e)





