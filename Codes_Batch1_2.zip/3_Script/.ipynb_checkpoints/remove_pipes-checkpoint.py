import os
from tqdm import tqdm
from itertools import groupby
from PIL import Image, TiffImagePlugin, ImageDraw


def image_remove_pipes_pill(df, tiff_op_dir,tiff_name):
    img_list = df['image_path'].unique()
    n = len(img_list)
    pipe_removed_imgs_list = []
    for j in tqdm(range(n)):
        gt_df = df.sort_values(by='image_path')
        gt_df = gt_df[~gt_df.classes.str.contains("classes")]
        uniq_name = gt_df.image_path.unique()
        image_path = str(uniq_name[j])
        img = Image.open(image_path)
        df_grp = gt_df.groupby("image_path").get_group(str(uniq_name[j]))
        for i, row in df_grp.iterrows():
            coord = (row.x1, row.y1, row.x2, row.y2)
            pipe_removed_img = color_filling_pill(img, coord)
        pipe_removed_img_path = os.path.dirname(image_path) + "/" + (
        os.path.basename(image_path).split(".")[0]) + "_pipes_removed_annot.jpg"
        pipe_removed_img.save(pipe_removed_img_path, "JPEG")
        pipe_removed_imgs_list.append(pipe_removed_img_path)

    pipe_removed_img_list = [list(i) for j, i in
                             groupby(pipe_removed_imgs_list, lambda a: os.path.basename(a).partition('_')[0])]
    
    print(len(pipe_removed_img_list))
    jpg_to_tif(tiff_op_dir, pipe_removed_img_list,tiff_name)

def color_filling_pill(source_img, coord):
    xmin, ymin, xmax, ymax = coord
    start_point = (int(xmin), int(ymin))
    end_point = (int(xmax), int(ymax))
    draw =  ImageDraw.Draw(source_img)
    draw.rectangle((start_point, end_point), fill="white")
    return source_img

def jpg_to_tif(output_dir, grouped_img_list,tiff_name):
    for img_list in grouped_img_list:
        out_tiff_name = output_dir + '/' + tiff_name
        print('save loc' + out_tiff_name)
        with TiffImagePlugin.AppendingTiffWriter(out_tiff_name, True) as tf:
            for jpg_in in img_list:
                im = Image.open(jpg_in)
                im = im.convert("1")
                im.save(tf)
                tf.newFrame()
