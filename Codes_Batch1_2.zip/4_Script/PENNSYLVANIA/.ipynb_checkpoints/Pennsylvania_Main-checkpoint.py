import os
import sys
import pandas as pd
import PENNSYLVANIA.pennsylvania_text_extractor as PA_text_extractor
import PENNSYLVANIA.pennsylvania_json_convertor as PA_json_convertor

address_split_lookup_path = os.path.join(os.getcwd(), "PENNSYLVANIA", "city_list.txt")
business_name_lookup_path = os.path.join(os.getcwd(), "PENNSYLVANIA", "business_name.txt")
code_description_lookup_path = os.path.join(os.getcwd(), "PENNSYLVANIA", "PA_list.csv")

def Process(csv_file_path, temp_path, check_box_model):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    text_extracted_df = pd.DataFrame()
    tif_file_name = csv_file_path.split('.')[0]+'.tif'
    xml_path = os.path.join(temp_path, csv_file_name + '/')
    try:
        print("Process : PDF Content Extraction" )
        text_extracted_df, form_type = PA_text_extractor.content_extraction(predicted_df, xml_path, check_box_model, address_split_lookup_path, business_name_lookup_path, code_description_lookup_path, tif_file_name)
        if(form_type == 'invalid'):
            return 'invalid file received', 'invalid'
    except:
        print("Error : Error occurred during PDF Content Extraction")
        return sys.exc_info(),"error"



    try:
        print("Process : JSON Conversion")
        data, tif_name = PA_json_convertor.json_convert(text_extracted_df, form_type)
        return data, tif_name
    except:
        print("Error : Error occurred during JSON Conversion")
        return sys.exc_info(), "error"

