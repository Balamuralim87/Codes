# -*- coding: utf-8 -*-
"""
Created on Fri Oct  2 19:32:45 2020

@author: 206011
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 01:03:18 2020

@author: 206011
"""


from typing import List
import json
import re
import os
import pandas as pd
import numpy as np
import copy
from fuzzywuzzy import fuzz, process
page_df = None


class Safety_Equipment_Restraint(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Helmet(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
        
class Alcohol_Drug_Use(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description


class Driver_Actions_At_Time_Of_Crash(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
        
class Non_Motorist_Actions_At_Time_Of_Crash(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

        
class Contributing_Circumstances_Vehicle(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description


class Weather_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Road_Surface_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
           

class Violation_Code(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description



class Incident(object):
    def __init__(self, Report_Date: str, Crash_Date: str, Case_Identifier: str, State_Report_Number: str, Crash_City: str,
                 Loss_Street: str, Loss_Cross_Street: str, Latitude: str, Longitude: str, Loss_State_Abbr: str,
                 Report_Type_Id:str, Gps_Other:str, Fatality_Involved:str, Incident_Hit_and_Run:str, Dispatch_Time:str,
                 Weather_Condition: List[Weather_Condition], Road_Surface_Condition: List[Road_Surface_Condition], Loss_Cross_Street_Speed_Limit:str):
        self.Report_Date = Report_Date
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Fatality_Involved = Fatality_Involved
        self.Incident_Hit_and_Run = Incident_Hit_and_Run
        self.Dispatch_Time = Dispatch_Time
        self.Weather_Condition = Weather_Condition
        self.Road_Surface_Condition = Road_Surface_Condition
        self.Loss_Cross_Street_Speed_Limit = Loss_Cross_Street_Speed_Limit


class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: int, First_Name: str, Middle_Name: str, Last_Name: str,
                Name_Suffix: str, Address:str, Address2:str, City:str, State:str, Zip_Code: str, Home_Phone: str,
                Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str, Injury_Status:str,
                Safety_Equipment_Restraint:List[Safety_Equipment_Restraint], Safety_Equipment_Helmet:List[Safety_Equipment_Helmet],
                Ejection: str, Transported_To: str, Alcohol_Drug_Use:List[Alcohol_Drug_Use], 
                Driver_Actions_At_Time_Of_Crash: List[Driver_Actions_At_Time_Of_Crash],
                Non_Motorist_Actions_At_Time_Of_Crash: List[Non_Motorist_Actions_At_Time_Of_Crash]):
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        self.Safety_Equipment_Restraint = Safety_Equipment_Restraint
        self.Safety_Equipment_Helmet = Safety_Equipment_Helmet
        self.Ejection = Ejection
        self.Transported_To = Transported_To
        self.Alcohol_Drug_Use= Alcohol_Drug_Use
        self.Driver_Actions_At_Time_Of_Crash = Driver_Actions_At_Time_Of_Crash
        self.Non_Motorist_Actions_At_Time_Of_Crash = Non_Motorist_Actions_At_Time_Of_Crash
    
        

class Vehicles(object):
   def __init__(self, VinValidation_VinStatus: str, Unit_Number:str, Trailer_Unit_Number: str, License_Plate: str, Registration_State: str, VIN:str,
                Vehicle_Towed: str, Model_Year: str, Make: str, Model: str, Insurance_Company: str, Insurance_Policy_Number:str,
                Insurance_Expiration_Date: str,Damaged_Areas:str,Air_Bag_Deployed:str,
                Contributing_Circumstances_Vehicle:List[Contributing_Circumstances_Vehicle]):
       self.VinValidation_VinStatus = VinValidation_VinStatus
       self.Unit_Number = Unit_Number
       self.Trailer_Unit_Number=Trailer_Unit_Number
       self.License_Plate = License_Plate
       self.Registration_State = Registration_State
       self.VIN = VIN
       self.Vehicle_Towed= Vehicle_Towed
       self.Model_Year = Model_Year
       self.Make = Make
       self.Model= Model
       self.Insurance_Company = Insurance_Company
       self.Insurance_Policy_Number=Insurance_Policy_Number
       self.Insurance_Expiration_Date=Insurance_Expiration_Date
       self.Damaged_Areas=Damaged_Areas
       self.Air_Bag_Deployed=Air_Bag_Deployed
       self.Contributing_Circumstances_Vehicle=Contributing_Circumstances_Vehicle
      
 

class Citations(object):
    def __init__(self, Citation_Or_Violation: str, Citation_Detail: str, Violation_Code: List[Violation_Code], Citation_Issued: str, Party_Id: str, Unit_Number: str):
        self.Party_Id = Party_Id
        self.Unit_Number = Unit_Number
        self.Citation_Or_Violation = Citation_Or_Violation
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code
        self.Citation_Issued = Citation_Issued
        
       
class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations



def get_person_type(page_df):
    person_type = str(get_value_from_df(page_df,'person_type'))
    if(person_type == '1'):
        return('DRIVER')
    elif(person_type == '2'):
        return('NON-MOTORIST')
    elif(person_type == '3'):
        return('PASSENGER')
    else:
        return('')
    
    
def get_sex_type(sex_type):
    sex_type = str(sex_type)
    if(sex_type == '1'):
        return('Male')
    elif(sex_type == '2'):
        return('Female')
    elif(sex_type == '3'):
        return('Unknown')
    else:
        return('')
    


def get_check_value(chk):
    if(chk == 'Checked'):
        return('1')
    elif(chk == 'Unchecked'):
        return('0')
    else:
        return('')
   
def get_value_from_df(df,label_name):
    if len(df.loc[df['label'] == label_name]) > 0:
        value = df.loc[df['label'] == label_name]['text'].iloc[0]
        if str(value) != 'nan':
            return value
        else:
            return ''
    else:
        return ''
    
   
def change_value(value):
    value = str(value).upper()
    if(value == 'YES' or value.find('Y')!=-1 or value == '1'):
        retvalue = '1'
    elif(value == 'NO' or value.find('N')!=-1or value == '0'):
        retvalue = '0'
    else:
        retvalue = ''
    return retvalue


def change_abbr_value(value):
    value = str(value).upper()
    if(value == 'YES' or value.find('Y')!=-1):
        retvalue = 'Y'
    elif(value == 'NO' or value.find('N')!=-1):
        retvalue = 'N'
    else:
        retvalue = ''
    return retvalue

def format_date(value):
    text = str(value)
    date_list = []
    full_date = ''
    date = ''
    month = ''
    year = ''
    if (text != ''):
        text = re.sub('[^0-9]', '/', text)
        if (text.find('/') != -1):
            date_list = text.split('/')
        else:
            date_list = [text[:2], text[2:4], text[4:]]
    if (len(date_list) == 3):
        if (len(date_list[0]) == 4):
            year = date_list[0]
            if (len(date_list[1]) == 2 and int(date_list[1]) <= 12):
                month = date_list[1]
            else:
                date = date_list[1]
            if (date == ''):
                date = date_list[2]
            else:
                month = date_list[2]
        elif (len(date_list[0]) == 2 and int(date_list[0]) <= 12):
            month = date_list[0]
            if (len(date_list[1]) == 2):
                date = date_list[1]
            else:
                year = date_list[1]
            if (len(date_list[2]) == 4):
                year = date_list[2]
            else:
                date = date_list[2]
        elif (len(date_list[0]) == 2 and int(date_list[0]) > 12):
            date = date_list[0]
            if (len(date_list[1]) == 2):
                month = date_list[1]
            else:
                year = date_list[1]
            if (len(date_list[2]) == 4):
                year = date_list[2]
            else:
                month = date_list[2]
        full_date = month + '/' + date + '/' + year
    else:
        full_date = text
    return(full_date)

def format_time(value):
    value = str(value)
    value = re.sub('[^0-9:]+','',value)
    if(value.find(':') == -1 and len(value) == 4):
        value = value[:2]+':'+value[2:]
    elif(value.find(':') == -1 and len(value) == 3):
        value = '0'+value[:1] + ':' + value[1:]
    else:
        pass
    return(value)

def format_phone_no(value):
    value = str(value)
    value = re.sub('[^0-9]+','',value)
    if(len(value) == 10):
        value = value[:3]+'-'+value[3:6]+'-'+value[6:]
    return(value)

def assign_no(df):
    temp_df_sub = df.copy()
    temp_df_sub.sort_values(by=['ymin','xmin'], inplace=True)
    unique_labels = temp_df_sub['label'].unique().tolist()
    group_df_sub = temp_df_sub.groupby('label')
    group_df_sub['label'].size().sort_values(ascending=False, inplace=True)
    max_value = group_df_sub['label'].value_counts()
    max_count = max_value.mode().max()
    # max_count = max_mode.values.item()
    label_no_df = pd.DataFrame()
    check_df = pd.DataFrame()
    label_chk = []
    flag = 0
    for label in unique_labels:
        group = group_df_sub.get_group(label)
        if(group.shape[0] == max_count):
            count = 1
            if(flag == 0):
                check_df = group
                flag = 1
            for i, row in group.iterrows():
                group.at[i,'label'] = row.label+'_'+str(count)
                count = count+1
            label_no_df = label_no_df.append(group)
       
        elif(len(check_df)!=0):
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if(diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1,'label'] = row1.label+'_'+str(no)
            label_no_df = label_no_df.append(group)
        else:
            label_chk.append(label)
            
    for label in label_chk:
        group = group_df_sub.get_group(label)
        if(len(check_df)!=0):  
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if(diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1,'label'] = row1.label+'_'+str(no)
            label_no_df = label_no_df.append(group)
    df = label_no_df.sort_values(by=['ymin','xmin'])
    return df
    
def create_group(df):
    df['no'] = df['label'].apply(lambda x: x.split('_')[-1])  
    temp_df = df[df['text']!='']
    temp_df.dropna(inplace=True)
    df_dict = temp_df['no'].value_counts().to_dict()
    return df_dict

def incident_extraction(page_df, form_type):
    Lat = ''
    Long = ''
    if(form_type == 'form_type_1'):
        deg = u'\u00b0'
        Lat=str(get_value_from_df(page_df,'Latitude Degrees')+str(deg)+get_value_from_df(page_df,'Latitude Minutes')+':'+get_value_from_df(page_df,'Latitude Seconds')+'.'+get_value_from_df(page_df,'Latitude Decimal'))
        Long=str("-"+get_value_from_df(page_df,'Longitude Degrees')+str(deg)+get_value_from_df(page_df,'Longitude Minutes')+':'+get_value_from_df(page_df,'Longitude Seconds')+'.'+get_value_from_df(page_df,'Longitude Decimal'))
    else:
        Lat = get_value_from_df(page_df,'Latitude')
        Long = get_value_from_df(page_df,'Longitude')
        if(Long.find('-') == -1):
            Long = '-'+Long
        
    incident = Incident(Report_Date = '',
                        Crash_Date=format_date(get_value_from_df(page_df,'Crash Date')),
                        Case_Identifier=get_value_from_df(page_df,'Incident No'),
                        State_Report_Number='',
                        Crash_City=get_value_from_df(page_df,'Municipality'),
                        Loss_Street=get_value_from_df(page_df,'Principal Road Street Name')+' '+get_value_from_df(page_df,'Principal Road Street Ending'),
                        Loss_Cross_Street=get_value_from_df(page_df,'Intersecting Road Street Name')+' '+get_value_from_df(page_df,'Intersecting Road Street Ending'),
                        Latitude=Lat,
                        Longitude=Long,
                        Loss_State_Abbr='PA',
                        Report_Type_Id='A',
                        Gps_Other='',
                        Fatality_Involved='',
                        Incident_Hit_and_Run=(get_check_value(get_value_from_df(page_df,'Hit and Run'))).strip(),
                        Dispatch_Time=format_time(get_value_from_df(page_df,'Dispatch Time')),
                        Weather_Condition=[Weather_Condition(get_value_from_df(page_df,'Weather Conditions_code'),get_value_from_df(page_df,'Weather Conditions'))],
                        Road_Surface_Condition=[Road_Surface_Condition(get_value_from_df(page_df,'Road Surface Conditions_code'),get_value_from_df(page_df,'Road Surface Conditions'))],
                        Loss_Cross_Street_Speed_Limit = get_value_from_df(page_df,'Intersecting Road Speed Limit')
                        )
   
    return(incident)

def vehicle_detail_extraction(page_df,vehicle_list,unit_count,form_type):
    if(form_type == 'form_type_1'):
        Contrib_Circumstances_Vehicle = [Contributing_Circumstances_Vehicle(get_value_from_df(page_df, 'Possible Vehicle Failures_code'),
                                               get_value_from_df(page_df, 'Possible Vehicle Failures'))]
    else:
        Contrib_Circumstances_Vehicle = [Contributing_Circumstances_Vehicle(get_value_from_df(page_df, 'Possible Vehicle Failure 1_code'),
                                               get_value_from_df(page_df, 'Possible Vehicle Failure 1')), Contributing_Circumstances_Vehicle(get_value_from_df(page_df, 'Possible Vehicle Failure 2_code'),
                                               get_value_from_df(page_df, 'Possible Vehicle Failure 2'))]

    vehicle_info=Vehicles(VinValidation_VinStatus = '',
                      Unit_Number = unit_count,
                      Trailer_Unit_Number = '',
                      License_Plate = get_value_from_df(page_df,'Vehicle License Plate'),
                      Registration_State = get_value_from_df(page_df,'Vehicle Reg. State'),
                      VIN = get_value_from_df(page_df,'Vehicle VIN'),
                      Vehicle_Towed = change_value(get_value_from_df(page_df,'Vehicle Towed')),
                      Model_Year = get_value_from_df(page_df,'Vehicle Model Year'),
                      Make = get_value_from_df(page_df,'Vehicle Make'),
                      Model = get_value_from_df(page_df,'Vehicle Model'),
                      Insurance_Company = get_value_from_df(page_df,'Vehicle Insurance Company'),
                      Insurance_Policy_Number = get_value_from_df(page_df,'Vehicle Policy Number'),
                      Insurance_Expiration_Date = format_date(get_value_from_df(page_df,'Vehicle Expiration Date')),
                      Damaged_Areas = get_value_from_df(page_df,'Initial Impact Point'),
                      Air_Bag_Deployed ='',
                      Contributing_Circumstances_Vehicle = Contrib_Circumstances_Vehicle)
    vehicle_list.append(vehicle_info)
    return(vehicle_list)


def owner_extraction(page_df,people_list,person_no,unit_no,person_type):
    people_info = People(Party_Id=person_no,
                        Person_Type=person_type,
                        Unit_Number=unit_no,
                        First_Name=get_value_from_df(page_df,'Owner First Name'),           
                        Middle_Name=get_value_from_df(page_df,'Owner MI'),
                        Last_Name=get_value_from_df(page_df,'Owner Last Name'),
                        Name_Suffix=get_value_from_df(page_df,'Owner Suffix'),
                        Address=get_value_from_df(page_df,'Owner Street Address'),
                        Address2='',
                        City=get_value_from_df(page_df,'Owner City'),
                        State=get_value_from_df(page_df,'Owner State'),
                        Zip_Code=get_value_from_df(page_df,'Owner Zip Code'),
                        Home_Phone=format_phone_no(get_value_from_df(page_df,'Owner Telephone No')),
                        Date_Of_Birth='',
                        Drivers_License_Number= '',
                        Drivers_License_Jurisdiction='',
                        Injury_Status='',
                        Safety_Equipment_Restraint=[],
                        Safety_Equipment_Helmet=[],
                        Ejection='',
                        Transported_To='',
                        Alcohol_Drug_Use=[],
                        Driver_Actions_At_Time_Of_Crash=[],
                        Non_Motorist_Actions_At_Time_Of_Crash=[])
    people_list.append(people_info)
    return(people_list)


def ped_driver_extraction(page_df,people_list,person_no,unit_no,person_type,form_type,hit_run):
    if (form_type == 'form_type_1'):
        driver_action_crash = [Driver_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Driver Action_code'),get_value_from_df(page_df,'Driver Action'))]
    else:
        driver_action_crash = [Driver_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Driver Action 1_code'),get_value_from_df(page_df,'Driver Action 1')),
                                           Driver_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Driver Action 2_code'),get_value_from_df(page_df,'Driver Action 2')),
                                           Driver_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Driver Action 3_code'),get_value_from_df(page_df,'Driver Action 3')),
                                           Driver_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Driver Action 4_code'),get_value_from_df(page_df,'Driver Action 4'))]
    people_info = People(Party_Id=person_no,
                        Person_Type=person_type,
                        Unit_Number=unit_no,
                        First_Name=get_value_from_df(page_df,'Driver First Name'),
                        Middle_Name=get_value_from_df(page_df,'Driver MI'),
                        Last_Name=get_value_from_df(page_df,'Driver Last Name'),
                        Name_Suffix=get_value_from_df(page_df,'Driver Suffix'),
                        Address=get_value_from_df(page_df,'Driver Street Address'),
                        Address2='',
                        City=get_value_from_df(page_df,'Driver City'),
                        State=get_value_from_df(page_df,'Driver State'),
                        Zip_Code=get_value_from_df(page_df,'Driver Zip Code'),
                        Home_Phone=format_phone_no(get_value_from_df(page_df,'Driver Telephone No')),
                        Date_Of_Birth=format_date(get_value_from_df(page_df,'Driver DOB')),
                        Drivers_License_Number=get_value_from_df(page_df,'Driver License Number'),
                        Drivers_License_Jurisdiction=get_value_from_df(page_df,'Driver License State'),
                        Injury_Status='',
                        Safety_Equipment_Restraint=[],
                        Safety_Equipment_Helmet=[Safety_Equipment_Helmet(get_value_from_df(page_df,'Driver Helmet Type_code'),get_value_from_df(page_df,'Driver Helmet Type'))],
                        Ejection='',
                        Transported_To='',
                        Alcohol_Drug_Use=[Alcohol_Drug_Use(get_value_from_df(page_df,'Alcohol/Drugs Suspected_code'), get_value_from_df(page_df,'Alcohol/Drugs Suspected'))],
                        Driver_Actions_At_Time_Of_Crash = driver_action_crash,
                        Non_Motorist_Actions_At_Time_Of_Crash=[Non_Motorist_Actions_At_Time_Of_Crash(get_value_from_df(page_df,'Pedestrian Action_code'),get_value_from_df(page_df,'Pedestrian Action'))])

    text = get_value_from_df(page_df,'Driver Presence')
    if((text.upper() == 'HIT AND RUN' or text.upper() == 'DRIVER FLED SCENE') and (hit_run == '0' or hit_run == '')):
        hit_run = '1'
    people_list.append(people_info)
    return(people_list,hit_run)

def passenger_extraction(pass_df,people_list,driver_list,ped_list,veh_per_list,pass_count):
    pass_df['old_label']= pass_df['label']
    pass_df = assign_no(pass_df)
    # pass_df['no'] = pass_df['label'].apply(lambda x: x.split('_')[-1])
    # temp_pass_df = pass_df[pass_df['text']!='']
    # temp_pass_df.dropna(inplace=True)
    # pass_dict = temp_pass_df['no'].value_counts().to_dict()
    pass_dict = create_group(pass_df)
    if(len(pass_dict)>0):
        for i in range(1,len(pass_dict)+1):
            if(pass_dict.get(str(i)) != None and pass_dict.get(str(i))>10):              
                person_type = get_value_from_df(pass_df,'Person Type'+'_'+str(i))
                if(person_type.upper() == 'PASSENGER'):
                    pass_count = pass_count + 1
                    people_info = People(Party_Id=pass_count,
                                        Person_Type='PASSENGER',
                                        Unit_Number=get_value_from_df(pass_df,'People Unit No'+'_'+str(i)),  
                                        First_Name=get_value_from_df(pass_df,'First Name'+'_'+str(i)),           
                                        Middle_Name=get_value_from_df(pass_df,'MI'+'_'+str(i)),
                                        Last_Name=get_value_from_df(pass_df,'Last Name'+'_'+str(i)),
                                        Name_Suffix=get_value_from_df(pass_df,'Suffix'+'_'+str(i)),
                                        Address=get_value_from_df(pass_df,'Street Address'+'_'+str(i)),
                                        Address2='',
                                        City=get_value_from_df(pass_df,'City'+'_'+str(i)),
                                        State=get_value_from_df(pass_df,'State'+'_'+str(i)),
                                        Zip_Code=get_value_from_df(pass_df,'Zip Code'+'_'+str(i)),
                                        Home_Phone=format_phone_no(get_value_from_df(pass_df,'People Phone Number'+'_'+str(i))),
                                        Date_Of_Birth=format_date(get_value_from_df(pass_df,'DOB'+'_'+str(i))),
                                        Drivers_License_Number='',
                                        Drivers_License_Jurisdiction='',
                                        Injury_Status=get_value_from_df(pass_df,'Injury Severity'+'_'+str(i)),
                                        Safety_Equipment_Restraint=[Safety_Equipment_Restraint(get_value_from_df(pass_df,'Safety Equipment 1_code'+'_'+str(i)),get_value_from_df(pass_df,'Safety Equipment 1'+'_'+str(i)))],
                                        Safety_Equipment_Helmet=[],
                                        Ejection=get_value_from_df(pass_df,'Ejection_code'+'_'+str(i)),
                                        Transported_To=get_value_from_df(pass_df,'Medical Facility'+'_'+str(i)),
                                        Alcohol_Drug_Use=[],
                                        Driver_Actions_At_Time_Of_Crash=[],
                                        Non_Motorist_Actions_At_Time_Of_Crash=[])
                    people_list.append(people_info)
                elif(person_type.upper() == 'PEDESTRIAN' or person_type.upper() == 'PEDALCYCLIST' or person_type.upper() == 'NONMOTORIST'):
                    for j in range(len(ped_list)):
                        if(ped_list[j].Unit_Number == int(get_value_from_df(pass_df,'People Unit No'+'_'+str(i)))):
                            ped_list[j].Injury_Status = get_value_from_df(pass_df,'Injury Severity'+'_'+str(i))
                            ped_list[j].Safety_Equipment_Restraint = [Safety_Equipment_Restraint(get_value_from_df(pass_df,'Safety Equipment 1_code'+'_'+str(i)),get_value_from_df(pass_df,'Safety Equipment 1'+'_'+str(i)))]
                            ped_list[j].Safety_Equipment_Helmet = []
                            ped_list[j].Ejection = get_value_from_df(pass_df,'Ejection_code'+'_'+str(i))
                            ped_list[j].Transported_To = get_value_from_df(pass_df,'Medical Facility'+'_'+str(i))
                            
                elif(person_type.upper() == 'DRIVER'):
                    for j in range(len(driver_list)):                        
                        if(int(driver_list[j].Unit_Number) == int(get_value_from_df(pass_df,'People Unit No'+'_'+str(i)))):
                            driver_list[j].Injury_Status = get_value_from_df(pass_df,'Injury Severity'+'_'+str(i))
                            driver_list[j].Safety_Equipment_Restraint = [Safety_Equipment_Restraint(get_value_from_df(pass_df,'Safety Equipment 1_code'+'_'+str(i)),get_value_from_df(pass_df,'Safety Equipment 1'+'_'+str(i)))]
                            
                            driver_list[j].Ejection = get_value_from_df(pass_df,'Ejection_code'+'_'+str(i))
                            driver_list[j].Transported_To = get_value_from_df(pass_df,'Medical Facility'+'_'+str(i))
                            veh_per_list.append((driver_list[j].Unit_Number, get_value_from_df(pass_df,'Safety Equipment 2'+'_'+str(i))))
                else:
                    continue
        
        return(people_list,driver_list,ped_list,veh_per_list,pass_count)


def witness_extraction(witness_df,people_list, form_type,witness_count):
    if(form_type == 'form_type_1'):
        witness_df['old_label']= witness_df['label']
        witness_df = assign_no(witness_df)
    if(form_type == 'form_type_2'):
        witness_df['label'] = witness_df['label'].apply(lambda x: x[:-2]+'_'+x[-1] if x.find('Address')==-1 else x[:-3]+'_'+x[-1])  
    # witness_df['no'] = witness_df['label'].apply(lambda x: x.split('_')[-1])  
    # temp_wit_df = witness_df[witness_df['text']!='']
    # temp_wit_df.dropna(inplace=True)
    wit_dict = create_group(witness_df)
    if(len(wit_dict)>0):
        for i in range(1,len(wit_dict)+1):
            if(wit_dict.get(str(i)) != None and wit_dict.get(str(i))>5):  
                witness_count = witness_count+1
                people_info = People(Party_Id=witness_count,
                                    Person_Type='WITNESS',
                                    Unit_Number=' ',
                                    First_Name=get_value_from_df(witness_df,'Witness First Name'+'_'+str(i)),           
                                    Middle_Name=get_value_from_df(witness_df,'Witness MI'+'_'+str(i)),
                                    Last_Name=get_value_from_df(witness_df,'Witness Last Name'+'_'+str(i)),
                                    Name_Suffix=get_value_from_df(witness_df,'Witness Suffix'+'_'+str(i)),
                                    Address=get_value_from_df(witness_df,'Witness Street Address'+'_'+str(i)),
                                    Address2='',
                                    City=get_value_from_df(witness_df,'Witness City'+'_'+str(i)),
                                    State=get_value_from_df(witness_df,'Witness State'+'_'+str(i)),
                                    Zip_Code=get_value_from_df(witness_df,'Witness Zip Code'+'_'+str(i)),
                                    Home_Phone=format_phone_no(get_value_from_df(witness_df,'Witness Phone Number'+'_'+str(i))),
                                    Date_Of_Birth='',
                                    Drivers_License_Number='',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status='',
                                    Safety_Equipment_Restraint=[],
                                    Safety_Equipment_Helmet=[],
                                    Ejection='',
                                    Transported_To='',
                                    Alcohol_Drug_Use=[],
                                    Driver_Actions_At_Time_Of_Crash=[],
                                    Non_Motorist_Actions_At_Time_Of_Crash=[])
                people_list.append(people_info)
    return(people_list, witness_count)



def PD_extraction(PD_df,people_list, PD_driver_list, PD_owner_list, PD_vehicle_list, PD_count):
    PD_df['old_label']= PD_df['label']
    PD_df = assign_no(PD_df)
    PD_dict = create_group(PD_df)
    if(len(PD_dict)>0):
        for i in range(1,len(PD_dict)+1):
            if(PD_dict.get(str(i)) != None and PD_dict.get(str(i))>5):   
                PD_count = PD_count+1
                people_info = People(Party_Id=PD_count,
                                     Person_Type='DRIVER',
                                     Unit_Number=PD_count,
                                     First_Name='',
                                     Middle_Name='',
                                     Last_Name='',
                                     Name_Suffix='',
                                     Address='',
                                     Address2='',
                                     City='',
                                     State='',
                                     Zip_Code='',
                                     Home_Phone='',
                                     Date_Of_Birth='',
                                     Drivers_License_Number='',
                                     Drivers_License_Jurisdiction='',
                                     Injury_Status='',
                                     Safety_Equipment_Restraint=[],
                                     Safety_Equipment_Helmet=[],
                                     Ejection='',
                                     Transported_To='',
                                     Alcohol_Drug_Use=[],
                                     Driver_Actions_At_Time_Of_Crash=[],
                                     Non_Motorist_Actions_At_Time_Of_Crash=[])
                PD_driver_list.append(people_info)
                people_info = People(Party_Id=PD_count,
                                    Person_Type='VEHICLE OWNER',
                                    Unit_Number=PD_count,
                                    First_Name=get_value_from_df(PD_df,'PD Owners First Name'+'_'+str(i)),           
                                    Middle_Name=get_value_from_df(PD_df,'PD MI'+'_'+str(i)),
                                    Last_Name=get_value_from_df(PD_df,'PD Last Name'+'_'+str(i)),
                                    Name_Suffix=get_value_from_df(PD_df,'PD Suffix'+'_'+str(i)),
                                    Address=get_value_from_df(PD_df,'PD Street Address'+'_'+str(i)),
                                    Address2='',
                                    City=get_value_from_df(PD_df,'PD City'+'_'+str(i)),
                                    State=get_value_from_df(PD_df,'PD State'+'_'+str(i)),
                                    Zip_Code=get_value_from_df(PD_df,'PD Zip Code'+'_'+str(i)),
                                    Home_Phone=format_phone_no(get_value_from_df(PD_df,'PD Phone Number'+'_'+str(i))),
                                    Date_Of_Birth='',
                                    Drivers_License_Number='',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status='',
                                    Safety_Equipment_Restraint=[],
                                    Safety_Equipment_Helmet=[],
                                    Ejection='',
                                    Transported_To='',
                                    Alcohol_Drug_Use=[],
                                    Driver_Actions_At_Time_Of_Crash=[],
                                    Non_Motorist_Actions_At_Time_Of_Crash=[])
                PD_owner_list.append(people_info)
                people_info = People(Party_Id=PD_count,
                                     Person_Type='PROPERTY OWNER',
                                     Unit_Number=PD_count,
                                     First_Name='',
                                     Middle_Name='',
                                     Last_Name=get_value_from_df(PD_df,'PD Property Description'+'_'+str(i)),
                                     Name_Suffix='',
                                     Address='',
                                     Address2='',
                                     City='',
                                     State='',
                                     Zip_Code='',
                                     Home_Phone='',
                                     Date_Of_Birth='',
                                     Drivers_License_Number='',
                                     Drivers_License_Jurisdiction='',
                                     Injury_Status='',
                                     Safety_Equipment_Restraint=[],
                                     Safety_Equipment_Helmet=[],
                                     Ejection='',
                                     Transported_To='',
                                     Alcohol_Drug_Use=[],
                                     Driver_Actions_At_Time_Of_Crash=[],
                                     Non_Motorist_Actions_At_Time_Of_Crash=[])
                people_list.append(people_info)
                vehicle_info = Vehicles(VinValidation_VinStatus=PD_count,
                                        Unit_Number=PD_count,
                                        Trailer_Unit_Number='',
                                        License_Plate='',
                                        Registration_State='',
                                        VIN='',
                                        Vehicle_Towed='',
                                        Model_Year='',
                                        Make='',
                                        Model='',
                                        Insurance_Company='',
                                        Insurance_Policy_Number='',
                                        Insurance_Expiration_Date='',
                                        Damaged_Areas='',
                                        Air_Bag_Deployed='',
                                        Contributing_Circumstances_Vehicle=[])
                PD_vehicle_list.append(vehicle_info)
    return(people_list, PD_driver_list, PD_owner_list, PD_vehicle_list, PD_count)




def trailer_driver_extraction(trailer_df, trailer_driver_list, temp_driver_list, unit_count, trailer_count):
    if(len(temp_driver_list) != 0):
        for i in range(len(temp_driver_list)):
            if(temp_driver_list[i].Unit_Number == unit_count):
                temp = copy.deepcopy(temp_driver_list[i])
                trailer_driver_list.append(temp)  
                trailer_driver_list[-1].Party_Id = trailer_count
                trailer_driver_list[-1].Unit_Number = trailer_count
    return(trailer_driver_list)
   
def trailer_owner_extraction(trailer_df, trailer_owner_list, temp_owner_list, unit_count, trailer_count, form_type, trailer_no):
    if(form_type == 'form_type_1'):
        if(len(temp_owner_list) != 0):
            for i in range(len(temp_owner_list)):
                if(temp_owner_list[i].Unit_Number == unit_count):
                     if(get_value_from_df(trailer_df,'Trailer Owner Last Name'+' '+str(trailer_no)) != ''):
                         people_info = People(Party_Id=trailer_count,
                                    Person_Type="VEHICLE OWNER",
                                    Unit_Number=trailer_count,
                                    First_Name=get_value_from_df(trailer_df,'Trailer Owner First Name'+' '+str(trailer_no)),       
                                    Middle_Name=get_value_from_df(trailer_df,'Trailer Owner MI'+' '+str(trailer_no)),
                                    Last_Name=get_value_from_df(trailer_df,'Trailer Owner Last Name'+' '+str(trailer_no)),
                                    Name_Suffix=get_value_from_df(trailer_df,'Trailer Owner Suffix'+' '+str(trailer_no)),
                                    Address='',
                                    Address2='',
                                    City='',
                                    State='',
                                    Zip_Code='',
                                    Home_Phone='',
                                    Date_Of_Birth='',
                                    Drivers_License_Number= '',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status='',
                                    Safety_Equipment_Restraint=[],
                                    Safety_Equipment_Helmet=[],
                                    Ejection='',
                                    Transported_To='',
                                    Alcohol_Drug_Use=[],
                                    Driver_Actions_At_Time_Of_Crash=[],
                                    Non_Motorist_Actions_At_Time_Of_Crash=[])
                         trailer_owner_list.append(people_info)  
                     else:
                        temp = copy.deepcopy(temp_owner_list[i])
                        trailer_owner_list.append(temp)  
                        trailer_owner_list[-1].Party_Id = trailer_count
                        trailer_owner_list[-1].Unit_Number = trailer_count
    else:
        if(len(temp_owner_list) != 0):
            for i in range(len(temp_owner_list)):
                if(temp_owner_list[i].Unit_Number == unit_count):
                    temp = copy.deepcopy(temp_owner_list[i])
                    trailer_owner_list.append(temp)  
                    trailer_owner_list[-1].Party_Id = trailer_count
                    trailer_owner_list[-1].Unit_Number = trailer_count
    return(trailer_owner_list)


def trailer_detail_extraction(trailer_df, trailer_list, temp_driver_list, temp_owner_list, trailer_driver_list, trailer_owner_list, trailer_count, unit_count, form_type):
    if(form_type == 'form_type_1'):
        trailer_df['label'] = trailer_df['label'].apply(lambda x: x[:-2]+'_'+x[-1])
        trailer_dict = create_group(trailer_df)
        if(len(trailer_dict)>0):
            for i in range(1,len(trailer_dict)+1):
                if(trailer_dict.get(str(i)) != None and trailer_dict.get(str(i))>3):   
                    trailer_count = trailer_count+1
                    trailer_info=Vehicles(VinValidation_VinStatus = '',
                                          Unit_Number = trailer_count,
                                          Trailer_Unit_Number = unit_count,
                                          License_Plate = get_value_from_df(trailer_df,'Tag Number'+' '+str(i)),
                                          Registration_State = get_value_from_df(trailer_df,'Tag State'+' '+str(i)),
                                          VIN = '',
                                          Vehicle_Towed = '',
                                          Model_Year = get_value_from_df(trailer_df,'Tag Year'+' '+str(i)),
                                          Make = get_value_from_df(trailer_df,'Unit Make'+' '+str(i)),
                                          Model = '',
                                          Insurance_Company = '',
                                          Insurance_Policy_Number = '',
                                          Insurance_Expiration_Date = '',
                                          Damaged_Areas = '',
                                          Air_Bag_Deployed ='',
                                          Contributing_Circumstances_Vehicle = [])
                    trailer_list.append(trailer_info)
                    trailer_no = i
                    trailer_driver_list = trailer_driver_extraction(trailer_df, trailer_driver_list, temp_driver_list, unit_count, trailer_count)
                    trailer_owner_list = trailer_owner_extraction(trailer_df, trailer_owner_list, temp_owner_list, unit_count, trailer_count, form_type, trailer_no)
    elif(form_type == 'form_type_2'):
         temp_trailer_df = trailer_df[trailer_df['text']!='']
         temp_trailer_df.dropna(inplace=True)
         if(len(temp_trailer_df)>2):
             trailer_count = trailer_count+1
             trailer_info=Vehicles(VinValidation_VinStatus = '',
                                      Unit_Number = trailer_count,
                                      Trailer_Unit_Number = unit_count,
                                      License_Plate = get_value_from_df(trailer_df,'Trailer Tag Number'),
                                      Registration_State = get_value_from_df(trailer_df,'Trl Tag State'),
                                      VIN ='',
                                      Vehicle_Towed = '',
                                      Model_Year = get_value_from_df(trailer_df,'Trailer Tag Year'),
                                      Make = get_value_from_df(trailer_df,'Type Trailing Unit'),
                                      Model = '',
                                      Insurance_Company = '',
                                      Insurance_Policy_Number = '',
                                      Insurance_Expiration_Date = '',
                                      Damaged_Areas = '',
                                      Air_Bag_Deployed ='',
                                      Contributing_Circumstances_Vehicle = [])
             trailer_list.append(trailer_info)
             trailer_no = 1
             trailer_driver_list = trailer_driver_extraction(trailer_df, trailer_driver_list, temp_driver_list, unit_count, trailer_count)
             trailer_owner_list = trailer_owner_extraction(trailer_df, trailer_owner_list, temp_owner_list, unit_count, trailer_count, form_type, trailer_no)
                
    else:
        pass
    
    return(trailer_list, trailer_driver_list, trailer_owner_list, trailer_count)

def citation_extraction(cite_df,citation_list,person_count,unit_count):
    cite_df['no'] = cite_df['label'].apply(lambda x: x.split(' ')[-1])  
    temp_cite_df = cite_df[cite_df['text']!='']
    temp_cite_df.dropna(inplace=True)
    cite_dict = temp_cite_df['no'].value_counts().to_dict()
    if(len(cite_dict)>0):
        for i in range(1,len(cite_dict)+1):
            cite_info = Citations(Party_Id=person_count,
                                Unit_Number=unit_count,
                                Citation_Or_Violation = 'CITATION',
                                Citation_Detail=get_value_from_df(cite_df,'Violation'+' '+str(i)),
                                Violation_Code=[],
                                Citation_Issued=change_abbr_value(get_value_from_df(cite_df,'Person Charged'+' '+str(i))))
            if(cite_info.Citation_Detail.upper().find('NONE') != -1):
                cite_info.Citation_Detail = 'None'
                cite_info.Citation_Issued = ''
            else:
                temp1 = cite_info.Citation_Detail.split(' ')[-1]
                # temp2 = cite_info.Citation_Detail.split(' ')[-2]
                # temp_cite = re.search('((\s)([0-9a-zA-Z])(\s)?)$', cite_info.Citation_Detail, re.IGNORECASE)
                if(re.search('\d+', temp1) != None):
                    new_temp = temp1 + ' ' +' '.join(cite_info.Citation_Detail.split(' ')[:-1])
                    cite_info.Citation_Detail = new_temp
                # elif(re.search('\d+', temp2) != None):
                #     new_temp = temp2 + ' - ' +' '.join(cite_info.Citation_Detail.split(' ')[:-2])
                #     cite_info.Citation_Detail = new_temp
            if(cite_info.Citation_Issued != '' or cite_info.Citation_Detail != ''):
                citation_list.append(cite_info)
    return(citation_list) 


class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report
      
        
        
def json_convert(df, form_type):
    """
        This Function writes the annoations in a xml format compatible with label me toolself.
        Args:
        data frame: --datafrmae

        Returns:
        Json String: --str
        """
    
    global page_df
    veh_per_list = []
    people_list = []
    vehicle_list = []
    citation_list = []
    owner_list = []
    driver_list = []
    other_list = []
    trailer_list = []
    ped_list = []
    trailer_driver_list = []
    trailer_owner_list = []
    PD_list = []
    PD_driver_list = []
    PD_owner_list = []
    PD_vehicle_list = []
    incident = None  
    tmpdf = df
    unit_count = 0
    person_count =0
    pass_count = 0
    witness_count = 0
    PD_count = 0
    trailer_count = 0
    hit_run = '0'
    air_bag_dict = {'NONE USED NOT APPLICABLE': '', 'FRONT AIR BAG DEPLOYED FOR THIS SEAT': '1', 'SIDE AIR BAG DEPLOYED FOR THIS SEAT': '1',
                    'OTHER TYPE AIR BAG DEPLOYED': '1', 'MULTIPLE AIR BAGS DEPLOYED': '1', 'AIR BAG NOT DEPLOYED SWITCH ON': '0', 
                    'AIR BAG NOT DEPLOYED SWITCH OFF': '0', 'AIR BAG NOT DEPLOYED UNK SWITCH SETTING': '0','AIR BAG REMOVED (PRIOR TO CRASH)': '',
                    'UNKNOWN IF AIR BAG DEPLOYED': '', 'UNKNOWN': ''}
    impact_location_dict = {'12': 'FRONT', '1': 'RIGHT FRONT', '2': 'RIGHT SIDE', '3': 'RIGHT SIDE', '4': 'RIGHT SIDE', '5': 'RIGHT REAR', '6': 'REAR', 
                            '7': 'LEFT REAR', '8': 'LEFT SIDE', '9': 'LEFT SIDE', '10': 'LEFT SIDE', '11': 'LEFT FRONT'}
    person_req_label_list = ['Person No', 'First Name', 'Suffix', 'DOB', 'MI', 'Last Name', 'People Unit No', 'Street Address', 'State', 'City',
                    'Zip Code', 'People Phone Number', 'Gender', 'EMS Transport', 'Person Type', 'Medical Facility',
                    'EMS Agency', 'Injury Severity', 'Seat Position', 'Safety Equipment 1', 'Extrication', 'Safety Equipment 2',
                    'Ejection Path', 'Ejection', 'Safety Equipment 1_code', 'Ejection_code', 'Injury Severity_code']
    trailer_req_label_list_1 = ['Tag Number 1', 'Type Unit 1', 'Tag State 1', 'Unit Owner 1', 'Tag Year 1', 'Unit Make 1',
                                'Trailer Owner First Name 1', 'Trailer Owner MI 1', 'Trailer Owner Last Name 1', 'Trailer Owner Suffix 1',
                                'Trailer Owner First Name 2', 'Trailer Owner MI 2', 'Trailer Owner Last Name 2', 'Trailer Owner Suffix 2',
                                'Tag Number 2', 'Type Unit 2', 'Tag State 2', 'Unit Owner 2', 'Tag Year 2', 'Unit Make 2']
    trailer_req_label_list_2 = ['Trailing Units', 'Trl Tag State', 'Type Trailing Unit', 'Trailer Tag Number', 'Trailer Tag Year']
    
    try:
        inner_img_list = tmpdf['path'].unique().tolist()
        inner_group_df = tmpdf.groupby('path')
        for inner_img in inner_img_list:
            page_df = inner_group_df.get_group(inner_img)
            incident_page_labels = []
            vehicle_page_labels = []
            person_page_labels = []
            witness_page_labels = []
            pd_page_labels = []
            incident_page_labels = list(filter(lambda x: 'Road Surface Conditions' in x or 'School Zone Related' in x or 'Weather Conditions' in x or 'Crash Date' in x or 'Reviewer Name' in x or 'Investigator Name' in x, page_df.label))
            vehicle_page_labels = list(filter(lambda x: 'Vehicle VIN' in x or 'Vehicle Make' in x or 'Vehicle Type' in x or 'Vehicle Color' in x or 'Vehicle Towed' in x or 'Vehicle Model' in x or 'Vehicle Position' in x, page_df.label))
            person_page_labels = list(filter(lambda x: 'Ejection' in x or 'EMS Agency' in x or 'People Unit No' in x or 'People Phone Number' in x or 'Seat Position' in x, page_df.label))
            witness_page_labels = list(filter(lambda x: 'Witness First Name' in x or 'Witness MI' in x or 'Witness Last Name' in x or 'Witness State' in x or 'Witness City' in x or 'Witness Zip Code' in x, page_df.label))
            pd_page_labels = list(filter(lambda x: 'PD Owners First Name' in x or 'PD MI' in x or 'PD Last Name' in x or 'PD State' in x or 'PD City' in x or 'PD Zip Code' in x, page_df.label))
  
            if(len(incident_page_labels)>=3):
                print("Incident extraction in progress!!!!")
                incident = incident_extraction(page_df, form_type)    
            elif(len(vehicle_page_labels)>=3):
                unit_count = unit_count+1
                person_count = person_count+1 
                print("Vehicle detail extraction in progress!!!")
                type_unit = get_value_from_df(page_df,'Type Unit').upper()
                type_unit = re.sub('[^A-Z]','',type_unit)
                if(fuzz.ratio(type_unit, 'PEDESTRIAN') >= 90 or type_unit.find('PEDESTRIAN') != -1):
                    ped_list, hit_run = ped_driver_extraction(page_df,ped_list,person_count,unit_count,"PEDESTRIAN", form_type, hit_run)
                    # owner_list = owner_extraction(page_df, owner_list, person_count, unit_count, "VEHICLE OWNER")
                    # vehicle_list = vehicle_detail_extraction(page_df, vehicle_list, unit_count, form_type)
                elif (fuzz.ratio(type_unit, 'PEDALCYCLIST') >= 90 or type_unit.find('PEDALCYCLIST') != -1 ):
                    ped_list, hit_run = ped_driver_extraction(page_df, ped_list, person_count, unit_count, "PEDALCYCLIST",
                                                              form_type, hit_run)
                elif (fuzz.ratio(type_unit, 'NONMOTORIST') >= 90 or type_unit.find('NONMOTORIST') != -1):
                    ped_list, hit_run = ped_driver_extraction(page_df, ped_list, person_count, unit_count, "NONMOTORIST",
                                                              form_type, hit_run)
                else:
                    driver_list, hit_run = ped_driver_extraction(page_df,driver_list,person_count,unit_count,"DRIVER", form_type, hit_run)
                    owner_list = owner_extraction(page_df,owner_list,person_count,unit_count,"VEHICLE OWNER")
                    vehicle_list = vehicle_detail_extraction(page_df,vehicle_list,unit_count,form_type)
                if(form_type == 'form_type_1'):
                    trailer_df = page_df[page_df['label'].isin(trailer_req_label_list_1)]
                elif(form_type == 'form_type_2'):
                    trailer_df = page_df[page_df['label'].isin(trailer_req_label_list_2)]
                else:
                    pass
                if(len(trailer_df)!=0):
                    print("Trailer details extraction!!!")
                    trailer_df['new_index'] = np.arange(len(trailer_df))
                    trailer_df.set_index('new_index',inplace=True)
                    trailer_list, trailer_driver_list, trailer_owner_list, trailer_count = trailer_detail_extraction(trailer_df, trailer_list, driver_list, owner_list, trailer_driver_list, trailer_owner_list, trailer_count, unit_count, form_type)
                cite_df = page_df[page_df['label'].str.contains("Violation|Charged")]
                if(len(cite_df)!=0):
                    print("Citation details extraction!!!")
                    cite_df['new_index'] = np.arange(len(cite_df))
                    cite_df.set_index('new_index',inplace=True)
                    citation_list = citation_extraction(cite_df, citation_list, person_count,unit_count)
            elif(len(witness_page_labels)>=3 or len(pd_page_labels)>=3 or len(person_page_labels)>=3):
                pass_df = page_df[page_df['label'].isin(person_req_label_list)]
                if(len(pass_df)!=0):
                    print("Passenger extraction in progress!!!!")
                    pass_df['new_index'] = np.arange(len(pass_df))
                    pass_df.set_index('new_index', inplace=True)
                    other_list,driver_list,ped_list,veh_per_list,pass_count = passenger_extraction(pass_df,other_list,driver_list,ped_list,veh_per_list,pass_count)
                witness_df = page_df[page_df['label'].str.contains('Witness')]
                if(len(witness_df)!=0):
                    print("Witness extraction in progress!!!!")
                    witness_df['new_index'] = np.arange(len(witness_df))
                    witness_df.set_index('new_index', inplace=True)
                    other_list,witness_count = witness_extraction(witness_df,other_list, form_type,witness_count)
                PD_df = page_df[page_df['label'].str.contains('PD')]
                if(len(PD_df)!=0):
                    print("Non vehicle property extraction in progress!!!!")
                    PD_df['new_index'] = np.arange(len(PD_df))
                    PD_df.set_index('new_index', inplace=True)
                    PD_list, PD_driver_list, PD_owner_list, PD_vehicle_list,PD_count = PD_extraction(PD_df,PD_list,PD_driver_list, PD_owner_list, PD_vehicle_list, PD_count)
                else:
                    pass
        # Assign air bag information in people section to vehicle array
        # Get value for Damage areas from dictionary
        veh_count = len(vehicle_list)    
        for i in range(0, veh_count):
            imp_point =  vehicle_list[i].Damaged_Areas
            imp_point = re.sub('[^0-9]+', '', imp_point)
            if(imp_point != ''):
                match_imp_point_text = process.extractOne(imp_point, impact_location_dict.keys())[0]
                damage_area = impact_location_dict.get(match_imp_point_text)
                if(damage_area != None):
                     vehicle_list[i].Damaged_Areas = damage_area
            for j in range(len(veh_per_list)):
                if(vehicle_list[i].Unit_Number == veh_per_list[j][0]):
                    air_bag_orig = veh_per_list[j][1].upper()
                    air_bag_orig = air_bag_orig.replace('UNKNOWN', 'UNK')
                    air_bag_orig=re.sub(r'[^a-zA-Z\s]+','',air_bag_orig)
                    air_bag_orig=re.sub('\s+',' ',air_bag_orig)
                    if(air_bag_orig != ''):
                        match_air_bag_text = process.extractOne(air_bag_orig,air_bag_dict.keys())[0]
                        # print(match_air_bag_text)
                        air_bag = air_bag_dict.get(match_air_bag_text)
                        if(air_bag != None):
                            vehicle_list[i].Air_Bag_Deployed = air_bag
        # Incident hit and run changes based value in vehicle page
        if(incident.Incident_Hit_and_Run == '' and hit_run == '1'):
            incident.Incident_Hit_and_Run = '1'
        elif(incident.Incident_Hit_and_Run == '0'):
            incident.Incident_Hit_and_Run = ''
        else:
            pass
        # Copy driver information to owner if their name are same
        for i in range(len(owner_list)):
            for j in range(len(driver_list)):
                owner_name = owner_list[i].First_Name + ' ' + owner_list[i].Middle_Name + ' ' + owner_list[i].Last_Name + ' ' + owner_list[i].Name_Suffix
                driver_name = driver_list[j].First_Name + ' ' + driver_list[j].Middle_Name + ' ' + driver_list[j].Last_Name + ' ' + owner_list[i].Name_Suffix
                fuzzy_ratio = fuzz.ratio(owner_name, driver_name)
                if(fuzzy_ratio >= 90):
                    owner_list[i].Address = driver_list[i].Address
                    owner_list[i].Address2 = driver_list[i].Address2
                    owner_list[i].City = driver_list[i].City
                    owner_list[i].State = driver_list[i].State
                    owner_list[i].Zip_Code = driver_list[i].Zip_Code
                    owner_list[i].Home_Phone = driver_list[j].Home_Phone
                    owner_list[i].Date_Of_Birth = driver_list[j].Date_Of_Birth
                    owner_list[i].Drivers_License_Number = driver_list[j].Drivers_License_Number
                    owner_list[i].Drivers_License_Jurisdiction = driver_list[j].Drivers_License_Jurisdiction
                    owner_list[i].Injury_Status = driver_list[j].Injury_Status
                    owner_list[i].Safety_Equipment_Restraint = driver_list[j].Safety_Equipment_Restraint
                    owner_list[i].Safety_Equipment_Helmet = driver_list[j].Safety_Equipment_Helmet
                    owner_list[i].Ejection = driver_list[j].Ejection
                    owner_list[i].Transported_To = driver_list[j].Transported_To
                    owner_list[i].Alcohol_Drug_Use = driver_list[j].Alcohol_Drug_Use
                    owner_list[i].Driver_Actions_At_Time_Of_Crash = driver_list[j].Driver_Actions_At_Time_Of_Crash
                    owner_list[i].Non_Motorist_Actions_At_Time_Of_Crash = driver_list[j].Non_Motorist_Actions_At_Time_Of_Crash

       # Append all people list

        # Append trailer list
        Units = vehicle_list[-1].Unit_Number
        if(len(trailer_list) != 0):
            total_unit = Units
            for i in range(len(trailer_list)):
                total_unit = total_unit+1
                trailer_list[i].Party_Id = total_unit
                trailer_list[i].Unit_Number = total_unit
                trailer_driver_list[i].Party_Id = total_unit
                trailer_driver_list[i].Unit_Number = total_unit
                trailer_owner_list[i].Party_Id = total_unit
                trailer_owner_list[i].Unit_Number = total_unit
                vehicle_list.append(trailer_list[i])
                driver_list.append(trailer_driver_list[i])
                owner_list.append(trailer_owner_list[i])

        Units = vehicle_list[-1].Unit_Number
        if (len(PD_list) != 0):
            total_unit = Units
            for i in range(len(PD_list)):
                total_unit = total_unit + 1
                PD_list[i].Unit_Number = total_unit
                PD_driver_list[i].Party_Id = total_unit
                PD_driver_list[i].Unit_Number = total_unit
                PD_owner_list[i].Party_Id = total_unit
                PD_owner_list[i].Unit_Number = total_unit
                PD_vehicle_list[i].Party_Id = total_unit
                PD_vehicle_list[i].Unit_Number = total_unit
                other_list.append(PD_list[i])
                driver_list.append(PD_driver_list[i])
                owner_list.append(PD_owner_list[i])
                vehicle_list.append(PD_vehicle_list[i])

        if (len(driver_list) != 0):
            for i in range(len(driver_list)):
                people_list.append(driver_list[i])
        if (len(owner_list) != 0):
            for i in range(len(owner_list)):
                people_list.append(owner_list[i])
        if (len(ped_list) != 0):
            for i in range(len(ped_list)):
                people_list.append(ped_list[i])
        if (len(other_list) != 0):
            for i in range(len(other_list)):
                people_list.append(other_list[i])

        report = Report(FormName="Universal", CountKeyed=44, Incident=incident, People=people_list, Vehicles=vehicle_list, Citations=citation_list)
        main_cls = MainCls(Report=report)
        # Serializing
        data = json.dumps(main_cls, default=lambda o: o.__dict__, indent=4)
       
        img_name = os.path.basename(df.iloc[0]['path']).split('_')[0]
        tif_name = img_name + '.tif'
        return data, tif_name
    except Exception as e:
        print(e)

