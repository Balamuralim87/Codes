import os
import time
import cv2
import pandas as pd
import xml.etree.ElementTree as ET
import re
from fuzzywuzzy import fuzz, process
import PENNSYLVANIA.name_address_split as split_text
import PENNSYLVANIA.common_util as common_util
import PENNSYLVANIA.text_extract as text_extract
import PENNSYLVANIA.preproceesor as preproceesor
import PENNSYLVANIA.pennsylvania_rule_layer as PA_rule_layer
import PENNSYLVANIA.pennsylvania_description_to_code as description_to_code


def changeKey(text):
    text = re.sub(r'[^a-zA-Z\s]+','',text)
    text = re.sub(r'\b[a-zA-Z]\b','',text)
    text = re.sub('\s+',' ',text)
    return(text)

"""----------------------------- TEXT EXTRACTION - START --------------------------------"""


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
df: DataFrame 
    DataFrame containing the image name, label name(object) and their coordinates obtained after applying the developed model on the images.
csv_path: String
          Path where the output csv in the following format ('path','xmin','ymin','xmax','ymax','label','text') has to be created.
model_path: string
            Path where the model to identify whether the given checkbox is checked or unchecked.
Returns:
Extracted text for each predicted bounding box is calculated and saved in the csv file where the input image are present.
"""
def content_extraction(df, xml_out_path, model, address_split_lookup_path, business_name_lookup_path, code_description_lookup_path, tif_file_name):
    try:
        list_df = pd.read_csv(code_description_lookup_path)
        State = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['State'].values) if (type(x) == str)}
        loss_cross_speed_limit = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Loss Cross Speed Limit'].values) if (type(x) == str)}
        check_box_list_1 = ['DUI', 'N_A', 'Fatality', 'Work Zone', 'Hit and Run', 'ATV', 'Commercial Vehicle',
                            'Snowmobile', 'State Police Vehicle', 'Commonwealth Vehicle', 'Local Police Vehicle', 'Local Gov Vehicle',
                            'Lane Closure', 'Road Closed with Detour', 'Work on Shoulder Median', 'Intermittent or Moving Work',
                            'Flagger Control', 'Other']
        numeric_label_list = ['Investigator Badge', 'Reviewer Badge', 'No of Units', 'No of Killed', 'No of People', 'No of Injured','Principal Road Route No', 'Principal Road Segment No',
                          'Principal Road Travel Lanes', 'Principal Road House No',  'Intersecting Road Route No', 'Intersecting Road Travel Lanes', 'Intersecting Road Segment No', 'Intersecting Road House No',
                          'Feet', 'Landmark 1 Route Number', 'Landmark 1 Or Mile Post', 'Landmark 1 Tenths', 'Or Miles', 'Tenths', 'Landmark 2 Route Number', 'Landmark 2 Or Mile Post', 'Landmark 2 Tenths',
                          'Latitude Degrees', 'Latitude Minutes', 'Latitude Seconds', 'Latitude Decimal', 'Longitude Degrees', 'Longitude Minutes', 'Longitude Seconds', 'Longitude Decimal', 'First Harmful Event Unit No',
                          'Most Harmful Event Unit No', 'Prime Factor Unit No', 'Vehicle Unit No','Person Unit No', 'Person No']
        
        df.rename(columns={'label': 'classes'}, inplace=True)
        df['image_path'] = df['filename'].apply(lambda x: x.split('.')[0] + '_' + x.split('_')[-1] + '.jpg')
        df['x1'] = df['xmin'] * df['img_width']
        df['y1'] = df['ymin'] * df['img_height']
        df['x2'] = df['xmax'] * df['img_width']
        df['y2'] = df['ymax'] * df['img_height']
        
        data_list = []
        # model = load_model(model_path)
        img_list = df['image_path'].unique().tolist()
        img_list.sort() # 28 July 2020
        group_df = df.groupby('image_path')
        page_occur_count = 0
        temp_df = pd.DataFrame()
        form_type = preproceesor.form_type_detection(xml_out_path)
        if(form_type == 'invalid'):
            return temp_df, 'invalid'
        else:
            # ===============================
            # Checkbox model - TIF to JPG
            output_jpg_dir = os.path.join(xml_out_path ,'jpg')
            if not os.path.exists(output_jpg_dir):
                os.makedirs(output_jpg_dir)
            preproceesor.tiff_to_jpg(tif_file_name, output_jpg_dir)
            # ===============================
            for img in img_list:
                page_occur_count += 1
                temp_df = group_df.get_group(img)
                temp_df = temp_df.sort_values(by=['y1', 'x1'])
                # ==========================================
                # to execute output locally
                # xml_path = os.path.join(xml_out_path, os.path.basename(img).split('.')[0] + '.xml')
                # xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')

                # image = cv2.imread(img)
                # img_height = image.shape[0]
                # ==========================================
                # ==========================================
                # uncomment this for docker model output
                # img_height = df['img_height'][0]
                # xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
                # ==========================================

                # ==========================================
                # Temporary fix for OCR not generating page in pdf which page was actually present in tif file

                img_height = df['img_height'][0]
                xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
                xml_path = xml_path.replace('_PA', '_pa')
                if os.path.exists(xml_path) == False:
                    continue
                # =========================================
                xml_str = open(xml_path, 'r', encoding='utf-8').read()
                upd_xml_str = common_util.str_replace_xml(xml_str)
                xml_tree = ET.XML(upd_xml_str)
                page_list = xml_tree.findall('.//page')
                page_height = page_list[0].attrib['height']
                c = round(img_height / float(page_height), 2)
                hit_run_checked = 0
                image = cv2.imread(os.path.join(output_jpg_dir, img))
                narr_df=temp_df[temp_df['classes']=='narration']
                temp_df=temp_df[temp_df['classes']!='narration']
                if(len(narr_df)!=0):
                    narr_df.sort_values(by='score',inplace=True)
                    narr_df.drop_duplicates(subset=['image_path','classes'],keep='first',inplace=True)
                    temp_df = pd.concat([temp_df,narr_df],ignore_index=True)

                temp_df = PA_rule_layer.model_missed_data_extractor(temp_df, form_type, image)
                presence_df = temp_df[temp_df['classes'].str.contains('Driver Presence')]
                if((len(presence_df) == 1)):
                    bb_coord=( presence_df.iloc[0]['x1'], presence_df.iloc[0]['y1'], presence_df.iloc[0]['x2'], presence_df.iloc[0]['y2'])
                    add_list = text_extract.find_text(xml_tree,bb_coord,c)
                    text_list = [x[2] for x in add_list]
                    text=' '.join(text_list)
                    if(text.upper() == 'HIT AND RUN' or text.upper() == 'DRIVER FLED SCENE'):
                        hit_run_checked = 1
                check_box_df = pd.DataFrame()
                temptext_df = pd.DataFrame()
                if(form_type=='form_type_1'):
                    check_box_df = temp_df[temp_df['classes'].isin(check_box_list_1)]
                    temp_df = temp_df[~temp_df['classes'].isin(check_box_list_1)]
                    for i, row1 in check_box_df.iterrows():
                        text_list = []
                        bb_xmin = int(row1.x1)
                        bb_ymin = int(row1.y1)
                        bb_xmax = int(row1.x2)
                        bb_ymax = int(row1.y2)
                        text = common_util.detect_check_box(image,bb_xmin,bb_ymin,bb_xmax,bb_ymax,model)
                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))

                for i,row1 in temp_df.iterrows():
                    bb_xmin = int(row1.x1)
                    bb_ymin = int(row1.y1)
                    bb_xmax = int(row1.x2)
                    bb_ymax = int(row1.y2)
                    text_list = []
                    text=''
                    bb_coord=(bb_xmin,bb_ymin,bb_xmax,bb_ymax)
                    # print(row1.classes)
                    try:
                        if(form_type=='form_type_2' and row1.classes == 'Intersecting Road' ):
                            line_list = []
                            line_list = text_extract.find_line_text(xml_tree, bb_coord, c)
                            if(len(line_list)!=0):
                                text = ' '.join(line_list)
                            data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                        elif (form_type == 'form_type_2' and row1.classes == 'County/Municipality'):
                            line_list = text_extract.find_line_text(xml_tree, bb_coord, c)
                            if (len(line_list) != 0):
                                text = ' '.join(line_list)
                            if (text.find(r'/') != -1):
                                municipality = text.split('/')[-1]
                                county = text.split('/')[0]
                            else:
                                municipality = ' '.join(text.split(' ')[1:])
                                county = text.split(' ')[0]
                            county = common_util.cleaning(county)
                            municipality = common_util.cleaning(municipality)
                            data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'County', county))
                            data_list.append(
                                (row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Municipality', municipality))
                        if(form_type=='form_type_2' and (row1.classes == 'Driver Name/Address' or row1.classes == 'Name/Address' or row1.classes == 'Owner Name/Address/Phone')):
                            name_dict = {'first_name':'','middle_name':'','last_name':'','suffix':''}
                            add_dict = {'address':'','city':'','state':'','zipcode':'', 'phone_no': ''}
                            line_list = []
                            name_list = []
                            phone_no_list = []
                            line_list = text_extract.find_line_text(xml_tree, bb_coord, c)
                            if(len(line_list) != 0):
                                name = line_list[0]
                                name_text = name.split(' ')
                                if(len(name_text) > 0):
                                    for t in name_text:
                                        numbers = sum(c.isdigit() for c in t)
                                        if(numbers < 2):
                                            name_list.append(t)
                                        else:
                                            phone_no_list.append(t)
                                if (len(name_list) > 0):
                                    name = ' '.join(name_list)
                                    name = re.sub('[^a-zA-Z0-9&,\s]+', '', name)
                                    name = name.strip()
                                    if((name.upper() == 'UNKNOWN') and (row1.classes.find(['Driver', 'Owner']))and (hit_run_checked == 1)):
                                         name_dict.update({'last_name': 'HIT&RUN'})
                                    else:
                                        name_dict = split_text.name_split_using_pattern(name,business_name_lookup_path)
                                if(len(line_list) > 1):
                                    line_list.pop(0)
                                    for line in line_list:
                                        if(len(line.split(' '))==1):
                                            line_list.remove(line)
                                    # print(line_list)
                                    for line in line_list[0:]:
                                        text = text +' '+line
                                    if(text != ''):
                                        text = text.strip()


                                    # text = re.sub('[^a-zA-Z0-9@#$^&}{:><\s]+', '', text)
                                    if(name_dict.get('last_name') != ''):
                                        add_dict = split_text.name_address_split_using_lookup(text, address_split_lookup_path, False)
                                    else:
                                        add_dict = split_text.name_address_split_using_lookup(text,address_split_lookup_path,True)
                                        name = re.sub('[^a-zA-Z0-9&,\s]+', '', add_dict.get('names'))
                                        name = name.strip()
                                        name_dict = split_text.name_split_using_pattern(name, business_name_lookup_path)
                                    if(add_dict != None and len(text) > 0):
                                        add_items_after_split = ' '.join(list(add_dict.values())).split(' ')
                                        add_items_before_split = text.split(' ')
                                        unmatched_list = list(set(add_items_after_split).difference(add_items_before_split))
                                        unmatched_list_flat = [y for x in unmatched_list for y in x]
                                    # if(line_list[1]):
                                    #     add_dict.update({'address': line_list[1]})
                                    # if(len(line_list)> 1):
                                    #     loc_list = line_list[2].split(' ')
                                    #     add_dict.update({'city': loc_list[0]})
                                    #     add_dict.update({'state': loc_list[1]})
                                    #     add_dict.update({'zipcode': loc_list[2]})
                                    #     if(len(loc_list) > 3):
                                    #         phone_no = ''.join(loc_list[3:])
                                    #         add_dict.update({'phone_no': phone_no})

                                if(len(phone_no_list) > 0):
                                    phone_no = ''.join(phone_no_list)
                                    add_dict.update({'phone_no': phone_no})
                                elif(len(unmatched_list_flat) > 0):
                                    phone_no = ''.join(unmatched_list_flat)
                                    add_dict.update({'phone_no': phone_no})
                                else:
                                    pass

                                zipcode = add_dict.get('zipcode')
                                if(zipcode != None):
                                    zipcode = re.sub('[^0-9@#$^&}{:><\s]+', '', zipcode)
                                    add_dict.update({'zipcode': zipcode})
                                phone_no = add_dict.get('phone_no')
                                if(phone_no != None):
                                    phone_no = re.sub('[^0-9@#$^&}{:><\s]+', '', phone_no)
                                    add_dict.update({'phone_no': phone_no})
                                State = dict((changeKey(k), v) for k, v in State.items())
                                if(add_dict.get('state') != ''):
                                    match_state_text = process.extractOne(add_dict.get('state'), State.keys())[0]
                                    add_dict.update({'state': State.get(match_state_text)})
                            if (name_dict is not None):
                                class_prefix = row1.classes.split(' ')[0]
                                if (class_prefix in ['Driver', 'Owner']):
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      class_prefix + ' First Name',
                                                      name_dict.get('first_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      class_prefix + ' MI', name_dict.get('middle_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      class_prefix + ' Last Name',
                                                      name_dict.get('last_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      class_prefix + ' Suffix', name_dict.get('suffix')))
                                else:
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      'First Name', name_dict.get('first_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'MI',
                                                      name_dict.get('middle_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                                      'Last Name', name_dict.get('last_name')))
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Suffix',
                                                      name_dict.get('suffix')))

                            if(add_dict is not None):
                                class_prefix = row1.classes.split(' ')[0]
                                if(class_prefix in ['Driver', 'Owner']):
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,class_prefix+' Street Address',add_dict.get('address')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,class_prefix+' City',add_dict.get('city')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,class_prefix+' State',add_dict.get('state')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,class_prefix+' Zip Code',add_dict.get('zipcode')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,class_prefix+' Telephone No',add_dict.get('phone_no')))
                                else:
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Street Address',add_dict.get('address')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'City',add_dict.get('city')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'State',add_dict.get('state')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Zip Code',add_dict.get('zipcode')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'People Phone Number',add_dict.get('phone_no')))
                        elif(row1.classes.find('Violation')!=-1 or row1.classes.find('Action')!=-1 or row1.classes.find('Possible')!=-1):
                                 bb_coord=(bb_xmin,bb_ymin,bb_xmax,bb_ymax)
                                 line_list = text_extract.find_line_text(xml_tree, bb_coord, c)
                                 unwanted_text_list = []
                                 if(len(line_list)!=0):
                                     unwanted_text_list = line_list[0].split(' ')
                                     if(len(unwanted_text_list)>2):
                                         if(unwanted_text_list[0] == 'Driver' and unwanted_text_list[1] == 'Action'):
                                             unwanted_text_list.pop(0)
                                             unwanted_text_list.pop(1)
                                     if(len(unwanted_text_list)>= 1):
                                         line_list[0] = ' '.join(unwanted_text_list)
                                 if(len(line_list)!=0):
                                     text = ' '.join(line_list)
                                 data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                        elif(row1.classes == 'narration'):
                            add_list = text_extract.find_text(xml_tree,bb_coord,c)
                            if(len(add_list)>0):
                                text_list = [x[2] for x in add_list]
                                text=' '.join(text_list)
                            text = common_util.cleaning(text)
                            data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                        else:
                            add_list = text_extract.find_text(xml_tree,bb_coord,c)
                            add_list = sorted(add_list, key = lambda x: x[0])
                            if(len(add_list)>0):
                                text_list = [x[2] for x in add_list]
                                text=' '.join(text_list)
                            if(row1.classes == 'Incident No'):
                                text = re.sub('[^a-zA-Z0-9@#$^&}{:<>\s]+', '', text)
                                text = common_util.cleaning(text)
                                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                            elif(row1.classes in ['Crash Date', 'Vehicle Expiration Date', 'Driver DOB', 'DOB']):
                                text = text.replace('—', '-')
                                text = re.sub('[^0-9/-]+', '', text)

                                # if(text != ''):
                                #     date = text[:2]+'/'+text[2:4]+'/'+text[4:]
                                    # date = text
                                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                            elif(row1.classes in ['Principal Road Street Name', 'Intersecting Road Street Name', 'Principal Road Street Ending'
                                                  'Intersecting Road Street Ending']):
                                text = re.sub('[^a-zA-Z0-9@#$^&}{:<>\s]+', '', text)
                                text = common_util.cleaning(text)
                                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                            elif(row1.classes == 'Intersecting Road Speed Limit'):
                                loss_cross_speed_limit = dict((changeKey(k), v) for k, v in loss_cross_speed_limit.items())
                                text = str(text).upper()
                                if (text != '' and text != 'UNKNOWN'):
                                    # match_speed_text = process.extractOne(text, loss_cross_speed_limit.keys())[0]
                                    # text = loss_cross_speed_limit.get(match_speed_text)
                                    text = re.sub('[^0-9]+', '', text)
                                elif(text == 'UNKNOWN'):
                                    text = '99'
                                else:
                                    text = '90'
                                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                            elif(row1.classes in ['Driver License State', 'Vehicle Reg. State', 'Driver_State', 'Owner_State', 'State', 'PD_State', 'Witness_State',
                                                'Tag State 1', 'Tag State 2', 'Trl Tag State']):
                                State = dict((changeKey(k), v) for k, v in State.items())
                                if(text != ''):
                                    match_state_text = process.extractOne(text, State.keys())[0]
                                    text = State.get(match_state_text)
                                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                            elif(form_type=='form_type_2' and row1.classes == 'Latitude Longitude'):
                                latitude = ''
                                longitude = ''
                                text=re.sub('\s+',' ',text)
                                if(text.find('Longitude') != -1):
                                    latitude = text.split('Longitude')[0]
                                    longitude = text.split('Longitude')[-1]
                                else:
                                    text=re.sub(r'[^0-9\.\s]+', '', text)
                                    latitude = text.split(' ')[0]
                                    longitude = text.split(' ')[-1]
                                latitude = common_util.cleaning(latitude)
                                longitude = common_util.cleaning(longitude)
                                data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Latitude',latitude))
                                data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Longitude',longitude))
                            elif(form_type=='form_type_1' and row1.classes.find('Unit Owner') != -1):
                                trailer_no = row1.classes.split(' ')[-1]
                                name_dict = split_text.name_split_using_pattern(text, business_name_lookup_path)
                                if(name_dict is not None):
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Trailer Owner First Name'+' '+trailer_no,name_dict.get('first_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Trailer Owner MI'+' '+trailer_no,name_dict.get('middle_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Trailer Owner Last Name'+' '+trailer_no,name_dict.get('last_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Trailer Owner Suffix'+' '+trailer_no,name_dict.get('suffix')))
                            elif(form_type=='form_type_2' and row1.classes.find('Witness Name') != -1):
                                witness_no = row1.classes.split(' ')[-1]
                                name_dict = split_text.name_split_using_pattern(text, business_name_lookup_path)
                                if(name_dict is not None):
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness First Name'+' '+witness_no,name_dict.get('first_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness MI'+' '+witness_no,name_dict.get('middle_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness Last Name'+' '+witness_no,name_dict.get('last_name')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness Suffix'+' '+witness_no,name_dict.get('suffix')))
                            elif(form_type=='form_type_2' and row1.classes.find('Witness Address') != -1):
                                witness_no = row1.classes.split(' ')[-1]
                                add_dict = split_text.name_address_split_using_lookup(text, address_split_lookup_path, False)
                                State = dict((changeKey(k), v) for k, v in State.items())
                                if(add_dict.get('state') != ''):
                                    match_state_text = process.extractOne(add_dict.get('state'), State.keys())[0]
                                    add_dict.update({'state': State.get(match_state_text)})
                                if(add_dict is not None):
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness Street Address '+' '+witness_no,add_dict.get('address')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness City'+' '+witness_no,add_dict.get('city')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness State'+' '+witness_no,add_dict.get('state')))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,'Witness Zip Code'+' '+witness_no,add_dict.get('zipcode')))
                            elif(row1.classes in numeric_label_list):
                                text  = re.sub('[^0-9]+','', text)
                                text = common_util.cleaning(text)
                                data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                            else:
                                text = common_util.cleaning(text)
                                data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                            # print(text)
                            # print(type(text))
                    except Exception as e:
                        print(e)
                        text=''
                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
            temptext_df = pd.DataFrame(data_list,columns=['path','xmin','ymin','xmax','ymax','label','text'])
            temptext_df['label'] = temptext_df['label'].replace('Intersecting Road', 'Intersecting Road Street Name')
            temptext_df['label'] = temptext_df['label'].replace('Owner Last Name or Business Name', 'Owner Last Name')
            temptext_df['label'] = temptext_df['label'].replace('Vehicle Plate Number', 'Vehicle License Plate')
            temptext_df['label'] = temptext_df['label'].replace('Towed', 'Vehicle Towed')
            temptext_df['page_no'] = temptext_df['path'].apply(lambda x: 'page_no ' +os.path.basename(x).split('.')[0].split('_')[-1])
            temptext_df = temptext_df[['path','page_no','xmin','ymin','xmax','ymax','label','text']]
            tempcode_df = description_to_code.desc_code(temptext_df, code_description_lookup_path)
            # data = PA_json_convertor.json_convert(tempcode_df, r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\MODEL\WatchFolder\TextExtraction\result", form_type)
            # csv_name = os.path.join(r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\MODEL\WatchFolder\TextExtraction\result",img.split('.')[0]+'_'+form_type+'.csv')
            # tempcode_df.to_csv(csv_name,index=False)
            return tempcode_df, form_type
    except Exception as e:
        print(e)

"""----------------------------- TEXT EXTRACTION - END --------------------------------"""

