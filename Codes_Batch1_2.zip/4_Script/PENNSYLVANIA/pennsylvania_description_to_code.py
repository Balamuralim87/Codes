# -*- coding: utf-8 -*-
"""
Created on Mon Jul 27 20:16:01 2020

@author: 206011
"""
import os
import pandas as pd
import re
from fuzzywuzzy import process

# list_df = pd.read_csv(os.path.join(os.getcwd(),"PA_list.csv"))


def changeKey(text):
    text = re.sub(r'[^a-zA-Z\s]+','',text)
    text = re.sub(r'\b[a-zA-Z]\b','',text)
    text = re.sub('\s+',' ',text)
    return(text)




def desc_code(df, code_description_lookup_path):
    try:
        list_df = pd.read_csv(code_description_lookup_path)
        Weather_Condition =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Weather Conditions'].values) if (type(x) == str)}
        Roadway_Surface_Condition =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Road Surface Conditions'].values) if (type(x) == str)}
        Driver_Action =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Driver Actions'].values) if (type(x) == str)}
        Pedestrian_Action = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Pedestrian Actions'].values) if (type(x) == str)}
        Possible_Vehicle_Failure = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Possible Vehicle Failures'].values) if (type(x) == str)}
        Safety_Equipment = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Safety Equipment 1'].values) if (type(x) == str)}
        Injury_Status = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Injury Status'].values) if (type(x) == str)}
        Alcohol_Drug_Use = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Alcohol Drug Use'].values) if (type(x) == str)}
        Safety_Equipment_Helmet = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Safety Equipment Helmet'].values) if (type(x) == str)}
        Ejection = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Ejection'].values) if (type(x) == str)}

        label_list = ['Weather Conditions', 'Road Surface Conditions', 'Driver Action', 'Pedestrian Action', 'Possible Vehicle Failures', 'Safety Equipment 1',
                      'Possible Vehicle Failure 1', 'Possible Vehicle Failure 2', 'Driver Action 1', 'Driver Action 2', 'Driver Action 3', 'Driver Action 4',
                      'Ejection', 'Driver Helmet Type', 'Alcohol/Drugs Suspected', 'Injury Severity']
        
        Weather_Condition = dict((changeKey(k), v) for k, v in Weather_Condition.items())
        Roadway_Surface_Condition = dict((changeKey(k), v) for k, v in Roadway_Surface_Condition.items())
        Driver_Action = dict((changeKey(k), v) for k, v in Driver_Action.items())
        Pedestrian_Action = dict((changeKey(k), v) for k, v in Pedestrian_Action.items())
        Possible_Vehicle_Failure = dict((changeKey(k), v) for k, v in Possible_Vehicle_Failure.items())
        Safety_Equipment = dict((changeKey(k), v) for k, v in Safety_Equipment.items())
        Injury_Status = dict((changeKey(k), v) for k, v in Injury_Status.items())
        Alcohol_Drug_Use = dict((changeKey(k), v) for k, v in Alcohol_Drug_Use.items())
        Safety_Equipment_Helmet = dict((changeKey(k), v) for k, v in Safety_Equipment_Helmet.items())
        Ejection = dict((changeKey(k), v) for k, v in Ejection.items())


        
        code_list = []
        code_df = pd.DataFrame()
        for ind,row in df.iterrows():    
            temp_var = ''
            if(row.label in label_list and len(str(row.text)) != 0):
                # df.at[ind, 'text'] = row.text[0]
                if(str(row.text)[0].isdigit()):
                    code_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', row.text))
                else:
                    text = changeKey(str(row.text).strip(' ').upper())
                    if (row.label == 'Injury Severity'):
                        if (text != ''):
                            match_text = process.extractOne(text, Injury_Status.keys())[0]
                            temp_var = Injury_Status.get(match_text)
                    elif (row.label == 'Alcohol/Drugs Suspected'):
                        if (text != ''):
                            match_text = process.extractOne(text, Alcohol_Drug_Use.keys())[0]
                            temp_var = Alcohol_Drug_Use.get(match_text)
                    elif (row.label == 'Driver Helmet Type'):
                        if (text != ''):
                            match_text = process.extractOne(text, Safety_Equipment_Helmet.keys())[0]
                            temp_var = Safety_Equipment_Helmet.get(match_text)
                    elif (row.label == 'Ejection'):
                        if (text != ''):
                            match_text = process.extractOne(text, Ejection.keys())[0]
                            temp_var = Ejection.get(match_text)
                    elif(row.label == 'Weather Conditions'):
                        if (text != ''):
                            match_text = process.extractOne(text, Weather_Condition.keys())[0]
                            temp_var = Weather_Condition.get(match_text)
                    elif(row.label == 'Road Surface Conditions'):
                        if (text != ''):
                            match_text = process.extractOne(text, Roadway_Surface_Condition.keys())[0]
                            temp_var = Roadway_Surface_Condition.get(match_text)

                    elif(row.label == 'Driver Action'):
                        if (text != ''):
                            match_text = process.extractOne(text, Driver_Action.keys())[0]
                            temp_var = Driver_Action.get(match_text)

                    elif(row.label == 'Driver Action 1'):
                        if (text != ''):
                            match_text = process.extractOne(text, Driver_Action.keys())[0]
                            temp_var = Driver_Action.get(match_text)

                    elif(row.label == 'Driver Action 2'):
                        if (text != ''):
                            match_text = process.extractOne(text, Driver_Action.keys())[0]
                            temp_var = Driver_Action.get(match_text)

                    elif(row.label == 'Driver Action 3'):
                        if (text != ''):
                            match_text = process.extractOne(text, Driver_Action.keys())[0]
                            temp_var = Driver_Action.get(match_text)

                    elif(row.label == 'Driver Action 4'):
                        if (text != ''):
                            match_text = process.extractOne(text, Driver_Action.keys())[0]
                            temp_var = Driver_Action.get(match_text)

                    elif(row.label == 'Pedestrian Action'):
                        if (text != ''):
                            match_text = process.extractOne(text, Pedestrian_Action.keys())[0]
                            temp_var = Pedestrian_Action.get(match_text)

                    elif(row.label == 'Possible Vehicle Failures'):
                        if (text != ''):
                            match_text = process.extractOne(text, Possible_Vehicle_Failure.keys())[0]
                            temp_var = Possible_Vehicle_Failure.get(match_text)

                    elif(row.label == 'Possible Vehicle Failure 1'):
                        if (text != ''):
                            match_text = process.extractOne(text, Possible_Vehicle_Failure.keys())[0]
                            temp_var = Possible_Vehicle_Failure.get(match_text)

                    elif(row.label == 'Possible Vehicle Failure 2'):
                        if (text != ''):
                            match_text = process.extractOne(text, Possible_Vehicle_Failure.keys())[0]
                            temp_var = Possible_Vehicle_Failure.get(match_text)

                    elif(row.label == 'Safety Equipment 1'):
                        if (text != ''):
                            match_text = process.extractOne(text, Safety_Equipment.keys())[0]
                            temp_var = Safety_Equipment.get(match_text)
                    else:
                        pass
                    if(temp_var == None):
                        # df.at[ind, 'text'] = ''
                        code_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', ''))
                    else:
                        code_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', temp_var))
               
        code_df = pd.DataFrame(code_list,columns=['path','page_no','xmin','ymin','xmax','ymax','label','text'])   
        df = df.append(code_df)
        df.sort_values(by=['page_no','ymin','xmin'],inplace=True)
    except Exception as e:
        print(e)    
    return(df)


if __name__ == '__main__':
    df = pd.read_csv(r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\OUT3\CSV\287857297_final.csv")   
    df  = desc_code(df)
    df.to_csv(r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\OUT3\CSV\287857297_final.csv")