# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 00:44:58 2020

@author: 206011
"""

import os
import pandas as pd
import re
import common_util


# city_lookup_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\MODEL\PA_city.csv"
# business_name_lookup_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\MODEL\Business_Name.csv"
        
"""
This Function using lookup of city and state, splits name and address into "names, address, city, state, zipcode".

Args:
address_text: string
              Name address text / address text to split.
city_lookup_path: string 
                  The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_lookup(address_text, city_lookup_path, is_text_has_name=False):
    # print(address_text)
    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': '', 'phone_no': ''}
    state_list = ['AK','AL','AR','AZ','BC','CA','CO','CT','DC','DE','FL','GA','GU','HI','IA','ID','IL','IN','KS','KY','LA','MA',
                  'MD','ME','MI','MN','MO','MS','MT','NB','NC','ND','NE','NH','NJ','NM','NS','NV','NY','OH','OK','ON','OR','PA',
                  'PE','PQ','PR','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY','Alaska','Alabama','Arkansas',
                  'Arizona','British Columbia','California','Colorado','Connecticut','Dist.Of Columbia','Delaware','Florida',
                  'Georgia','Guam','Hawaii','Iowa','Idaho','Illinois','Indiana','Kansas','Kentucky','Louisiana','Massachusetts',
                  'Maryland','Maine','Michigan','Minnesota','Missouri','Mississippi','Montana','New Brunswick','North Carolina',
                  'North Dakota','Nebraska','New Hampshire','New Jersey','New Mexico','Nova Scotia','Nevada','New York',                  'Ohio',
                  'Oklahoma','Ontario','Oregon','Pennsylvania','Prince Edward','Quebec','Puerto Rico','Rhode Island',
                  'South Carolina','South Dakota','Tennessee','Texas','Utah','Virginia','Vermont','Washington','Wisconsin',
                  'West Virginia','Wyoming']

    city = ''
    state = ''
    zipcode = ''
    names = ''
    phone_no = ''

    with open(city_lookup_path) as f:
        city_lookup = f.readlines()
        city_lookup = [x.strip() for x in city_lookup]
    states = '|'.join(state_list)
    cities = '|'.join(city_lookup)
    cities = cities.replace(' ', '\s')

    if is_text_has_name:
        name_match = re.search('^(([A-Za-z\,?\s&-\.\/]+)(\,|\s))', address_text)
        if name_match:
            names = name_match.group(2)
            address_text = address_text.replace(name_match.group(1), '')

    phone_no_match = re.search('((\([0-9]+\)\s)([0-9]+(\-))[0-9]+)$', address_text, re.IGNORECASE)
    if phone_no_match:
        phone_no = phone_no_match.group(1)
        address_text = address_text.replace(phone_no_match.group(1), '')

    zipcode_match = re.search('((\s|,)([0-9]{5,})(\s|,\-)?)$', address_text, re.IGNORECASE)
    if zipcode_match:
        zipcode = zipcode_match.group(3)
        address_text = address_text.replace(zipcode_match.group(1), '')

    state_match = re.search('((\s|,)(' + states + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if state_match:
        state = state_match.group(3)
        address_text = address_text.replace(state_match.group(1), '')

    city_match = re.search('((\s|,|\\b)(' + cities + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if city_match:
        city = city_match.group(3)
        address_text = address_text.replace(city_match.group(1), '')

    address = address_text
    address = address.strip(', ')

    add_dict.update({'names': names})
    add_dict.update({'address': address})
    add_dict.update({'city': city})
    add_dict.update({'state': state})
    add_dict.update({'zipcode': zipcode})
    add_dict.update({'phone_no': phone_no})

    return add_dict

"""
This Function using patterns, splits name and address into "names, address, city, state, zipcode".

Args:
address_text:       string
                    Name address text / address text to split.
                    
city_lookup_path:   string 
                    The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_pattern(address_text):
    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': '', 'phone_no': ''}
    # name_address_match = re.search("^([A-Za-z0-9\,?\s&-\.\/]+)(\,?\s(([0-9]{2,}\s([A-Za-z0-9#\s]+))\,?\s([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9]{5}))?)$", address_text)
    name_address_match = re.search("^([A-Za-z\,?\s&-\.\/]+)(\,?\s(([0-9\s]{2,}\s([A-Za-z0-9#\s]+))\,?\s([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9\s]{5,10}))?)$",
        address_text)
    address_match = re.search(
        "^((([0-9]{2,}\s([A-Za-z0-9#\s]+))(\,|\s)([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9]{5}))?)$", address_text)
    address_match = re.search(
        "^([A-Za-z\,?\s&-\.\/]+)(\,?\s(([0-9\s]{2,}\s([A-Za-z0-9#\s]+))\,?\s([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))\s((\(([0-9\s]{3})\)\s)?([0-9]+\-[0-9]+))\s([0-9]{5}))$", address_text)
    
    if name_address_match:
        name = name_address_match.group(1)
        name = name.strip(',')
        add_dict.update({'name': name})
        add_dict.update({'address': name_address_match.group(4)})
        add_dict.update({'city': name_address_match.group(6)})
        add_dict.update({'state': name_address_match.group(7)})
        add_dict.update({'zipcode': name_address_match.group(9)})
        add_dict.update({'phone_no': name_address_match.group(9)})
        return add_dict
    elif address_match:
        add_dict.update({'address': address_match.group(3)})
        add_dict.update({'city': address_match.group(6)})
        add_dict.update({'state': address_match.group(7)})
        add_dict.update({'zipcode': address_match.group(9)})
        add_dict.update({'phone_no': name_address_match.group(9)})
        return (add_dict)
    else:
        return None


def name_split_using_pattern(name_text, business_name_lookup_path, name_order='', ischecked = False):
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}

    # =====================================
    # Business name - logic
    if ischecked == True:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict
    
    with open(business_name_lookup_path) as f:
        business_name_lookup = f.readlines()
        business_name_lookup = [x.strip() for x in business_name_lookup]
    business_names = '|'.join(business_name_lookup)
    # business_names = business_names.replace(' ', '\s')
    # business_name_match = re.search('\\b(Holdings|LLC|INC|CORP|COMPANY|ENVIROMENTAL|HYUNDAI|TRANSPORTATION|GROUP|CO|INCORPORATED)\\b',name_text, re.IGNORECASE)

    input_words = name_text.split()
    for word in input_words:
        business_name_match =  re.search('(\\b(' + business_names + ')\\b)', word, re.IGNORECASE)
        if business_name_match:
            add_dict.update({'last_name': name_text.upper()})
            add_dict.update({'name': name_text.upper()})
            return add_dict
    # =====================================

    suffix_list = ['JR', 'BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC', 'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                   'ESQ', 'II', 'III', 'IV', 'INC', 'JD', 'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                   'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM', 'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                   'USCG', 'USMC', 'USMCR']
    suffix_found = ''
    
    for suffix in suffix_list:
        suffix_match = re.search('\s' + suffix, name_text, re.IGNORECASE)
        if suffix_match:
            suffix_found = suffix_match.group(0).strip()
            name_text = re.sub(suffix_match.group(0), '', name_text, re.IGNORECASE)
            break

    name_match_1 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi
    name_match_2 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi Vaithinaden
    name_match_3 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi Vaithinaden Vaithi
    name_match_4 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi Vaithinaden
    name_match_5 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi, Vaithinaden
    name_match_6 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+\s+[A-Za-z]+))$", name_text)
    name_match_7 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga Jaanagi, Vaithinaden
    name_match_8 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi
    name_match_9 = re.search("^(([A-Za-z]+),\s*([A-Za-z]+)\s+([A-Z]\s?\.\s?[A-Za-z]+))$", name_text)  # Solis, Jose M.Morales
    name_match_10 = re.search("^(([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{1}))$", name_text)  # SLub Rodrigueza Torres A
    name_match_11 = re.search("^(([A-Za-z]{3,}\s*-\s*[A-Za-z]{3,})\s+([A-Za-z]{3,}))$", name_text)  # Galeana-Garica Gabriela
    name_match_12 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Van Lue, Tyler A
    name_match_13 = re.search("^(([A-Za-z]+)\s*\,\s*([A-Za-z]+\s+[A-Za-z]+)\s*\,\s*([A-Za-z]+))$", name_text)  # RAMIREZ, J OANN, MARIE
    name_match_14 = re.search("^(([A-Za-z]+)\,\s+([A-Za-z]+)\,)$",name_text)
    name_match_15 = re.search("^(([A-Za-z]+)\s([A-Za-z]+)(\s?\;\s?[A-Z]{2})?)$",name_text)
    name_match_16 = re.search("^(([A-Za-z]+)\s([A-Za-z]+)\s([A-Za-z]+)(\s?\;\s?[A-Z]{2})?)$",name_text)
    
    if name_match_1:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_1, add_dict)
        else:
            add_dict.update({'first_name': name_match_1.group(2).upper()})
            add_dict.update({'last_name': name_match_1.group(3).upper()})
    elif name_match_2:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_2, add_dict)
        else:
            add_dict.update({'first_name': name_match_2.group(2).upper()})
            add_dict.update({'middle_name': name_match_2.group(3).upper()})
            add_dict.update({'last_name': name_match_2.group(4).upper()})
    elif name_match_10:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_10, add_dict)
        else:
            add_dict.update({'first_name': name_match_10.group(2).upper()})
            add_dict.update({'middle_name': name_match_10.group(3).upper() + ' ' + name_match_10.group(5).upper()})
            add_dict.update({'last_name': name_match_10.group(4).upper()})
    elif name_match_3:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_3, add_dict)
        else:
            add_dict.update({'first_name': name_match_3.group(2).upper()})
            add_dict.update({'middle_name': name_match_3.group(3).upper()})
            add_dict.update({'last_name': name_match_3.group(4).upper() + ' ' + name_match_3.group(5).upper()})
    elif name_match_4:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_4, add_dict)
        else:
            add_dict.update({'first_name': name_match_4.group(3).upper()})
            add_dict.update({'middle_name': name_match_4.group(4).upper()})
            add_dict.update({'last_name': name_match_4.group(2).upper()})
    elif name_match_5:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_5, add_dict)
        else:
            add_dict.update({'first_name': name_match_5.group(2).upper()})
            add_dict.update({'middle_name': name_match_5.group(3).upper()})
            add_dict.update({'last_name': name_match_5.group(4).upper()})
    elif name_match_6:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_6, add_dict)
        else:
            add_dict.update({'first_name': name_match_6.group(3).upper()})
            add_dict.update({'middle_name': name_match_6.group(4).upper()})
            add_dict.update({'last_name': name_match_6.group(2).upper()})
    elif name_match_7:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_7, add_dict)
        else:
            add_dict.update({'first_name': name_match_7.group(3).upper()})
            add_dict.update({'last_name': name_match_7.group(2).upper()})
    elif name_match_8:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_8, add_dict)
        else:
            add_dict.update({'first_name': name_match_8.group(3).upper()})
            add_dict.update({'last_name': name_match_8.group(2).upper()})
    elif name_match_9:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_9, add_dict)
        else:
            add_dict.update({'first_name': name_match_9.group(3).upper()})
            add_dict.update({'middle_name': name_match_9.group(4).upper()})
            add_dict.update({'last_name': name_match_9.group(2).upper()})
    elif name_match_11:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_11, add_dict)
        else:
            add_dict.update({'first_name': name_match_11.group(3).upper()})
            add_dict.update({'last_name': name_match_11.group(2).upper()})
    elif name_match_12:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_12, add_dict)
        else:
            add_dict.update({'first_name': name_match_12.group(3).upper()})
            add_dict.update({'middle_name': name_match_12.group(4).upper()})
            add_dict.update({'last_name': name_match_12.group(2).upper()})
    elif name_match_13:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_13, add_dict)
        else:
            add_dict.update({'first_name': name_match_13.group(2).upper()})
            add_dict.update({'middle_name': name_match_13.group(3).upper()})
            add_dict.update({'last_name': name_match_13.group(4).upper()})
    elif name_match_14:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_14, add_dict)
        else:
            add_dict.update({'first_name': name_match_14.group(3).upper()})
            add_dict.update({'last_name': name_match_14.group(2).upper()})
    elif name_match_15:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_15, add_dict)
        else:
            add_dict.update({'first_name': name_match_15.group(2).upper()})
            add_dict.update({'last_name': name_match_15.group(3).upper()})
    elif name_match_16:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_16, add_dict)
        else:
            add_dict.update({'first_name': name_match_16.group(2).upper()})
            add_dict.update({'middle_name': name_match_16.group(3).upper()})
            add_dict.update({'last_name': name_match_16.group(4).upper()})
    else:
        add_dict.update({'last_name': name_text.upper()})

    add_dict.update({'suffix': suffix_found.upper()})
    add_dict.update({'name': name_text.upper()})

    return add_dict

def name_split_in_given_order(name_order, name_match, add_dict):
    if name_order == 'FML':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'last_name': name_match.group(3).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
    if name_order == 'LFM':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})


    
    

    
    
    
    
    
    
    
    
    
    
    