# -*- coding: utf-8 -*-
"""
Created on Wed Mar 25 20:46:07 2020

@author: 206011
"""


import re
import cv2
import numpy as np
from keras.applications.vgg16 import preprocess_input as preprocess_input_vgg16
from keras.preprocessing.image import img_to_array

"""
Remove the unwanted text and unicode characters in the string format of xml to improve the text extraction process.

Args:
xml_str: String 
         XML in the string form
Returns:
xml_str: String
         New XML obtained after the process.
"""    
    
def str_replace_xml(xml_str):
    try:
        xml_str=xml_str.replace('http://www.w3.org/1999/xhtml','')
        xml_str=xml_str.replace('❑','')
        xml_str=xml_str.replace('•','')
        xml_str=xml_str.replace('■','')
        xml_str=xml_str.replace('&apos;','')
        xml_str=xml_str.replace('&quot;','')
        return xml_str
    except:
        return ''
       


"""
Check whether given string consists of alphabets or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains alphabet or not
       
Returns:
flag: Boolean
      It return True if there is alphabet character in the given string else it returns False
      
text : String
       Updated text is returned to the function.
"""    
    

def check_text(text):
    try:
        flag = False
        for i in text:
            if(i.isalpha()):
                flag = True
            elif(i.isdigit() and i=='3'):
                text = text.replace(i,'J')
                flag = True
            elif(i.isdigit() and i=='1'):
                text = text.replace(i,'I')
                flag = True 
            elif(i ==','):
                flag = True
            else:
                flag = False
                return(flag,text)
        return(flag,text)
    except:
        return('','')



"""
Check whether given string consists of digit or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains digit or not
       
Returns:
flag: Boolean
      It return True if there is digit character in the given string else it returns False
      
"""

def check_digit(text):
    try:
        flag = False
        for i in text:
            if(i.isdigit()):
                flag = True
            else:
                flag =False
                return(flag)
        return flag
    except:
        return ''



    
"""
Check whether given string consists of alphabet/digit or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains alphabet/digit or not
       
Returns:
flag: Boolean
      It return True if there is alphabet/digit character in the given string else it returns False
      
"""
       
def check_alnum(text):
    try:
        flag = False
        for i in text:
            if(i.isalnum()):
                flag = True
            else:
                flag =False
                return(flag)
        return flag
    except:
        return ''
        

"""
Check whether given list of strings contain comma or not and returns index list where the comma is present.

Args:
new_name_list : list
               List consisting of name strings.
       
Returns:
index: list
       List of indices which contain comma in the string.
      
"""

def check_comma(new_name_list):
    try:
        index = []
        for name in new_name_list:
            if(name.find(',')!=-1):
                index.append(new_name_list.index(name))
        return index
    except:
        return ''
        

"""
Remove unnecessary special charcters and spaces and some cleaning to improve text quality.

Args:
text : String
       Input string for cleaning.
       
Returns:
text : String
       Updated text is returned to the function.
""" 


def cleaning(text):
    try:
        if(text=='I' or text == 'i'):
           text = '1'
        text=re.sub('\s+',' ',text)
        text=re.sub(r"(\d+)\s+(-)\s+(\d+)",r"\1\2\3",text.rstrip())
        text=re.sub(r"(\d+)\s+(\d+)",r"\1\2",text.rstrip())
        text = re.sub(r'^([\W]+)$','',text)
        char_check_beg = re.compile('[(]')
        char_check_end = re.compile('[)]')
        if(char_check_beg.search(text)!=None and char_check_end.search(text)==None):
            text=text+')'
        if(char_check_end.search(text)!=None and char_check_beg.search(text)==None):
            if(char_check_end.search(text)==None):
                text='('+text 
        return text
    except:
        return ''

"""
Identify whether the checkbox is checked or unchecked and returns corresponding text.

Args:
image : Numpy array of image
xmin, ymin, xmax, ymax: Integer
                        Bounding box coordinates of check box
model: Classification model to detect checkbox is checked or unchecked

Returns:
y_pred: String
        Text containing either checked or unchecked is returned.
"""

def detect_check_box(image,xmin,ymin,xmax,ymax,model):
    try:
        label_map=dict({0:"Checked",
                        1:"Unchecked"})
        image = image[ymin:ymax,xmin:xmax]
        image = img_to_array(image)
        image = cv2.resize(image, (224,224), interpolation = cv2.INTER_AREA)
        image = preprocess_input_vgg16(image)
        image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
        y_pred = model.predict(image)
        y_pred = np.argmax(y_pred, axis=1)
        y_pred = label_map[y_pred[0]]
        return y_pred
    except:
        return ''