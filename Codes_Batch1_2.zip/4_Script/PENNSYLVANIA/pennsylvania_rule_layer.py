# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:15:22 2020

@author: 206011
"""

import re
import pandas as pd



def model_missed_data_extractor(temp_df, form_type, image):
    presence_df = temp_df[temp_df['classes'].str.contains('Driver Presence')]
    if(form_type == 'form_type_1'):
        street_df = temp_df[temp_df['classes'].str.contains('Principal Road Street Name')]
        if((len(street_df)==1) and (temp_df['classes'].str.contains('Principal Road Street Ending').any() == False)):
            temp_df = temp_df.append({'image_path': street_df.iloc[0]['image_path'], 'classes': 'Principal Road Street Ending', 'score': 99.00,
                        'x1': street_df.iloc[0]['x2'],'y1': street_df.iloc[0]['y1'], 'x2': image.shape[1], 'y2':  street_df.iloc[0]['y2']}, ignore_index=True)
    
        driver_df = temp_df[temp_df['classes'].str.contains('Driver MI|Driver Suffix')]
        driver_df.sort_values(by=['x1'],inplace=True)
        if((len(driver_df) == 2) and (temp_df['classes'].str.contains('Driver Last Name').any() == False)):
            temp_df = temp_df.append({'image_path': driver_df.iloc[0]['image_path'], 'classes': 'Driver Last Name', 'score': 99.00,
                        'x1': driver_df.iloc[0]['x2'],'y1': driver_df.iloc[0]['y1'], 'x2':driver_df.iloc[1]['x1'], 'y2': driver_df.iloc[0]['y2']}, ignore_index=True)
        
        driver_df = temp_df[temp_df['classes'].str.contains('Driver Suffix|Driver Telephone No')]
        driver_df.sort_values(by=['x1'],inplace=True)
        if((len(driver_df) == 2) and (temp_df['classes'].str.contains('Driver DOB').any() == False)):
            temp_df = temp_df.append({'image_path': driver_df.iloc[0]['image_path'], 'classes': 'Driver DOB', 'score': 99.00,
                        'x1': driver_df.iloc[0]['x2'],'y1': driver_df.iloc[0]['y1'], 'x2':driver_df.iloc[1]['x1'], 'y2': driver_df.iloc[0]['y2']}, ignore_index=True)
          
        driver_df = temp_df[temp_df['classes'].str.contains('Alcohol/Drugs Suspected|Drug Test Type')]
        driver_df.sort_values(by=['y1'],inplace=True)
        if((len(driver_df) == 2) and (temp_df['classes'].str.contains('Driver Action').any() == False)):
            temp_df = temp_df.append({'image_path': driver_df.iloc[0]['image_path'], 'classes': 'Driver Action', 'score': 99.00,
                        'x1': driver_df.iloc[1]['x1'],'y1': driver_df.iloc[1]['y2'], 'x2':image.shape[1], 
                        'y2': driver_df.iloc[1]['y2'] + (driver_df.iloc[1]['y2'] - driver_df.iloc[0]['y2'])}, ignore_index=True)
        
        owner_df = temp_df[temp_df['classes'].str.contains('Owner City')]
        if((len(owner_df) == 1) and (temp_df['classes'].str.contains('Owner Street Address').any() == False)):
            temp_df = temp_df.append({'image_path': owner_df.iloc[0]['image_path'], 'classes': 'Owner Street Address', 'score': 99.00,
                        'x1': 0,'y1': owner_df.iloc[0]['y1'], 'x2':owner_df.iloc[0]['x1'], 'y2': owner_df.iloc[0]['y2']}, ignore_index=True)
            
        owner_df = temp_df[temp_df['classes'].str.contains('Owner State|Owner Telephone No')]
        owner_df.sort_values(by=['x1'],inplace=True)
        if((len(owner_df) == 2) and (temp_df['classes'].str.contains('Owner Zip Code').any() == False)):
            temp_df = temp_df.append({'image_path': driver_df.iloc[0]['image_path'], 'classes': 'Owner Zip Code', 'score': 99.00,
                        'x1': owner_df.iloc[0]['x2'],'y1': owner_df.iloc[0]['y1'], 'x2':owner_df.iloc[1]['x1'], 'y2': owner_df.iloc[0]['y2']}, ignore_index=True)
        
        charge_df = temp_df[temp_df['classes'].str.contains('Person Charged')]
        if((len(charge_df) > 1) and (len(driver_df) > 0)):
            ind = 0
            for ch,charge in charge_df.iterrows():
                charge_no = charge_df.iloc[ind]['classes'].split(' ')[-1]
                if(temp_df['classes'].str.contains('Violation ' + str(charge_no)).any() == False):
                    temp_df = temp_df.append({'image_path': charge_df.iloc[ind]['image_path'], 'classes': 'Violation ' + str(charge_no), 'score': 99.00,
                            'x1': driver_df.iloc[0]['x1'],'y1': charge_df.iloc[ind]['y1'], 'x2':charge_df.iloc[ind]['x1'], 'y2': charge_df.iloc[ind]['y2']}, ignore_index=True)
                ind = ind + 1
    if(form_type == 'form_type_2'):  
        crash_df = temp_df[temp_df['classes'].str.contains('County/Municipality|Crash Time')]
        crash_df.sort_values(by=['x1'], inplace=True)
        if(len(crash_df) == 2)and(temp_df['classes'].str.contains('Crash Date').any() == False):
            temp_df = temp_df.append({'image_path': crash_df.iloc[0]['image_path'], 'classes': 'Crash Date', 'score': 99.00,
                        'x1': crash_df.iloc[0]['x2'],'y1': crash_df.iloc[0]['y1'], 'x2': crash_df.iloc[1]['x1'], 'y2': crash_df.iloc[0]['y2']}, ignore_index=True)
           
        violation_df = temp_df[temp_df['classes'].str.contains('Violation')]
        charge_df = temp_df[temp_df['classes'].str.contains('Person Charged')]
        if((len(charge_df) > 1) and (len(violation_df) == 1)):
            ind = 0
            for ch,charge in charge_df.iterrows():
                charge_no = charge_df.iloc[ind]['classes'].split(' ')[-1]
                if(temp_df['classes'].str.contains('Violation ' + str(charge_no)).any() == False):
                    temp_df = temp_df.append({'image_path': charge_df.iloc[ind]['image_path'], 'classes': 'Violation '+ str(charge_no), 'score': 99.00,
                        'x1': violation_df.iloc[0]['x1'],'y1': charge_df.iloc[ind]['y1'], 'x2':charge_df.iloc[ind]['x1'], 'y2': charge_df.iloc[ind]['y2']}, ignore_index=True)
                ind = ind + 1
           
        owner_df = temp_df[temp_df['classes'].str.contains('Vehicle Insurance Company|Vehicle Type')]
        owner_df.sort_values(by=['y1'], inplace=True)
        if(len(owner_df) == 2)and(temp_df['classes'].str.contains('Owner Name/Address/Phone').any() == False):
            temp_df = temp_df.append({'image_path': owner_df.iloc[0]['image_path'], 'classes': 'Owner Name/Address/Phone', 'score': 99.00,
                        'x1': owner_df.iloc[1]['x1'],'y1': owner_df.iloc[0]['y1'], 'x2': 2*(owner_df.iloc[1]['x2']-owner_df.iloc[1]['x1']), 
                        'y2': owner_df.iloc[0]['y2']}, ignore_index=True)
    return temp_df