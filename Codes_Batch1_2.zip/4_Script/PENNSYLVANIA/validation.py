# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 16:18:50 2020

@author: saugatapaul
"""

import re

def _format_phone_number(text):
    text = text.strip()
    if(len(text)==10 and len(text) != 0):
        text = re.sub('[^0-9]', '', text)
        text = text.strip()
        text = text[:3] + "-" + text[3:6] + "-" + text[6:]
    elif(len(text) == 0):
        text = ""
    return text

def _format_date(text):
    text = text.strip()
    if(len(text) != 0):
        text = re.sub('[^0-9]', ' ', text)
        text = text.strip()
        
        day = text.split()[0]
        month = text.split()[1]
        year = text.split()[-1]
        
        if(len(day) == 1):
            day = "0"+day
            
        if(len(month) == 1):
            month = "0"+month
            
        date = month + "/" + day + "/" + year
    else:
        date = ""
    return date

def _format_speed(text):
    if(len(text) != 0):
        text = re.sub('[^0-9]', '', text)
        text = text.strip()
    else:
        text = ""
    return text

#Standard time in Hour Format
def _format_time_no_am_pm(text):
    if(len(text) != 0):
        text = re.sub('[^0-9]', '', text)
        text = text.strip()
        minute = text[-2:]
        hour = text.replace(minute,"")
        if(len(hour) == 1):
            hour = "0"+hour
        text = hour + ":" + minute
    else:
        text = ""
    return text

#When time is in AM/PM format
def _format_time_am_pm(text):
    if(len(text) != 0):
        text = text.strip()
        time = re.sub('[^0-9]', ' ', text)
        time = time.strip()
        am_pm = re.sub('[^A-Za-z]', ' ', text).upper()
        am_pm = am_pm.strip()
        minute = time[-2:]
        hour = time.replace(minute,"")
        hour = hour.strip()
        
        if(am_pm == "PM"):
            hour = int(hour)
            if(hour != 12):
                hour = hour + 12
            
        hour = str(hour)
        if(len(hour) == 1):
            hour = "0"+hour
        if(len(minute) == 1):
            minute = "0"+minute    
    else:
        text = ""

    
final_time = hour + ":" + minute

                
                