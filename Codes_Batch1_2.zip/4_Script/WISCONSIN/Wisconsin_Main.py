import os
import sys
import pandas as pd

import WISCONSIN.wisconsin_text_extractor as wisconsin_text_extractor
import WISCONSIN.wisconsin_json_convertor as wisconsin_json_convertor

look_up_address_split = os.path.join(os.getcwd(), "WISCONSIN", "CityList.txt")
look_up_business_name = os.path.join(os.getcwd(), "WISCONSIN", "Business_Name.csv")

def Process(csv_file_path, temp_path, checkbox_model):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    text_extracted_df = pd.DataFrame()
    tif_file_name = str(csv_file_path.split('.')[0]) + '.tif'

    try:
        print("Process : PDF Content Extraction" )
        text_extracted_df = wisconsin_text_extractor.content_extraction(predicted_df, os.path.join(temp_path, csv_file_name),look_up_address_split, checkbox_model, tif_file_name, look_up_business_name)
    except:
        print("Error : Error occured during PDF Content Extraction" )
        return sys.exc_info(),"error"

    try:
        print("Process : JSON Conversion")
        data, tif_name = wisconsin_json_convertor.json_convertion(text_extracted_df)
        return data, tif_name
    except:
        print("Error : Error occured during JSON Conversion")
        return sys.exc_info(), "error"

