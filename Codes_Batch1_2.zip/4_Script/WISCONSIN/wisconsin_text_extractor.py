import os
import time
import pandas as pd
import xml.etree.ElementTree as ET
import re
import cv2
import WISCONSIN.name_address_split as name_address_split
import WISCONSIN.common_util as common_util
import WISCONSIN.text_extract as text_extract
import WISCONSIN.preproceesor as preproceesor


"""----------------------------- TEXT EXTRACTION - START --------------------------------"""


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
df: DataFrame 
    DataFrame containing the image name, label name(object) and their coordinates obtained after applying the developed model on the images.
csv_path: String
          Path where the output csv in the following format ('path','xmin','ymin','xmax','ymax','label','text') has to be created.
model_path: string
            Path where the model to identify whether the given checkbox is checked or unchecked.
Returns:
Extracted text for each predicted bounding box is calculated and saved in the csv file where the input image are present.
"""
def content_extraction(df, xml_out_path, look_up_address_split, checkbox_model, tif_file_name, look_up_business_name):
    df.rename(columns={'label': 'classes'}, inplace=True)
    df['image_path'] = df['filename'].apply(lambda x: x.split('.')[0] + '_' + x.split('_')[-1] + '.jpg')
    df['x1'] = df['xmin'] * df['img_width']
    df['y1'] = df['ymin'] * df['img_height']
    df['x2'] = df['xmax'] * df['img_width']
    df['y2'] = df['ymax'] * df['img_height']

    overall_list = []
    data_list = []
    img_list = df['image_path'].unique().tolist()
    img_list.sort()  # 28 July 2020
    group_df = df.groupby('image_path')
    page_occur_count = 0

    # ===============================
    # Checkbox model - TIF to JPG
    output_jpg_dir = os.path.join(xml_out_path ,'jpg')
    if not os.path.exists(output_jpg_dir):
        os.makedirs(output_jpg_dir)
    preproceesor.tiff_to_jpg(tif_file_name, output_jpg_dir)
    # ===============================

    for img in img_list:
        page_occur_count += 1
        csv_name = os.path.join(xml_out_path, img.split('.')[0] + '_final.csv')
        temp_df = group_df.get_group(img)
        temp_df = temp_df.sort_values(by='y1')
        img_height = df['img_height'][0]
        xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
        xml_path = xml_path.replace('_WI', '_wi')
        if os.path.exists(xml_path) == False:
            continue

        xml_str = open(xml_path, 'r', encoding='utf-8').read()

        upd_xml_str = common_util.str_replace_xml(xml_str)

        xml_tree = ET.XML(upd_xml_str)
        page_list = xml_tree.findall('.//page')
        page_height = page_list[0].attrib['height']
        c = round(img_height / float(page_height), 2)
        hit_and_run_checked_status =''
        image = cv2.imread(os.path.join(output_jpg_dir, img))

        for i, row1 in temp_df.iterrows():
            text_list = []
            bb_xmin = int(row1.x1)
            bb_ymin = int(row1.y1)
            bb_xmax = int(row1.x2)
            bb_ymax = int(row1.y2)
            bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

            if row1.classes == 'Hit and Run':
                hit_and_run_checked_status = common_util.detect_check_box(image, bb_xmin, bb_ymin, bb_xmax, bb_ymax, checkbox_model)
                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, hit_and_run_checked_status))
            elif row1.classes == 'St':
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                text_list = [x[1] for x in add_list]
                text = ' '.join(text_list)
                state_abbr = common_util.state_abbr_convertor(text)
                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, state_abbr))
            elif row1.classes == 'Location':
                bb_coord = (10, bb_ymin, bb_xmax, bb_ymax)
                line_list = name_address_split.find_text_lines(xml_tree, bb_coord, c)
                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                  'Location', ' '.join(line_list)))
                for line in line_list:
                    # loss_st_match = re.search('^(ON (HIGHWAY\s)?)([A-Za-z0-9\/\s]+)(\s[A-Z]{2,3})$', line)
                    loss_st_match = re.search('^(ON (HIGHWAY\s)?)(.*?)$', line)
                    loss_cross_st_match = re.search('^((OF|AT)\s(.*?))$', line)
                    crash_city_match = re.search('^((IN THE (TOWN|CITY|VILLAGE) OF )(.*?))$', line)
                    if loss_st_match:
                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                          'Loss_Street', loss_st_match.group(3)))
                    elif loss_cross_st_match:
                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                          'Loss_Cross_Street', loss_cross_st_match.group(3)))
                    elif crash_city_match:
                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                          'Crash_City', crash_city_match.group(4)))

            elif row1.classes == 'Driver License Number':
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                text_list = [x[1] for x in add_list]
                text = ' '.join(text_list)
                state_match = re.search('^(([A-Z0-9]+)\s(STATE:\s)([A-Z]+))', text)
                if state_match:
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes, state_match.group(2)))
                    state_abbr = common_util.state_abbr_convertor(state_match.group(4))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      'Drivers_License_Jurisdiction', state_abbr))
                else:
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes, text))

            elif row1.classes == 'Owner Name' or row1.classes == 'Driver' or row1.classes == 'Passenger' \
                    or row1.classes == 'Individual' or row1.classes == 'Organization/Company' or row1.classes == 'Government':
                bb_coord = (bb_xmin, bb_ymin - 20, bb_xmax, bb_ymax)
                add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix': '', 'name': ''}

                line_list = name_address_split.find_text_lines(xml_tree, bb_coord, c)

                if len(line_list) == 1:
                    if (row1.classes == 'Owner Name' or row1.classes == 'Driver') and (
                            'unknown' in line_list[0].lower() and hit_and_run_checked_status == 'Checked'):
                        add_dict.update({'last_name': 'HIT&RUN'})
                        add_dict.update({'name': line_list[0]})
                    else:
                        add_dict = name_address_split.name_split_using_pattern(line_list[0], look_up_business_name)

                elif len(line_list) > 1:
                    if re.match(r'^([0-9\(\)\-\s]+)$', line_list[1]):
                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                          row1.classes + '_Home_Phone', line_list[1]))
                        add_dict = name_address_split.name_split_using_pattern(line_list[0], look_up_business_name)
                    else:
                        if len(line_list) > 0: data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                              'Person_Type', line_list[0]))

                        if len(line_list) > 1:
                            if (row1.classes == 'Owner Name' or row1.classes == 'Driver') and ('unknown' in line_list[1].lower() and hit_and_run_checked_status == 'Checked'):
                                    add_dict.update({'last_name': 'HIT&RUN'})
                                    add_dict.update({'name': line_list[1]})
                            else:
                                add_dict = name_address_split.name_split_using_pattern(line_list[1], look_up_business_name)

                        if len(line_list) > 2: data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                              row1.classes + '_Home_Phone', line_list[2]))

                if (add_dict is not None):
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_first_name', format_name(add_dict.get('first_name'))))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_middle_name', format_name(add_dict.get('middle_name'))))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_last_name', format_name(add_dict.get('last_name'))))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_suffix',
                                      format_name(add_dict.get('suffix'))))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_name',
                                      add_dict.get('name')))
            else:
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                text_list = [x[1] for x in add_list]

            if (row1.classes == 'Address') or row1.classes == 'Owner Address':
                add_dict = None
                line_list = name_address_split.find_text_lines(xml_tree, bb_coord, c)
                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                  row1.classes, ' '.join(line_list)))

                if len(line_list) > 2:
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      format_text(line_list[0])))
                    if re.match('po(\s\.?)box', str(line_list[1]).lower()):
                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address2',
                                          format_text(line_list[1])))
                    add_dict = name_address_split.name_address_split_using_pattern(line_list[2])
                    if add_dict is None:
                        add_dict = name_address_split.name_address_split_using_lookup(line_list[2], look_up_address_split)

                        data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      line_list[0]))
                elif len(line_list) > 1:
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      format_text(line_list[0])))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address2',''))
                    add_dict = name_address_split.name_address_split_using_pattern(line_list[1])
                    if add_dict is None:
                        add_dict = name_address_split.name_address_split_using_lookup(line_list[1], look_up_address_split)
                elif len(line_list) == 1:
                    text = ' '.join(line_list)
                    add_dict = name_address_split.name_address_split_using_pattern(text)
                    if add_dict is None:
                        add_dict = name_address_split.name_address_split_using_lookup(text, look_up_address_split)

                if (add_dict is not None):
                    state_abbr = common_util.state_abbr_convertor(add_dict.get('state'))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_city',
                                      add_dict.get('city')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_state',
                                      state_abbr))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_zipcode',
                                      format_text(add_dict.get('zipcode'))))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_phone_no',
                                      add_dict.get('phone_no')))
            try:
                text = ' '.join(text_list)
                if row1.classes != 'Longitude':
                    text = common_util.cleaning(text)
            except TypeError:
                text = ''
            data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            ex2 = time.time()

        temptext_df = pd.DataFrame(data_list, columns=['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])
        temptext_df['text'] = temptext_df['text'].apply(lambda x: common_util.cleaning(x))
        temptext_df['page_no'] = temptext_df['path'].apply(
            lambda x: int(os.path.basename(x).split('.')[0].split('_')[-1]))
        temptext_df = temptext_df[['path', 'page_no', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text']]

        # temptext_df.to_csv(csv_name, index=False)

    # temp_df = pd.DataFrame(overall_list, columns=['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])
    # temp_df.to_csv(os.path.join(xml_out_path, 'overall_extracted.csv'), index=False)

    return temptext_df


"""----------------------------- TEXT EXTRACTION - END --------------------------------"""


def format_name(value):
    value = value.replace('—', '-')
    if(value != ''):
        value = re.sub('[^a-zA-Z&\-\\s]+', '', str(value))
        value = value.upper()
    return value

# Address, zip code, lincence
def format_text(value):
    value = value.replace('—', '-')
    if(value != ''):
        value = re.sub('[^a-zA-Z0-9@#$^&}{:<>/\\-\'\.\,\s]+', '', str(value))
        value = value.upper()
    return value

# temptext_df = content_extraction(df, xml_path, image_path, model_path)
# wisconsin_json_convertor.json_convertion(temptext_df, output_path)