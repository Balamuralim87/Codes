# -*- coding: utf-8 -*-
"""
Created on Wed Feb 18 19:01:30 2019

@author: Priyanga

This script is a utility to convert model predicted data to JSON format.
"""

from typing import List
import json
import re
import tqdm
import os
import pandas as pd
import numpy as np

global_df = None

class Violation_Code(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class TransportedTo(object):
    def __init__(self, unit_num:str, prsn_num: str, transported_to: str):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.transported_to = transported_to

class CitationsDetails(object):
    def __init__(self, unit_num:str, prsn_num: str, Citation_Detail: str, Violation_Code: Violation_Code):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code

class ContributingFactorDetails(object):
    def __init__(self, unit_num: str, Contributing_Factors: List):
        self.unit_num = unit_num
        self.Contributing_Factors = Contributing_Factors

class Weather_Condition(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Road_Surface_Condition(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Safety_Equipment_Restraint(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Safety_Equipment_Helmet(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Alcohol_Use_Suspected(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Drug_Use_Suspected(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Driver_Actions_at_Time_Of_Crash(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Driver_Distracted_By(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Non_Motorist_Actions_At_Time_Of_Crash(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Contributing_Circumstances_Person(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Contributing_Circumstances_Vehicle(object):
    def __init__(self, code: str, Description: str):
        self.Code = code
        self.Description = Description

class Citations(object):
    def __init__(self, Citation_Type: str, Citation_Issued: str, Citation_Detail: str, Violation_Code: Violation_Code, Party_Id: str, Unit_Number: str):
        self.Citation_Type = Citation_Type
        self.Citation_Issued = Citation_Issued
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code
        self.Party_Id = Party_Id
        self.Unit_Number = Unit_Number

class Incident(object):
    def __init__(self, Report_Date: str, Crash_Date: str, Case_Identifier: str, State_Report_Number: str, Crash_City: str,
                 Loss_Street: str, Loss_Cross_Street: str, Latitude: str, Longitude: str, Loss_State_Abbr: str,
                Report_Type_Id:str, Gps_Other:str, Fatality_Involved:str, Incident_Hit_and_Run:str, Dispatch_Time:str,
                 Photographed_By:str,Weather_Condition: List[Weather_Condition], Road_Surface_Condition: List[Road_Surface_Condition]):
        self.Report_Date = Report_Date
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Fatality_Involved = Fatality_Involved
        self.Incident_Hit_and_Run = Incident_Hit_and_Run
        self.Dispatch_Time = Dispatch_Time
        self.Photographed_By = Photographed_By
        self.Weather_Condition = Weather_Condition
        self.Road_Surface_Condition = Road_Surface_Condition

class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations

class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: str, First_Name: str, Middle_Name: str, Last_Name: str,
                 Name_Suffix: str, Address:str, Address2:str, City:str, State:str, Zip_Code: str, Home_Phone: str,
                 Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str, Injury_Status:str,
                 Safety_Equipment_Restraint:List[Safety_Equipment_Restraint], Safety_Equipment_Helmet:List[Safety_Equipment_Helmet],
                 Ejection: str, Transported_To: str, Alcohol_Use_Suspected:List[Alcohol_Use_Suspected], Drug_Use_Suspected:List[Drug_Use_Suspected],
                 Driver_Actions_at_Time_Of_Crash:List[Driver_Actions_at_Time_Of_Crash], Driver_Distracted_By:List[Driver_Distracted_By],
                 Non_Motorist_Actions_At_Time_Of_Crash:List[Non_Motorist_Actions_At_Time_Of_Crash]):
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        self.Safety_Equipment_Restraint = Safety_Equipment_Restraint
        self.Safety_Equipment_Helmet = Safety_Equipment_Helmet
        self.Ejection = Ejection
        self.Transported_To=Transported_To
        self.Drug_Use_Suspected=Drug_Use_Suspected
        self.Alcohol_Use_Suspected =Alcohol_Use_Suspected
        self.Driver_Actions_At_Time_Of_Crash = Driver_Actions_at_Time_Of_Crash
        self.Driver_Distracted_By = Driver_Distracted_By
        self.Non_Motorist_Actions_At_Time_Of_Crash = Non_Motorist_Actions_At_Time_Of_Crash

class Vehicles(object):
    def __init__(self, VinValidation_VinStatus: str, Unit_Number:str, License_Plate: str, Registration_State: str, VIN:str,
                 Vehicle_Towed: str, Model_Year: str, Make: str, Model: str, Insurance_Company: str, Insurance_Policy_Number:str,
                 Insurance_Expiration_Date: str, Damaged_Areas:str, Air_Bag_Deployed:str, Party_Id:str,
                 Contributing_Circumstances_Vehicle:List[Contributing_Circumstances_Vehicle], Posted_Statutory_SpeedLimit:str):
        self.VinValidation_VinStatus = VinValidation_VinStatus
        self.Unit_Number = Unit_Number
        self.License_Plate = License_Plate
        self.Registration_State = Registration_State
        self.VIN = VIN
        self.Vehicle_Towed= Vehicle_Towed
        self.Model_Year = Model_Year
        self.Make = Make
        self.Model= Model
        self.Insurance_Company = Insurance_Company
        self.Insurance_Policy_Number=Insurance_Policy_Number
        self.Insurance_Expiration_Date=Insurance_Expiration_Date
        self.Damaged_Areas=Damaged_Areas
        self.Air_Bag_Deployed=Air_Bag_Deployed
        self.Party_Id=Party_Id
        self.Contributing_Circumstances_Vehicle=Contributing_Circumstances_Vehicle
        self.Posted_Statutory_SpeedLimit = Posted_Statutory_SpeedLimit
        # self.Citations=Citations

class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report

def get_inner_details(second_page_df, label_name, unit_num, prsn_num):
    if len(second_page_df) > 0:
        for i, j in second_page_df.iterrows():
            if j.label == label_name and (label_name == 'ContributingFactor' or label_name == 'VehiDefects_Contrib'):
                if j.value.unit_num == unit_num:
                    return j.value.Contributing_Factors
            elif j.label == label_name:
                if j.value.prsn_num == prsn_num and j.value.unit_num == unit_num:
                    return  j.value
    return ''

def get_value_from_df(label_name):
    if len(global_df.loc[global_df['label'] == label_name]) > 0:
        value = global_df.loc[global_df['label'] == label_name]['text'].iloc[0]
        if str(value) != 'nan':
            return value
        else:
            return ''
    else:
        return ''

def get_value_from_df_with_rename(label_name):
    if len(global_df.loc[global_df['label'] == label_name]) > 0:
        value = global_df.loc[global_df['label'] == label_name]['text'].iloc[0]
        idx = global_df.index[global_df['label'] == label_name]
        global_df.at[idx[0], 'label'] = label_name + '_took'
        if str(value) != 'nan':
            return value
        else:
            return ''
    else:
        return ''

def assign_no(df):
    temp_df_sub = df.copy()
    temp_df_sub.sort_values(by=['ymin', 'xmin'], inplace=True)
    unique_labels = temp_df_sub['label'].unique().tolist()
    group_df_sub = temp_df_sub.groupby('label')
    group_df_sub['label'].size().sort_values(ascending=False, inplace=True)
    max_value = group_df_sub['label'].value_counts()
    max_count = max_value.mode().max()
    # max_count = max_mode.values.item()
    label_no_df = pd.DataFrame()
    check_df = pd.DataFrame()
    label_chk = []
    flag = 0
    for label in unique_labels:
        group = group_df_sub.get_group(label)
        if (group.shape[0] == max_count):
            count = 1
            if (flag == 0):
                check_df = group
                flag = 1
            for i, row in group.iterrows():
                group.at[i, 'label'] = row.label + '_' + str(count)
                count = count + 1
            label_no_df = label_no_df.append(group)

        elif (len(check_df) != 0):
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if (diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1, 'label'] = row1.label + '_' + str(no)

            label_no_df = label_no_df.append(group)
        else:
            label_chk.append(label)

    for label in label_chk:
        group = group_df_sub.get_group(label)
        if (len(check_df) != 0):
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if (diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1, 'label'] = row1.label + '_' + str(no)

            label_no_df = label_no_df.append(group)
    df = label_no_df.sort_values(by=['ymin', 'xmin'])
    return df

# Address, zip code, lincence
def format_text(value):
    value = value.replace('—', '-')
    if(value != ''):
        value = re.sub('[^a-zA-Z0-9@#$^&}{:<>/\\-\'\.\,\s]+', '', str(value))
        value = value.upper()
    return value

def date_fomat_maker(date):
    new_date = ''
    if date != '':
        date = date.replace(' ', '')
        date_match = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{4}))$', date)
        date_match2 = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{3}))$', date)
        if date_match:
            new_date = date_match.group(2) + '/' + date_match.group(4) + '/'  + date_match.group(5)
        elif date_match2:
            new_date = date_match2.group(2) + '/' + date_match2.group(4) + '/' + date_match2.group(5)
        else:
            new_date = date
    return new_date

def is_object_has_values(user_object):
    # if user_object.Party_Id == '' and user_object.Person_Type =='' and user_object.First_Name =='' and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == ''  and user_object.Drivers_License_Jurisdiction =='':
    if user_object.Injury_Status == '' and user_object.First_Name == '' and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == '' and user_object.Drivers_License_Jurisdiction == '':
        return False
    else:
        return True

def create_group(df):
    df['no'] = df['label'].apply(lambda x: x.split('_')[-1])
    temp_df = df[df['text']!='']
    temp_df.dropna(inplace=True)
    df_dict = temp_df['no'].value_counts().to_dict()
    return df_dict

def witness_details_extraction(people_list, df):
    global global_df
    other_df, df_list = slicing_main_df(df, 'Witness_T')
    for split_df in df_list:
        split_df['new_index'] = np.arange(len(split_df))
        split_df.set_index('new_index', inplace=True)
        witness_df = assign_no(split_df)
        wit_dict = create_group(witness_df)
        global_df = witness_df
        witness_count = 0
        if (len(wit_dict) > 0):
            for i in range(1, len(wit_dict) + 1):
                if (wit_dict.get(str(i)) != None and wit_dict.get(str(i)) > 5):
                    witness_count = witness_count + 1
                    Home_Phone = get_value_from_df('Individual_Home_Phone' + '_' + str(i))
                    Home_Phone = Home_Phone.replace('(', '')
                    Home_Phone = re.sub('\)\s?', '-', Home_Phone)

                    people_info = People(Party_Id=witness_count,
                                         Person_Type='WITNESS',
                                         Unit_Number='',
                                         First_Name=get_value_from_df('Individual_first_name' + '_' + str(i)),
                                         Middle_Name=get_value_from_df('Individual_middle_name' + '_' + str(i)),
                                         Last_Name=get_value_from_df('Individual_last_name' + '_' + str(i)),
                                         Name_Suffix=get_value_from_df('Individual_suffix' + '_' + str(i)),
                                         Address=get_value_from_df('Address_address' + '_' + str(i)),
                                         Address2=get_value_from_df('Address_address2' + '_' + str(i)),
                                         City=get_value_from_df('Address_city' + '_' + str(i)),
                                         State=get_value_from_df('Address_state' + '_' + str(i)),
                                         Zip_Code=get_value_from_df('Address_zipcode' + '_' + str(i)),
                                         Home_Phone=Home_Phone,
                                         Date_Of_Birth=get_value_from_df('Date of Birth' + '_' + str(i)),
                                         Drivers_License_Number='',
                                         Drivers_License_Jurisdiction='',
                                         Injury_Status='',
                                         Safety_Equipment_Restraint=[],
                                         Safety_Equipment_Helmet=[],
                                         Ejection='',
                                         Transported_To='',
                                         Drug_Use_Suspected=[],
                                         Alcohol_Use_Suspected=[],
                                         Driver_Actions_at_Time_Of_Crash=[],
                                         Driver_Distracted_By=[],
                                         Non_Motorist_Actions_At_Time_Of_Crash=[])
                    people_list.append(people_info)
        return (people_list, witness_count)


def property_owner_details_extraction(people_list, df, vehicle_list):
    unit_num = len(vehicle_list) + 1
    global global_df
    other_df, df_list = slicing_main_df(df, 'PropertyOwner_T')
    count = 0
    for split_df in df_list:
        split_df['new_index'] = np.arange(len(split_df))
        split_df.set_index('new_index', inplace=True)
        property_df = assign_no(split_df)
        property_dict = create_group(property_df)
        global_df = property_df
        if (len(property_dict) > 0):
            TwoOrMoreProp = list(filter(lambda x: x == 'Struck Object_1', property_df['label']))
            for i in range(1, len(property_dict) + 1):
                if (property_dict.get(str(i)) != None and property_dict.get(str(i)) > 5):
                    count = count + 1
                    property_owner_info(str(count), '0' + str(unit_num), get_value_from_df('Struck Object' + '_' + str(i)), people_list)

                    label_name = ''
                    if get_value_from_df('Government' + '_last_name' + '_' + str(i)) != '':
                        label_name = 'Government'
                    elif get_value_from_df('Organization/Company' + '_last_name' + '_' + str(i)) != '':
                        label_name = 'Organization/Company'
                    elif get_value_from_df('Individual' + '_last_name' + '_' + str(i)) != '':
                        label_name = 'Individual'

                    Home_Phone = get_value_from_df(label_name + '_Home_Phone' + '_' + str(i))
                    Home_Phone = Home_Phone.replace('(', '')
                    Home_Phone = re.sub('\)\s?', '-', Home_Phone)

                    people_info = People(Party_Id=str(count),
                                         Person_Type='VEHICLE OWNER',
                                         Unit_Number='0' + str(unit_num),
                                         First_Name=get_value_from_df(label_name + '_first_name' + '_' + str(i)),
                                         Middle_Name=get_value_from_df(label_name + '_middle_name' + '_' + str(i)),
                                         Last_Name=get_value_from_df(label_name + '_last_name' + '_' + str(i)),
                                         Name_Suffix=get_value_from_df(label_name + '_suffix' + '_' + str(i)),
                                         Address=get_value_from_df('Address_address' + '_' + str(i)),
                                         Address2=get_value_from_df('Address_address2' + '_' + str(i)),
                                         City=get_value_from_df('Address_city' + '_' + str(i)),
                                         State=get_value_from_df('Address_state' + '_' + str(i)),
                                         Zip_Code=get_value_from_df('Address_zipcode' + '_' + str(i)),
                                         Home_Phone=Home_Phone,
                                         Date_Of_Birth=get_value_from_df('Date of Birth' + '_' + str(i)),
                                         Drivers_License_Number='',
                                         Drivers_License_Jurisdiction='',
                                         Injury_Status='',
                                         Safety_Equipment_Restraint=[],
                                         Safety_Equipment_Helmet=[],
                                         Ejection='',
                                         Transported_To='',
                                         Drug_Use_Suspected=[],
                                         Alcohol_Use_Suspected=[],
                                         Driver_Actions_at_Time_Of_Crash=[],
                                         Driver_Distracted_By=[],
                                         Non_Motorist_Actions_At_Time_Of_Crash=[])
                    people_list.append(people_info)

                    if len(TwoOrMoreProp) == 2:
                        struck_object = property_df.loc[property_df['label'] == 'Struck Object_1']
                        if len(struck_object) == 2:
                            property_owner_info(str(count + 1), '0' + str(unit_num),struck_object.iloc[[1]]['text'].iloc[0], people_list)

                    empty_driver_vehicle_block(people_list, vehicle_list, unit_num)

                    unit_num += 1


def property_owner_info(party_id, unit_num, property_name, people_list):
    people_info = People(Party_Id=party_id,
                         Person_Type='PROPERTY OWNER',
                         Unit_Number='0' + str(unit_num),
                         First_Name='',
                         Middle_Name='',
                         Last_Name=property_name,
                         Name_Suffix='',
                         Address='',
                         Address2='',
                         City='',
                         State='',
                         Zip_Code='',
                         Home_Phone='',
                         Date_Of_Birth='',
                         Drivers_License_Number='',
                         Drivers_License_Jurisdiction='',
                         Injury_Status='',
                         Safety_Equipment_Restraint=[],
                         Safety_Equipment_Helmet=[],
                         Ejection='',
                         Transported_To='',
                         Drug_Use_Suspected=[],
                         Alcohol_Use_Suspected=[],
                         Driver_Actions_at_Time_Of_Crash=[],
                         Driver_Distracted_By=[],
                         Non_Motorist_Actions_At_Time_Of_Crash=[])
    people_list.append(people_info)

def empty_driver_vehicle_block(people_list, vehicle_list, unit_num):
    people_info = People(Party_Id='1',
                         Person_Type='DRIVER',
                         Unit_Number= '0' + str(unit_num),
                         First_Name='',
                         Middle_Name='',
                         Last_Name='',
                         Name_Suffix='',
                         Address='',
                         Address2='',
                         City='',
                         State='',
                         Zip_Code='',
                         Home_Phone='',
                         Date_Of_Birth='',
                         Drivers_License_Number='',
                         Drivers_License_Jurisdiction='',
                         Injury_Status='',
                         Safety_Equipment_Restraint=[],
                         Safety_Equipment_Helmet=[],
                         Ejection='',
                         Transported_To='',
                         Drug_Use_Suspected=[],
                         Alcohol_Use_Suspected=[],
                         Driver_Actions_at_Time_Of_Crash=[],
                         Driver_Distracted_By=[],
                         Non_Motorist_Actions_At_Time_Of_Crash=[])
    people_list.append(people_info)

    vehicle = Vehicles(
        VinValidation_VinStatus='V',
        Unit_Number='0' + str(unit_num),
        License_Plate='',
        Registration_State='',
        VIN='',
        Vehicle_Towed='',
        Model_Year='',
        Make='',
        Model='',
        Insurance_Company='',
        Insurance_Policy_Number='',
        Insurance_Expiration_Date='',
        Damaged_Areas='',
        Air_Bag_Deployed='',
        Party_Id='1',
        Contributing_Circumstances_Vehicle=[],
        Posted_Statutory_SpeedLimit=''
    )
    vehicle_list.append(vehicle)


def person_details_extraction(people_list, unit_num, df, psrn_num):
    # PeopleList = []
    OwnerFlag = 1
    global global_df

    other_df, df_list = slicing_main_df(df, 'Individual_T')
    if other_df.empty:
        other_df, df_list = slicing_main_df(df, 'Date of Birth')
    if other_df.empty:
        pass

    OwnerName = ''
    OwnerFirst_Name = ''
    OwnerMiddle_Name = ''
    OwnerLast_Name = ''
    OwnerName_Suffix = ''
    OwnerAddress = ''
    OwnerAddress2 = ''
    OwnerCity = ''
    OwnerState = ''
    OwnerZip_Code = ''
    OwnerHome_Phone = ''
    Driver_Actions_at_Time_Of_Crash_List = []

    global_df = other_df
    if other_df.empty == False:
        OwnerName = get_value_from_df('Owner Name_name')
        OwnerFirst_Name = get_value_from_df('Owner Name_first_name')
        OwnerMiddle_Name = get_value_from_df('Owner Name_middle_name')
        OwnerLast_Name = get_value_from_df('Owner Name_last_name')
        OwnerName_Suffix = get_value_from_df('Owner Name_suffix')
        OwnerAddress = get_value_from_df('Owner Address_address')
        OwnerAddress2 = get_value_from_df('Owner Address_address2')
        OwnerCity = get_value_from_df('Owner Address_city')
        OwnerState = get_value_from_df('Owner Address_state')
        OwnerZip_Code = get_value_from_df('Owner Address_zipcode')
        OwnerHome_Phone = get_value_from_df('Owner Name_Home_Phone')
        OwnerHome_Phone = OwnerHome_Phone.replace('(', '')
        OwnerHome_Phone = re.sub('\)\s?', '-', OwnerHome_Phone)
        Driver_Actions = get_value_from_df('Driver Actions')
        if Driver_Actions != '': Driver_Actions_at_Time_Of_Crash_List.append(Driver_Actions_at_Time_Of_Crash('', Driver_Actions))

    person_num_count = psrn_num

    for people_df in df_list:

        # witness_df = people_df[people_df['label'].str.contains('Witness')]
        # if (len(witness_df) != 0):
        #     print("Witness extraction in progress!!!!")
        #     witness_df['new_index'] = np.arange(len(witness_df))
        #     witness_df.set_index('new_index', inplace=True)
        #     assign_no(witness_df)

        global_df = people_df
        is_owner_same_as_driver = False

        person_type = get_value_from_df('PersonType_T')
        if person_type == '':
            person_type = get_value_from_df('Person_Type')
        person_type = person_type.upper()
        Safety_Equipment_Restraint_List = []
        Safety_Equipment_Helmet_List = []
        Alcohol_Use_Suspected_List = []
        Drug_Use_Suspected_List = []
        Driver_Distracted_By_List = []
        Non_Motorist_Actions_At_Time_Of_Crash_List = []

        person_num = str(person_num_count)

        Date_Of_Birth = get_value_from_df('Date of Birth')
        Date_Of_Birth = date_fomat_maker(Date_Of_Birth)
        Address = get_value_from_df('Address_address')
        Address2 = get_value_from_df('Address_address2')
        City = get_value_from_df('Address_city')
        State = get_value_from_df('Address_state')
        ZipCode = get_value_from_df('Address_zipcode')

        Safety_Equipment = get_value_from_df('Safety Equipment')
        if Safety_Equipment!= '': Safety_Equipment_Restraint_List.append(Safety_Equipment_Restraint('', Safety_Equipment))
        Helmet_User = get_value_from_df('Helmet Use')
        if Helmet_User != '':  Safety_Equipment_Helmet_List.append(Safety_Equipment_Helmet('', Helmet_User))
        Suspected_Alcohol_Use = get_value_from_df('Suspected Alcohol Use')
        if Suspected_Alcohol_Use != '': Alcohol_Use_Suspected_List.append(Alcohol_Use_Suspected('', Suspected_Alcohol_Use))
        Suspected_Drug_Use = get_value_from_df('Suspected Drug Use')
        if Suspected_Drug_Use != '': Drug_Use_Suspected_List.append(Drug_Use_Suspected('', Suspected_Drug_Use))
        # Driver_Distractions = get_value_from_df('Driver Distractions') 'UAT: extracting from this field
        Driver_Distractions = get_value_from_df('Distracted By Action')
        if Driver_Distractions != '': Driver_Distracted_By_List.append(Driver_Distracted_By('', Driver_Distractions))
        Actions = get_value_from_df('Action')
        if Actions != '': Non_Motorist_Actions_At_Time_Of_Crash_List.append(Non_Motorist_Actions_At_Time_Of_Crash('', Actions))


        Drivers_License_Number = format_text(get_value_from_df('Driver License Number'))
        Drivers_License_Jurisdiction = get_value_from_df('Drivers_License_Jurisdiction')
        First_Name = get_value_from_df('Driver_first_name')
        Middle_Name = get_value_from_df('Driver_middle_name')
        Last_Name = get_value_from_df('Driver_last_name')
        Name_Suffix = get_value_from_df('Driver_suffix')
        Home_Phone = get_value_from_df('Driver_Home_Phone')
        Home_Phone = Home_Phone.replace('(', '')
        Home_Phone = re.sub('\)\s?', '-', Home_Phone)

        # ===========================================
        # Injury Status
        Injury_Status = get_value_from_df('Injury Severity')
        InjuryStatusDic = {'Killed': 'K', 'Possible Injury': 'C', 'Incapacitating': 'A', 'Non-Incapacitating': 'B',
                           'No Injury': 'N', 'NO APPARENT INJURY': 'N'}
        found_injury_status = list(filter(lambda x: x.lower() == Injury_Status.lower(), InjuryStatusDic.keys()))
        if len(found_injury_status) > 0:
            injury_status_code = InjuryStatusDic.get(found_injury_status[0])
        else:
            injury_status_code = Injury_Status
        # ===========================================

        if OwnerName != None:
            OwnerName = OwnerName.replace(',', '')
            OwnerName = OwnerName.replace('s ', '')
        DriverName = get_value_from_df('Driver_name')

        if DriverName != '' and OwnerName != '' and OwnerName != None:
            if OwnerName.lower() == DriverName.lower():
                is_owner_same_as_driver = True

        if Last_Name == '':
            person_num_count += 1
            person_num = str(person_num_count)
            First_Name = get_value_from_df('Passenger_first_name')
            Middle_Name = get_value_from_df('Passenger_middle_name')
            Last_Name = get_value_from_df('Passenger_last_name')
            Name_Suffix = get_value_from_df('Passenger_suffix')
            Home_Phone = get_value_from_df('Passenger_Home_Phone')
            Home_Phone = Home_Phone.replace('(', '')
            Home_Phone = re.sub('\)\s?', '-', Home_Phone)

        if Last_Name != '':
            people_info = People(Party_Id=person_num,
                                 Person_Type=person_type,
                                 Unit_Number=unit_num,
                                 First_Name=First_Name,
                                 Middle_Name=Middle_Name,
                                 Last_Name=Last_Name,
                                 Name_Suffix=Name_Suffix,
                                 Address=Address,
                                 Address2=Address2,
                                 City=City,
                                 State=State,
                                 Zip_Code=ZipCode,
                                 Home_Phone=Home_Phone,
                                 Date_Of_Birth=Date_Of_Birth,
                                 Drivers_License_Number=Drivers_License_Number,
                                 Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                                 Injury_Status=injury_status_code,
                                 Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                                 Safety_Equipment_Helmet=Safety_Equipment_Helmet_List,
                                 Ejection=get_value_from_df('Ejected'),
                                 Transported_To=get_value_from_df('Hospital'),
                                 Drug_Use_Suspected=Drug_Use_Suspected_List,
                                 Alcohol_Use_Suspected=Alcohol_Use_Suspected_List,
                                 Driver_Actions_at_Time_Of_Crash=Driver_Actions_at_Time_Of_Crash_List,
                                 Driver_Distracted_By=Driver_Distracted_By_List,
                                 Non_Motorist_Actions_At_Time_Of_Crash=Non_Motorist_Actions_At_Time_Of_Crash_List
                                 )

            if is_object_has_values(people_info) == True:
                people_list.append(people_info)

        if is_owner_same_as_driver == True and OwnerFlag == 1:
            OwnerFlag = 0
            people_info = People(
                                 Party_Id = person_num,
                                 Person_Type='VEHICLE OWNER',
                                 Unit_Number=unit_num,
                                 First_Name=OwnerFirst_Name,
                                 Middle_Name=OwnerMiddle_Name,
                                 Last_Name=OwnerLast_Name,
                                 Name_Suffix=OwnerName_Suffix,
                                 Address=Address,
                                 Address2=Address2,
                                 City=City,
                                 State=State,
                                 Zip_Code=ZipCode,
                                 Home_Phone=OwnerHome_Phone,
                                 Date_Of_Birth=Date_Of_Birth,
                                 Drivers_License_Number=Drivers_License_Number,
                                 Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                                 Injury_Status=injury_status_code,
                                 Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                                 Safety_Equipment_Helmet=Safety_Equipment_Helmet_List,
                                 Ejection=get_value_from_df('Ejected'),
                                 Transported_To=get_value_from_df('Hospital'),
                                 Drug_Use_Suspected=Drug_Use_Suspected_List,
                                 Alcohol_Use_Suspected=Alcohol_Use_Suspected_List,
                                 Driver_Actions_at_Time_Of_Crash=Driver_Actions_at_Time_Of_Crash_List,
                                 Driver_Distracted_By=Driver_Distracted_By_List,
                                 Non_Motorist_Actions_At_Time_Of_Crash=Non_Motorist_Actions_At_Time_Of_Crash_List
                                 )
            if is_object_has_values(people_info) == True:
                people_list.append(people_info)
        else:
            # OwnerAddress = get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_address')
            if OwnerName != '' and OwnerFlag == 1:
                OwnerFlag = 0
                people_info = People(
                                     Party_Id = person_num,
                                     Person_Type='VEHICLE OWNER',
                                     Unit_Number=unit_num,
                                     First_Name=OwnerFirst_Name,
                                     Middle_Name=OwnerMiddle_Name,
                                     Last_Name=OwnerLast_Name,
                                     Name_Suffix=OwnerName_Suffix,
                                     Address=OwnerAddress,
                                     Address2=OwnerAddress2,
                                     City=OwnerCity,
                                     State=OwnerState,
                                     Zip_Code=OwnerZip_Code,
                                     Home_Phone=OwnerHome_Phone,
                                     Date_Of_Birth='',
                                     Drivers_License_Number='',
                                     Drivers_License_Jurisdiction='',
                                     Injury_Status='',
                                     Safety_Equipment_Restraint=[],
                                     Safety_Equipment_Helmet=[],
                                     Ejection='',
                                     Transported_To='',
                                     Drug_Use_Suspected=[],
                                     Alcohol_Use_Suspected=[],
                                     Driver_Actions_at_Time_Of_Crash=[],
                                     Driver_Distracted_By=[],
                                     Non_Motorist_Actions_At_Time_Of_Crash=[]
                                     )

                if is_object_has_values(people_info) == True:
                    people_list.append(people_info)


    return person_num_count

def vehicle_details_extraction(vehicle_list, unit_num):
    Contributing_Circumstances_Vehicle_List = []
    ContributingFactorsVehicle = get_value_from_df('Vehicle Factors')
    if ContributingFactorsVehicle != '':
        Contributing_Circumstances_Vehicle_List.append(Contributing_Circumstances_Vehicle('', ContributingFactorsVehicle))

    VIN = get_value_from_df('Vehicle Identification Number')
    VIN = VIN.replace(' ', '')

    ModelYear = get_value_from_df('Year')
    ModelYear = ModelYear.replace(' ', '')

    vehicle_make = get_value_from_df('Make')
    vehicle_model = get_value_from_df('Model')
    license_plate = get_value_from_df('License Plate Number')
    insurance_company = get_value_from_df('Insurance Company')
    insurance_company = insurance_company.replace('-', ' ')

    airbag_deployed = get_value_from_df('Airbag')
    airbag_deployed = airbag_deployed.lower()
    if 'not deployed' in airbag_deployed or 'non deployed' in airbag_deployed:
        airbag_status = '0'
    elif 'not applicable' in airbag_deployed or 'unknown' in airbag_deployed:
        airbag_status = ''
    else:
        airbag_status = '1'

    # ============================================
    # Vehicle damaged ratings
    damaged_area_desc = get_value_from_df('Vehicle Damage')
    rear_list = ['5', '6', '7']
    front_list = ['1', '11', '12']
    damaged_areas = ''
    damaged_area_codes = re.findall('([0-9]+)', damaged_area_desc)
    if 'no damage' in damaged_area_desc.lower():
        damaged_areas = 'NA'
    elif len(damaged_area_codes) > 0 and set(damaged_area_codes).issubset(set(rear_list)):
            damaged_areas = 'Rear'
    elif len(damaged_area_codes) > 0 and set(damaged_area_codes).issubset(set(front_list)):
            damaged_areas = 'Front'
    elif len(damaged_area_codes) > 1 or damaged_area_desc.lower() == 'all areas':
        damaged_areas = 'Multiple'
    elif len(damaged_area_codes) == 1:
        damage_ratings_dic = {'1': 'Right Front', '2': 'Right Side', '3': 'Right Side', '4': 'Right Side',
                              '5': 'Right Rear', '6': 'Rear', '7': 'Left Rear', '8': 'Left Side', '9': 'Left Side',
                              '10': 'Left Side', '11': 'Left Front', '12': 'Front'}

        found_damage_rating = list(filter(lambda x: x == damaged_area_codes[0], damage_ratings_dic.keys()))
        if len(found_damage_rating) == 1:
            damaged_areas = damage_ratings_dic.get(found_damage_rating[0])
    else:
        damaged_areas = damaged_area_desc
    # for damage_code in damaged_area_codes:
    #     damage_ratings_dic = {'1': 'Right Front', '2': 'Right Side', '3': 'Right Side', '4': 'Right Side',
    #                           '5': 'Right Rear', '6': 'Rear', '7': 'Left Rear', '8': 'Left Side', '9': 'Left Side',
    #                           '10': 'Left Side', '11': 'Left Front', '12': 'Front'}
    #
    #     found_damage_rating = list(filter(lambda x: x == damage_code, damage_ratings_dic.keys()))
    #     if len(found_damage_rating) == 1:
    #         damaged_areas = damaged_areas + '&' + damage_ratings_dic.get(found_damage_rating[0])
    # damaged_areas = damaged_areas.strip('&')
    # ============================================

    # ============================================
    # Vehicle towed by and to
    towed_by_to = get_value_from_df('Towed Due To Damage')
    towed_by_to = towed_by_to.lower()
    if 'driver' in towed_by_to or 'left' in towed_by_to or 'scene' in towed_by_to or 'not towed' in towed_by_to \
            or 'owner' in towed_by_to or (towed_by_to == '' and vehicle_make != '' and vehicle_model != '' and license_plate != ''):
        towed_status = '0'
    elif 'N/A' in towed_by_to or 'NA' in towed_by_to or 'Unknown' in towed_by_to \
            or (towed_by_to == ' ' and vehicle_make == '' and vehicle_model == '' and license_plate == ''):
        towed_status = ''
    elif towed_by_to == ' ':
        towed_status = ''
    else:
        towed_status = '1'
    # ============================================


    vehicle = Vehicles(
        VinValidation_VinStatus = 'V',
        Unit_Number = unit_num,
        License_Plate = license_plate,
        Registration_State=get_value_from_df('St'),
        VIN = VIN,
        Vehicle_Towed = towed_status,
        Model_Year = ModelYear,
        Make = vehicle_make,
        Model = vehicle_model,
        Insurance_Company = insurance_company,
        # Insurance_Policy_Number = get_value_from_df('Individual'),
        Insurance_Policy_Number= '',
        Insurance_Expiration_Date = '',
        Damaged_Areas = damaged_areas,
        Air_Bag_Deployed = airbag_status,
        Party_Id = '1',
        Contributing_Circumstances_Vehicle = Contributing_Circumstances_Vehicle_List,
        Posted_Statutory_SpeedLimit = get_value_from_df('Speed Limit')
    )
    if vehicle.License_Plate != '' and vehicle.Registration_State != '' and vehicle.Make != '' \
             and vehicle.Model != '' and vehicle.VIN != '':
        vehicle_list.append(vehicle)

    return vehicle_list

def citation_details_extraction(citations_list, unit_num):
    CitationsList = list(filter(lambda x: re.search(r'^Issue To', x), global_df['label']))
    for citation in CitationsList:
        CitationCls = Citations('', '', get_value_from_df_with_rename('Description'), get_value_from_df_with_rename('Statute Number'),
                                get_value_from_df_with_rename('Issue To?'), unit_num)

        if CitationCls.Citation_Detail != '' or CitationCls.Violation_Code != '' or CitationCls.Party_Id != '':
            citations_list.append(CitationCls)

def incident_extraction():
    is_checked = ''
    if len(global_df.loc[global_df['label'] == 'Hit and Run']) > 0:
        is_checked_count = list(filter(lambda x: x == 'Checked', global_df.loc[global_df['label'] == 'Hit and Run']['text']))
        if len(is_checked_count) > 0:
            is_checked = '1'
        else:
            is_checked = ''

    CrashDate = get_value_from_df('Crash Date')
    CrashDate = date_fomat_maker(CrashDate)

    Weather_Condition_List = []
    Weather_Condition_List.append(Weather_Condition('', get_value_from_df('Weather Condition(s)')))
    Road_Surface_Condition_List = []
    Road_Surface_Condition_List.append(Road_Surface_Condition('', get_value_from_df('Road Surface Condition(s)')))
    Loss_Cross_Steeet = get_value_from_df('Loss_Cross_Street')
    Loss_Cross_Steeet= Loss_Cross_Steeet.replace('/', '')

    photos_by = get_value_from_df('Photos By')
    # if photos_by != '': In UAT testing they are giving 'name' as output
    #     photo_status = 'Y'
    # else:
    #     photo_status = 'N'

    incident = Incident(Report_Date='',
                        Crash_Date=CrashDate,
                        Case_Identifier=get_value_from_df('ReportNum'),
                        # Case_Identifier=get_value_from_df('CaseID_1'), UAT: 'ReportNum' is expected output
                        # State_Report_Number=get_value_from_df('ReportNum'), Not captured in WI
                        State_Report_Number='',
                        Crash_City=get_value_from_df('Crash_City'),
                        Loss_Street=get_value_from_df('Loss_Street'),
                        Loss_Cross_Street=Loss_Cross_Steeet,
                        Latitude=get_value_from_df('Latitude'),
                        Longitude='-' + get_value_from_df('Longitude'),
                        Loss_State_Abbr='WI',
                        Report_Type_Id='A',
                        Gps_Other='',
                        Fatality_Involved='',
                        Incident_Hit_and_Run=is_checked,
                        Dispatch_Time=get_value_from_df('Time Notified'),
                        Photographed_By = photos_by,
                        Weather_Condition=Weather_Condition_List,
                        Road_Surface_Condition=Road_Surface_Condition_List,
                        )

    return incident

def slicing_main_df(df, split_trigger):

    sorted_df = df.sort_values(by=['page_no', 'ymin', 'xmin'])

    group_df = pd.DataFrame()
    other_df = pd.DataFrame()
    common_list = []

    df_list = []
    flag = 0
    is_found = list(filter(lambda x: x == split_trigger, df['label']))
    if len(is_found) > 0:
        for i, row in sorted_df.iterrows():
            if  flag == 0 and row.label == split_trigger:
                other_df = pd.DataFrame(common_list)
                common_list = []
                flag = 1
            elif flag == 1 and row.label == split_trigger:
                group_df = pd.DataFrame(common_list)
                df_list.append(group_df)
                common_list = []

            common_list.append(row)

            group_df = pd.DataFrame(common_list)
        df_list.append(group_df)

    return other_df, df_list

"""
    This Function writes the annoations in a xml format compatible with label me toolself.
    Args:
    data frame: --datafrmae

    Returns:
    Json String: --str
    """

def json_convertion(df):
    global global_df
    other_df, df_list = slicing_main_df(df, 'UnitSummary_T')

    if other_df.empty:
        return 'invalid file received', 'invalid'

    people_list = []
    vehicle_list = []
    citations_list = []
    global_df = other_df
    incident = incident_extraction()

    unit_num = 1
    prsn_num = 0
    for df_u in df_list:
        prsn_num += 1
        global_df = df_u
        citation_details_extraction(citations_list, '0' + str(unit_num))
        vehicle_details_extraction(vehicle_list, '0' + str(unit_num))
        prsn_num = person_details_extraction(people_list, '0' + str(unit_num), global_df, prsn_num)


        unit_num += 1
    witness_details_extraction(people_list, df)
    property_owner_details_extraction(people_list, df, vehicle_list)

    report = Report(FormName="Universal", CountKeyed=44, Incident=incident, People=people_list, Vehicles=vehicle_list, Citations=citations_list)

    main_cls = MainCls(Report= report)
    data = json.dumps(main_cls, default=lambda o: o.__dict__, indent=4)
    img_name = os.path.basename(df.iloc[0]['path']).split('_')[0]
    tif_name = img_name + '.tif'
    return data, tif_name



# # Deserializing
# decoded_team = Report.from_json(json.loads(data))
# print(decoded_team)
# print(decoded_team.students)

