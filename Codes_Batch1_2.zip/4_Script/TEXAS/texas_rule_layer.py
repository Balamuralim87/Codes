import re
import os
import cv2
import xml.etree.ElementTree as ET
import common_util
import text_extract

def ocr_error_converter(df, label_name):
    unit_list = list(filter(lambda x: re.search(r'^(UnitNum[1-2])$', x), df['label']))
    for unit in unit_list:
        unit_df = df.loc[(df['label'] == unit)]
        if re.match('^([ilITt])$',unit_df['text'].values[0]):
            df.loc[int(unit_df.index[0]), 'text'] = '1'

    return df

def partyID_prsnType_extractor(df, temp_df, xml_tree, adjust_coord):
    for unit in range(1, 3):
        names_list = list(filter(lambda x: re.search(r'^(U' + str(unit) + '_Name[0-9])$', x), temp_df['label']))
        for name in names_list:
            num_id = re.sub(r'^(U' + str(unit) + '_Name)','', name)
            person_num = list(filter(lambda x: re.search(r'^(U' + str(unit) + '_PersonNum' + num_id + ')$', x), temp_df['label']))
            person_type = list(filter(lambda x: re.search(r'^(U' + str(unit) + '_PrsnType' + num_id + ')$', x), temp_df['label']))
            seat_position = list(filter(lambda x: re.search(r'^(U' + str(unit) + '_SeatPosition' + num_id + ')$', x), temp_df['label']))

            if len(person_num) > 0 and len(person_type) > 0 and len(seat_position) > 0:
                # Model identified but text not extracted due to OCR
                prsn_num = temp_df.loc[(temp_df['label'] == person_num[0])]
                prsn_type = temp_df.loc[(temp_df['label'] == person_type[0])]
                if prsn_num.iloc[0]['text'] == '' or prsn_type.iloc[0]['text'] == '':
                    # Check for Vehicle details if that avaliable then it is driver info
                    if prsn_num.iloc[0]['label'] == 'U' + str(unit) + '_PersonNum1' or prsn_type.iloc[0]['label'] == 'U' + str(unit) + '_PrsnType1':
                        vin_list = list(filter(lambda x: re.search(r'^(VIN' + str(unit) +')$', x), temp_df['label']))
                        veh_make_list = list(filter(lambda x: re.search(r'^(VehMake' + str(unit) + ')$', x), temp_df['label']))
                        veh_model_list = list(filter(lambda x: re.search(r'^(VehModel' + str(unit) + ')$', x), temp_df['label']))
                        veh_details_count = 0
                        if len(vin_list) > 0:
                            vin_df = temp_df.loc[(temp_df['label'] == vin_list[0])]
                            if vin_df.iloc[0]['text'] != '':
                                veh_details_count += 1
                        if len(veh_make_list) > 0:
                            veh_model_df = temp_df.loc[(temp_df['label'] == veh_make_list[0])]
                            if veh_model_df.iloc[0]['text'] != '':
                                veh_details_count += 1
                        if len(veh_model_list) > 0:
                            veh_model_df = temp_df.loc[(temp_df['label'] == veh_model_list[0])]
                            if veh_model_df.iloc[0]['text'] != '':
                                veh_details_count += 1

                        if veh_details_count >= 1:
                            if prsn_num['text'].values[0] == '': df.loc[int(prsn_num.index[0]),'text'] = '1'
                            if prsn_type['text'].values[0] == '': df.loc[int(prsn_type.index[0]),'text'] = '1'
                    else:
                        # Always driver with row number assigned
                        if prsn_num['text'].values[0] == '': df.loc[int(prsn_num.index[0]),'text'] = num_id
                        if prsn_type['text'].values[0] == '': df.loc[int(prsn_type.index[0]),'text'] = '2'
            else:
                name_df = temp_df.loc[(temp_df['label'] == name)]
                if len(name_df) > 1:
                    name_df = name_df.iloc[0]
                bb_xmin = 0
                bb_ymin = int(name_df.ymin)
                bb_xmax = int(name_df.xmin)
                bb_ymax = int(name_df.ymax)
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

                add_list = text_extract.find_text(xml_tree, bb_coord, adjust_coord)
                if len(add_list) > 0:
                    text_list = [x[1] for x in add_list]
                    count = 0
                    for txt in text_list:
                        if re.match('(^[0-9])$', txt):
                            count += 1
                            if count == 1 and len(person_num) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'U' + str(unit) + '_PersonNum' + num_id, 'text': txt}
                                df = df.append(new_row, ignore_index=True)
                            elif count == 2 and len(person_type) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'U' + str(unit) + '_PrsnType' + num_id, 'text': txt}
                                df = df.append(new_row, ignore_index=True)
                            elif count == 3 and len(seat_position) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'U' + str(unit) + '_SeatPosition' + num_id, 'text': txt}
                                df = df.append(new_row, ignore_index=True)
    return df

def unitNum_prsnNum_extractor(df, temp_df, xml_tree, adjust_coord, key, table_num, tbl_range):
    for row in range(1, tbl_range):
        names_list = list(filter(lambda x: re.search(r'^('+ key + str(row) + ')$', x), temp_df['label']))
        for name in names_list:
            unit_num = list(filter(lambda x: re.search(r'(T' + table_num+ '_UnitNum' + str(row) + ')$', x), temp_df['label']))
            prsn_num = list(filter(lambda x: re.search(r'(T' + table_num+ '_PrsnNum' + str(row) + ')$', x), temp_df['label']))

            if len(unit_num) > 0 and len(prsn_num) > 0:
                # prsn_num = temp_df.loc[(temp_df['label'] == person_num[0])]
                # if prsn_num['text'] == '':
                d = 1
            else:
                name_df = temp_df.loc[(temp_df['label'] == name)]
                bb_xmin = 0
                bb_ymin = int(name_df.ymin)
                bb_xmax = int(name_df.xmin)
                bb_ymax = int(name_df.ymax)
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

                add_list = text_extract.find_text(xml_tree, bb_coord, adjust_coord)
                if len(add_list) > 0:
                    text_list = [x[1] for x in add_list]
                    count = 0
                    for txt in text_list:
                        if re.match('(^[0-9])$', txt):
                            count += 1
                            if count == 1 and len(unit_num) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'T' + str(table_num) + '_UnitNum' + str(row), 'text': txt}
                                df = df.append(new_row, ignore_index=True)
                            elif count == 2 and len(prsn_num) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'T' + str(table_num) + '_PrsnNum' + str(row), 'text': txt}
                                df = df.append(new_row, ignore_index=True)

    return df


def unitNum_on_contri_factor_extractor(df, temp_df, xml_tree, adjust_coord):
    for row in range(1, 3):
        names_list = list(filter(lambda x: re.search(r'^(ContributingFactor_R' + str(row) +'_1)$', x), temp_df['label']))
        for name in names_list:
            unit_num = list(filter(lambda x: re.search(r'(Unit' + str(row) + ')$', x), temp_df['label']))

            if len(unit_num) > 0:
                # prsn_num = temp_df.loc[(temp_df['label'] == person_num[0])]
                # if prsn_num['text'] == '':
                d = 1
            else:
                name_df = temp_df.loc[(temp_df['label'] == name)]
                bb_xmin = 0
                bb_ymin = int(name_df.ymin)
                bb_xmax = int(name_df.xmin)
                bb_ymax = int(name_df.ymax)
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

                add_list = text_extract.find_text(xml_tree, bb_coord, adjust_coord)
                if len(add_list) > 0:
                    text_list = [x[1] for x in add_list]
                    for txt in text_list:
                        if re.match('(^[0-9])$', txt):
                            if  len(unit_num) == 0:
                                new_row = {'path': name_df['path'].values[0], 'page_no': name_df['page_no'].values[0],
                                           'xmin': bb_xmin, 'ymin': bb_ymin, 'xmax': bb_xmax, 'ymax': bb_ymax,
                                           'label': 'Unit' + str(row), 'text': txt}
                                df = df.append(new_row, ignore_index=True)

    return df

def unit_num_extractor(df, temp_df, xml_tree, adjust_coord):
    UnitNumberList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), temp_df['label']))
    # Model not able to identify the UnitNumber block
    if len(UnitNumberList) < 2:
        VehYearList = list(filter(lambda x: re.search(r'^(VehYear[0-9])$', x), temp_df['label']))
        # Applicable only on 1st page
        # Create box using veh year box and extract text from it
        for VehYear_df in VehYearList:
            VehYear = temp_df.loc[(temp_df['label'] == VehYear_df)]
            bb_xmin = int(VehYear.xmin)
            bb_ymin = int(VehYear.ymin) - (int(VehYear.ymax) - int(VehYear.ymin))
            bb_xmax = int(VehYear.xmax) - int((int(VehYear.xmax) - bb_xmin) / 1.5)
            bb_ymax = bb_ymin + (int(VehYear.ymax) - int(VehYear.ymin))
            bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

            add_list = text_extract.find_text(xml_tree, bb_coord, adjust_coord)
            if len(add_list) > 0 and int(VehYear['page_no'].values[0]) == 1:
                text_list = [x[1] for x in add_list]
                for txt in text_list:
                    if re.match('(^[0-9])$', txt):
                        label_name = VehYear['label'].values[0].replace('VehYear', '')
                        new_row = {'path': VehYear['path'].values[0], 'page_no': VehYear['page_no'].values[0], 'xmin': bb_xmin,
                                   'ymin': bb_ymin,
                                   'xmax': bb_xmax, 'ymax': bb_ymax, 'label': 'UnitNum' + label_name, 'text': txt}
                        df = df.append(new_row, ignore_index=True)
            elif int(VehYear['page_no'].values[0]) == 1:
                # If due to OCR error not able to extract the text from it, then asign the veh year number as Unit number
                label_name = VehYear['label'].values[0].replace('VehYear', '')
                new_row = {'path': VehYear['path'].values[0], 'page_no': VehYear['page_no'].values[0], 'xmin': bb_xmin,
                           'ymin': bb_ymin,
                           'xmax': bb_xmax, 'ymax': bb_ymax, 'label': 'UnitNum' + label_name, 'text': label_name}
                df = df.append(new_row, ignore_index=True)
    return df

def rule_layer_main(df, xml_out_path):
   
    img_list = df['path'].unique().tolist()
    img_list.sort()  # 28 July 2020
    group_df = df.groupby('path')

    for img in img_list:
        #csv_name = os.path.join(xml_out_path, img.split('.')[0] + '_final.csv')
        #temp_df = group_df.get_group(img)
        #temp_df = temp_df.sort_values(by='ymin')

        # ==========================================
        # to execute output locally
        #xml_path = os.path.join(xml_out_path, os.path.basename(img).split('.')[0] + '.xml')
        #image = cv2.imread(img)
        #img_height = image.shape[0]
        # ==========================================
        
        
  
        csv_name = os.path.join(xml_out_path, img.split('.')[0] + '_final.csv')
        temp_df = group_df.get_group(img)
        temp_df = temp_df.sort_values(by='ymin')
        img_height = df['img_height'][0]
        xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
        xml_path=xml_path.replace('_TX','_tx')
        
        
        
        

        # ==========================================
        # uncomment this for docker model output
        # img_height = df['img_height'][0]
        # xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
        # ==========================================

        # ==========================================
        # Temporary fix for OCR not generating page in pdf which page was actually present in tif file
        if os.path.exists(xml_path) == False:
            continue
        # ==========================================

        xml_str = open(xml_path, 'r', encoding='utf-8').read()
        upd_xml_str = common_util.str_replace_xml(xml_str)
        xml_tree = ET.XML(upd_xml_str)
        page_list = xml_tree.findall('.//page')
        page_height = page_list[0].attrib['height']

        coord_adjustment = round(img_height / float(page_height), 2)

        df = unit_num_extractor(df, temp_df, xml_tree, coord_adjustment)
        df = partyID_prsnType_extractor(df, temp_df, xml_tree, coord_adjustment)
        df = unitNum_prsnNum_extractor(df, temp_df, xml_tree, coord_adjustment, 'TakenTo', '1', 7)
        df = unitNum_prsnNum_extractor(df, temp_df, xml_tree, coord_adjustment, 'Charge', '2', 5)
        df = unitNum_on_contri_factor_extractor(df, temp_df, xml_tree, coord_adjustment)
        df = ocr_error_converter(df, r'^(UnitNum[1-2])$')
        df = ocr_error_converter(df, r'^(U[1-2]_PersonNum[0-9])$')
        df = ocr_error_converter(df, r'^(U[1-2]_PrsnType[0-9])$')
        df = ocr_error_converter(df, r'^(T[1-2]_UnitNum[1-2])$')
        df = ocr_error_converter(df, r'^(T[1-2]_PrsnNum[1-2])$')
        df = ocr_error_converter(df, r'^(T[1-2]_PrsnNum[1-2])$')

    return df
