import os
import time
import cv2
import pandas as pd
import xml.etree.ElementTree as ET
import re
import name_address_split
import common_util
import text_extract


"""----------------------------- TEXT EXTRACTION - START --------------------------------"""


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
df: DataFrame 
    DataFrame containing the image name, label name(object) and their coordinates obtained after applying the developed model on the images.
csv_path: String
          Path where the output csv in the following format ('path','xmin','ymin','xmax','ymax','label','text') has to be created.
model_path: string
            Path where the model to identify whether the given checkbox is checked or unchecked.
Returns:
Extracted text for each predicted bounding box is calculated and saved in the csv file where the input image are present.
"""
def content_extraction(df, xml_out_path,look_up_address_split):
    df.rename(columns={'label': 'classes'}, inplace=True)
    df['image_path'] = df['filename'].apply(lambda x: x.split('.')[0] + '_' + x.split('_')[-1] + '.jpg')
    df['x1'] = df['xmin'] * df['img_width']
    df['y1'] = df['ymin'] * df['img_height']
    df['x2'] = df['xmax'] * df['img_width']
    df['y2'] = df['ymax'] * df['img_height']

    overall_list = []
    data_list = []
    img_list = df['image_path'].unique().tolist()
    img_list.sort()  # 28 July 2020
    group_df = df.groupby('image_path')
    page_occur_count = 0
    for img in img_list:
        page_occur_count += 1
        csv_name = os.path.join(xml_out_path, img.split('.')[0] + '_final.csv')
        temp_df = group_df.get_group(img)
        temp_df = temp_df.sort_values(by='y1')
        img_height = df['img_height'][0]
        xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
        xml_path=xml_path.replace('_TX','_tx')
        if os.path.exists(xml_path) == False:
            continue
        #print(xml_path)
        xml_str = open(xml_path, 'r', encoding='utf-8').read()
        
        upd_xml_str = common_util.str_replace_xml(xml_str)
        
        xml_tree = ET.XML(upd_xml_str)
        page_list = xml_tree.findall('.//page')
        page_height = page_list[0].attrib['height']
        #print('pageheight ' + page_height)
        c = round(img_height / float(page_height), 2)
        for i, row1 in temp_df.iterrows():
            text_list = []
            bb_xmin = int(row1.x1)
            bb_ymin = int(row1.y1)
            bb_xmax = int(row1.x2)
            bb_ymax = int(row1.y2)
            bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
            if re.search(r'(_UC)$', row1.classes):
                text_list.append('UnChecked')
            elif re.search(r'(_C)$', row1.classes):
                text_list.append('Checked')
            
            elif re.search(r'^(UnitNum[0-9])$', row1.classes) and page_occur_count == 1:
                text = row1.classes.replace('UnitNum', '')
                text_list.append(text)

            elif 'U1_Name' in row1.classes or 'U2_Name' in row1.classes or 'OwnerLesseeNameAddress' in row1.classes:
                add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix': '', 'name': ''}
                try:
                    bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
                    add_list = name_address_split.find_address_text(xml_tree, bb_coord, c, row1.classes)
                    add_list = sorted(add_list, key=lambda x: x[0])
                    text_list = [x[1] for x in add_list]
                    if (len(text_list) != 0):
                        text = ' '.join([str(elem) for elem in text_list])
                        text = text.strip()
                        text = text.strip(',')
                        text = text.strip()
                        if ('U1_Name' in row1.classes or 'OwnerLesseeNameAddress1' in row1.classes) and 'unknown' in text.lower():
                            is_checked_count = list(filter(lambda x: re.search(r'(HitAndRun1_C)$', x), temp_df['classes']))
                            if len(is_checked_count) > 0:
                                add_dict.update({'last_name': 'HIT&RUN'})
                                add_dict.update({'name': text})
                            else:
                                add_dict = name_address_split.name_split_using_pattern(text, 'LFM')
                        elif ('U2_Name' in row1.classes or 'OwnerLesseeNameAddress2' in row1.classes) and 'unknown' in text.lower():
                            is_checked_count = list(filter(lambda x: re.search(r'(HitAndRun2_C)$', x), temp_df['classes']))
                            if len(is_checked_count) > 0:
                                add_dict.update({'last_name': 'HIT&RUN'})
                                add_dict.update({'name': text})
                            else:
                                add_dict = name_address_split.name_split_using_pattern(text, 'LFM')
                        elif 'U1_Name' in row1.classes or 'U2_Name' in row1.classes:
                            add_dict = name_address_split.name_split_using_pattern(text, 'LFM')
                        else:
                            add_dict = name_address_split.name_split_using_pattern(text)
                except:
                    print("exception")

                if (add_dict is not None):
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_first_name', add_dict.get('first_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                         row1.classes + '_first_name', add_dict.get('first_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_middle_name', add_dict.get('middle_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                         row1.classes + '_middle_name', add_dict.get('middle_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_last_name', add_dict.get('last_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                         row1.classes + '_last_name', add_dict.get('last_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_suffix',
                                      add_dict.get('suffix')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_suffix',
                                         add_dict.get('suffix')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_name',
                                      add_dict.get('name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_name',
                                         add_dict.get('name')))
            else:
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                if row1.classes != 'TxDOT_Crash_ID':
                    add_list = sorted(add_list, key=lambda x: x[0])
                text_list = [x[1] for x in add_list]

            if ('Address' in row1.classes) or 'OwnerLesseeNameAddress' in row1.classes:
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
                add_list = name_address_split.find_address_text(xml_tree, bb_coord, c, '')
                add_list = sorted(add_list, key=lambda x: x[0])
                text_list = [x[1] for x in add_list]
                text = t.join(text_list)
                text = text.replace('(Stree) ZIP)', '')
                add_dict = name_address_split.name_address_split_using_pattern(text)
                if add_dict is None:
                    add_dict = name_address_split.name_address_split_using_lookup(text,look_up_address_split)

                if (add_dict is not None):
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      add_dict.get('address')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_city',
                                      add_dict.get('city')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_state',
                                      add_dict.get('state')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_zipcode',
                                      add_dict.get('zipcode')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_phone_no',
                                      add_dict.get('phone_no')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                         add_dict.get('address')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_city',
                                         add_dict.get('city')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_state',
                                         add_dict.get('state')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_zipcode',
                                         add_dict.get('zipcode')))
                    overall_list.append((
                                        row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_phone_no',
                                        add_dict.get('phone_no')))

            t = ' '
            try:
                if (row1.classes == 'TxDOT_Crash_ID'):
                    text = ''.join(text_list)
                    text = common_util.cleaning(text)
                else:
                    text = t.join(text_list)
                    text = common_util.cleaning(text)
            except TypeError:
                text = ''
            data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            ex2 = time.time()
        temptext_df = pd.DataFrame(data_list, columns=['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])
        temptext_df['text'] = temptext_df['text'].apply(lambda x: common_util.cleaning(x))
        temptext_df['page_no'] = temptext_df['path'].apply(
            lambda x: 'page_no ' + os.path.basename(x).split('.')[0].split('_')[-1])
        temptext_df['img_height'] = img_height
        temptext_df = temptext_df[['path', 'page_no', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text', 'img_height']]
        
    return temptext_df

"""----------------------------- TEXT EXTRACTION - END --------------------------------"""