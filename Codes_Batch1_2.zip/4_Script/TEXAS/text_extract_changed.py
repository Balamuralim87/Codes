# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 00:43:49 2020

@author: 206011
"""

import numpy as np

"""------------------------------------TEXT EXTRACTION---------------------------------------------------------------"""
"""
Update the coordinates in the xml to match with coordinates in the image.
Args:
coord: Tuple
       Coordinates of the bounding box(predicted object).
c:  Integer
    Constant value to be multiplied with ocr_coord to map with bb_coord
    
Returns:
coord: Tuple
       Updated coordinates of the bounding box(predicted object).
"""

def update_coord(coord, c): 
    coord = [float(i)*c for i in coord]
    return(coord)


"""
Compute pairwise intersection areas between boxes.
Args:
boxes1: a numpy array with shape [N, 4] holding N boxes
boxes2: a numpy array with shape [M, 4] holding M boxes
Returns:
a numpy array with shape [N*M] representing pairwise intersection area
"""

def intersection(ocr_coord,bb_coord):
    [y_min1, x_min1, y_max1, x_max1] = np.split(ocr_coord, 4, axis=1)
    [y_min2, x_min2, y_max2, x_max2] = np.split(bb_coord, 4, axis=1)

    all_pairs_min_ymax = np.minimum(y_max1, np.transpose(y_max2))
    all_pairs_max_ymin = np.maximum(y_min1, np.transpose(y_min2))
    intersect_heights = np.maximum(
      np.zeros(all_pairs_max_ymin.shape),
      all_pairs_min_ymax - all_pairs_max_ymin)
    all_pairs_min_xmax = np.minimum(x_max1, np.transpose(x_max2))
    all_pairs_max_xmin = np.maximum(x_min1, np.transpose(x_min2))
    intersect_widths = np.maximum(
      np.zeros(all_pairs_max_xmin.shape),
      all_pairs_min_xmax - all_pairs_max_xmin)
    return intersect_heights * intersect_widths

"""
Computes area of boxes.
Args:
boxes: Numpy array with shape [N, 4] holding N boxes
Returns:
a numpy array with shape [N*1] representing box areas
"""


def area(ocr_coord):
    return (ocr_coord[:, 2] - ocr_coord[:, 0]) * (ocr_coord[:, 3] - ocr_coord[:, 1])


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
ocr_coord: Tuple
           Coordinates of the current text in the XML.
bb_coord:  Tuple
           Coordinates of the bounding box.
ocr_text:  String
           Text value captured in the XML
Returns:
result_text: String
             Text which satisifies the condition is returned to the calling fucntion.
"""

def check_text_in_BB(ocr_coord,bb_coord,ocr_text):
    ocr_coord = np.expand_dims(np.array(ocr_coord),axis=0)
    bb_coord = np.expand_dims(np.array(bb_coord),axis=0)
    intersect = intersection(ocr_coord,bb_coord)
    text_area = area(ocr_coord)
    intersect_over_text_area = intersect/text_area
    if (intersect_over_text_area>0.5):
        result_text = ocr_text
    else:
        result_text = ''
    return(result_text)

"""
Extract the list of words present within the predicted bounding box.
Args:
xml_tree: XML format
          XML structure of the xml file.
bb_coord:  Tuple
           Coordinates of the bounding box.
c:  Integer
    Constant value to be multiplied with ocr_coord to map with bb_coord
Returns:
add_list: list
             List of list consisting of 'xmin' attribute of word and text.
"""

def find_text(xml_tree,bb_coord,c):
    add_list = []
    text_list = []
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        coord=(elem.attrib['xMin'],elem.attrib['yMin'],elem.attrib['xMax'],elem.attrib['yMax'])
        ocr_coord=update_coord(coord,c)
        result_text = check_text_in_BB(ocr_coord, bb_coord, elem.text)
        if(result_text is not None and result_text!=''):
            add_list.append([float(elem.attrib['xMin']),result_text]) 
    return(add_list)
