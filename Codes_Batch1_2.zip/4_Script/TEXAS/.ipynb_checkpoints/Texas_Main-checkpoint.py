import os
import sys
import pandas as pd

import texas_text_extractor
import texas_rule_layer
import texas_json_convertor

look_up_address_split = os.path.join(os.getcwd(), "TEXAS", "CityList.txt")

def Process(csv_file_path, temp_path):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    text_extracted_df = pd.DataFrame()



    try:
        print("Process : PDF Content Extraction" )
        text_extracted_df = texas_text_extractor.content_extraction(predicted_df, os.path.join(temp_path, csv_file_name),look_up_address_split)
    except:
        print("Error : Error occured during PDF Content Extraction" )
        return sys.exc_info(), "error"


    try:
        print("Process : Post-Processing Layer")
        text_extracted_df = texas_rule_layer.rule_layer_main(text_extracted_df, os.path.join(temp_path, csv_file_name))
    except Exception as e:
        print("Error : Error occured during Post-Processing Layer")
        return sys.exc_info(), "error"


    try:
        print("Process : JSON Conversion")
        data, tif_name = texas_json_convertor.json_convertion(text_extracted_df)
        return data, tif_name
    except:
        print("Error : Error occured during JSON Conversion")
        return sys.exc_info(), "error"

