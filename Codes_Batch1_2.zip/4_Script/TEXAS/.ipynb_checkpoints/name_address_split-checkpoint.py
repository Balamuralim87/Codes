"""
Created on March 27 2020
@author: Priyanga (203367)

This script is a utility to split name and address to "names, address, city, state, zipcode".
Usage: Could be used by calling in command prompt.
"""

import re
import common_util
import text_extract

"""
This Function using lookup of city and state, splits name and address into "names, address, city, state, zipcode".

Args:
address_text: string
              Name address text / address text to split.
city_lookup_path: string 
                  The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_lookup(address_text, city_lookup_path):

    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': ''}
    state_list = ['CA', 'NC', 'TX', 'NJ', 'FL', 'NY', 'IL', 'PA', 'OH', 'NM', 'GA', 'MD', 'MI',
                  'LA', 'MN', 'WI', 'KS', 'OK', 'IA', 'NV', 'UT', 'MS', 'OR', 'KY', 'TN', 'NH',
                  'HI', 'NE', 'WV', 'DE', 'ID', 'IN', 'DC', 'SD', 'RI', 'AK', 'VT', 'ME', 'WY',
                  'ND', 'PR', 'BC', 'VI', 'GU', 'ON', 'PQ', 'AB', 'NS', 'YT', 'MB', 'NF',
                  'Florida', 'Texas', 'California', 'New York', 'Pennsylvania', 'Ohio',
                  'Tennessee', 'Wisconsin', 'Missouri', 'Michigan', 'New Jersey', 'Georgia',
                  'Minnesota', 'Mississippi', 'Louisiana', 'Alabama', 'Maryland', 'Connecticut',
                  'Oklahoma', 'Oregon', 'Arkansas', 'Massachusetts', 'West Virginia', 'Iowa', 'New Mexico',
                  'Nebraska', 'Virginia', 'Delaware', 'New Hampshire', 'Arizona', 'Washington', 'Kansas',
                  'Montana', 'Maine', 'Nevada', 'Kentucky', 'Vermont', 'Rhode Island', 'Hawaii', 'Colorado',
                  'Dis Of Columbia', 'Alaska', 'Wyoming', 'North Dakota', 'South Carolina', 'North Carolina',
                  'Illinois', 'Idaho', 'Virgin Island', 'Indiana', 'South Dakota', 'Guam', 'New Brunswick',
                  'Puerto Rico',
                  'Yukon', 'Utah', 'British Columbia']

    city = ''
    state = ''
    zipcode = ''
    names = ''

    with open(city_lookup_path) as f:
        city_lookup = f.readlines()
        city_lookup = [x.strip() for x in city_lookup]
    states = '|'.join(state_list)
    cities = '|'.join(city_lookup)
    cities = cities.replace(' ', '\s')

    name_match = re.search('^(([A-Za-z\,?\s&-\.\/]+)(\,|\s))', address_text)
    if name_match:
        names = name_match.group(2)
        address_text = address_text.replace(name_match.group(1), '')

    zipcode_match = re.search('((\s|,)([0-9]{5,})(\s|,)?)$', address_text, re.IGNORECASE)
    if zipcode_match:
        zipcode = zipcode_match.group(3)
        address_text = address_text.replace(zipcode_match.group(1), '')

    state_match = re.search('((\s|,)(' + states + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if state_match:
        state = state_match.group(3)
        address_text = address_text.replace(state_match.group(1), '')

    city_match = re.search('((\s|,)(' + cities + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if city_match:
        city = city_match.group(3)
        address_text = address_text.replace(city_match.group(1), '')

    address = address_text
    address = address.strip(', ')

    add_dict.update({'names': names})
    add_dict.update({'address': address})
    add_dict.update({'city': city})
    add_dict.update({'state': state})
    add_dict.update({'zipcode': zipcode})

    return add_dict

"""
This Function using patterns, splits name and address into "names, address, city, state, zipcode".

Args:
address_text:       string
                    Name address text / address text to split.
                    
city_lookup_path:   string 
                    The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_pattern(address_text):
    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': ''}
    
    name_address_match = re.search("^([A-Za-z\,?\s&-\.\/]+)(\,?\s(([0-9\s]{2,}\s([A-Za-z0-9#\s]+))\,?\s([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9\s]{5,10}))?)$",
        address_text)
    address_match = re.search(
        "^((([0-9]{2,}\s([A-Za-z0-9#\s]+))(\,|\s)([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9]{5}))?)$", address_text)
    if name_address_match:
        name = name_address_match.group(1)
        name = name.strip(',')
        add_dict.update({'name': name})
        add_dict.update({'address': name_address_match.group(4)})
        add_dict.update({'city': name_address_match.group(6)})
        add_dict.update({'state': name_address_match.group(7)})
        add_dict.update({'zipcode': name_address_match.group(9)})
        return add_dict
    elif address_match:
        add_dict.update({'address': address_match.group(3)})
        add_dict.update({'city': address_match.group(6)})
        add_dict.update({'state': address_match.group(7)})
        add_dict.update({'zipcode': address_match.group(9)})
        return (add_dict)
    else:
        return None




"""------------------------------------NAME SPLIT LOGIC---------------------------------------------------------------"""
"""
Update the coordinates in the xml to match with coordinates in the image.

Args:
new_name_list: list
               List consisting of name strings.

add_dict: Dictionary
          It consists of label name as key and text as value.
          Eg: 'first_name' is considered as key and corresponding text as value.


Returns:
add_dict: Dictionary
          Updated dictionary with values detected from name list is returned to the function.
"""

def name_split(new_name_list, add_dict):
    suffix_list = ['BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC', 'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                   'ESQ', 'II', 'III', 'IV', 'INC', 'JD', 'JR', 'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                   'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM', 'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                   'USCG', 'USMC', 'USMCR']
    first_name = ' '
    middle_name = ' '
    last_name = ' '
    suffix_name = ' '
    index = common_util.check_comma(new_name_list)
    n = len(new_name_list)
    temp_suffix = new_name_list[n - 1].upper()
    suffix = re.sub(r'[^a-zA-Z]', '', temp_suffix)
    if (suffix in suffix_list):
        new_name_list.remove(temp_suffix)
        suffix_name = common_util.cleaning(temp_suffix)
    if (len(new_name_list) == 2 and len(index) == 0):
        first_name = new_name_list[0]
        last_name = new_name_list[1]
    elif (len(new_name_list) == 2 and len(index) == 1 and index[0] == 0):
        first_name = new_name_list[1]
        last_name = new_name_list[0]
    elif (len(new_name_list) >= 3 and len(index) == 0):
        first_name = new_name_list[0]
        middle_name = new_name_list[1]
        last_name = ''
        for n in range(2, len(new_name_list), 1):
            last_name = last_name + new_name_list[n] + ' '  

    elif (len(new_name_list) >= 3 and len(index) == 1):

        first_name = new_name_list[index[0] + 1]

        middle_name = ''
        for n in range(index[0] + 2, len(new_name_list), 1):
            middle_name = middle_name + new_name_list[n] + ' '

        last_name = ''
        for n in range(index[0] + 1):
            last_name = last_name + new_name_list[n] + ' '


    elif (len(new_name_list) >= 3 and len(index) == 2):
        first_name = ''

        for n in range(index[0] + 1):
            first_name = first_name + new_name_list[n] + ' '

        middle_name = new_name_list[index[0] + 1]

        last_name = ''
        for n in range(index[0] + 2, len(new_name_list), 1):
            last_name = last_name + new_name_list[n] + ' '

    first_name = common_util.cleaning(first_name)
    middle_name = common_util.cleaning(middle_name)
    last_name = common_util.cleaning(last_name)
    suffix_name = common_util.cleaning(suffix_name)
    add_dict.update({'first_name': first_name.upper()})
    add_dict.update({'middle_name': middle_name.upper()})
    add_dict.update({'last_name': last_name.upper()})
    add_dict.update({'suffix_name': suffix_name.upper()})
    add_dict.update({'name': ' '.join([str(elem) for elem in new_name_list])})
    return (add_dict)

def name_split_using_pattern(name_text, name_order='', ischecked = False):
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}

    # =====================================
    # Business name - logic
    if ischecked == True:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict

    business_name_match = re.search('\\b(Holdings|LLC|INC|CORP|COMPANY|ENVIROMENTAL|HYUNDAI|TRANSPORTATION|GROUP|CO|INCORPORATED)\\b',name_text, re.IGNORECASE)
    if business_name_match:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict
    # =====================================

    suffix_list = ['JR', 'BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC', 'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                   'ESQ', 'II', 'III', 'IV', 'INC', 'JD', 'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                   'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM', 'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                   'USCG', 'USMC', 'USMCR']
    suffix_found = ''
    for suffix in suffix_list:
        suffix_match = re.search(r'\b' + suffix + r'\b', name_text, re.IGNORECASE)
        if suffix_match:
            suffix_found = suffix_match.group(0)
            name_text = re.sub('(\s)' + suffix_match.group(0), '', name_text, re.IGNORECASE)
            name_text = re.sub(suffix_match.group(0) + '(\s)', '', name_text, re.IGNORECASE)
            break

    name_match_1 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_2 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_3 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_4 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_5 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  
    name_match_6 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+\s+[A-Za-z]+))$", name_text)
    name_match_7 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text) 
    name_match_8 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  
    name_match_9 = re.search("^(([A-Za-z]+),\s*([A-Za-z]+)\s+([A-Z]\s?\.\s?[A-Za-z]+))$", name_text) 
    name_match_10 = re.search("^(([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{1}))$", name_text)  
    name_match_11 = re.search("^(([A-Za-z]{3,}\s*-\s*[A-Za-z]{3,})\s+([A-Za-z]{3,}))$", name_text) 
    name_match_12 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text) 
    name_match_13 = re.search("^(([A-Za-z]+)\s*\,\s*([A-Za-z]+\s+[A-Za-z]+)\s*\,\s*([A-Za-z]+))$", name_text) 
    if name_match_1:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_1, add_dict)
        else:
            add_dict.update({'first_name': name_match_1.group(2).upper()})
            add_dict.update({'last_name': name_match_1.group(3).upper()})
    elif name_match_2:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_2, add_dict)
        else:
            add_dict.update({'first_name': name_match_2.group(2).upper()})
            add_dict.update({'middle_name': name_match_2.group(3).upper()})
            add_dict.update({'last_name': name_match_2.group(4).upper()})
    elif name_match_10:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_10, add_dict)
        else:
            add_dict.update({'first_name': name_match_10.group(2).upper()})
            add_dict.update({'middle_name': name_match_10.group(3).upper() + ' ' + name_match_10.group(5).upper()})
            add_dict.update({'last_name': name_match_10.group(4).upper()})
    elif name_match_3:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_3, add_dict)
        else:
            add_dict.update({'first_name': name_match_3.group(2).upper()})
            add_dict.update({'middle_name': name_match_3.group(3).upper()})
            add_dict.update({'last_name': name_match_3.group(4).upper() + ' ' + name_match_3.group(5).upper()})
    elif name_match_4:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_4, add_dict)
        else:
            add_dict.update({'first_name': name_match_4.group(3).upper()})
            add_dict.update({'middle_name': name_match_4.group(4).upper()})
            add_dict.update({'last_name': name_match_4.group(2).upper()})
    elif name_match_5:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_5, add_dict)
        else:
            add_dict.update({'first_name': name_match_5.group(2).upper()})
            add_dict.update({'middle_name': name_match_5.group(3).upper()})
            add_dict.update({'last_name': name_match_5.group(4).upper()})
    elif name_match_6:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_6, add_dict)
        else:
            add_dict.update({'first_name': name_match_6.group(3).upper()})
            add_dict.update({'middle_name': name_match_6.group(4).upper()})
            add_dict.update({'last_name': name_match_6.group(2).upper()})
    elif name_match_7:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_7, add_dict)
        else:
            add_dict.update({'first_name': name_match_7.group(3).upper()})
            add_dict.update({'last_name': name_match_7.group(2).upper()})
    elif name_match_8:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_8, add_dict)
        else:
            add_dict.update({'first_name': name_match_8.group(3).upper()})
            add_dict.update({'last_name': name_match_8.group(2).upper()})
    elif name_match_9:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_9, add_dict)
        else:
            add_dict.update({'first_name': name_match_9.group(3).upper()})
            add_dict.update({'middle_name': name_match_9.group(4).upper()})
            add_dict.update({'last_name': name_match_9.group(2).upper()})
    elif name_match_11:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_11, add_dict)
        else:
            add_dict.update({'first_name': name_match_11.group(3).upper()})
            add_dict.update({'last_name': name_match_11.group(2).upper()})
    elif name_match_12:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_12, add_dict)
        else:
            add_dict.update({'first_name': name_match_12.group(3).upper()})
            add_dict.update({'middle_name': name_match_12.group(4).upper()})
            add_dict.update({'last_name': name_match_12.group(2).upper()})
    elif name_match_13:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_13, add_dict)
        else:
            add_dict.update({'first_name': name_match_13.group(2).upper()})
            add_dict.update({'middle_name': name_match_13.group(3).upper()})
            add_dict.update({'last_name': name_match_13.group(4).upper()})
    else:
        add_dict.update({'last_name': name_text.upper()})

    add_dict.update({'suffix': suffix_found.upper()})
    add_dict.update({'name': name_text.upper()})

    return add_dict

def name_split_in_given_order(name_order, name_match, add_dict):
    if name_order == 'FML':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'last_name': name_match.group(3).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
    if name_order == 'LFM':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})

def find_address_text(xml_tree, bb_coord, c, label):
    add_list = []
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        coord = (elem.attrib['xMin'], elem.attrib['yMin'], elem.attrib['xMax'], elem.attrib['yMax'])
        ocr_coord = text_extract.update_coord(coord, c)
        result_text = text_extract.check_text_in_BB(ocr_coord, bb_coord, elem.text)
        if (result_text is not None and result_text != ''):
            if 'OwnerLesseeNameAddress' in label and re.match("^([0-9]+)$", result_text):
                return add_list
            add_list.append([float(elem.attrib['xMin']), result_text])
    return (add_list)
