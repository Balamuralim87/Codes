import re

"""
Remove the unwanted text and unicode characters in the string format of xml to improve the text extraction process.

Args:
xml_str: String 
         XML in the string form
Returns:
xml_str: String
         New XML obtained after the process.
"""    
    
def str_replace_xml(xml_str):
    xml_str=xml_str.replace('http://www.w3.org/1999/xhtml','')
    xml_str=xml_str.replace('❑','')
    xml_str=xml_str.replace('•','')
    xml_str=xml_str.replace('■','')
    xml_str = xml_str.replace("</body>\n</html>\n</body>\n</html>", '</body>\n</html>')
    return(xml_str)


"""
Check whether given string consists of alphabets or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains alphabet or not
       
Returns:
flag: Boolean
      It return True if there is alphabet character in the given string else it returns False
      
text : String
       Updated text is returned to the function.
"""    
    

def check_text(text):
    flag = False
    for i in text:
        if(i.isalpha()):
            flag = True
            return(flag,text)
        elif(i.isdigit() and i=='3'):
            text = text.replace(i,'J')
            flag = True
            return(flag,text)
        elif(i.isdigit() and i=='1'):
            text = text.replace(i,'I')
            flag = True 
            return(flag,text)
        else:
            flag =False
    return(flag,text)


    
"""
Check whether given string consists of digit or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains digit or not
       
Returns:
flag: Boolean
      It return True if there is digit character in the given string else it returns False
      
"""

def check_digit(text):
    flag = False
    for i in text:
        if(i.isdigit()):
            flag = True
            return(flag)
        else:
            flag =False
    return(flag)


    
"""
Check whether given string consists of alphabet/digit or not and returns boolean value accordingly.

Args:
text : String
       Input string to check whether it contains alphabet/digit or not
       
Returns:
flag: Boolean
      It return True if there is alphabet/digit character in the given string else it returns False
      
"""
       
def check_alnum(text):
    for i in text:
        if (i.isalnum()):
            return True
        else:
            return False

"""
Check whether given list of strings contain comma or not and returns index list where the comma is present.

Args:
new_name_list : list
               List consisting of name strings.
       
Returns:
index: list
       List of indices which contain comma in the string.
      
"""

def check_comma(new_name_list):
    index = []
    for name in new_name_list:
        if(name.find(',')!=-1):
            index.append(new_name_list.index(name))
    return(index)

"""
Remove unnecessary special charcters and spaces and some cleaning to improve text quality.

Args:
text : String
       Input string for cleaning.
       
Returns:
text : String
       Updated text is returned to the function.
""" 


def cleaning(text):
    if text != None:
        text = text.replace(',', ' ')
        text = text.replace('_', ' ')
        text = re.sub(r'^[\W\.\_]*', '', text)
        text = re.sub(r'\W*$', '', text)
        if ((re.match("[a-zA-Z0-9]*", text)) == None):
            text = ''
        text = re.sub(r"(\d+)\s(-)\s(\d+)", r"\1\2\3", text.rstrip())
        text = re.sub(r"(\d+)(-)\s(\d+)", r"\1\2\3", text.rstrip())
        text = re.sub(r"(\d+)\s(-)(\d+)", r"\1\2\3", text.rstrip())
        text = re.sub(r"(\d+)\s(\d+)", r"\1\2", text.rstrip())
        text = re.sub(r"(\s){2,}", ' ', text.rstrip())  
        text = re.sub(r"\|", '', text.rstrip())  
        char_check_end = re.compile('[(]')
        if (char_check_end.search(text) != None):
            text = text + ')'
        char_check_beg = re.compile('[)]')
        if (char_check_beg.search(text) != None):
            if (char_check_end.search(text) == None):
                text = '(' + text
        return (text)