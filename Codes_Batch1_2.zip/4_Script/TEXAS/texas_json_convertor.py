# -*- coding: utf-8 -*-
"""
Created on Wed Feb 18 19:01:30 2019

@author: 203367

This script is a utility to convert model predicted data to JSON format.
"""

from typing import List
import json
import re
import tqdm
import os
import pandas as pd
import requests

page_df = None

class Violation_Code(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class TransportedTo(object):
    def __init__(self, unit_num:str, prsn_num: str, transported_to: str):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.transported_to = transported_to

class CitationsDetails(object):
    def __init__(self, unit_num:str, prsn_num: str, Citation_Detail: str, Violation_Code: Violation_Code):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code

class ContributingFactorDetails(object):
    def __init__(self, unit_num: str, Contributing_Factors: List):
        self.unit_num = unit_num
        self.Contributing_Factors = Contributing_Factors

class Weather_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Road_Surface_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Restraint(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Helmet(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Alcohol_Test_Type(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Drug_Test_Type(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Contributing_Circumstances_Person(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Contributing_Circumstances_Vehicle(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Citations(object):
    def __init__(self, Citation_Type: str, Citation_Issued: str, Citation_Detail: str, Violation_Code: Violation_Code, Party_Id: str, Unit_Number: str):
        self.Citation_Type = Citation_Type
        self.Citation_Issued = Citation_Issued
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code
        self.Party_Id = Party_Id
        self.Unit_Number = Unit_Number

class Incident(object):
    def __init__(self, Report_Date: str, Crash_Date: str, Case_Identifier: str, State_Report_Number: str, Crash_City: str,
                 Loss_Street: str, Loss_Cross_Street: str, Latitude: str, Longitude: str, Loss_State_Abbr: str,
                Report_Type_Id:str, Gps_Other:str, Fatality_Involved:str, Incident_Hit_and_Run:str, Dispatch_Time:str,
                 Weather_Condition: List[Weather_Condition], Road_Surface_Condition: List[Road_Surface_Condition],
                 Loss_Cross_Street_Speed_Limit: str):
        self.Report_Date = Report_Date
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Fatality_Involved = Fatality_Involved
        self.Incident_Hit_and_Run = Incident_Hit_and_Run
        self.Dispatch_Time = Dispatch_Time
        self.Weather_Condition = Weather_Condition
        self.Road_Surface_Condition = Road_Surface_Condition
        self.Loss_Cross_Street_Speed_Limit = Loss_Cross_Street_Speed_Limit

class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations

class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: int, First_Name: str, Middle_Name: str, Last_Name: str,
                Name_Suffix: str, Address:str, Address2:str, City:str, State:str, Zip_Code: str, Home_Phone: str,
                Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str, Injury_Status:str,
                 Safety_Equipment_Restraint:List[Safety_Equipment_Restraint], Safety_Equipment_Helmet:List[Safety_Equipment_Helmet],
                 Ejection: str, Transported_To: str, Alcohol_Test_Type:List[Alcohol_Test_Type], Drug_Test_Type:List[Drug_Test_Type],
                 Contributing_Circumstances_Person: List[Contributing_Circumstances_Person]):
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        self.Safety_Equipment_Restraint = Safety_Equipment_Restraint
        self.Safety_Equipment_Helmet = Safety_Equipment_Helmet
        self.Ejection = Ejection
        self.Transported_To=Transported_To
        self.Alcohol_Test_Type=Alcohol_Test_Type
        self.Drug_Test_Type =Drug_Test_Type
        self.Contributing_Circumstances_Person = Contributing_Circumstances_Person

class Vehicles(object):
    def __init__(self, VinValidation_VinStatus: str, Unit_Number:str, License_Plate: str, Registration_State: str, VIN:str,
                 Vehicle_Towed: str, Model_Year: str, Make: str, Model: str, Insurance_Company: str, Insurance_Policy_Number:str,
                 Insurance_Expiration_Date: str, Damaged_Areas:str, Air_Bag_Deployed:str, Party_Id:str,
                 Contributing_Circumstances_Vehicle:List[Contributing_Circumstances_Vehicle]):
        self.VinValidation_VinStatus = VinValidation_VinStatus
        self.Unit_Number = Unit_Number
        self.License_Plate = License_Plate
        self.Registration_State = Registration_State
        self.VIN = VIN
        self.Vehicle_Towed= Vehicle_Towed
        self.Model_Year = Model_Year
        self.Make = Make
        self.Model= Model
        self.Insurance_Company = Insurance_Company
        self.Insurance_Policy_Number=Insurance_Policy_Number
        self.Insurance_Expiration_Date=Insurance_Expiration_Date
        self.Damaged_Areas=Damaged_Areas
        self.Air_Bag_Deployed=Air_Bag_Deployed
        self.Party_Id=Party_Id
        self.Contributing_Circumstances_Vehicle=Contributing_Circumstances_Vehicle

class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report

def get_inner_details(second_page_df, label_name, unit_num, prsn_num):
    if len(second_page_df) > 0:
        for i, j in second_page_df.iterrows():
            if j.label == label_name and (label_name == 'ContributingFactor' or label_name == 'VehiDefects_Contrib'):
                if j.value.unit_num == unit_num:
                    return j.value.Contributing_Factors
            elif j.label == label_name:
                if j.value.prsn_num == prsn_num and j.value.unit_num == unit_num:
                    return  j.value
    return ''

def is_object_has_values(user_object):
    #if user_object.Party_Id == '' and user_object.Person_Type =='' and user_object.First_Name =='' and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == ''  and user_object.Drivers_License_Jurisdiction =='':
    if user_object.Injury_Status == '' and (user_object.First_Name == '' or user_object.Last_Name == '') and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == '' and user_object.Drivers_License_Jurisdiction == '':
        return False
    else:
        return True

def person_details_extraction(second_page_df, people_list):
    UnitNumList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), page_df['label']))

    for unit in UnitNumList:
        OwnerFlag = 1
        unit_num = re.sub(r'^((UnitNum)([0-9]))$', r'\3', unit)

        for row in range(1, 5):
            is_owner_same_as_driver = False
            OwnerName = ''
            prsn_type = get_value_from_df('U' + unit_num + '_PrsnType' + str(row))
            person_type = ''
            Date_Of_Birth = ''
            Drivers_License_Number = ''
            Drivers_License_Jurisdiction = ''
            Address = ''
            City = ''
            State =''
            ZipCode = ''

            Safety_Equipment_Restraint_List = []
            Safety_Equipment_Helmet_List = []
            Alcohol_Test_Type_List = []
            Drug_Test_Type_List = []
            Contributing_Circumstances_Person_List = []

            person_num = get_value_from_df('U' + unit_num + '_PersonNum' + str(row))
            TransportedTo = get_inner_details(second_page_df, 'TransferedToDetail', unit_num, person_num)
            Transported_To =''
            if TransportedTo != '':
                Transported_To = TransportedTo.transported_to

            if prsn_type == '1':
                person_type = 'DRIVER'
                Date_Of_Birth = get_value_from_df('DOB' + unit_num)
                Date_Of_Birth = date_fomat_maker(Date_Of_Birth)
                Drivers_License_Number = get_value_from_df('DL_ID_Num' + unit_num)
                Drivers_License_Jurisdiction = get_value_from_df('DL_ID_State' + unit_num)
                Address = get_value_from_df('Address' + unit_num + '_address')
                if Address == '':
                    Address = get_value_from_df('Address' + unit_num)
                City = get_value_from_df('Address' + unit_num + '_city')
                State = get_value_from_df('Address' + unit_num + '_state')
                ZipCode = get_value_from_df('Address' + unit_num + '_zipcode')
                OwnerName = get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_name')
                if OwnerName != None:
                    OwnerName = OwnerName.replace(',', '')
                    OwnerName = OwnerName.replace('s ', '')
                DriverName = get_value_from_df('U' + unit_num + '_Name' + str(row))

                if DriverName != '' and OwnerName != '' and OwnerName != None:
                    if OwnerName.lower() == DriverName.lower():
                        is_owner_same_as_driver = True

                Safety_Equipment_Restraint_List.append(
                    Safety_Equipment_Restraint(get_value_from_df('U' + unit_num + '_Restr' + str(row)), ''))
                Safety_Equipment_Helmet_List.append(
                    Safety_Equipment_Helmet(get_value_from_df('U' + unit_num + '_Helmet' + str(row)), ''))
                Alcohol_Test_Type_List.append(
                    Alcohol_Test_Type(get_value_from_df('U' + unit_num + '_AlcSpec' + str(row)), ''))
                Drug_Test_Type_List.append(
                    Drug_Test_Type(get_value_from_df('U' + unit_num + '_AlcSpec' + str(row)), ''))

                ContributingFactors = get_inner_details(second_page_df, 'ContributingFactor', unit_num, '')
                if ContributingFactors != '':
                    Contributing_Circumstances_Person_List.append(
                        Contributing_Circumstances_Person(ContributingFactors, ''))

            elif prsn_type == '2':
                person_type = 'PASSENGER'
            elif prsn_type == '3':
                person_type = 'PEDALCYCLIST'
            elif prsn_type == '4':
                person_type = 'PEDESTRIAN'
            elif prsn_type == '5':
                person_type = 'WITNESS'
            elif prsn_type == '99':
                person_type = 'UNKNOWN'

            people_info = People(Party_Id=person_num,
                                 Person_Type=person_type,
                                 Unit_Number=get_value_from_df('UnitNum' + unit_num),
                                 First_Name=get_value_from_df('U' + unit_num + '_Name' + str(row) + '_first_name'),
                                 Middle_Name=get_value_from_df('U' + unit_num + '_Name' + str(row) + '_middle_name'),
                                 Last_Name=get_value_from_df('U' + unit_num + '_Name' + str(row) + '_last_name'),
                                 Name_Suffix=get_value_from_df('U' + unit_num + '_Name' + str(row) + '_suffix'),
                                 Address=Address,
                                 Address2='',
                                 City=City,
                                 State=State,
                                 Zip_Code=ZipCode,
                                 Home_Phone='',
                                 Date_Of_Birth=Date_Of_Birth,
                                 Drivers_License_Number=Drivers_License_Number,
                                 Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                                 Injury_Status=get_value_from_df('U' + unit_num + '_InjurySeverity' + str(row)),
                                 Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                                 Safety_Equipment_Helmet=Safety_Equipment_Helmet_List,
                                 Ejection=get_value_from_df('U' + unit_num + '_Eject' + str(row)),
                                 Transported_To=Transported_To,
                                 Alcohol_Test_Type=Alcohol_Test_Type_List,
                                 Drug_Test_Type=Drug_Test_Type_List,
                                 Contributing_Circumstances_Person = Contributing_Circumstances_Person_List
                                 )

            if is_object_has_values(people_info) == True:
                people_list.append(people_info)

            if is_owner_same_as_driver == True and OwnerFlag == 1:
                OwnerFlag = 0
                people_info = People(# Party_Id=person_num,
                                     Party_Id = '1',
                                     Person_Type='VEHICLE OWNER',
                                     Unit_Number=get_value_from_df('UnitNum' + unit_num),
                                     First_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_first_name'),
                                     Middle_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_middle_name'),
                                     Last_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_last_name'),
                                     Name_Suffix=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_suffix'),
                                     Address=Address,
                                     Address2='',
                                     City=City,
                                     State=State,
                                     Zip_Code=ZipCode,
                                     Home_Phone='',
                                     Date_Of_Birth=Date_Of_Birth,
                                     Drivers_License_Number=Drivers_License_Number,
                                     Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                                     Injury_Status=get_value_from_df('U' + unit_num + '_InjurySeverity' + str(row)),
                                     Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                                     Safety_Equipment_Helmet=Safety_Equipment_Helmet_List,
                                     Ejection=get_value_from_df('U' + unit_num + '_Eject' + str(row)),
                                     Transported_To=Transported_To,
                                     Alcohol_Test_Type=Alcohol_Test_Type_List,
                                     Drug_Test_Type=Drug_Test_Type_List,
                                     Contributing_Circumstances_Person=Contributing_Circumstances_Person_List
                                     )
                if is_object_has_values(people_info) == True:
                    people_list.append(people_info)
            else:
                OwnerAddress = get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_address')
                if OwnerName != '' or OwnerAddress != '' and OwnerFlag == 1:
                    OwnerFlag = 0
                    people_info = People(# Party_Id=person_num,
                                         Party_Id = '1',
                                         Person_Type='VEHICLE OWNER',
                                         Unit_Number=get_value_from_df('UnitNum' + unit_num),
                                         First_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_first_name'),
                                         Middle_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_middle_name'),
                                         Last_Name=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_last_name'),
                                         Name_Suffix=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_suffix'),
                                         Address=OwnerAddress,
                                         Address2='',
                                         City=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_city'),
                                         State=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_state'),
                                         Zip_Code=get_value_from_df('OwnerLesseeNameAddress' + unit_num + '_zipcode'),
                                         Home_Phone='',
                                         Date_Of_Birth='',
                                         Drivers_License_Number='',
                                         Drivers_License_Jurisdiction='',
                                         Injury_Status='',
                                         Safety_Equipment_Restraint=[],
                                         Safety_Equipment_Helmet=[],
                                         Ejection='',
                                         Transported_To='',
                                         Alcohol_Test_Type=[],
                                         Drug_Test_Type=[],
                                         Contributing_Circumstances_Person=[]
                                         )

                    if is_object_has_values(people_info) == True:
                        people_list.append(people_info)

def vehicle_details_extraction(second_page_df, vehicle_list):
    UnitNumList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), page_df['label']))

    for unit in UnitNumList:
        Contributing_Circumstances_Vehicle_List = []
        unit_num = re.sub(r'^((UnitNum)([0-9]))$', r'\3', unit)

        ContributingFactorsVehicle = ''

        if len(second_page_df) > 0:
            ContributingFactorsVehicle = get_inner_details(second_page_df, 'VehiDefects_Contrib', unit_num, '')
        if ContributingFactorsVehicle != '':
            Contributing_Circumstances_Vehicle_List.append(Contributing_Circumstances_Vehicle(ContributingFactorsVehicle, ''))
        VIN = get_value_from_df('VIN' + unit_num)
        VIN = VIN.replace(' ', '')

        ModelYear = get_value_from_df('VehYear' + unit_num)
        ModelYear = ModelYear.replace(' ', '')

        # ============================================
        # Vehicle damaged ratings
        damaged_area_desc = get_value_from_df('U' + unit_num + '_VehicleDamageRating1')
        damaged_area_code = re.sub('[0-9\-\s]+', '', damaged_area_desc)
        damage_ratings_dic = {'FD': 'Front', 'FC': 'Front', 'FL': 'Left Front', 'LFQ': 'Left Front', 'LBQ': 'Left Rear',
                              'BL': 'Left Rear', 'LD': 'Left Side', 'LP': 'Left Side', 'L&T': 'Left Side', 'BC': 'Rear',
                              'BD': 'Rear', 'FR': 'Right Front', 'RFQ': 'Right Front', 'RBQ': 'Right Rear', 'BR': 'Right Rear',
                              'RD': 'Right Side', 'RP': 'Right Side', 'R&T': 'Right Side'}
        found_damage_rating = list(filter(lambda x: x == damaged_area_code, damage_ratings_dic.keys()))
        if len(found_damage_rating) == 1:
            damaged_area_desc = damage_ratings_dic[found_damage_rating[0]]
        # ============================================

        # ============================================
        # Vehicle towed by and to
        vehicle_make = get_value_from_df('VehMake' + unit_num)
        vehicle_model = get_value_from_df('VehModel' + unit_num)
        license_plate = get_value_from_df('LP_Num' + unit_num)
        towed_by = get_value_from_df('TowedBy' + unit_num)
        towed_to = get_value_from_df('TowedTo' + unit_num)
        towed_by_to = towed_by + ' ' + towed_to
        towed_by_to = towed_by_to.lower()
        towed_status = ''
        if 'driver' in towed_by_to or 'left' in towed_by_to or 'scene' in towed_by_to or 'not towed' in towed_by_to \
                or 'owner' in towed_by_to or (towed_by_to == '' and vehicle_make != '' and vehicle_model != '' and license_plate != ''):
            towed_status = '0'
        elif 'N/A' in towed_by_to or 'NA' in towed_by_to or 'Unknown' in towed_by_to \
                or (towed_by_to == ' ' and vehicle_make == '' and vehicle_model == '' and license_plate == ''):
            towed_status = ''
        elif towed_by_to == ' ':
            towed_status = ''
        else:
            towed_status = '1'
        # ============================================

        vehicle = Vehicles(
            VinValidation_VinStatus = 'V',
            Unit_Number = get_value_from_df('UnitNum' + unit_num),
            License_Plate = license_plate,
            Registration_State=get_value_from_df('LP_State' + unit_num),
            VIN = VIN,
            Vehicle_Towed = towed_status,
            Model_Year = ModelYear,
            Make = vehicle_make,
            Model = vehicle_model,
            Insurance_Company = get_value_from_df('FinRespName' + unit_num),
            Insurance_Policy_Number = get_value_from_df('FinRespNum' + unit_num),
            Insurance_Expiration_Date='',
            Damaged_Areas =  damaged_area_desc,
            Air_Bag_Deployed = get_value_from_df('U' + unit_num + '_Airbag1'),
            #Party_Id = get_value_from_df('U' + unit_num + '_PersonNum1'),
			Party_Id = '1',
            Contributing_Circumstances_Vehicle = Contributing_Circumstances_Vehicle_List,
        )


        if_object_empty = False
        if vehicle.License_Plate == '' and vehicle.Registration_State == '' and vehicle.Make == '' \
                and vehicle.Damaged_Areas == '' and vehicle.Model == '' and vehicle.VIN == '':
            if_object_empty = True

        if if_object_empty == False:
            vehicle_list.append(vehicle)

    return vehicle_list


def get_value_from_df(label_name):
    if len(page_df.loc[page_df['label'] == label_name]) > 0:
        value = page_df.loc[page_df['label'] == label_name]['text'].iloc[0]
        if str(value) != 'nan':
            return value
        else:
            return ''
    else:
        return ''

def date_fomat_maker(date):
    new_date = ''
    if date != '':
        date = date.replace(' ', '')
        date_match = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{4}))$', date)
        date_match2 = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{3}))$', date)
        if date_match:
            new_date = date_match.group(2) + '/' + date_match.group(4) + '/'  + date_match.group(5)
        elif date_match2:
            new_date = date_match2.group(2) + '/' + date_match2.group(4) + '/' + date_match2.group(5)
        else:
            new_date = date
    return new_date

def second_page_extraction():
    second_page_details_list = []
    Weather_Condition_1 = Weather_Condition(get_value_from_df('WeatherCond'), '')

    Road_Surface_Condition_1 = Road_Surface_Condition(get_value_from_df('SurfaceCondition'), '')

    second_page_details_list.append(('Weather_Condition_1', Weather_Condition_1))
    second_page_details_list.append(('Road_Surface_Condition_1', Road_Surface_Condition_1))

    UnitNumList = list(filter(lambda x: re.search(r'^(T1_UnitNum[0-9])$', x), page_df['label']))

    for unit in UnitNumList:
        unit_num = re.sub(r'^((T1_UnitNum)([0-9]))$', r'\3', unit)
        T1_Unit_Number = get_value_from_df('T1_UnitNum' + unit_num)
        T1_Person_Num = get_value_from_df('T1_PrsnNum' + unit_num)
        Transported_To = get_value_from_df('TakenTo' + unit_num)
        if T1_Unit_Number != '' or T1_Person_Num != '' or Transported_To != '':
            TransportedToDetail = TransportedTo(T1_Unit_Number, T1_Person_Num, Transported_To)
            second_page_details_list.append(('TransferedToDetail', TransportedToDetail))

        T2_Unit_Number = get_value_from_df('T2_UnitNum' + unit_num)
        T2_Person_Num = get_value_from_df('T2_PrsnNum' + unit_num)
        Citation = get_value_from_df('Charge' + unit_num)
        Violation = Violation_Code(get_value_from_df('CitationReferenceNum' + unit_num), '')
        if T2_Unit_Number != '' or T2_Person_Num != '' or Citation != '' or Violation != '':
            CitationsDetail = CitationsDetails(T2_Unit_Number, T2_Person_Num, Citation, Violation)
            second_page_details_list.append(('CitationsDetail', CitationsDetail))

        for row in range(1,4):
            Unit_Number = get_value_from_df('Unit' + unit_num)
            ContributingFactor = get_value_from_df('ContributingFactor_R' + unit_num + '_' + str(row))
            if Unit_Number != '' or ContributingFactor != '':
                ContributingFactorsDetail = ContributingFactorDetails(Unit_Number, ContributingFactor)
                second_page_details_list.append(('ContributingFactor', ContributingFactorsDetail))

        for row in range(1,4):
            Unit_Number = get_value_from_df('Unit' + unit_num)
            ContributingFactor = get_value_from_df('VehiDefects_Contrib' + unit_num + '_' + str(row))
            if Unit_Number != '' or ContributingFactor != '':
                ContributingFactorsDetail = ContributingFactorDetails(Unit_Number, ContributingFactor)
                second_page_details_list.append(('VehiDefects_Contrib', ContributingFactorsDetail))

    second_page_df = pd.DataFrame(second_page_details_list, columns=['label', 'value'])

    return second_page_df

def first_page_extraction(second_page_df, people_list, vehicle_list):
    HitRunList = list(filter(lambda x: 'HitAndRun' in x, page_df['label']))
    is_checked_count = list(filter(lambda x: re.search(r'(_C)$', x), HitRunList))
    if len(is_checked_count) > 0:
        is_checked = '1'
    else:
        is_checked = ''

    CrashDate = get_value_from_df('CrashDate')
    CrashDate = date_fomat_maker(CrashDate)

    if len(second_page_df) > 0:
        incident = Incident(Report_Date='',
                            Crash_Date=CrashDate,
                            Case_Identifier=get_value_from_df('CaseID'),
                            State_Report_Number=get_value_from_df('TxDOT_Crash_ID'),
                            Crash_City=get_value_from_df('CityName'),
                            Loss_Street=get_value_from_df('StreetName1')+ ' ' +get_value_from_df('StreetSuffix1'),
                            Loss_Cross_Street=get_value_from_df('StreetName2') + ' ' +get_value_from_df('StreetSuffix2'),
                            Latitude=get_value_from_df('Latitude'),
                            Longitude=get_value_from_df('Longitude'),
                            Loss_State_Abbr='TX',
                            Report_Type_Id='A',
                            Gps_Other='',
                            Fatality_Involved='',
                            Incident_Hit_and_Run=is_checked,
                            Dispatch_Time='',
                            Weather_Condition=[
                                second_page_df.loc[second_page_df['label'] == 'Weather_Condition_1']['value'].iloc[0]],
                            Road_Surface_Condition=[
                                second_page_df.loc[second_page_df['label'] == 'Road_Surface_Condition_1']['value'].iloc[0]],
                            Loss_Cross_Street_Speed_Limit=get_value_from_df('SpeedLimit')
                            )
    else:
        Weather_Condition_List = []
        Weather_Condition_List.append(Weather_Condition('', ''))
        Road_Surface_Condition_List = []
        Road_Surface_Condition_List.append(Road_Surface_Condition('', ''))
        incident = Incident(Report_Date='',
                            Crash_Date=CrashDate,
                            Case_Identifier=get_value_from_df('CaseID'),
                            State_Report_Number=get_value_from_df('TxDOT_Crash_ID'),
                            Crash_City=get_value_from_df('CityName'),
                            Loss_Street=get_value_from_df('StreetName1') + ' ' + get_value_from_df('StreetSuffix1'),
                            Loss_Cross_Street=get_value_from_df('StreetName2') + ' ' + get_value_from_df(
                                'StreetSuffix2'),
                            Latitude=get_value_from_df('Latitude'),
                            Longitude=get_value_from_df('Longitude'),
                            Loss_State_Abbr='TX',
                            Report_Type_Id='A',
                            Gps_Other='',
                            Fatality_Involved='',
                            Incident_Hit_and_Run=is_checked,
                            Dispatch_Time='',
                            Weather_Condition=Weather_Condition_List,
                            Road_Surface_Condition=Road_Surface_Condition_List,
                            Loss_Cross_Street_Speed_Limit=get_value_from_df('SpeedLimit')
                            )
    person_details_extraction(second_page_df, people_list)
    vehicle_details_extraction(second_page_df, vehicle_list)

    return incident

def grouping_pages_paths(img_path_list, inner_group_df):
    sorted_path_list = []
    flag = 0
    second_page_path = ''
    first_page_path = ''
    if len(img_path_list) == 1:
        sorted_path_list.append((1, img_path_list[0]))
        return sorted_path_list
    for inner_img in img_path_list:
        page_df = inner_group_df.get_group(inner_img)
        first_page_labels = list(filter(lambda x: 'FinRespName' in x or 'CrashDate' in x or 'SpeedLimit' in x or 'VehMake' in x, page_df.label))

        second_page_labels = list(filter(lambda x: 'ContributingFactor_' in x or 'WeatherCond' in x or 'CrashGraph' in x or 'VehiDefects_Contrib' in x or 'CitationReferenceNum' in x or 'TakenBy' in x or 'Charge', page_df.label))

        if len(first_page_labels) >= 3:
            first_page_path = inner_img
            f_id = 1
        elif len(second_page_labels) >= 3:
            second_page_path = inner_img
            s_id = 2

        if first_page_path != '' and second_page_path != '':
            sorted_path_list.append((s_id + flag, second_page_path))
            sorted_path_list.append((f_id + flag, first_page_path))
            first_page_path = ''
            second_page_path = ''
            flag += 2

    return sorted_path_list
"""
    This Function writes the annoations in a xml format compatible with label me toolself.
    Args:
    data frame: --datafrmae

    Returns:
    Json String: --str
    """

def json_convertion(df):
    global page_df

    img_list = df['path'].unique().tolist()
    group_df = df.groupby('path')

    sorted_paths_list = grouping_pages_paths(img_list, group_df)

    people_list = []
    vehicle_list = []
    incident = None
    second_page_df = pd.DataFrame()

    for pg_id, img in sorted_paths_list:
        page_df = group_df.get_group(img)

        if pg_id == 2 or pg_id == 4 or pg_id == 6:
            second_page_df = second_page_extraction()
        else:
            incident = first_page_extraction(second_page_df, people_list, vehicle_list)

    citations_list = []
    if len(second_page_df) > 0:
        for i, j in second_page_df.iterrows():
            if j.label == 'CitationsDetail':
                CitationsDetail = j.value
                if CitationsDetail.Citation_Detail != '' and CitationsDetail.Violation_Code != '':
                    CitationCls = Citations('', '', CitationsDetail.Citation_Detail, CitationsDetail.Violation_Code,
                                            CitationsDetail.prsn_num, CitationsDetail.unit_num)
                    citations_list.append(CitationCls)

    report = Report(FormName="Universal", CountKeyed=44, Incident=incident, People=people_list, Vehicles=vehicle_list, Citations=citations_list)

    main_cls = MainCls(Report= report)
    data = json.dumps(main_cls, default=lambda o: o.__dict__, indent=4)
    img_name = os.path.basename(img).split('_')[0]
    tif_name=img_name+'.tif'
    return data,tif_name

