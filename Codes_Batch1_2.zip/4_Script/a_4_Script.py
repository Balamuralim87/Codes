import glob
import os
import shutil
import psutil
import time
import datetime
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
import warnings
warnings.filterwarnings('ignore')

import sys, traceback
import requests
import subprocess
os.umask(0x000)

sys.path.append(os.path.join(os.getcwd() ,'TEXAS'))
from TEXAS import Texas_Main, preproceesor

sys.path.append(os.path.join(os.getcwd() ,'TENNESSEE'))
from TENNESSEE import Tennessee_Main

sys.path.append(os.path.join(os.getcwd() ,'WISCONSIN'))
from WISCONSIN import Wisconsin_Main

sys.path.append(os.path.join(os.getcwd() ,'PENNSYLVANIA'))
from PENNSYLVANIA import Pennsylvania_Main

sys.path.append(os.path.join(os.getcwd() ,'OHIO'))
from OHIO import Ohio_Main

#sys.path.append(os.path.join(os.getcwd() ,'NORTH_CAROLINA'))
#from NORTH_CAROLINA import NC_Main


from keras.models import load_model
check_box_model_path = os.path.join(os.getcwd() ,'Model','checkbox_classification.h5')
check_box_model = load_model(check_box_model_path)

# json response and error response url path
url_error = "http://alawpctx329.noam.lnrm.net:8080/ecrash_api/public/api/update-failed-report"
url = "http://alawpctx329.noam.lnrm.net:8080/ecrash_api/public/api/store-auto-extracted-data"

model_out_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/2_Model/Out/"
OCR_out_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/4_Ocr/Ocr_out/"
temp_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Temp/"
text_extraction_out_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Final_Output/"
log_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Log/"
error_file_path = r"/home/developer/deep_learning/ecrash_deployment_noam_server_texas/WatchFolder/5_Extraction/Final_Output/ERROR/Error_Script_4/"


state_dict ={'TX':'TEXAS', 'PA':'PENNSYLVANIA', 'OH':'OHIO', 'TN':'TENNESSEE', 'WI':'WISCONSIN', 'NC':'NORTH CAROLINA'}

current_platform = ''
if sys.platform == 'win32': current_platform = 'win'
if current_platform == 'win':
    model_out_path = r"E:\Samples\8_ECRASH\script4_testing\model_out/"
    OCR_out_path = r"E:\Samples\8_ECRASH\script4_testing\ocr_out/"
    temp_path = r"E:\Samples\8_ECRASH\script4_testing\temp/"
    text_extraction_out_path = r"E:\Samples\8_ECRASH\script4_testing\final_out/"
    log_file_path = r"E:\Samples\8_ECRASH\script4_testing\log/"
    error_file_path = r"E:\Samples\8_ECRASH\script4_testing\error/"

def __move_error_files(csv_file_path, pdf_file_path, error_file_path_today):
    # move files to error folder path
    try:
        tif_file_path = csv_file_path.replace('.csv', '.tif')
        if not os.path.exists(error_file_path_today):
            os.makedirs(error_file_path_today)
        if os.path.exists(csv_file_path):
            shutil.move(csv_file_path, os.path.join(error_file_path_today, os.path.basename(csv_file_path)))
        if pdf_file_path != '' and os.path.exists(pdf_file_path):
            shutil.move(pdf_file_path, os.path.join(error_file_path_today, os.path.basename(pdf_file_path)))
        if os.path.exists(tif_file_path):
            shutil.move(tif_file_path, os.path.join(error_file_path_today, os.path.basename(tif_file_path)))
    except Exception as e:
        print(e)

def __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, traceback_str, errorDesc):
    payload = {"fileName": os.path.basename(pdf_file_path.replace('_tx','_TX')), "errorDesc":errorDesc}
    try:
        session=requests.Session()
        session.trust_env=False
        print('Process : sending error response to API')
        response = session.request("POST", url_error, data=payload)
        print(response.text)
    except Exception as e:
        print('Error : unable to send error_response to API')
        print(e)
    if os.path.exists(error_file_path_today) == False: os.makedirs(error_file_path_today)
    f = open(error_file_path_today + '/' + str(os.path.basename(csv_file_path).split('.')[0]) + '.err', "a")
    f.write(str(today.time()) + '\n' + traceback_str)
    f.close()
    __move_error_files(csv_file_path, pdf_file_path, error_file_path_today)


def __move_sucess_files(csv_file_path, pdf_file_path, folder_today):
    # move files to final out folder path
    try:
        tif_file_path = csv_file_path.replace('.csv', '.tif')
        if os.path.exists(tif_file_path):
            shutil.move(tif_file_path, os.path.join(folder_today, os.path.basename(tif_file_path)))
        if os.path.exists(csv_file_path):
            shutil.move(csv_file_path, os.path.join(folder_today, os.path.basename(csv_file_path)))
        if os.path.exists(pdf_file_path):
            shutil.move(pdf_file_path, os.path.join(folder_today, os.path.basename(pdf_file_path)))
    except Exception as e:
        print(e)


def __json_response(csv_file_name, folder_today, tif_name, pdf_file_path, csv_file_path, error_file_path_today, data):

    json_file_name = csv_file_name + ".json"
    json_path = os.path.join(folder_today, json_file_name)
    with open(json_path, 'w') as f:
        f.write(data)
    payload = {"fileName": tif_name, "entryData": data}
    try:
        session = requests.Session()
        session.trust_env = False
        response = session.request("POST", url, data=payload)
        print(response.text)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        print('Error Message: ' + str(traceback.format_tb(exc_traceback)))
        __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, str(traceback.format_tb(exc_traceback)), 'unable to create json')
        print("Error : Error occured during JSON Conversion - API")


def __save_log(file_log):
    save_log = log_file_path + str(today.day) + '_' + str(today.month) + '_' + str(today.year)
    if not os.path.exists(save_log):
        oldmask = os.umask(0x000)
        os.mkdir(save_log, 0o777)
        os.umask(oldmask)
    f = open(save_log + '/' + str(os.path.basename(csv_file_path).split('.')[0]) + '.log', "a")
    f.write(str(file_log))
    f.close()

if __name__ == "__main__":
    print("\nBucket 4 - Content Extraction Started!\n")
    while True:
        time.sleep(1)
        today = datetime.datetime.today()
        csv_list = glob.glob(model_out_path + '*.csv')
        csv_files_list = []
        for csv_path in csv_list:
            start_time = time.time()
            csv_file_name = str(os.path.basename(csv_path).split('.')[0])
            if csv_file_name not in csv_files_list:
                csv_files_list.append(csv_path)

        for csv_file_path in csv_files_list:
            pdf_file_path = ''
            error_file_path_today = os.path.join(error_file_path, 'text_extraction', str(today.day) + '_' + str(today.month) + '_' + str(today.year))
            folder_today = os.path.join(text_extraction_out_path, str(today.day) + '-' + str(today.month) + '-' + str(today.year))
            file_log = ''
            try:
                csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
                pdf_list = os.listdir(OCR_out_path)
                found_pdf = list(filter(lambda x: str(os.path.basename(x).split('.')[0].lower()) == csv_file_name.lower(),  pdf_list))
                if len(found_pdf) == 1:
                    pdf_file_path = os.path.join(OCR_out_path,os.path.basename(csv_file_name).split('.')[0] + '.pdf')
                else:
                    continue

                if os.path.isfile(csv_file_path) and os.path.isfile(pdf_file_path) :
                    start_time = str(datetime.datetime.now())

                    file_state = os.path.splitext(os.path.basename(csv_file_path))[0].split('_')[-1]
                    if file_state not in state_dict:
                        continue

                    model_name = state_dict[file_state]

                    print('*************************************')
                    print("Process : JSON CONVERSION")
                    print("Process : " + csv_file_name)
                    print("Process : State " + model_name)

                    file_log += 'Process : ' + str(os.path.basename(csv_file_name).split('.')[0]) + '\n'

                    try:
                        print("Process : PDF 2 XML Conversion")
                        file_log += "Process : PDF 2 XML Conversion\n"

                        pdf_file_path = pdf_file_path.replace('_TX','_tx')
                        if current_platform != 'win':
                            mysubproces1 = subprocess.Popen(["sudo","chmod", "777", pdf_file_path])
                            mysubproces1.wait()
                        preproceesor.extract_text(pdf_file_path, temp_path)
                    except:
                        print("Error : Error occured during PDF 2 XML Conversion" )
                        exc_type, exc_value, exc_traceback = sys.exc_info()
                        print(str(traceback.format_tb(exc_traceback)))
                        __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, str(traceback.format_tb(exc_traceback)), 'unable to create json')
                        file_log += "Error : Error occured during PDF 2 XML Conversion\n"
                        file_log += str(traceback.format_tb(exc_traceback)) + '\n'

                    try:
                        file_log += "Process : " + model_name + " main process\n"
                        data = ''
                        tif_name = ''
                        if model_name == 'TEXAS':
                            data, tif_name = Texas_Main.Process(csv_file_path, temp_path)

                        if model_name == 'WISCONSIN':
                            data, tif_name = Wisconsin_Main.Process(csv_file_path, temp_path, check_box_model)

                        if model_name == 'TENNESSEE':
                            data, tif_name = Tennessee_Main.Process(csv_file_path, temp_path)

                        if model_name == 'PENNSYLVANIA':
                            data, tif_name = Pennsylvania_Main.Process(csv_file_path, temp_path, check_box_model)

                        if model_name == 'OHIO':
                            data, tif_name = Ohio_Main.Process(csv_file_path, temp_path, check_box_model)

                        #if model_name == 'NORTH CAROLINA':
                            #data, tif_name = NC_Main.Process(csv_file_path, temp_path, check_box_model)

                        if tif_name == "error":
                            print("Error : Error response from main process")
                            exc_type, exc_value, exc_traceback = data
                            print(str(traceback.format_tb(exc_traceback)))
                            __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, str(traceback.format_tb(exc_traceback)), 'unable to create json')
                            file_log += "Error : " + model_name + " main process\n"
                            file_log += str(traceback.format_tb(exc_traceback)) + '\n'
                        elif tif_name == "invalid":
                            __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, 'invalid file received', 'invalid file received')
                            file_log += "Error : " + model_name + " main process\n"
                            file_log += 'invalid file received' + '\n'
                        else:
                            if os.path.exists(folder_today) == False: os.makedirs(folder_today)
                            file_log += "Process : Sending JSON response\n"
                            print("Process : Sending JSON response")
                            __json_response(csv_file_name, folder_today, tif_name, pdf_file_path, csv_file_path, error_file_path_today, data)
                            __move_sucess_files(csv_file_path, pdf_file_path, folder_today)
                    except:
                        print("Error : Error occured during " + model_name + " Conversion")
                        exc_type, exc_value, exc_traceback = sys.exc_info()
                        print('Error Message: ' + str(traceback.format_tb(exc_traceback)))
                        __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, str(traceback.format_tb(exc_traceback)), 'unable to create json')
                        file_log += "Error : Error occured during " + model_name + " Conversion\n"
                        file_log += str(traceback.format_tb(exc_traceback)) + '\n'

                    end_time = str(datetime.datetime.now())

                    file_log += 'Process : Start Time ' + str(start_time) + '\n'
                    file_log += 'Process : End Time ' + str(end_time) + '\n'
                    file_log += 'Process : Current Time ' + str(datetime.datetime.now()) + '\n'

            except Exception as e:
                print('Error : Main Function')
                exc_type, exc_value, exc_traceback = sys.exc_info()
                print('Error Message: ' + str(traceback.format_tb(exc_traceback)))
                __error_response_in_json(csv_file_path, pdf_file_path, error_file_path_today, str(traceback.format_tb(exc_traceback)), 'unable to create json')
                file_log += "Error : Main Function\n"
                file_log += str(traceback.format_tb(exc_traceback)) + '\n'

            __save_log(file_log)
            processx = psutil.Process(os.getpid())
            print('Memory consumption in GB :',(processx.memory_info().rss)/(1024**3))
            print('*************************************\n')