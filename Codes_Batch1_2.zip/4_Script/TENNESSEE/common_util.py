# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 07:58:47 2020

@author: developer
"""
import re
from fuzzywuzzy import fuzz
from statistics import mode 
import pandas as pd

def get_insurance(text):
    out = ""
    if(len(text) > 0):
        if("NO" in text.upper() or "NOT" in text.upper()):
            out = ""
        else:
            out = text
    else:
        out = ""
    return out

#Validation Functions
def get_loss_cross_street_form1(df):
    try:
        est_distance = get_value_from_df(df,"Incident_Information_Estimated_Distance")
        est_distance = re.sub('[^0-9.]', '', est_distance)
        est_distance = est_distance.strip()
        
        if(len(est_distance) > 0):
            loss_street = ""
        else:
            loss_street = get_value_from_df(df,"Incident_Information_From_Highway_Number_Intersection")
    except:
        loss_street = ""
    return loss_street

def get_loss_cross_street_form3(df):
    try:
        loss_street_full = get_value_from_df(df,"Incident_Information_Location").split(",")[-1]
        if(("FEET" in loss_street_full.upper()) or ("FT" in loss_street_full.upper()) or ("MILES" in loss_street_full.upper())):
            loss_street = ""
        else:
            loss_street = loss_street_full
    except:
        loss_street = ""
    return loss_street


def get_value_from_df(df,label_name):
    if len(df.loc[df['label'] == label_name]) > 0:
        value = df.loc[df['label'] == label_name]['text'].iloc[0]
        if str(value) != 'nan':
            return value.strip()
        else:
            return ''
    else:
        return ''
    
def determine_form_type(df):
    t1_fields = ['Incident_Information_County', 'Commercial_Carrier_Information_Carrier_Type',
                  'Vehicle_Information_Vehicle_Model', 'Approved_By', 'Driver_Information_License_State']
    
    t3_fields = ['Incident_Information_City_County', 'Incident_Information_District',
                  'Incident_Information_Total_Vehicles_Occupants_Killed_Injured', 'Driver_Information_Written_Statement',
                  'Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Officer_Damage_Estimate']
    for label_name in list(df['label'].unique()):
        if(label_name in t1_fields):
            form_type = "form_type_1_2"
            break
        elif(label_name in t3_fields):
            form_type = "form_type_3"
            break

    return form_type


def get_code_desc_from_df(df, label_name):
    default = {"Code" : "", "Description" : ""}
    dic_ = dict()
    value = get_value_from_df(df, label_name)
    code = get_value_from_df(df, label_name+"_code")
    
    try:
    
        if(len(value) > 0):
            dic_["Code"] = code
            dic_["Description"] = value
            return dic_
        else:
            return default
    except:
        return default
    
def get_code_desc_from_dic(dic, label_name):
    default = {"Code" : "", "Description" : ""}
    dic_ = dict()
    value = get_dic_value(dic, label_name)
    code = get_dic_value(dic, label_name+"_code")
    
    try:
    
        if(len(value) > 0):
            dic_["Code"] = code
            dic_["Description"] = value
            return dic_
        else:
            return default
    except:
        return default
    
#SAUGATA    
def map_driver_actions(dic):
    default = {"Code" : "", "Description" : ""}
    
    try:
        d_action1 = get_code_desc_from_dic(dic, "Driver_Conditions_and_Actions_Drivers_1st_Action")
    except:
        d_action1 = default
    try:
        d_action2 = get_code_desc_from_dic(dic, "Driver_Conditions_and_Actions_Drivers_2nd_Action")
    except:
        d_action2 = default
    try:
        d_action3 = get_code_desc_from_dic(dic, "Driver_Conditions_and_Actions_Drivers_3rd_Action")
    except:
        d_action3 = default
    try:
        d_action4 = get_code_desc_from_dic(dic, "Driver_Conditions_and_Actions_Drivers_4th_Action")
    except:
        d_action4 = default
        
    list_actions = []
    for action in [d_action1, d_action2, d_action3, d_action4]:
        dic_ = dict()
        if(len(action['Description'].strip()) >= 0):
            code = action['Code']
            desc = action['Description']
            dic_["Code"] = code
            dic_["Description"] = desc
            list_actions.append(dic_)
            
    if(len(list_actions) > 0):       
        return list_actions
    else:
        return([default])
    
def map_driver_phone(dic):
    try:
        d_phone1 = dic['Driver_Information_Phone_1']
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic['Driver_Information_Phone_2']
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic['Driver_Information_Phone_3']
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""

def map_property_owner_phone(dic):
    try:
        d_phone1 = dic['Property_Owner_Information_Phone_1']
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic['Property_Owner_Information_Phone_2']
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic['Property_Owner_Information_Phone_3']
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""
    
def map_list_functions_without_dic(value):
    default = {"Code" : "", "Description" : ""}
    dic_ = dict()
    try:
        if(len(value) > 0):
            dic_["Code"] = ""
            dic_["Description"] = value
            return [dic_]
        else:
            return [default]
    except:
        return [default]
        
def get_label_count(df, label):
    list_ = list(df['label'].values)
    count = list_.count(label)
    return count


def name_split_in_given_order(name_order, name_match, add_dict):
    if name_order == 'FML':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'last_name': name_match.group(3).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
    if name_order == 'LFM':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})

def name_split_using_pattern(name_text, name_order='', ischecked = False, business_name_lookup_path=""):
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    name_text = name_text.strip()

    # =====================================
    # Business name - logic
    if ischecked == True:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict
    with open(business_name_lookup_path) as f:
        business_name_lookup = f.readlines()
        business_name_lookup = [x.strip() for x in business_name_lookup]
    business_names = '|'.join(business_name_lookup)
    business_names = business_names.replace(' ', '\s')
    #business_name_match = re.search('\s' + business_names, name_text, re.IGNORECASE)
    business_name_match = re.search('\\b(Holdings|LLC|INC|CORP|COMPANY|ENVIROMENTAL|HYUNDAI|TRANSPORTATION|GROUP|CO|INCORPORATED)\\b',name_text, re.IGNORECASE)

    
    
    if business_name_match:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict
    # =====================================

    suffix_list = ['JR', 'BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC', 'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                   'ESQ', 'II', 'III', 'IV', 'INC', 'JD', 'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                   'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM', 'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                   'USCG', 'USMC', 'USMCR', 'OR']
    suffix_found = ''
    for suffix in suffix_list:
        suffix_match = re.search(r'\b' + suffix + r'\b', name_text, re.IGNORECASE)
        if suffix_match:
            suffix_found = suffix_match.group(0)
            name_text = re.sub('(\s)' + suffix_match.group(0), '', name_text, re.IGNORECASE)
            name_text = re.sub(suffix_match.group(0) + '(\s)', '', name_text, re.IGNORECASE)
            break

    name_match_1 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi
    name_match_2 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi Vaithinaden
    name_match_3 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga Jaanagi Vaithinaden Vaithi
    name_match_4 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi Vaithinaden
    name_match_5 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi, Vaithinaden
    name_match_6 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+\s+[A-Za-z]+))$", name_text)
    name_match_7 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga Jaanagi, Vaithinaden
    name_match_8 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  # Priyanga, Jaanagi
    name_match_9 = re.search("^(([A-Za-z]+),\s*([A-Za-z]+)\s+([A-Z]\s?\.\s?[A-Za-z]+))$", name_text)  # Solis, Jose M.Morales
    name_match_10 = re.search("^(([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{1}))$", name_text)  # SLub Rodrigueza Torres A
    name_match_11 = re.search("^(([A-Za-z]{3,}\s*-\s*[A-Za-z]{3,})\s+([A-Za-z]{3,}))$", name_text)  # Galeana-Garica Gabriela
    name_match_12 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  # Van Lue, Tyler A
    name_match_13 = re.search("^(([A-Za-z]+)\s*\,\s*([A-Za-z]+\s+[A-Za-z]+)\s*\,\s*([A-Za-z]+))$", name_text)  # RAMIREZ, J OANN, MARIE
    
    if name_match_1:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_1, add_dict)
        else:
            add_dict.update({'first_name': name_match_1.group(2).upper()})
            add_dict.update({'last_name': name_match_1.group(3).upper()})
    elif name_match_2:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_2, add_dict)
        else:
            add_dict.update({'first_name': name_match_2.group(2).upper()})
            add_dict.update({'middle_name': name_match_2.group(3).upper()})
            add_dict.update({'last_name': name_match_2.group(4).upper()})
    elif name_match_10:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_10, add_dict)
        else:
            add_dict.update({'first_name': name_match_10.group(2).upper()})
            add_dict.update({'middle_name': name_match_10.group(3).upper() + ' ' + name_match_10.group(5).upper()})
            add_dict.update({'last_name': name_match_10.group(4).upper()})
    elif name_match_3:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_3, add_dict)
        else:
            add_dict.update({'first_name': name_match_3.group(2).upper()})
            add_dict.update({'middle_name': name_match_3.group(3).upper()})
            add_dict.update({'last_name': name_match_3.group(4).upper() + ' ' + name_match_3.group(5).upper()})
    elif name_match_4:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_4, add_dict)
        else:
            add_dict.update({'first_name': name_match_4.group(3).upper()})
            add_dict.update({'middle_name': name_match_4.group(4).upper()})
            add_dict.update({'last_name': name_match_4.group(2).upper()})
    elif name_match_5:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_5, add_dict)
        else:
            add_dict.update({'first_name': name_match_5.group(2).upper()})
            add_dict.update({'middle_name': name_match_5.group(3).upper()})
            add_dict.update({'last_name': name_match_5.group(4).upper()})
    elif name_match_6:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_6, add_dict)
        else:
            add_dict.update({'first_name': name_match_6.group(3).upper()})
            add_dict.update({'middle_name': name_match_6.group(4).upper()})
            add_dict.update({'last_name': name_match_6.group(2).upper()})
    elif name_match_7:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_7, add_dict)
        else:
            add_dict.update({'first_name': name_match_7.group(3).upper()})
            add_dict.update({'last_name': name_match_7.group(2).upper()})
    elif name_match_8:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_8, add_dict)
        else:
            add_dict.update({'first_name': name_match_8.group(3).upper()})
            add_dict.update({'last_name': name_match_8.group(2).upper()})
    elif name_match_9:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_9, add_dict)
        else:
            add_dict.update({'first_name': name_match_9.group(3).upper()})
            add_dict.update({'middle_name': name_match_9.group(4).upper()})
            add_dict.update({'last_name': name_match_9.group(2).upper()})
    elif name_match_11:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_11, add_dict)
        else:
            add_dict.update({'first_name': name_match_11.group(3).upper()})
            add_dict.update({'last_name': name_match_11.group(2).upper()})
    elif name_match_12:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_12, add_dict)
        else:
            add_dict.update({'first_name': name_match_12.group(3).upper()})
            add_dict.update({'middle_name': name_match_12.group(4).upper()})
            add_dict.update({'last_name': name_match_12.group(2).upper()})
    elif name_match_13:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_13, add_dict)
        else:
            add_dict.update({'first_name': name_match_13.group(2).upper()})
            add_dict.update({'middle_name': name_match_13.group(3).upper()})
            add_dict.update({'last_name': name_match_13.group(4).upper()})
    else:
        add_dict.update({'last_name': name_text})

    add_dict.update({'suffix': suffix_found.upper()})
    add_dict.update({'name': name_text.upper()})

    return add_dict

def name_address_split_using_lookup(address_text, city_lookup_path):

    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': ''}
    state_list = ['AK','AL','AR','AZ','BC','CA','CO','CT','DC','DE','FL','GA','GU','HI','IA','ID','IL','IN','KS','KY','LA','MA',
                  'MD','ME','MI','MN','MO','MS','MT','NB','NC','ND','NE','NH','NJ','NM','NS','NV','NY','OH','OK','ON','OR','PA',
                  'PE','PQ','PR','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY','Alaska','Alabama','Arkansas',
                  'Arizona','British Columbia','California','Colorado','Connecticut','Dist.Of Columbia','Delaware','Florida',
                  'Georgia','Guam','Hawaii','Iowa','Idaho','Illinois','Indiana','Kansas','Kentucky','Louisiana','Massachusetts',
                  'Maryland','Maine','Michigan','Minnesota','Missouri','Mississippi','Montana','New Brunswick','North Carolina',
                  'North Dakota','Nebraska','New Hampshire','New Jersey','New Mexico','Nova Scotia','Nevada','New York', 'Ohio',
                  'Oklahoma','Ontario','Oregon','Pennsylvania','Prince Edward','Quebec','Puerto Rico','Rhode Island',
                  'South Carolina','South Dakota','Tennessee','Texas','Utah','Virginia','Vermont','Washington','Wisconsin',
                  'West Virginia','Wyoming']

    city = ''
    state = ''
    zipcode = ''
    names = ''
    dob = ''
    
    address_text = address_text.replace("ADDRESS","").replace("NAME", "").replace("D.O.B","").replace("D O B","").replace("DOB","")
    try:
        dob = re.findall(r'\d{2}/\d{2}/\d{4}', address_text)[0]
    except IndexError:
        dob = ""
    address_text = address_text.replace(dob, '')
    address_text = re.sub('[^A-Za-z0-9 -]', '', address_text)
    

    with open(city_lookup_path) as f:
        city_lookup = f.readlines()
        city_lookup = [x.strip() for x in city_lookup]
    states = '|'.join(state_list)
    cities = '|'.join(city_lookup)
    cities = cities.replace(' ', '\s')

    name_match = re.search('^(([A-Za-z\,?\s&-\.\/]+)(\,|\s))', address_text)
    if name_match:
        names = name_match.group(2)
        address_text = address_text.replace(name_match.group(1), '')

    zipcode_match =  re.search('((\s|,)([0-9\- ]{5,})(\s|,)?)$', address_text, re.IGNORECASE)
    if zipcode_match:
        zipcode = zipcode_match.group(3)
        address_text = address_text.replace(zipcode_match.group(1), '')

    state_match = re.search('((\s|,)(' + states + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if state_match:
        state = state_match.group(3)
        address_text = address_text.replace(state_match.group(1), '')

    city_match = re.search('((\s|,)(' + cities + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if city_match:
        city = city_match.group(3)
        address_text = address_text.replace(city_match.group(1), '')
        
    dob_match = re.search(r'\d{2}/\d{2}/\d{4}', address_text, re.IGNORECASE)
    if dob_match:
        dob = dob_match.group(4)
        address_text = address_text.replace(dob_match.group(1), '')        
        
    address = address_text
    address = address.strip(', ')

    add_dict.update({'names': names})
    add_dict.update({'address': address})
    add_dict.update({'city': city})
    add_dict.update({'state': state})
    add_dict.update({'zipcode': zipcode})
    add_dict.update({'dob': dob})
    add_dict.update({'address2': ""})
    
    if("PO BOX" in names.upper()):
        address2 = names + " " + address
        address = ""
        names = ""
        
        add_dict.update({'address2': address2})
        add_dict.update({'address': address})
        add_dict.update({'names': names})        
            
    return add_dict


def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

def map_phone_form3(dic, p1, p2, p3):
    try:
        d_phone1 = dic[p1]
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic[p2]
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic[p3]
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""

def get_dic_value(dic, label):
    try:
        value = dic[label]
    except:
        value = ""
    return value

def get_make_model_year(text, key='make'):
    try:
        if("UTIL" not in text.upper() and len(text.strip()) > 0):
            if(hasNumbers(text)):
                text = re.sub('[^A-Za-z0-9]', " ", text)
                text = text.strip()
                year = re.search(r"\d+", text, re.IGNORECASE).group(0)
                idx_of_year = text.index(year)
                if(idx_of_year) == 0:
                    rem_text = text.replace(year, "").strip()
                    text_list = rem_text.split()
                    
                    if(len(text_list) == 1):
                        make = text_list[0]
                        model = ""
                    elif(len(text_list) == 2 or len(text_list) == 3):
                        make = text_list[0]
                        model = text_list[1]
                    
                    if(key == 'model'):
                        return model
                    elif(key == 'make'):
                        return make
                    elif(key == 'year'):
                        return year
                
                else:
                    text_list = text.split()
                    
                    if(len(text_list) == 1):
                        make = text_list[0]
                        model = ""
                    elif(len(text_list) == 2 or len(text_list) == 3):
                        make = text_list[0]
                        model = text_list[1]
                    
                    if(key == 'model'):
                        return model
                    elif(key == 'make'):
                        return make
                    elif(key == 'year'):
                        return ""
                    
            else:
                text_list = text.split()
                
                if(len(text_list) == 1):
                    make = text_list[0]
                    model = ""
                elif(len(text_list) == 2 or len(text_list) == 3):
                    make = text_list[0]
                    model = text_list[1]
                
                if(key == 'model'):
                    return model
                elif(key == 'make'):
                    return make
                elif(key == 'year'):
                    return ""    
        else:
            return ""
    except:
        return ""

def map_list_functions(dic, label):
    default = {"Code" : "", "Description" : ""}
    dic_ = dict()
    try:
        value = get_dic_value(dic, label)
        if(len(value) > 0):
            dic_["Code"] = ""
            dic_["Description"] = value
            return [dic_]
        else:
            return [default]
    except:
        return [default]
    
#Fixes    
def get_dispatch_time(text):
    try:
        date = re.search(r'\d{2}/\d{2}/\d{4}', text, re.IGNORECASE).group(0)
        time = text.replace(date,"")
        text = time.strip()
        time = re.sub('[^0-9]', ' ', text)
        time = time.strip()
        am_pm = re.sub('[^A-Za-z]', ' ', text).upper()
        am_pm = am_pm.strip()
        minute = time[-2:]
        hour = time.replace(minute,"")
        hour = hour.strip()
        
        if(am_pm == "PM"):
            hour = int(hour)
            if(hour != 12):
                hour = hour + 12
            
        hour = str(hour)
        if(len(hour) == 1):
            hour = "0"+hour
        if(len(minute) == 1):
            minute = "0"+minute    
        
            
        final_time = hour + ":" + minute     
        
        return final_time
    except:
        return ""
    
def map_occupants_phone(dic):
    try:
        d_phone1 = dic['Occupants_Phone_1']
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic['Occupants_Phone_2']
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic["Occupants_Phone_3"]
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""
    
def map_v_owner_phone(dic):
    try:
        d_phone1 = dic['Vehicle_Information_Phone_1']
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic['Vehicle_Information_Phone_2']
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic["Vehicle_Information_Phone_3"]
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""
    
def map_witness_phone(dic):
    try:
        d_phone1 = dic['Collision_Witnesses_Phone_1']
    except:
        d_phone1 = ""
    try:
        d_phone2 = dic['Collision_Witnesses_Phone_2']
    except:
        d_phone2 = ""
    try:
        d_phone3 = dic["Collision_Witnesses_Phone_3"]
    except:
        d_phone3 = ""
        
    if(len(d_phone1) > 0):
        return d_phone1
    elif(len(d_phone2) > 0):
        return d_phone2
    elif(len(d_phone3) > 0):
        return d_phone3
    else:
        return ""
            
def vin_status(text):
    try:
        text = str(text)
        if(len(text.strip()) > 0):
            return "Yes"
        else:
            return "No"
    except:
        return ""
    

def vehicle_air_bag_status(dic_driver, dic):
    try:
        air_bag = get_dic_value(dic_driver, "Driver_Information_Air_Bag")
        air_bag = air_bag.upper().strip()
        
        if(len(air_bag)>0):
            value = ""
            if(fuzz.token_sort_ratio(air_bag,"not deployed") > 90 or \
               fuzz.token_sort_ratio(air_bag,"no deployed") > 90 or \
                   fuzz.token_sort_ratio(air_bag,"NO DEPLOYMENT") > 90 or \
                       fuzz.token_sort_ratio(air_bag, "Airbag Available - No Deployment") > 90 or \
                           fuzz.token_sort_ratio(air_bag,"Available not Deployed") > 90 or \
                               fuzz.token_sort_ratio(air_bag,"Installed/Not deployed") > 90 or \
                                   fuzz.token_sort_ratio(air_bag,"Air bag not deployed, Switch on") > 90 or \
                                       fuzz.token_sort_ratio(air_bag,"Air bag not deployed, Switch off") > 90 or \
                                           fuzz.token_sort_ratio(air_bag,"Air bag not deployed, UNK Switch setting") > 90 or \
                                               fuzz.token_sort_ratio(air_bag,"Not deployed - Unknown if switch on or off") > 90 or \
                                                   fuzz.token_sort_ratio(air_bag,"Installed/Not deployed") > 90):
                value = "0" 
            elif(fuzz.token_sort_ratio(air_bag,"not") > 90 or fuzz.token_sort_ratio(air_bag,"no") > 90):
                value = "0"
            elif(fuzz.token_sort_ratio(air_bag,"yes") > 90):
                value = "1"
            elif(fuzz.token_sort_ratio(air_bag,"Driverless vehicle") > 90):
                value = "0"
            elif(fuzz.token_sort_ratio(air_bag,"MULTIPLE UNKNOWN") > 90 or fuzz.token_sort_ratio(air_bag, "Airbag Available - Deployed") > 90 or \
                 fuzz.token_sort_ratio(air_bag, "Airbag Available - Multiple unknown") > 90):
                value = "1"
            elif(fuzz.token_sort_ratio(air_bag,"MULTIPLE") > 90 or \
                 fuzz.token_sort_ratio(air_bag,"Deployed (in any seat position)") > 90 or \
                     fuzz.token_sort_ratio(air_bag,"Available Deployed") > 90 or \
                         fuzz.token_sort_ratio(air_bag,"Not deployed at pos., deployed at others") > 90):
                value = "1"
                
            elif(fuzz.token_sort_ratio(air_bag,"Airbag Available - Deployed Unknown") or \
                 fuzz.token_sort_ratio(air_bag,"The deployment is unknown") or \
                     fuzz.token_sort_ratio(air_bag,"N/A or not applicable") or \
                         fuzz.token_sort_ratio(air_bag,"N/A") or \
                             fuzz.token_sort_ratio(air_bag,"not applicable") or \
                                 fuzz.token_sort_ratio(air_bag,"unk") or \
                                     fuzz.token_sort_ratio(air_bag,"Unknown") or \
                                         fuzz.token_sort_ratio(air_bag,"Not equipped") or \
                                             fuzz.token_sort_ratio(air_bag,"Non-Motorist") or \
                                                 fuzz.token_sort_ratio(air_bag,"Not available (this seat)") or \
                                                     fuzz.token_sort_ratio(air_bag,"Not replaced") or \
                                                         fuzz.token_sort_ratio(air_bag,"Disabled/Removed") or \
                                                             fuzz.token_sort_ratio(air_bag,"UNK or unknown") or \
                                                                 fuzz.token_sort_ratio(air_bag,"None") or \
                                                                     fuzz.token_sort_ratio(air_bag,"Deactivated") or \
                                                                         fuzz.token_sort_ratio(air_bag,"Not installed") or \
                                                                             fuzz.token_sort_ratio(air_bag,"Missing") or \
                                                                                 fuzz.token_sort_ratio(air_bag,"None used/Not applicable") or \
                                                                                     fuzz.token_sort_ratio(air_bag,"Motorcycle eye protection") or \
                                                                                         fuzz.token_sort_ratio(air_bag,"Bicyclist wearing elbow/knee/pads") or \
                                                                                             fuzz.token_sort_ratio(air_bag,"Air bag Removed (prior to Crash)") or \
                                                                                                 fuzz.token_sort_ratio(air_bag,"Unknown if airbag deployed") or \
                                                                                                     fuzz.token_sort_ratio(air_bag,"Unknown if ON-OFF switch is present") or \
                                                                                                         fuzz.token_sort_ratio(air_bag,"Unknown switch position") or \
                                                                                                             fuzz.token_sort_ratio(air_bag,"Not applicable (Motorcycle, snowmobile, etc.)") or \
                                                                                                                 fuzz.token_sort_ratio(air_bag,"seat belt/harness")):
                value = "NA"
            else:
                value = "0"
        else:
            if((len(dic_driver['Driver_Information_Address_Line_1'])>0 or \
               len(dic_driver['Driver_Information_First_Name'])>0 or \
                   len(dic_driver['Driver_Information_Last_Name'])>0 or \
                       len(dic_driver['Driver_Information_State'])>0 or \
                           len(dic_driver['Driver_Conditions_and_Actions_Distraction'])>0) and len(air_bag)==0):
                value = "0"
            else:
                value = "NA"
                
        return value

    except:
        return "NA"
          
def get_license_info(text, get = "state"):
    text = re.sub('[^a-zA-Z0-9,]',' ',text).strip()
    try:
        if("," in text):
            license_no = text.split(',')[0].replace(" ","").upper()
            state = text.split(",")[1].split()[0]
            
        else:
            license_no = text.replace(" ","").upper()
            state = text.split(" ")[1]

        if(get=="state"):
            return state
        else:
            return license_no
            
    except:
        return ""
    
def get_prop_owner_params(df, prop_owner_infos_list):
    search_values = prop_owner_infos_list
    prop_df = df[df.label.str.contains('|'.join(search_values))]
    prop_df.sort_values(by = ['path','ymin', 'xmin'], inplace = True, ascending = True)
    prop_df = prop_df.reset_index(drop=True)
    
    
    indexes_of_prop_no = prop_df.label[prop_df.label == 'Property_Owner_Information_Other_Property_Damages'].index.tolist()
    
            
    for i in range(len(indexes_of_prop_no)):
        if(i != len(indexes_of_prop_no)-1):
            start = indexes_of_prop_no[i]
            end = indexes_of_prop_no[i+1]
            globals()["df_prop_{}".format(i+1)] = prop_df.iloc[start:end,:]
        else:
            start = indexes_of_prop_no[i]
            globals()["df_prop_{}".format(i+1)] = prop_df.iloc[start:,:]
    
    
    
    prop_name_count = get_label_count(prop_df, "Property_Owner_Information_First_Name")
    prop_damage_count = get_label_count(prop_df, "Property_Owner_Information_Other_Property_Damages")
    prop_city_count = get_label_count(prop_df, "Property_Owner_Information_City")
    prop_desc_count = get_label_count(prop_df, "Property_Owner_Information_Property_Description")
    prop_state_count = get_label_count(prop_df, "Property_Owner_Information_State")
    prop_zip_count = get_label_count(prop_df, "Property_Owner_Information_Zip_Code")
    prop_lname_count = get_label_count(prop_df, "Property_Owner_Information_Middle_Name")
    prop_add_count = get_label_count(prop_df, "Property_Owner_Information_Address_Line_1")
    
    
    no_of_prop_owner = mode([prop_name_count,prop_damage_count,prop_city_count,prop_desc_count,
                             prop_state_count,prop_zip_count,prop_lname_count,prop_add_count])
    
    for prop_owner_no in range(no_of_prop_owner):
        globals()["property_owner_{}".format(prop_owner_no+1)] = dict()
        
    for j in range(no_of_prop_owner):
        for key in prop_owner_infos_list:
            globals()["property_owner_{}".format(j+1)][key] = get_value_from_df(globals()["df_prop_{}".format(j+1)],key)
        globals()["property_owner_{}".format(j+1)]["Page_No"] = globals()["df_prop_{}".format(j+1)]['page_no'].unique()[0].split("_")[-1]
                
    prop_owner_list = [globals()['property_owner_{}'.format(i+1)] for i in range(no_of_prop_owner)]
    return prop_owner_list, no_of_prop_owner
    
def get_occupants_params(df, occupants_infos_list):
    label_count_dict = dict()
    
    for label in occupants_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    occupants_type = label_count_dict["Occupants_Person_Type"]
    occupants_f_name = label_count_dict["Occupants_First_Name"]
    occupants_add1 = label_count_dict["Occupants_Address_Line_1"]
    occupants_add2 = label_count_dict["Occupants_Address_Line_2"]
    
    all_occupants_count = max(occupants_type, occupants_f_name, occupants_add1, occupants_add2)
    
    for i in range(all_occupants_count):
        globals()["occupants_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    occupants_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
            
        
        label_count_dict_in_page = dict()
        for label in occupants_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_occupants_count_in_page = label_count_dict_in_page["Occupants_Person_Type"]
        except:
            get_occupants_count_in_page = 0
        
        if(get_occupants_count_in_page > 0):
            is_occupants_present_in_page = 1
        else:
            is_occupants_present_in_page = 0
            
        if(is_occupants_present_in_page == 1):
            for i in range(len(occupants_infos_list)):
                globals()["occupants_{}".format(occupants_no)][occupants_infos_list[i]] = get_value_from_df(page_df,occupants_infos_list[i])
                
            occupants_no += 1
        
    occupants_list = [globals()['occupants_{}'.format(i+1)] for i in range(all_occupants_count)]
    return occupants_list, all_occupants_count

def get_driver_params(df, driver_infos_list):
    
    label_count_dict = dict()
    
    for label in driver_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    # driver_age = label_count_dict["Driver_Information_Age"]
    # driver_f_name = label_count_dict["Driver_Information_First_Name"]
    # driver_add1 = label_count_dict["Driver_Information_Address_Line_1"]
    # driver_add2 = label_count_dict["Driver_Information_Address_Line_2"]
    
    # all_driver_count = max(driver_age, driver_f_name, driver_add1, driver_add2)
    
    all_driver_count = mode([*label_count_dict.values()])
    
    for i in range(all_driver_count):
        globals()["driver_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    driver_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
        label_count_dict_in_page = dict()
        for label in driver_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_driver_count_in_page = mode([*label_count_dict_in_page.values()])
        except:
            get_driver_count_in_page = 0
        
        if(get_driver_count_in_page > 0):
            is_driver_present_in_page = 1
        else:
            is_driver_present_in_page = 0
            
        if(is_driver_present_in_page == 1):
            for i in range(len(driver_infos_list)):
                globals()["driver_{}".format(driver_no)][driver_infos_list[i]] = get_value_from_df(page_df,driver_infos_list[i])
                
            driver_no += 1
        
    driver_list = [globals()['driver_{}'.format(i+1)] for i in range(all_driver_count)]
    return driver_list, all_driver_count

def get_vehicle_params(df, vehicle_infos_list):
    
    label_count_dict = dict()
    
    for label in vehicle_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    owner_f_name = label_count_dict["Vehicle_Information_Owner_First_Name"]
    owner_m_name = label_count_dict["Vehicle_Information_Owner_Middle_Name"]
    owner_add1 = label_count_dict["Vehicle_Information_Address_Line_1"]
    owner_add2 = label_count_dict["Vehicle_Information_Address_Line_2"]
    owner_zip = label_count_dict["Vehicle_Information_Zip_Code"]
        
    all_vehicle_count = max(owner_f_name, owner_m_name, owner_add1, owner_add2, owner_zip)
    
    for i in range(all_vehicle_count):
        globals()["vehicle_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    vehicle_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
    
        label_count_dict_in_page = dict()
        for label in vehicle_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_vehicle_count_in_page = label_count_dict_in_page["Vehicle_Information_Owner_First_Name"]
        except:
            get_vehicle_count_in_page = 0
            
        try:    
            get_count_part_1st_page_poc = label_count_dict_in_page["Vehicle_Damage_and_Roadway_Characteristics_Point_of_First_Impact"]
        except:
            get_count_part_1st_page_poc = 0
            
        try:    
            get_count_part_1st_page_speed = label_count_dict_in_page["Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit"]
        except:
            get_count_part_1st_page_speed = 0

        try:    
            get_count_part_1st_page_road = label_count_dict_in_page["Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions"]
        except:
            get_count_part_1st_page_road = 0
            
            
        if(get_vehicle_count_in_page > 0 and (get_count_part_1st_page_poc>0 or get_count_part_1st_page_speed>0 or get_count_part_1st_page_road>0)):
            is_all_vehicle_present_in_page = 1
        else:
            is_all_vehicle_present_in_page = 0
            
        if(is_all_vehicle_present_in_page == 1):
            for i in range(len(vehicle_infos_list)):
                globals()["vehicle_{}".format(vehicle_no)][vehicle_infos_list[i]] = get_value_from_df(page_df,vehicle_infos_list[i])
                
            vehicle_no += 1
            
            
            
        elif(get_vehicle_count_in_page > 0 and (get_count_part_1st_page_poc == 0 and get_count_part_1st_page_speed == 0 and get_count_part_1st_page_road == 0)):
            page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
        
            label_count_dict_in_page = dict()
            for label in vehicle_infos_list:
                label_count_dict_in_page[label] = get_label_count(page_df, label)
            
            try:    
                get_vehicle_count_in_page = label_count_dict_in_page["Vehicle_Information_Owner_First_Name"]
            except:
                get_vehicle_count_in_page = 0
            
            vehicle_infos_list_2nd_part = ["Vehicle_Damage_and_Roadway_Characteristics_Point_of_First_Impact", "Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit", "Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions"]
            
            vehicle_infos_list_1st_part = list(set(vehicle_infos_list) - set(vehicle_infos_list_2nd_part))
                        
            next_page_df = df[df["page_no"] == "page_no_{}".format(page_no+1)]
            label_count_dict_in_page_part2 = dict()
            for label in ["Vehicle_Damage_and_Roadway_Characteristics_Point_of_First_Impact", "Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit", "Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions"]:
                label_count_dict_in_page_part2[label] = get_label_count(next_page_df, label)
                
            try:    
                get_count_2nd_part_page_poc = label_count_dict_in_page_part2["Vehicle_Damage_and_Roadway_Characteristics_Point_of_First_Impact"]
            except:
                get_count_2nd_part_page_poc = 0
                
            try:    
                get_count_2nd_part_page_speed = label_count_dict_in_page_part2["Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit"]
            except:
                get_count_2nd_part_page_speed = 0
    
            try:    
                get_count_2nd_part_page_road = label_count_dict_in_page_part2["Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions"]
            except:
                get_count_2nd_part_page_road = 0
                
              
            if(get_vehicle_count_in_page > 0 and (get_count_2nd_part_page_poc>0 or get_count_2nd_part_page_speed>0 or get_count_2nd_part_page_road>0)):
                is_all_vehicle_present_in_page = 1
            else:
                is_all_vehicle_present_in_page = 0
                
            if(is_all_vehicle_present_in_page == 1):
                for i in range(len(vehicle_infos_list_1st_part)):
                    globals()["vehicle_{}".format(vehicle_no)][vehicle_infos_list_1st_part[i]] = get_value_from_df(page_df,vehicle_infos_list_1st_part[i])

                for i in range(len(vehicle_infos_list_2nd_part)):
                    globals()["vehicle_{}".format(vehicle_no)][vehicle_infos_list_2nd_part[i]] = get_value_from_df(next_page_df,vehicle_infos_list_2nd_part[i])
                    
                vehicle_no += 1
    
    vehicle_list = [globals()['vehicle_{}'.format(i+1)] for i in range(all_vehicle_count)]
    return vehicle_list, all_vehicle_count

def get_witness_params(df, witness_infos_list):
    
    label_count_dict = dict()
    
    for label in witness_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    witness_city = label_count_dict["Collision_Witnesses_City"]
    witness_f_name = label_count_dict["Collision_Witnesses_First_Name"]
    witness_add1 = label_count_dict["Collision_Witnesses_Address_Line_1"]
    witness_add2 = label_count_dict["Collision_Witnesses_Address_Line_2"]
    
    all_witness_count = max(witness_city, witness_f_name, witness_add1, witness_add2)
    
    for i in range(all_witness_count):
        globals()["witness_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    witness_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]        
        
        label_count_dict_in_page = dict()
        for label in witness_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_witness_count_in_page = label_count_dict_in_page["Collision_Witnesses_First_Name"]
        except:
            get_witness_count_in_page = 0
        
        if(get_witness_count_in_page > 0):
            is_witness_present_in_page = 1
        else:
            is_witness_present_in_page = 0
            
        if(is_witness_present_in_page == 1):
            for i in range(len(witness_infos_list)):
                globals()["witness_{}".format(witness_no)][witness_infos_list[i]] = get_value_from_df(page_df,witness_infos_list[i])
                
            witness_no += 1
        
    witness_list = [globals()['witness_{}'.format(i+1)] for i in range(all_witness_count)]
    return witness_list, all_witness_count


def map_vehicle_contrib_circum(dic):
    default = {"Code" : "", "Description" : ""}
    
    try:
        v_contrib1 = get_code_desc_from_dic(dic, "Vehicle_Information_1st_Factor")
    except:
        v_contrib1 = default
    try:
        v_contrib2 = get_code_desc_from_dic(dic, "Vehicle_Information_2nd_Factor")
    except:
        v_contrib2 = default
    try:
        v_contrib3 = get_code_desc_from_dic(dic, "Vehicle_Information_3rd_Factor")
    except:
        v_contrib3 = default
       
    list_contrib = []
    for contrib in [v_contrib1, v_contrib2, v_contrib3]:
        dic_ = dict()
        if(len(contrib['Description'].strip()) >= 0):
            code = contrib['Code']
            desc = contrib['Description']
            dic_["Code"] = code
            dic_["Description"] = desc
            list_contrib.append(dic_)
            
    if(len(list_contrib) > 0):       
        return list_contrib
    else:
        return([default])
    
    
def get_incident_hit_run(text):
    try:
        if("YES" in text.upper()):
            hit = "1"
        else:
            hit = "0"
        return hit
    except:
        return "0"
  
  
def get_vehicle_towed(text):
    try:
        text = text.strip().upper()
        
        if(fuzz.token_sort_ratio(text,"Towed away") > 90):
            towed = "1"
        
        elif(len(text) == 0 or "NO" in text or fuzz.token_sort_ratio(text,"driven away") > 90):
            towed = "0"
        else:
            towed = ""
        return towed
    except:
        return ""
    
    
def get_photo(taken, by):
    try:
        taken = taken.upper().strip()
        by = by.strip()
        if("NO" in taken):
            value = "N"
        elif(len(by) > 1 or "YES" in taken):
            value = "Y"
        return value
    except:
        return "N"
    

def process_ejection(text):
    try:
        if(len(text) != 0):
            if(fuzz.token_sort_ratio(text,"Not ejected") > 85 or \
               fuzz.token_sort_ratio(text,"NOT") > 85 or \
                   fuzz.token_sort_ratio(text,"NO") > 85):
                out = "Not Ejected"
            elif(fuzz.token_sort_ratio(text,"Not Applicable") > 85 or \
               fuzz.token_sort_ratio(text,"NA") > 85 or \
                   fuzz.token_sort_ratio(text,"N/A") > 85):
                out = "Not Applicable"
            elif(fuzz.token_sort_ratio(text,"Totally Ejected") > 85 or \
               fuzz.token_sort_ratio(text,"Totally") > 85 or \
                   fuzz.token_sort_ratio(text,"Ejected") > 85):
                out = "Totally Ejected"
            elif(fuzz.token_sort_ratio(text,"Partially Ejected") > 85 or \
               fuzz.token_sort_ratio(text,"Partially") > 85):
                out = "Partially Ejected"
            elif(fuzz.token_sort_ratio(text,"Unknown") > 80):
                out = "Unknown"
            else:
                out = ""
        else:
            out = ""
    except:
        out = ""
    return out    

def get_injury_status(dic, label_name):
    try:
        injury_desc = get_dic_value(dic, label_name).upper()
        
        if(len(injury_desc)>0):
            value = ""
            if(fuzz.token_sort_ratio(injury_desc,"NO INJURY") > 90 or fuzz.token_sort_ratio(injury_desc,"NO") > 90):
                value = "O" 
            elif(fuzz.token_sort_ratio(injury_desc,"Possible Injury") > 90 or \
                 fuzz.token_sort_ratio(injury_desc,"SUSPECTED SERIOUS INJURY") > 90 or \
                     fuzz.token_sort_ratio(injury_desc,"Possible") > 90 or \
                         fuzz.token_sort_ratio(injury_desc,"SERIOUS Injury") > 90):
                value = "I"

        else:
            value = "O"
                
        return value

    except:
        return ""
    
def get_damaged_areas(text):
    try:
        if(len(text.strip()) > 0):
            if(fuzz.token_sort_ratio(text,"Front end, Driver side, near front") > 85 or \
               fuzz.token_sort_ratio(text,"FRONT END") > 85 or \
                   fuzz.token_sort_ratio(text,"FRONT") > 85 or \
                       fuzz.token_sort_ratio(text,"Front end, Passenger side, near front") > 85 or\
                           fuzz.token_sort_ratio(text,"near front") > 85):
                out = "Front"
                
            elif(fuzz.token_sort_ratio(text,"Driver side, center, Driver side, between rear/center, Driver side, near rear") > 85 or \
               fuzz.token_sort_ratio(text,"LEFT SIDE") > 85 or \
                   fuzz.token_sort_ratio(text,"LEFT") > 85 or \
                       fuzz.token_sort_ratio(text,"between rear/center") > 85 or\
                           fuzz.token_sort_ratio(text,"Driver side") > 85 or \
                               fuzz.token_sort_ratio(text,"LEFT SIDE-FAR FRONT") > 85 or\
                                   fuzz.token_sort_ratio(text,"LEFT SIDE-NEAR FRONT") > 85 or \
                                       fuzz.token_sort_ratio(text,"LEFT SIDE-CENTER") > 85 or \
                                           fuzz.token_sort_ratio(text,"LEFT SIDE-FAR") > 85 or \
                                               fuzz.token_sort_ratio(text,"LEFT SIDE-NEAR") > 85 or \
                                                   fuzz.token_sort_ratio(text,"Left Side-Far Rear") > 85 or \
                                                       fuzz.token_sort_ratio(text,"Left Side-Center Left Side-Far Front") > 85 or \
                                                           fuzz.token_sort_ratio(text,"Left Side-Far Front Left Side-Far Rear") > 85 or \
                                                               fuzz.token_sort_ratio(text,"Left Side-Far Rear Left Side-Center") > 85 or \
                                                                   fuzz.token_sort_ratio(text,"Left Side-Center Left Side-Far Front Left Side-Far Rear")):
                out = "Left Side"
                
            elif(fuzz.token_sort_ratio(text,"RIGHT SIDE-FAR FRONT") > 85 or \
               fuzz.token_sort_ratio(text,"RIGHT SIDE-NEAR FRONT") > 85 or \
                   fuzz.token_sort_ratio(text,"RIGHT SIDE-CENTER") > 85 or \
                       fuzz.token_sort_ratio(text,"RIGHT SIDE-FAR REAR") > 85 or\
                           fuzz.token_sort_ratio(text,"RIGHT SIDE-NEAR FRONT") > 85 or \
                               fuzz.token_sort_ratio(text,"Right") > 85 or \
                                   fuzz.token_sort_ratio(text,"Right Side-Center Right Side-Far Front") > 80 or \
                                       fuzz.token_sort_ratio(text,"Right Side-Far Front Right Side-Far Rear") > 80 or \
                                           fuzz.token_sort_ratio(text,"Right Side-Far Rear Right Side-Center") > 80 or \
                                               fuzz.token_sort_ratio(text,"Right Side-Center Right Side-Far Front Right Side-Far Rear") > 80):
                out = "Right Side"
                
            elif(fuzz.token_sort_ratio(text,"Rear-End") > 80 or \
                 fuzz.token_sort_ratio(text,"Right Side-Near Rear Rear-End") > 80 or \
                     fuzz.token_sort_ratio(text,"Rear-End Left Side-Near Rear") > 80 or \
                         fuzz.token_sort_ratio(text,"Right Side-Near Left Side-Near Rear") > 80 or \
                             fuzz.token_sort_ratio(text,"Right Side-Near Left Side-Near Rear Rear-End") > 80 or \
                                 fuzz.token_sort_ratio(text,"Rear") > 80):
                out = "Rear"
                
            elif(fuzz.token_sort_ratio(text,"Front-End Rear-End") > 80):
                out = "Front & Rear"
            elif((len(text.replace("-"," ").strip()) > 6) or (fuzz.token_sort_ratio(text,"All Areas") > 80)):
                 out = "Multiple"
        else:
            out = ""
        return out
                
    except:
        return ""
    

#SAUGATA  
def get_driver_params_form3(df, driver_infos_list):
    
    label_count_dict = dict()
    
    for label in driver_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    # driver_age = label_count_dict["Driver_Information_Driver_Conditions_and_Actions_Drivers_Action"]
    # driver_f_name = label_count_dict["Driver_Information_First_Middle_Last_Name"]
    # driver_add1 = label_count_dict["Driver_Information_Address"]
    # driver_add2 = label_count_dict["Driver_Information_Date_of_Birth"]
    
    all_driver_count = mode([*label_count_dict.values()])
    
    for i in range(all_driver_count):
        globals()["driver_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    driver_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
        label_count_dict_in_page = dict()
        for label in driver_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_driver_count_in_page = mode([*label_count_dict_in_page.values()])
        except:
            get_driver_count_in_page = 0
        
        if(get_driver_count_in_page > 0):
            is_driver_present_in_page = 1
        else:
            is_driver_present_in_page = 0
            
        if(is_driver_present_in_page == 1):
            for i in range(len(driver_infos_list)):
                globals()["driver_{}".format(driver_no)][driver_infos_list[i]] = get_value_from_df(page_df,driver_infos_list[i])
                
            driver_no += 1
        
    driver_list = [globals()['driver_{}'.format(i+1)] for i in range(all_driver_count)]
    return driver_list, all_driver_count

def get_occupants_params_form3(df, occupants_infos_list):
    search_values = occupants_infos_list
    occupants_df = df[df.label.str.contains('|'.join(search_values))]
    occupants_df.sort_values(by = ['path','ymin', 'xmin'], inplace = True, ascending = True)
    occupants_df = occupants_df.reset_index(drop=True)
    
    new_df = occupants_df.groupby('label')['text'].apply(list).to_dict()
    
    no_of_vehicles = get_label_count(occupants_df, "Occupants_Vehicle_No")
    list(occupants_df["label"].values).index("Occupants_Vehicle_No")
    
    indexes_of_vehicle_no = occupants_df.label[occupants_df.label == 'Occupants_Vehicle_No'].index.tolist()
    
    for i in range(len(indexes_of_vehicle_no)):
        if(i != len(indexes_of_vehicle_no)-1):
            start = 0
            end = indexes_of_vehicle_no[i+1]
            globals()["df_veh_{}".format(i+1)] = occupants_df.iloc[start:end,:]
        else:
            # start = end
            start = 0
            globals()["df_veh_{}".format(i+1)] = occupants_df.iloc[start:,:]
            
    total_no_of_occ = 0 
    for veh_no in range(len(indexes_of_vehicle_no)):  
        number_of_occ_pass_name = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_First_Middle_Last_Name")
        number_of_occ_pass_add = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Address")
        number_of_occ_pass_phone1 = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Phone_1")
        number_of_occ_pass_gender = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Gender")
        number_of_pass_in_vehicle = max(number_of_occ_pass_name,number_of_occ_pass_add,number_of_occ_pass_phone1,number_of_occ_pass_gender)
        total_no_of_occ += number_of_pass_in_vehicle
        
    for occ_no in range(total_no_of_occ):
        globals()["occupants_{}".format(occ_no+1)] = dict()
        
    occupants_no_list = []
    for i in range(total_no_of_occ):
        occupants_no_list.append(i)
        
    vehicle_no_list = []
    for i in range(no_of_vehicles):
        vehicle_no_list.append(i)
        
    i = 0
    occupant = 0
    occ_list = []
    end_pass=0
    for veh_no in range(len(indexes_of_vehicle_no)):  
        number_of_occ_pass_name = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_First_Middle_Last_Name")
        number_of_occ_pass_add = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Address")
        number_of_occ_pass_phone1 = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Phone_1")
        number_of_occ_pass_gender = get_label_count(globals()["df_veh_{}".format(veh_no+1)], "Occupants_Gender")
        number_of_pass_in_vehicle = max(number_of_occ_pass_name,number_of_occ_pass_add,number_of_occ_pass_phone1,number_of_occ_pass_gender)
        occupant += number_of_pass_in_vehicle
            
        if(number_of_pass_in_vehicle !=0):
            df_occ = globals()["df_veh_{}".format(veh_no+1)]
    
            df_occ = df_occ.reset_index(drop=True)
            try:
                indexes_of_statement = df_occ.label[df_occ.label == 'Occupants_Written_Statement'].index.tolist()
            except:
                indexes_of_statement = df_occ.label[df_occ.label == 'Occupants_Ambulance_Hospital'].index.tolist()
    
            party = 1
            vehicle_no = get_value_from_df(df_occ, "Occupants_Vehicle_No")
            #vehicle_no = re.sub('[^0-9]','',vehicle_no)
            vehicle_no = veh_no + 1
            
            start_pass = end_pass
            end_pass = start_pass + number_of_pass_in_vehicle
            occ_no_list = occupants_no_list[start_pass:end_pass]
            
            for j in occ_no_list:
                if(len(occ_no_list) != 1):
                    try:
                        if(j%2 != len(indexes_of_statement)-1):
                            start = 0
                            end = indexes_of_statement[j%2]
                            globals()["occupants_df_{}".format(j+1)] = df_occ.iloc[start:end+1,:]
                            globals()["occupants_df_{}".format(j+1)]['text']=globals()["occupants_df_{}".format(j+1)]['text'].fillna("")
                            for i, row in globals()["occupants_df_{}".format(j+1)].iterrows():
                                globals()["occupants_{}".format(j+1)][row.label] = row.text
                                globals()["occupants_{}".format(j+1)]["Occupants_Party_Id"] = str(party)
                                globals()["occupants_{}".format(j+1)]["Occupants_Unit_Id"] = vehicle_no
                            party += 1
                        else:
                            start = 0
                            globals()["occupants_df_{}".format(j+1)] = df_occ.iloc[start:,:]
                            globals()["occupants_df_{}".format(j+1)]['text']=globals()["occupants_df_{}".format(j+1)]['text'].fillna("")
                            for i, row in globals()["occupants_df_{}".format(j+1)].iterrows():
                                globals()["occupants_{}".format(j+1)][row.label] = row.text
                                globals()["occupants_{}".format(j+1)]["Occupants_Party_Id"] = str(party)
                                globals()["occupants_{}".format(j+1)]["Occupants_Unit_Id"] = vehicle_no
                            party += 1
                    except:
                        pass
                else:
                    try:
                        start = 0
                        end = indexes_of_statement[j%2]
                        globals()["occupants_df_{}".format(j+1)] = df_occ.iloc[start:end+1,:]
                        globals()["occupants_df_{}".format(j+1)]['text']=globals()["occupants_df_{}".format(j+1)]['text'].fillna("")
                        for i, row in globals()["occupants_df_{}".format(j+1)].iterrows():
                            globals()["occupants_{}".format(j+1)][row.label] = row.text
                            globals()["occupants_{}".format(j+1)]["Occupants_Party_Id"] = str(party)
                            globals()["occupants_{}".format(j+1)]["Occupants_Unit_Id"] = vehicle_no
                    except:
                        continue
        else:
            continue

    occupants_list = [globals()['occupants_{}'.format(i+1)] for i in range(total_no_of_occ)]
    return occupants_list, total_no_of_occ


def get_vehicle_params_form3(df, prop_owner_infos_list):
    search_values = prop_owner_infos_list
    veh_df = df[df.label.str.contains('|'.join(search_values))]
    veh_df.sort_values(by = ['path','ymin'], inplace = True, ascending = True)
    veh_df = veh_df.reset_index(drop=True)
   
    label_count_dict = dict()
    
    for label in prop_owner_infos_list:
        label_count_dict[label] = get_label_count(df, label)
        
    all_vehicle_count = mode([*label_count_dict.values()])
    
    index_lists = []
    
    index_vehicle_no = veh_df.label[veh_df.label == 'Vehicle_Information_Vehicle_No'].index.tolist()
    index_no_occ = veh_df.label[veh_df.label == 'Vehicle_Information_No_of_Occupants'].index.tolist()
    index_make_model = veh_df.label[veh_df.label == 'Vehicle_Information_Vehicle_Make_Model_Year'].index.tolist()
    index_vehicle_col = veh_df.label[veh_df.label == 'Vehicle_Information_Color'].index.tolist()

    
    for list_ in [index_vehicle_no, index_no_occ, index_make_model, index_vehicle_col]:
        if(len(list_) == all_vehicle_count):
            index_lists.append(list_)
    
    indexes_of_prop_no = []
    
    df_index = pd.DataFrame(index_lists, columns = [i+1 for i in range(all_vehicle_count)])
    
    for col_name in [i+1 for i in range(all_vehicle_count)]:
        indexes_of_prop_no.append(min(df_index[col_name]))  
        
    for i in range(len(indexes_of_prop_no)):
        if(i != len(indexes_of_prop_no)-1):
            start = indexes_of_prop_no[i]
            end = indexes_of_prop_no[i+1]
            globals()["df_vehicle_{}".format(i+1)] = veh_df.iloc[start:end,:]
        else:
            start = indexes_of_prop_no[i]
            globals()["df_vehicle_{}".format(i+1)] = veh_df.iloc[start:,:]
    
    for prop_owner_no in range(all_vehicle_count):
        globals()["vehicle_{}".format(prop_owner_no+1)] = dict()
        
    for j in range(all_vehicle_count):
        for key in prop_owner_infos_list:
            globals()["vehicle_{}".format(j+1)][key] = get_value_from_df(globals()["df_vehicle_{}".format(j+1)],key)
                
    vehicle_list = [globals()['vehicle_{}'.format(i+1)] for i in range(all_vehicle_count)]
    return vehicle_list, all_vehicle_count


def get_witness_params_form3(df, witness_infos_list):
    
    label_count_dict = dict()
    
    for label in witness_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    witness_city = label_count_dict["Witnesses_License_Number"]
    witness_f_name = label_count_dict["Witnesses_Name"]
    witness_add1 = label_count_dict["Witnesses_Address"]
    witness_add2 = label_count_dict["Witnesses_Phone_1"]
    
    all_witness_count = max(witness_city, witness_f_name, witness_add1, witness_add2)
    
    for i in range(all_witness_count):
        globals()["witness_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    witness_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]        
        
        label_count_dict_in_page = dict()
        for label in witness_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_witness_count_in_page = label_count_dict_in_page["Witnesses_Name"]
        except:
            get_witness_count_in_page = 0
        
        if(get_witness_count_in_page > 0):
            is_witness_present_in_page = 1
        else:
            is_witness_present_in_page = 0
            
        if(is_witness_present_in_page == 1):
            for i in range(len(witness_infos_list)):
                globals()["witness_{}".format(witness_no)][witness_infos_list[i]] = get_value_from_df(page_df,witness_infos_list[i])
                
            witness_no += 1
        
    witness_list = [globals()['witness_{}'.format(i+1)] for i in range(all_witness_count)]
    return witness_list, all_witness_count

def get_vehicle_owner_params_form3(df, vehicle_owner_infos_list):
    
    label_count_dict = dict()
    
    for label in vehicle_owner_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    owner_name = get_dic_value(label_count_dict, "Owner_Name")
    owner_add = get_dic_value(label_count_dict, "Owner_Address") 
    owner_gen = get_dic_value(label_count_dict, "Owner_Gender") 
    owner_dob = get_dic_value(label_count_dict, "Owner_Date_of_Birth") 
    
    all_veh_owner_count = max(owner_name, owner_add, owner_gen, owner_dob)
    
    for i in range(all_veh_owner_count):
        globals()["v_owner_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    if(all_veh_owner_count > 0):
        owner_no = 1
        for page_no in range(1,total_pages_in_df+1):
            page_df = df[df["page_no"] == "page_no_{}".format(page_no)]
            label_count_dict_in_page = dict()
            for label in vehicle_owner_infos_list:
                label_count_dict_in_page[label] = get_label_count(page_df, label)
            
            try:    
                get_owner_count_in_page = max(label_count_dict_in_page.values())
            except:
                get_owner_count_in_page = 0
            
            if(get_owner_count_in_page > 0):
                is_owner_present_in_page = 1
            else:
                is_owner_present_in_page = 0
                
            if(is_owner_present_in_page == 1):
                for i in range(len(vehicle_owner_infos_list)):
                    globals()["v_owner_{}".format(owner_no)][vehicle_owner_infos_list[i]] = get_value_from_df(page_df,vehicle_owner_infos_list[i])  
                owner_no += 1
            
        owner_list = [globals()['v_owner_{}'.format(i+1)] for i in range(all_veh_owner_count)]
    else:
        owner_list = [{}]
        
    return owner_list, all_veh_owner_count

def get_prop_owner_params_form3(df, prop_owner_infos_list):
    
    label_count_dict = dict()
    
    for label in prop_owner_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    prop_owner_city = label_count_dict["Damaged_Properties_Phone"]
    prop_owner_f_name = label_count_dict["Damaged_Properties_Owner"]
    prop_owner_add1 = label_count_dict["Damaged_Properties_Address"]
    prop_owner_add2 = label_count_dict["Damaged_Properties_License_Number"]
    
    all_prop_owner_count = max(prop_owner_city, prop_owner_f_name, prop_owner_add1, prop_owner_add2)
    
    for i in range(all_prop_owner_count):
        globals()["prop_owner_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    prop_owner_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]        
        
        label_count_dict_in_page = dict()
        for label in prop_owner_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_prop_owner_count_in_page = label_count_dict_in_page["Damaged_Properties_Owner"]
        except:
            get_prop_owner_count_in_page = 0
        
        if(get_prop_owner_count_in_page > 0):
            is_prop_owner_present_in_page = 1
        else:
            is_prop_owner_present_in_page = 0
            
        if(is_prop_owner_present_in_page == 1):
            for i in range(len(prop_owner_infos_list)):
                globals()["prop_owner_{}".format(prop_owner_no)][prop_owner_infos_list[i]] = get_value_from_df(page_df,prop_owner_infos_list[i])
                
            prop_owner_no += 1
        
    prop_owner_list = [globals()['prop_owner_{}'.format(i+1)] for i in range(all_prop_owner_count)]
    return prop_owner_list, all_prop_owner_count

def get_citation_params_form3(df, citation_infos_list):
    
    label_count_dict = dict()
    
    for label in citation_infos_list:
        label_count_dict[label] = get_label_count(df, label)
            
        
    cite_viol = label_count_dict["Driver_Violations_1st_Violation"]
    cite_desc = label_count_dict["Driver_Violations_1st_Violation_Description"]

    
    all_citation_count = max(cite_viol, cite_desc)
    
    for i in range(all_citation_count):
        globals()["citation_{}".format(i+1)] = dict()
    
    total_pages_in_df = df["page_no"].nunique()
    
    citation_no = 1
    for page_no in range(1,total_pages_in_df+1):
        page_df = df[df["page_no"] == "page_no_{}".format(page_no)]        
        
        label_count_dict_in_page = dict()
        for label in citation_infos_list:
            label_count_dict_in_page[label] = get_label_count(page_df, label)
        
        try:    
            get_citation_count_in_page = label_count_dict_in_page["Driver_Violations_1st_Violation"]
        except:
            get_citation_count_in_page = 0
        
        if(get_citation_count_in_page > 0):
            is_citation_present_in_page = 1
        else:
            is_citation_present_in_page = 0
            
        if(is_citation_present_in_page == 1):
            for i in range(len(citation_infos_list)):
                globals()["citation_{}".format(citation_no)][citation_infos_list[i]] = get_value_from_df(page_df,citation_infos_list[i])
                
            citation_no += 1
        
    citation_list = [globals()['citation_{}'.format(i+1)] for i in range(all_citation_count)]
    return citation_list, all_citation_count

def get_photo_form3(df):
    try:
        key = "Incident_Information_Photographer_Name"
        value = get_value_from_df(df,key)
        value = value.strip()
        if(len(value) == 0):
            photos = "N"
        else:
            photos = "Y"
        return photos
    except:
        return "N"
 