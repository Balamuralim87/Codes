from typing import List
import json
import pandas as pd
import re
import sys
from TENNESSEE.common_util import *  
  

global num_property_owner_1
global num_property_owner_2

class Incident(object):
    def __init__(self, Crash_Date:str, Case_Identifier:str, State_Report_Number:str, Crash_City:str, Loss_Street:str,
                  Loss_Cross_Street:str, Latitude:str, Longitude:str, Loss_State_Abbr:str, Report_Type_Id:str, Gps_Other:str, Incident_Hit_and_Run:str, 
                  Dispatch_Time:str, Photographs_Taken:str, Weather_Condition:str):
        
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Incident_Hit_and_Run = Incident_Hit_and_Run
        self.Dispatch_Time = Dispatch_Time        
        self.Photographs_Taken = Photographs_Taken        
        self.Weather_Condition = Weather_Condition


class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: str, First_Name: str, Middle_Name: str, Last_Name: str, Name_Suffix: str, Address: str, Address2: str,
                  City: str, State: str, Zip_Code: str, Home_Phone: str, Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str,
                  Injury_Status: str, Safety_Equipment_Restraint: str, Ejection: str, Transported_To :str, Drug_Use_Suspected:str, Alcohol_Use_Suspected: str,
                  Driver_Actions_At_Time_Of_Crash: str, Driver_Distracted_By: str, Non_Motorist_Actions_At_Time_Of_Crash:str):
        
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        self.Safety_Equipment_Restraint = Safety_Equipment_Restraint
        self.Ejection = Ejection
        self.Transported_To = Transported_To
        self.Drug_Use_Suspected = Drug_Use_Suspected
        self.Alcohol_Use_Suspected = Alcohol_Use_Suspected
        self.Driver_Actions_At_Time_Of_Crash = Driver_Actions_At_Time_Of_Crash
        self.Driver_Distracted_By = Driver_Distracted_By
        self.Non_Motorist_Actions_At_Time_Of_Crash = Non_Motorist_Actions_At_Time_Of_Crash
        
        
class Vehicle(object):
    def __init__(self, VinValidation_VinStatus:str, Unit_Number:str, License_Plate:str, Registration_State:str, VIN:str,
                  Vehicle_Towed:str, Model_Year:str, Make:str, Model:str, Insurance_Company:str, Insurance_Policy_Number:str, 
                  Insurance_Expiration_Date:str, Damaged_Areas:str, Air_Bag_Deployed:str, Party_Id:str,
                  Contributing_Circumstances_Vehicle:str, Road_Surface_Condition:str, Posted_Statutory_SpeedLimit:str):

        self.VinValidation_VinStatus = VinValidation_VinStatus
        self.Unit_Number = Unit_Number
        self.License_Plate = License_Plate
        self.Registration_State = Registration_State
        self.VIN = VIN
        self.Vehicle_Towed = Vehicle_Towed
        self.Model_Year = Model_Year
        self.Make = Make
        self.Model = Model
        self.Insurance_Company = Insurance_Company
        self.Insurance_Policy_Number = Insurance_Policy_Number
        self.Insurance_Expiration_Date = Insurance_Expiration_Date
        self.Damaged_Areas = Damaged_Areas
        self.Air_Bag_Deployed = Air_Bag_Deployed
        self.Party_Id = Party_Id
        self.Contributing_Circumstances_Vehicle = Contributing_Circumstances_Vehicle
        self.Road_Surface_Condition = Road_Surface_Condition
        self.Posted_Statutory_SpeedLimit = Posted_Statutory_SpeedLimit  
        
class Citations(object):
    def __init__(self,Citation_Issued:str, Citation_Detail:str, Violation_Code:str, Party_Id:str, Unit_Number:str):
        
        self.Citation_Issued = Citation_Issued
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code
        self.Party_Id = Party_Id
        self.Unit_Number = Unit_Number

class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations

class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report    
        
"""Form 1,2 JSON Conversion"""    
def incident_extraction(df, incident_list):
    try:
        incident = Incident(Crash_Date = get_value_from_df(df,"Incident_Information_Date_Of_Crash"),
                            Case_Identifier = get_value_from_df(df,"Incident_Information_Local_Agency_Number"),
                            State_Report_Number = get_value_from_df(df,"Incident_Information_Agency_Tracking_Number"),
                            Crash_City = get_value_from_df(df,"Incident_Information_City"),
                            Loss_Street = get_value_from_df(df,"Incident_Information_Roadway_Name"),
                            Loss_Cross_Street = get_loss_cross_street_form1(df),
                            Latitude = get_value_from_df(df,"Incident_Information_Latitude"),
                            Longitude = get_value_from_df(df,"Incident_Information_Longitude"),
                            Loss_State_Abbr = "TN",
                            Report_Type_Id = "A",
                            Gps_Other = "",
                            Incident_Hit_and_Run = get_incident_hit_run(get_value_from_df(df,"Incident_Information_Hit_and_Run")),
                            Dispatch_Time = get_value_from_df(df,"Incident_Information_Time_Notified"),
                            Photographs_Taken = get_photo(get_value_from_df(df,"Incident_Information_Photos_Taken_"), get_value_from_df(df,"Incident_Information_Photos_Taken_By")),
                            Weather_Condition = [get_code_desc_from_df(df, "Incident_Information_Weather_Conditions")])
        
        incident_list.append(incident)
        return(incident_list)
    except:
        print("Error : Error in incident_extraction()")
        return sys.exc_info(), "error" 

def driver_extraction(df, driver_list, people_list):
    try:
        for i in range(len(driver_list)):
            dic = driver_list[i]
            driver_info = People(Party_Id = "01",
                                Person_Type = "DRIVER",
                                Unit_Number = i+1,
                                First_Name = get_dic_value(dic, "Driver_Information_First_Name"),
                                Middle_Name = get_dic_value(dic, "Driver_Information_Middle_Initial"),
                                Last_Name = get_dic_value(dic, "Driver_Information_Last_Name"),
                                Name_Suffix = get_dic_value(dic, "Driver_Information_Suffix"),
                                Address = get_dic_value(dic, "Driver_Information_Address_Line_1"),
                                Address2 = get_dic_value(dic, "Driver_Information_Address_Line_2"),
                                City = get_dic_value(dic, "Driver_Information_City"),
                                State = get_dic_value(dic, "Driver_Information_State"),
                                Zip_Code = get_dic_value(dic, "Driver_Information_Zip_Code"),
                                Home_Phone = map_driver_phone(dic), #Write
                                Date_Of_Birth = get_dic_value(dic, "Driver_Information_Date_of_Birth"),
                                Drivers_License_Number = get_dic_value(dic, "Driver_Information_Drivers_License_Number"),
                                Drivers_License_Jurisdiction = get_dic_value(dic, "Driver_Information_License_State"),
                                Injury_Status= get_injury_status(dic, "Driver_Information_Injury_Code"),
                                Safety_Equipment_Restraint = [get_code_desc_from_dic(dic, "Driver_Information_Safety_Equipment")],
                                Ejection = process_ejection(get_dic_value(dic, "Driver_Information_Ejected")), 
                                Transported_To = get_dic_value(dic, "Driver_Information_Ambulance_Hospital"),
                                Drug_Use_Suspected = [get_code_desc_from_dic(dic, "Alcohol_and_Drugs_Presence_of_Drugs")],
                                Alcohol_Use_Suspected = [get_code_desc_from_dic(dic, "Alcohol_and_Drugs_Presence_of_Alcohol")],
                                Driver_Actions_At_Time_Of_Crash = map_driver_actions(dic),
                                Driver_Distracted_By = [get_code_desc_from_dic(dic, "Driver_Conditions_and_Actions_Distraction")],
                                Non_Motorist_Actions_At_Time_Of_Crash = [{"Code" : "", "Description" : ""}]) #Could not find
            
            # l_fn = len(driver_info.First_Name)
            # l_ln = len(driver_info.Last_Name)
            # l_ad = len(driver_info.Address)
            
            # if(l_fn > 0 or l_ln >0 or l_ad > 0):
            people_list.append(driver_info)
                
        return(people_list)
    except:
        print("Error : Error in driver_extraction()")
        return sys.exc_info(), "error"   
        
def occupants_extraction(df, people_list, other_party_list):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(other_party_list)):
            dic = other_party_list[i]
            occupants_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = get_dic_value(dic, "Occupants_Person_Type").upper(),
                                Unit_Number = i+1,
                                First_Name = get_dic_value(dic, "Occupants_First_Name"),
                                Middle_Name = get_dic_value(dic, "Driver_Information_Middle_Initial"),
                                Last_Name = get_dic_value(dic, "Driver_Information_Last_Name"),
                                Name_Suffix = get_dic_value(dic, "Occupants_Suffix"),
                                Address = get_dic_value(dic, "Occupants_Address_Line_1"),
                                Address2 = get_dic_value(dic, "Occupants_Address_Line_2"),
                                City = get_dic_value(dic, "Occupants_City"),
                                State = get_dic_value(dic, "Occupants_State"),
                                Zip_Code = get_dic_value(dic, "Occupants_Zip_Code"),
                                Home_Phone = map_occupants_phone(dic),
                                Date_Of_Birth = get_dic_value(dic, "Occupants_Date_Of_Birth"),
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= get_injury_status(dic, "Occupants_Injury_Code"),
                                Safety_Equipment_Restraint = [get_code_desc_from_dic(dic, "Occupants_Safety_Equipment")],
                                Ejection = process_ejection(get_dic_value(dic, "Occupants_Ejected")),
                                Transported_To = get_dic_value(dic, "Occupants_Ambulance_Hospital"),
                                Drug_Use_Suspected = [get_code_desc_from_dic(dic, "Alcohol_and_Drugs_Presence_of_Drugs")],
                                Alcohol_Use_Suspected = [get_code_desc_from_dic(dic, "Alcohol_and_Drugs_Presence_of_Alcohol")],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = default,
                                Non_Motorist_Actions_At_Time_Of_Crash = default)
            
            # o_pt = len(occupants_info.Person_Type)
            # o_zc = len(occupants_info.Zip_Code)
            # o_fn = len(occupants_info.First_Name)
            # o_st = len(occupants_info.State)
            
            # if(o_pt > 0 or o_zc >0 or o_fn > 0 or o_st > 0):
            people_list.append(occupants_info)
            
        return(people_list)
    except:
        print("Error : Error in occupants_extraction()")
        return sys.exc_info(), "error"   
        
def witness_extraction(df, people_list, witness_list):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(witness_list)):
            dic = witness_list[i]
            witness_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "WITNESS",
                                Unit_Number = "",
                                First_Name = get_dic_value(dic, "Collision_Witnesses_First_Name"),
                                Middle_Name = get_dic_value(dic, "Collision_Witnesses_Middle_Name"),
                                Last_Name = get_dic_value(dic, "Collision_Witnesses_Last_Name"),
                                Name_Suffix = get_dic_value(dic, "Collision_Witnesses_Suffix"),
                                Address = get_dic_value(dic, "Collision_Witnesses_Address_Line_1"),
                                Address2 = get_dic_value(dic, "Collision_Witnesses_Address_Line_2"),
                                City = get_dic_value(dic, "Collision_Witnesses_City"),
                                State = get_dic_value(dic, "Collision_Witnesses_State"),
                                Zip_Code = get_dic_value(dic, "Collision_Witnesses_Zip_Code"),
                                Home_Phone = map_witness_phone(dic),
                                Date_Of_Birth = get_dic_value(dic, "Collision_Witnesses_Date_Of_Birth"),
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = default,
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = default,
                                Alcohol_Use_Suspected = default,
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = default,
                                Non_Motorist_Actions_At_Time_Of_Crash = default)
            
            # w_fn = len(witness_info.First_Name)
            # w_ad = len(witness_info.Address)
            # w_ln = len(witness_info.Last_Name)
            # w_st = len(witness_info.State)

            # if(w_fn > 0 or w_ad >0 or w_ln > 0 or w_st > 0):
            people_list.append(witness_info)

        return(people_list)
    except:
        print("Error : Error in witness_extraction()")
        return sys.exc_info(), "error"   
    
   
def vehicle_detail_extraction(df, vehicle_list, driver_list, vehicle_list_ext):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(vehicle_list)):
            dic_driver = driver_list[i]
            dic = vehicle_list[i]
            vehicle_info = Vehicle(VinValidation_VinStatus = vin_status(get_dic_value(dic, "Vehicle_Information_VIN")),
                                    Unit_Number = i+1,
                                    License_Plate = get_dic_value(dic, "Vehicle_Information_License_Plate_Number"),
                                    Registration_State = get_dic_value(dic, "Vehicle_Information_State"),
                                    VIN = get_dic_value(dic, "Vehicle_Information_VIN"),
                                    Vehicle_Towed = get_vehicle_towed(get_dic_value(dic, "Vehicle_Information_Towed")),
                                    Model_Year = get_dic_value(dic, "Vehicle_Information_Vehicle_Year"),
                                    Make = get_dic_value(dic, "Vehicle_Information_Vehicle_Make"),
                                    Model = get_dic_value(dic, "Vehicle_Information_Vehicle_Model"),
                                    Insurance_Company = get_insurance(get_dic_value(dic, "Vehicle_Information_Insurance_1_Carrier")),
                                    Insurance_Policy_Number = get_dic_value(dic, "Vehicle_Information_Insurance_1"),
                                    Insurance_Expiration_Date = get_dic_value(dic, "Vehicle_Information_Insurance_1_End_Date"),
                                    Damaged_Areas = get_damaged_areas(get_dic_value(dic, "Vehicle_Damage_and_Roadway_Characteristics_Point_of_First_Impact")),
                                    Air_Bag_Deployed = vehicle_air_bag_status(dic_driver, dic),
                                    Party_Id = "01",
                                    Contributing_Circumstances_Vehicle = map_vehicle_contrib_circum(dic),
                                    Road_Surface_Condition = [get_code_desc_from_dic(dic, "Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions")],
                                    Posted_Statutory_SpeedLimit = get_dic_value(dic, "Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit"))
            
            # v_lp = len(vehicle_info.License_Plate)
            # v_make = len(vehicle_info.Make)
            # v_model = len(vehicle_info.Model_Year)
            # v_area = len(vehicle_info.Damaged_Areas)
            
            # if(v_lp > 0 or v_make >0 or v_model > 0 or v_area > 0):
            vehicle_list_ext.append(vehicle_info)
                
        return(vehicle_list_ext)
    except:
        print("Error : Error in vehicle_detail_extraction()")
        return sys.exc_info(), "error"   
    
def vehicle_owner_extraction(df, vehicle_list, driver_list, people_list):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(vehicle_list)):
            dic = vehicle_list[i]
            dic_driver = driver_list[i]
            owner_same_as_driver = get_dic_value(dic, "Vehicle_Information_Owner_Same_as_Driver")
            owner_same_as_driver = owner_same_as_driver.upper()
            if("YES" in owner_same_as_driver or "YE" in owner_same_as_driver):
                v_owner_info = People(Party_Id = "01",
                                    Person_Type = "VEHICLE OWNER",
                                    Unit_Number = i+1,
                                    First_Name = get_dic_value(dic_driver, "Driver_Information_First_Name"),
                                    Middle_Name = get_dic_value(dic_driver, "Driver_Information_Middle_Initial"),
                                    Last_Name = get_dic_value(dic_driver, "Driver_Information_Last_Name"),
                                    Name_Suffix = get_dic_value(dic_driver, "Driver_Information_Suffix"),
                                    Address = get_dic_value(dic_driver, "Driver_Information_Address_Line_1"),
                                    Address2 = get_dic_value(dic_driver, "Driver_Information_Address_Line_2"),
                                    City = get_dic_value(dic_driver, "Driver_Information_City"),
                                    State = get_dic_value(dic_driver, "Driver_Information_State"),
                                    Zip_Code = get_dic_value(dic_driver, "Driver_Information_Zip_Code"),
                                    Home_Phone = map_driver_phone(dic_driver),
                                    Date_Of_Birth = get_dic_value(dic_driver, "Driver_Information_Date_of_Birth"),
                                    Drivers_License_Number = get_dic_value(dic_driver, "Driver_Information_Drivers_License_Number"),
                                    Drivers_License_Jurisdiction = get_dic_value(dic_driver, "Driver_Information_License_State"),
                                    Injury_Status = get_injury_status(dic, "Driver_Information_Injury_Code"),
                                    Safety_Equipment_Restraint = [get_code_desc_from_dic(dic_driver, "Driver_Information_Safety_Equipment")],
                                    Ejection = process_ejection(get_dic_value(dic, "Driver_Information_Ejected")),
                                    Transported_To = get_dic_value(dic_driver, "Driver_Information_Ambulance_Hospital"),
                                    Drug_Use_Suspected = [get_code_desc_from_dic(dic_driver, "Alcohol_and_Drugs_Presence_of_Drugs")],
                                    Alcohol_Use_Suspected = [get_code_desc_from_dic(dic_driver, "Alcohol_and_Drugs_Presence_of_Alcohol")],
                                    Driver_Actions_At_Time_Of_Crash = map_driver_actions(dic_driver),
                                    Driver_Distracted_By = [get_code_desc_from_dic(dic_driver, "Driver_Conditions_and_Actions_Distraction")],
                                    Non_Motorist_Actions_At_Time_Of_Crash = [default]) #Could not find

            else:
                v_owner_info = People(Party_Id = "0" + str(i+1),
                                    Person_Type = "VEHICLE OWNER",
                                    Unit_Number = i+1,
                                    First_Name = get_dic_value(dic, "Vehicle_Information_Owner_First_Name"),
                                    Middle_Name = get_dic_value(dic, "Vehicle_Information_Owner_Middle_Name"),
                                    Last_Name = get_dic_value(dic, "Vehicle_Information_Owner_Last_Name"),
                                    Name_Suffix = get_dic_value(dic, "Vehicle_Information_Owner_Suffix"),
                                    Address = get_dic_value(dic, "Vehicle_Information_Address_Line_1"),
                                    Address2 = get_dic_value(dic, "Vehicle_Information_Address_Line_2"),
                                    City = get_dic_value(dic, "Vehicle_Information_City"),
                                    State = get_dic_value(dic, "Vehicle_Information_State"),
                                    Zip_Code = get_dic_value(dic, "Vehicle_Information_Zip_Code"),
                                    Home_Phone = map_v_owner_phone(dic),
                                    Date_Of_Birth = "",
                                    Drivers_License_Number = "",
                                    Drivers_License_Jurisdiction = "",
                                    Injury_Status= "",
                                    Safety_Equipment_Restraint = [default],
                                    Ejection = "",
                                    Transported_To = "",
                                    Drug_Use_Suspected = "",
                                    Alcohol_Use_Suspected = "",
                                    Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                    Driver_Distracted_By = [default],
                                    Non_Motorist_Actions_At_Time_Of_Crash = [default]) #Could not find
                
            # vo_fn = len(v_owner_info.First_Name)
            # vo_ln = len(v_owner_info.Last_Name)
            # vo_ad = len(v_owner_info.Address)
            
            # if(vo_fn > 0 or vo_ln >0 or vo_ad > 0):
            people_list.append(v_owner_info)
                
        return(people_list)
    except:
        print("Error : Error in vehicle_owner_extraction()")
        return sys.exc_info(), "error"   
        
def citation_extraction(df, driver_list, citation_list):
    try:
        d_citation_codes = ['Driver_Violations_1st_Violation_Statute', 'Driver_Violations_2nd_Violation_Statute',
                            'Driver_Violations_3rd_Violation_Statute', 'Driver_Violations_4th_Violation_Statute',
                            'Driver_Violations_5th_Violation_Statute']
        
        d_citation_desc = ['Driver_Violations_1st_Violation_Description', 'Driver_Violations_2nd_Violation_Description',
                           'Driver_Violations_3rd_Violation_Description', 'Driver_Violations_4th_Violation_Description',
                           'Driver_Violations_5th_Violation_Description']

        for i in range(len(driver_list)):
            dic = driver_list[i]
            for code, desc in zip(d_citation_codes, d_citation_desc):
                
                v_code = get_dic_value(dic, code)
                cite_detail = get_dic_value(dic, desc)
                citation_issued = "Yes" if len(cite_detail.strip()) > 0 else ""
            

                cite_info = Citations(Citation_Issued = citation_issued,
                                      Citation_Detail = cite_detail,
                                      Violation_Code = v_code,
                                      Party_Id =  "",
                                      Unit_Number =  i+1)
                
        
                if(len(str(cite_info.Citation_Detail)) > 1 or len(str(cite_info.Violation_Code)) > 0):
                    citation_list.append(cite_info)

    except:
        return(citation_list)
    if(len(citation_list) > 0):
        return citation_list
    else:
        cite_info = Citations(Citation_Issued = "",
                              Citation_Detail = "",
                              Violation_Code = "",
                              Party_Id =  "",
                              Unit_Number =  "")
        citation_list.append(cite_info)
        return citation_list
    
global page_no_prop_owner_1
def property_owner_extraction(df, people_list, property_infos_list, vehicle_list_ext, num_property_owner_1):
    try:
        default = {"Code" : "", "Description" : ""}
        unit_no = int(num_property_owner_1)    
        for i in range(len(property_infos_list)):
            unit_no += 1
            dic = property_infos_list[i]
            p_owner_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "PROPERTY OWNER",
                                Unit_Number = unit_no,
                                First_Name = "",
                                Middle_Name = "",
                                Last_Name = get_dic_value(dic, "Property_Owner_Information_Other_Property_Damages"),
                                Name_Suffix = "",
                                Address = "",
                                Address2 = "",
                                City = "",
                                State = "",
                                Zip_Code = "",
                                Home_Phone = "",
                                Date_Of_Birth = "",
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = [default],
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = [default],
                                Alcohol_Use_Suspected = [default],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = default,
                                Non_Motorist_Actions_At_Time_Of_Crash = default)
            
            driver_info = People(Party_Id = "01",
                                Person_Type = "DRIVER",
                                Unit_Number = unit_no,
                                First_Name = "",
                                Middle_Name = "",
                                Last_Name = "",
                                Name_Suffix = "",
                                Address = "",
                                Address2 = "",
                                City = "",
                                State = "",
                                Zip_Code = "",
                                Home_Phone = "", 
                                Date_Of_Birth = "",
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = [default],
                                Ejection = "", 
                                Transported_To = "",
                                Drug_Use_Suspected = [default],
                                Alcohol_Use_Suspected = [default],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default]) #Could not find
            
            v_owner_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "VEHICLE OWNER",
                                Unit_Number = unit_no,
                                First_Name = get_dic_value(dic, "Property_Owner_Information_First_Name"),
                                Middle_Name = get_dic_value(dic, "Property_Owner_Information_Middle_Name"),
                                Last_Name = get_dic_value(dic, "Property_Owner_Information_Last_Name"),
                                Name_Suffix = get_dic_value(dic, "Property_Owner_Information_Suffix"),
                                Address = get_dic_value(dic, "Property_Owner_Information_Address_Line_1"),
                                Address2 = get_dic_value(dic, "Property_Owner_Information_Address_Line_2"),
                                City = get_dic_value(dic, "Property_Owner_Information_City"),
                                State = get_dic_value(dic, "Property_Owner_Information_State"),
                                Zip_Code = get_dic_value(dic, "Property_Owner_Information_Zip_Code"),
                                Home_Phone = map_v_owner_phone(dic),
                                Date_Of_Birth = "",
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = [default],
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = "",
                                Alcohol_Use_Suspected = "",
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default])
            
            vehicle_info = Vehicle(VinValidation_VinStatus = "",
                                    Unit_Number = unit_no,
                                    License_Plate = "",
                                    Registration_State = "",
                                    VIN = "",
                                    Vehicle_Towed = "",
                                    Model_Year = "",
                                    Make = "",
                                    Model = "",
                                    Insurance_Company = "",
                                    Insurance_Policy_Number = "",
                                    Insurance_Expiration_Date = "",
                                    Damaged_Areas = "",
                                    Air_Bag_Deployed = "",
                                    Party_Id = "01",
                                    Contributing_Circumstances_Vehicle = "",
                                    Road_Surface_Condition = "",
                                    Posted_Statutory_SpeedLimit = "")
                        
            people_list.append(p_owner_info)
            people_list.append(driver_info)
            people_list.append(v_owner_info)
            vehicle_list_ext.append(vehicle_info)

        return(people_list, vehicle_list_ext)
    except:
        print("Error : Error in property_owner_extraction()")
        return sys.exc_info(), "error"   





      

"""Form 3 JSON COnversion"""
def incident_extraction_form3(df, incident_list):
    try:
        incident = Incident(Crash_Date = get_value_from_df(df,"Incident_Information_Date_Of_Crash"),
                            Case_Identifier = get_value_from_df(df,"Master_Record_Number"),
                            State_Report_Number = get_value_from_df(df,"Incident_Information_Agency_Tracking_Number"),
                            Crash_City = get_value_from_df(df,"Incident_Information_City_County").split(",")[0],
                            Loss_Street = get_value_from_df(df,"Incident_Information_Location").split(",")[0],
                            Loss_Cross_Street = get_loss_cross_street_form3(df),
                            Latitude = get_value_from_df(df,"Incident_Information_Latitude_Longitude").split("/")[0].strip(),
                            Longitude = get_value_from_df(df,"Incident_Information_Latitude_Longitude").split("/")[-1].strip(),
                            Loss_State_Abbr = "TN",
                            Report_Type_Id = "A",
                            Gps_Other = "",
                            Incident_Hit_and_Run = get_incident_hit_run(get_value_from_df(df,"Incident_Information_Hit_and_Run")),
                            Dispatch_Time = get_dispatch_time(get_value_from_df(df,"Incident_Information_Time_Notified")),
                            Photographs_Taken = get_photo_form3(df),
                            Weather_Condition = [get_code_desc_from_df(df, "Incident_Information_Weather_Conditions")])
        
        incident_list.append(incident)
        return(incident_list)
    except:
        print("Error : Error in incident_extraction_form3()")
        return sys.exc_info(), "error"  
    
def driver_extraction_form3(df, driver_list, people_list, city_lookup_path, business_name_lookup_path):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(driver_list)):
            dic = driver_list[i]
            driver_info = People(Party_Id = "01",
                                Person_Type = "DRIVER",
                                Unit_Number = i+1,
                                First_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                Middle_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                Last_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                Address = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['address'],
                                Address2 = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['address2'],
                                City = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['city'],
                                State = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['state'],
                                Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['zipcode'],
                                Home_Phone = map_phone_form3(dic, "Driver_Information_Phone_1", "Driver_Information_Phone_2", "Driver_Information_Phone_3"), #Write
                                Date_Of_Birth = get_dic_value(dic, "Driver_Information_Date_of_Birth"),
                                Drivers_License_Number = get_dic_value(dic, "Driver_Information_Drivers_License_Number").split(",")[0],
                                Drivers_License_Jurisdiction = get_dic_value(dic, "Driver_Information_Drivers_License_Number").split(",")[-1],
                                Injury_Status = get_injury_status(dic, "Driver_Information_Injury_Code"),
                                Safety_Equipment_Restraint = [get_code_desc_from_dic(dic, "Driver_Information_Safety_Equipment")],
                                Ejection = process_ejection(get_dic_value(dic, "Driver_Information_Ejected")),
                                Transported_To = get_dic_value(dic, "Driver_Information_Ambulance_Hospital"),
                                Drug_Use_Suspected = [get_code_desc_from_dic(dic, "Driver_Information_Alcohol_and_Drugs_Presence_of_Drugs")],
                                Alcohol_Use_Suspected = [get_code_desc_from_dic(dic, "Driver_Information_Alcohol_and_Drugs_Presence_of_Alcohol")],
                                Driver_Actions_At_Time_Of_Crash = [get_code_desc_from_dic(dic, "Driver_Information_Driver_Conditions_and_Actions_Drivers_Action"), default, default, default],
                                Driver_Distracted_By = [get_code_desc_from_dic(dic, "Driver_Information_Driver_Conditions_and_Actions_Distraction")],
                                Non_Motorist_Actions_At_Time_Of_Crash = [{"Code" : "", "Description" : ""}]) #Could not find
            
            # l_fn = len(driver_info.First_Name)
            # l_ln = len(driver_info.Last_Name)
            # l_ad = len(driver_info.Address)
            # l_ej = len(driver_info.Ejection)
            # l_in = len(driver_info.Injury_Status)
            
            # if(l_fn > 0 or l_ln >0 or l_ad > 0 or l_ej>0 or l_in >0):
            people_list.append(driver_info)
                
        return(people_list)
    except:
        print("Error : Error in driver_extraction_form3()")
        return sys.exc_info(), "error"   

def witness_extraction_form3(df, people_list, witness_list, city_lookup_path, business_name_lookup_path):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(witness_list)):
            dic = witness_list[i]
            witness_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "WITNESS",
                                Unit_Number = i+1,
                                First_Name = name_split_using_pattern(get_dic_value(dic, "Witnesses_Name"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                Middle_Name = name_split_using_pattern(get_dic_value(dic, "Witnesses_Name"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                Last_Name = name_split_using_pattern(get_dic_value(dic, "Witnesses_Name"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Witnesses_Name"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                Address = name_address_split_using_lookup(get_dic_value(dic, "Witnesses_Address"), city_lookup_path)['address'],
                                Address2 = name_address_split_using_lookup(get_dic_value(dic, "Witnesses_Address"), city_lookup_path)['address2'],
                                City = name_address_split_using_lookup(get_dic_value(dic, "Witnesses_Address"), city_lookup_path)['city'],
                                State = name_address_split_using_lookup(get_dic_value(dic, "Witnesses_Address"), city_lookup_path)['state'],
                                Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Witnesses_Address"), city_lookup_path)['zipcode'],
                                Home_Phone = map_phone_form3(dic, "Witnesses_Phone_1", "Witnesses_Phone_2", "Witnesses_Phone_3"),
                                Date_Of_Birth = get_dic_value(dic, "Witnesses_Date_of_Birth"),
                                Drivers_License_Number = get_dic_value(dic, "Witnesses_License_Number"),
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = default,
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = "",
                                Alcohol_Use_Suspected = "",
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = default,
                                Non_Motorist_Actions_At_Time_Of_Crash = default)
            
            # w_fn = len(witness_info.First_Name)
            # w_ad = len(witness_info.Address)
            # w_ln = len(witness_info.Last_Name)
            # w_st = len(witness_info.State)

            # if(w_fn > 0 or w_ad >0 or w_ln > 0 or w_st > 0):
            people_list.append(witness_info)

        return(people_list)
    except:
        print("Error : Error in witness_extraction_form3()")
        return sys.exc_info(), "error"   
        
def occupants_extraction_form3(df, people_list, other_party_list, city_lookup_path, business_name_lookup_path):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(other_party_list)):
            dic = other_party_list[i]
            occupants_info = People(Party_Id = get_dic_value(dic, "Occupants_Party_Id"),
                                Person_Type = "PASSENGER",
                                Unit_Number = get_dic_value(dic, "Occupants_Unit_Id"),
                                First_Name = name_split_using_pattern(get_dic_value(dic, "Occupants_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                Middle_Name = name_split_using_pattern(get_dic_value(dic, "Occupants_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                Last_Name = name_split_using_pattern(get_dic_value(dic, "Occupants_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Occupants_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                Address = name_address_split_using_lookup(get_dic_value(dic, "Occupants_Address"), city_lookup_path)['address'],
                                Address2 = name_address_split_using_lookup(get_dic_value(dic, "Occupants_Address"), city_lookup_path)['address2'],
                                City = name_address_split_using_lookup(get_dic_value(dic, "Occupants_Address"), city_lookup_path)['city'],
                                State = name_address_split_using_lookup(get_dic_value(dic, "Occupants_Address"), city_lookup_path)['state'],
                                Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Occupants_Address"), city_lookup_path)['zipcode'],
                                Home_Phone = map_phone_form3(dic, "Occupants_Phone_1", "Occupants_Phone_2", "Occupants_Phone_3"),
                                Date_Of_Birth = get_dic_value(dic, "Occupants_Date_Of_Birth"),
                                Drivers_License_Number = get_dic_value(dic, "Occupants_Drivers_License_Number"),
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= get_injury_status(dic, "Occupants_Injury_Code"),
                                Safety_Equipment_Restraint = [get_code_desc_from_dic(dic, "Occupants_Safety_Equipment")],
                                Ejection = process_ejection(get_dic_value(dic, "Occupants_Ejected")),
                                Transported_To = get_dic_value(dic, "Occupants_Ambulance_Hospital"),
                                Drug_Use_Suspected = [get_code_desc_from_dic(dic, "Occupants_Alcohol_and_Drugs_Presence_of_Drugs")],
                                Alcohol_Use_Suspected = [get_code_desc_from_dic(dic, "Occupants_Alcohol_and_Drugs_Presence_of_Alcohol")],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default])
            
            # o_pt = len(occupants_info.Person_Type)
            # o_zc = len(occupants_info.Zip_Code)
            # o_fn = len(occupants_info.First_Name)
            # o_st = len(occupants_info.State)
            
            # if(o_pt > 0 or o_zc >0 or o_fn > 0 or o_st > 0):
            people_list.append(occupants_info)
            
        return(people_list)
    except:
        print("Error : Error in occupants_extraction_form3()")
        return sys.exc_info(), "error"   

def citation_extraction_form3(df, driver_list, citation_list, blank_list):
    try:        
        for value in range(len(citation_list)):
            v_code = citation_list[value]['Driver_Violations_1st_Violation']
            cite_detail = citation_list[value]['Driver_Violations_1st_Violation_Description']

            idx = 0
            for i in range(len(cite_detail)):
                if(cite_detail[i] == "("):
                    idx = i
                    break;
                else:
                    idx = len(cite_detail)+1
            
            cite_detail = cite_detail[:idx-1]
            
            if("NO" in cite_detail.upper()):
                cite_detail = ""
                


            citation_issued = "Yes" if len(cite_detail.strip()) > 0 else ""
            pattern = "\d"
            n = re.search(pattern, citation_list[value]['Driver_Information_Vehicle_No']).group(0)
            party_id =  "0" + str(n)
            unit = "0" + str(n)
            
            cite_info = Citations(Citation_Issued = citation_issued,
                                  Citation_Detail = cite_detail,
                                  Violation_Code = v_code,
                                  Party_Id =  "",
                                  Unit_Number =  unit)


            if(len(str(cite_info.Citation_Detail)) > 1 or len(str(cite_info.Violation_Code)) > 0):
                blank_list.append(cite_info)
    
        if(len(blank_list) > 0):
            return blank_list
        else:
            cite_info = Citations(Citation_Issued = "",
                                  Citation_Detail = "",
                                  Violation_Code = "",
                                  Party_Id =  "",
                                  Unit_Number =  "")
            blank_list.append(cite_info)
            return blank_list
    except:
        cite_info = Citations(Citation_Issued = "",
                              Citation_Detail = "",
                              Violation_Code = "",
                              Party_Id =  "",
                              Unit_Number =  "")
        blank_list.append(cite_info)
        return blank_list
        
def property_owner_extraction_form3(df, people_list, property_infos_list, city_lookup_path, business_name_lookup_path, vehicle_list_ext, num_property_owner_2):
    try:
        unit_no = int(num_property_owner_2) + 1
        default = {"Code" : "", "Description" : ""}
        for i in range(len(property_infos_list)):
            dic = property_infos_list[i]
            unit_no += 1
            p_owner_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "PROPERTY OWNER",
                                Unit_Number = unit_no,
                                First_Name = "",
                                Middle_Name = "",
                                Last_Name = get_dic_value(dic, "Damaged_Properties_Item"),
                                Name_Suffix = "",
                                Address = "",
                                Address2 = "",
                                City = "",
                                State = "",
                                Zip_Code = "",
                                Home_Phone = "",
                                Date_Of_Birth = "",
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = default,
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = [default],
                                Alcohol_Use_Suspected = [default],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = default,
                                Non_Motorist_Actions_At_Time_Of_Crash = default)
            
            
            driver_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "DRIVER",
                                Unit_Number = unit_no,
                                First_Name = "",
                                Middle_Name = "",
                                Last_Name = "",
                                Name_Suffix = "",
                                Address = "",
                                Address2 = "",
                                City = "",
                                State = "",
                                Zip_Code = "",
                                Home_Phone = "", #Write
                                Date_Of_Birth = "",
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status = "",
                                Safety_Equipment_Restraint = "",
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = "",
                                Alcohol_Use_Suspected = "",
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default])
            

            owner_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "VEHICLE OWNER",
                                Unit_Number = unit_no,
                                First_Name = name_split_using_pattern(get_dic_value(dic, "Damaged_Properties_Owner"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                Middle_Name = name_split_using_pattern(get_dic_value(dic, "Damaged_Properties_Owner"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                Last_Name = name_split_using_pattern(get_dic_value(dic, "Damaged_Properties_Owner"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Damaged_Properties_Owner"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                Address = name_address_split_using_lookup(get_dic_value(dic, "Damaged_Properties_Address"), city_lookup_path)['address'],
                                Address2 = name_address_split_using_lookup(get_dic_value(dic, "Damaged_Properties_Address"), city_lookup_path)['address2'],
                                City = name_address_split_using_lookup(get_dic_value(dic, "Damaged_Properties_Address"), city_lookup_path)['city'],
                                State = name_address_split_using_lookup(get_dic_value(dic, "Damaged_Properties_Address"), city_lookup_path)['state'],
                                Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Damaged_Properties_Address"), city_lookup_path)['zipcode'],
                                Home_Phone =get_dic_value(dic, "Damaged_Properties_Phone"), 
                                Date_Of_Birth = get_dic_value(dic, "Damaged_Properties_Date_of_Birth"),
                                Drivers_License_Number = "",
                                Drivers_License_Jurisdiction = "",
                                Injury_Status= "",
                                Safety_Equipment_Restraint = [default],
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = [default],
                                Alcohol_Use_Suspected = [default],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default]) #Could not find
            


            vehicle_info = Vehicle(VinValidation_VinStatus = "",
                                    Unit_Number = unit_no,
                                    License_Plate = "",
                                    Registration_State = "",
                                    VIN = "",
                                    Vehicle_Towed = "",
                                    Model_Year = "",
                                    Make = "",
                                    Model = "",
                                    Insurance_Company = "",
                                    Insurance_Policy_Number = "",
                                    Insurance_Expiration_Date = "",
                                    Damaged_Areas = "",
                                    Air_Bag_Deployed = "",
                                    Party_Id = "01",
                                    Contributing_Circumstances_Vehicle = "",
                                    Road_Surface_Condition = "",
                                    Posted_Statutory_SpeedLimit = "")
            
            people_list.append(p_owner_info)
            people_list.append(driver_info)
            people_list.append(owner_info)
            vehicle_list_ext.append(vehicle_info)

        return(people_list, vehicle_list_ext)
    except:
        print("Error : Error in property_owner_extraction_form3()")
        return sys.exc_info(), "error"   
    
    
        
def vehicle_owner_extraction_is_driver_form3(df, driver_list, people_list, city_lookup_path, business_name_lookup_path):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(driver_list)):
            dic = driver_list[i]
            is_driver_owner = get_dic_value(dic, "Driver_Information_Owner_Data")
            if(len(is_driver_owner) > 3 and "NO" not in is_driver_owner.upper()):
                owner_info = People(Party_Id = "0" + str(i+1),
                                    Person_Type = "VEHICLE OWNER",
                                    Unit_Number = i+1,
                                    First_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                    Middle_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                    Last_Name = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                    Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Driver_Information_First_Middle_Last_Name"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                    Address = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['address'],
                                    Address2 = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['address2'],
                                    City = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['city'],
                                    State = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['state'],
                                    Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Driver_Information_Address"), city_lookup_path)['zipcode'],
                                    Home_Phone = map_phone_form3(dic, "Driver_Information_Phone_1", "Driver_Information_Phone_2", "Driver_Information_Phone_3"), #Write
                                    Date_Of_Birth = get_dic_value(dic, "Driver_Information_Date_of_Birth"),
                                    Drivers_License_Number = get_dic_value(dic, "Driver_Information_Drivers_License_Number").split(",")[0],
                                    Drivers_License_Jurisdiction = get_dic_value(dic, "Driver_Information_Drivers_License_Number").split(",")[-1],
                                    Injury_Status= get_injury_status(dic, "Driver_Information_Injury_Code"),
                                    Safety_Equipment_Restraint = [get_code_desc_from_dic(dic, "Driver_Information_Safety_Equipment")],
                                    Ejection = process_ejection(get_dic_value(dic, "Driver_Information_Ejected")),
                                    Transported_To = get_dic_value(dic, "Driver_Information_Ambulance_Hospital"),
                                    Drug_Use_Suspected = [get_code_desc_from_dic(dic, "Driver_Information_Alcohol_and_Drugs_Presence_of_Drugs")],
                                    Alcohol_Use_Suspected = [get_code_desc_from_dic(dic, "Driver_Information_Alcohol_and_Drugs_Presence_of_Alcohol")],
                                    Driver_Actions_At_Time_Of_Crash = [get_code_desc_from_dic(dic, "Driver_Information_Driver_Conditions_and_Actions_Drivers_Action"), default, default, default],
                                    Driver_Distracted_By = [get_code_desc_from_dic(dic, "Driver_Information_Driver_Conditions_and_Actions_Distraction")],
                                    Non_Motorist_Actions_At_Time_Of_Crash = [{"Code" : "", "Description" : ""}]) #Could not find
                
                # l_fn = len(owner_info.First_Name)
                # l_ln = len(owner_info.Last_Name)
                # l_ad = len(owner_info.Address)
                
                # if(l_fn > 0 or l_ln >0 or l_ad > 0):
                people_list.append(owner_info)
                
        return(people_list)
    except:
        print("Error : Error in vehicle_owner_extraction_is_driver_form3()")
        return sys.exc_info(), "error"   


def vehicle_owner_extraction_not_driver_form3(df, vehicle_owner_list, people_list, city_lookup_path, business_name_lookup_path):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(vehicle_owner_list)):
            dic = vehicle_owner_list[i]
            party_id_text = get_dic_value(dic, "Owner_Vehicle_No")
            try:
                party_id = re.search(r"\d+", party_id_text, re.IGNORECASE).group(0)
                unit_no = int(party_id)
            except:
                party_id = ""
                unit_no = ""
                
            owner_info = People(Party_Id = "0" + str(i+1),
                                Person_Type = "VEHICLE OWNER",
                                Unit_Number = unit_no,
                                First_Name = name_split_using_pattern(get_dic_value(dic, "Owner_Name"), business_name_lookup_path=business_name_lookup_path)['first_name'],
                                Middle_Name = name_split_using_pattern(get_dic_value(dic, "Owner_Name"), business_name_lookup_path=business_name_lookup_path)['middle_name'],
                                Last_Name = name_split_using_pattern(get_dic_value(dic, "Owner_Name"), business_name_lookup_path=business_name_lookup_path)['last_name'],
                                Name_Suffix = name_split_using_pattern(get_dic_value(dic, "Owner_Name"), business_name_lookup_path=business_name_lookup_path)['suffix'],
                                Address = name_address_split_using_lookup(get_dic_value(dic, "Owner_Address"), city_lookup_path)['address'],
                                Address2 = name_address_split_using_lookup(get_dic_value(dic, "Owner_Address"), city_lookup_path)['address2'],
                                City = name_address_split_using_lookup(get_dic_value(dic, "Owner_Address"), city_lookup_path)['city'],
                                State = name_address_split_using_lookup(get_dic_value(dic, "Owner_Address"), city_lookup_path)['state'],
                                Zip_Code = name_address_split_using_lookup(get_dic_value(dic, "Owner_Address"), city_lookup_path)['zipcode'],
                                Home_Phone = map_phone_form3(dic, "Owner_Phone_1", "Owner_Phone_2", "Owner_Phone_3"), #Write
                                Date_Of_Birth = get_dic_value(dic, "Owner_Date_of_Birth"),
                                Drivers_License_Number = get_dic_value(dic, "Owner_License_Number").split(",")[0],
                                Drivers_License_Jurisdiction = "",
                                Injury_Status = "",
                                Safety_Equipment_Restraint = [default],
                                Ejection = "",
                                Transported_To = "",
                                Drug_Use_Suspected = [default],
                                Alcohol_Use_Suspected = [default],
                                Driver_Actions_At_Time_Of_Crash = [default, default, default, default],
                                Driver_Distracted_By = [default],
                                Non_Motorist_Actions_At_Time_Of_Crash = [default]) #Could not find
            
            # l_fn = len(owner_info.First_Name)
            # l_ln = len(owner_info.Last_Name)
            # l_ad = len(owner_info.Address)
            
            # if(l_fn > 0 or l_ln >0 or l_ad > 0):
            people_list.append(owner_info)
                
        return(people_list)
    except:
        print("Error : Error in vehicle_owner_extraction_not_driver_form3()")
        return sys.exc_info(), "error"   

           
       
def vehicle_detail_extraction_form3(df, vehicle_list, driver_list, vehicle_list_ext):
    try:
        default = {"Code" : "", "Description" : ""}
        for i in range(len(vehicle_list)):
            try:
                dic_driver = driver_list[i]
            except:
                dic_driver = dict()
            dic = vehicle_list[i]
            vehicle_info = Vehicle(VinValidation_VinStatus = vin_status(get_dic_value(dic, "Vehicle_Information_VIN")),
                                    Unit_Number = i+1,
                                    License_Plate = get_license_info(get_dic_value(dic, "Vehicle_Information_License_Plate_Number_Plate_Expiration"), "license"),
                                    Registration_State = get_license_info(get_dic_value(dic, "Vehicle_Information_License_Plate_Number_Plate_Expiration"), "state"),
                                    VIN = get_dic_value(dic, "Vehicle_Information_VIN").replace(" ",""),
                                    Vehicle_Towed = get_vehicle_towed(get_dic_value(dic, "Vehicle_Information_Towed")),
                                    Model_Year = get_make_model_year(get_dic_value(dic, "Vehicle_Information_Vehicle_Make_Model_Year"), key='year'),
                                    Make = get_make_model_year(get_dic_value(dic, "Vehicle_Information_Vehicle_Make_Model_Year"), key='make'),
                                    Model = get_make_model_year(get_dic_value(dic, "Vehicle_Information_Vehicle_Make_Model_Year"), key='model'),
                                    Insurance_Company = get_insurance(get_dic_value(dic, "Vehicle_Information_Insurance_1_Carrier")),
                                    Insurance_Policy_Number = get_dic_value(dic, "Vehicle_Information_Insurance_1"),
                                    Insurance_Expiration_Date = get_dic_value(dic, "Vehicle_Information_Insurance_1_End_Date"),
                                    Damaged_Areas = get_damaged_areas(get_dic_value(dic, "Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Areas_of_Vehicle_Damage")),
                                    Air_Bag_Deployed = vehicle_air_bag_status(dic_driver, dic),
                                    Party_Id = "01",
                                    Contributing_Circumstances_Vehicle = [default, default, default],
                                    Road_Surface_Condition = [get_code_desc_from_dic(dic, "Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions")],
                                    Posted_Statutory_SpeedLimit = get_dic_value(dic, "Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit"))
            
            # v_lp = len(vehicle_info.License_Plate)
            # v_make = len(vehicle_info.Make)
            # v_model = len(vehicle_info.Model_Year)
            # v_area = len(vehicle_info.Damaged_Areas)
            # i_comp = len(vehicle_info.Insurance_Company)
            # air_bag = len(vehicle_info.Air_Bag_Deployed)
            # i_pol = len(vehicle_info.Insurance_Policy_Number)
            
            # if(v_lp > 0 or v_make >0 or v_model > 0 or v_area > 0 or i_comp>0 or air_bag>0 or i_pol>0):
            vehicle_list_ext.append(vehicle_info)
                
        return(vehicle_list_ext)
    except:
        print("Error : Error in vehicle_detail_extraction_form3()")
        return sys.exc_info(), "error"    
        

def extract_json_tennessee_form1(text_extracted_df, infos_csv_path):
    global num_property_owner_1

    df = text_extracted_df
    info_csv = pd.read_csv(infos_csv_path)
    
    driver_infos_list = list(info_csv['driver_info'].dropna().values)
    vehicle_infos_list = list(info_csv['vehicle_info'].dropna().values)
    witness_infos_list = list(info_csv['witness_info'].dropna().values)
    occupants_infos_list = list(info_csv['occupants_info'].dropna().values)
    property_infos_list = list(info_csv['prop_owner_info'].dropna().values)
    
    driver_list, all_driver_count = get_driver_params(df, driver_infos_list)
    vehicle_list, all_vehicle_count = get_vehicle_params(df, vehicle_infos_list)
    witness_list, all_witness_count = get_witness_params(df, witness_infos_list)
    other_party_list, all_occupants_count = get_occupants_params(df, occupants_infos_list)    
    property_owner_list, all_prop_owner_count = get_prop_owner_params(df, property_infos_list) 
    
    incident_list = []
    people_list = []
    vehicle_list_ext = []
    citation_list = []
    
    num_property_owner_1 = all_vehicle_count
    
    incident = incident_extraction(df,incident_list)
    people_list = driver_extraction(df, driver_list, people_list)
    people_list = occupants_extraction(df, people_list, other_party_list)
    people_list = witness_extraction(df, people_list, witness_list)
    vehicle_list_ext = vehicle_detail_extraction(df, vehicle_list, driver_list, vehicle_list_ext)
    people_list = vehicle_owner_extraction(df, vehicle_list, driver_list, people_list)
    citation_list = citation_extraction(df, driver_list, citation_list)
    people_list, vehicle_list_ext = property_owner_extraction(df, people_list, property_owner_list, vehicle_list_ext, num_property_owner_1)
   
    
    report = Report(FormName = "Universal",
                    CountKeyed = "",
                    Incident = incident[0],
                    People = people_list,
                    Vehicles = vehicle_list_ext,
                    Citations = citation_list)
    
    main_cls = MainCls(Report = report)
    
    data = json.dumps(main_cls, default = lambda o : o.__dict__, indent = 4)        
    return data

            
def extract_json_tennessee_form3(text_extracted_df, infos_csv_path, city_lookup_path, business_name_lookup_path):
    global num_property_owner_2
    df = text_extracted_df
    df.sort_values(by = ['path','ymin', 'xmin'], inplace = True, ascending = True)
    info_csv = pd.read_csv(infos_csv_path)
    
    driver_infos_list = list(info_csv['form3_driver_info'].dropna().values)
    vehicle_infos_list = list(info_csv['form3_vehicle_info'].dropna().values)
    witness_infos_list = list(info_csv['form3_witness_info'].dropna().values)
    occupants_infos_list = list(info_csv['form3_occupants_info'].dropna().values)
    property_infos_list = list(info_csv['form3_prop_owner_info'].dropna().values)
    citation_infos_list = list(info_csv['form3_citation_info'].dropna().values)
    vehicle_owner_infos_list = list(info_csv['form3_owner_info'].dropna().values)
    
    driver_list, all_driver_count = get_driver_params_form3(df, driver_infos_list)
    vehicle_list, all_vehicle_count = get_vehicle_params_form3(df, vehicle_infos_list)
    witness_list, all_witness_count = get_witness_params_form3(df, witness_infos_list)
    other_party_list, all_occupants_count = get_occupants_params_form3(df, occupants_infos_list)    
    property_owner_list, all_prop_owner_count = get_prop_owner_params_form3(df, property_infos_list) 
    citation_list, all_citation_count = get_citation_params_form3(df, citation_infos_list)
    vehicle_owner_list, all_occupants_count = get_vehicle_owner_params_form3(df, vehicle_owner_infos_list)
    
    num_property_owner_2 = all_vehicle_count
    
    incident_list = []
    people_list = []
    vehicle_list_ext = []
    vehicle_owner = []
    blank_cite_list = []
    
    incident = incident_extraction_form3(df,incident_list)
    people_list = driver_extraction_form3(df, driver_list, people_list, city_lookup_path, business_name_lookup_path)
    people_list = occupants_extraction_form3(df, people_list, other_party_list, city_lookup_path, business_name_lookup_path)
    people_list = witness_extraction_form3(df, people_list, witness_list, city_lookup_path, business_name_lookup_path)
    people_list = vehicle_owner_extraction_is_driver_form3(df, driver_list, people_list, city_lookup_path, business_name_lookup_path)
    people_list = vehicle_owner_extraction_not_driver_form3(df, vehicle_owner_list, people_list, city_lookup_path, business_name_lookup_path)
    vehicle_list_ext = vehicle_detail_extraction_form3(df, vehicle_list, driver_list, vehicle_list_ext)
    people_list, vehicle_list_ext = property_owner_extraction_form3(df, people_list, property_owner_list, city_lookup_path, business_name_lookup_path, vehicle_list_ext, num_property_owner_2)
    cite_list = citation_extraction_form3(df, driver_list, citation_list, blank_cite_list)
    
    
    report = Report(FormName = "Universal",
                    CountKeyed = "",
                    Incident = incident[0],
                    People = people_list,
                    Vehicles = vehicle_list_ext,
                    Citations = cite_list)
    
    main_cls = MainCls(Report = report)
    
    
    data = json.dumps(main_cls, default = lambda o : o.__dict__, indent = 4)    
    return data


def extract_json_tennessee(text_extracted_df, infos_csv_path, city_lookup_path, business_name_lookup_path):
    form_type = determine_form_type(text_extracted_df)
    
    tif_name = text_extracted_df['path'].unique()[0].split("_")[0]+".tif"
    
    print(form_type)
    if(form_type == 'form_type_1_2'):
        data = extract_json_tennessee_form1(text_extracted_df, infos_csv_path)
    elif(form_type == 'form_type_3'):
        data = extract_json_tennessee_form3(text_extracted_df, infos_csv_path, city_lookup_path, business_name_lookup_path)
        
    return data, tif_name