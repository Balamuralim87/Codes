import pandas as pd
from tqdm import tqdm
import xml.etree.ElementTree as ET
import os
import re
from TN_description_to_code import *
#from TENNESSEE.TN_description_to_code import desc_to_code
import TENNESSEE.text_extract as text_extract
# import text_extract

def __str_replace_xml(xml_str):
    xml_str=xml_str.replace('http://www.w3.org/1999/xhtml','')
    xml_str=xml_str.replace('❑','')
    xml_str=xml_str.replace('•','')
    xml_str=xml_str.replace('■','')
    return(xml_str)

def content_extraction(p_df, xml_out_path, code_description_lookup_path):

    df = p_df
    df['filename'] = df['filename'].apply(lambda x: x.replace('.tif',''))
    
    df['xmin'] = df['xmin']*df['img_width']
    df['ymin'] = df['ymin']*df['img_height']
    df['xmax'] = df['xmax']*df['img_width']
    df['ymax'] = df['ymax']*df['img_height']
        
    df = df[['filename','xmin','ymin','xmax','ymax','label', 'img_width', 'img_height']]
    img_list = df['filename'].unique().tolist()
    group_df = df.groupby('filename')

    #csv_name = os.path.join(text_extraction_out_path,img_list[0][:-2]+'.csv')
    temptext_df_final = pd.DataFrame()
    for img in tqdm(img_list):
        tmpdf = group_df.get_group(img)
        inner_img_list = tmpdf['filename'].unique().tolist()
        inner_group_df = tmpdf.groupby('filename')
        data_list = [] 

        for inner_img in inner_img_list:
            #xml_name = os.path.join(xml_out_path,inner_img[:-2],inner_img+'.xml')
            xml_name = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
            # xml_name = xml_name.replace('_TN','')
            xml_str = open(xml_name, 'r', encoding = 'utf-8').read()
            upd_xml_str = __str_replace_xml(xml_str)
            xml_tree = ET.XML(upd_xml_str)
            #os.path.join(os.path.dirname(tif_file_path),inner_img+'.jpg')
            #image = cv2.imread(os.path.join(os.path.dirname(tif_file_path),inner_img+'.jpg'))
            #plt.imshow(image)
            page_list = xml_tree.findall('.//page')
            page_height = page_list[0].attrib['height']
            c = round((df['img_height'][0])/float(page_height), 2)

            temp_df = inner_group_df.get_group(inner_img)
           
            for i, row1 in temp_df.iterrows():
                bb_xmin = int(row1.xmin)
                bb_ymin = int(row1.ymin)
                bb_xmax = int(row1.xmax)
                bb_ymax = int(row1.ymax)
                
                text_list = []
                text = " "
                
                t = ' '
                bb_coord=(bb_xmin,bb_ymin,bb_xmax,bb_ymax)
                add_list = text_extract.find_text(xml_tree,bb_coord,c)

                if(len(add_list) == 0):
                    text = " "
                else:

                    try:
                        # text = t.join(text_list)
    
                        if(row1.label!= 'narration'):
    
                            if(row1.label == 'Driver_Information_Address_Line_2'):
                                try:
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                except:
                                    print("exception in function --> common_util.detect_only_integers()")                                    
                            
                            elif(row1.label == 'vehicle_owner_details'):
                                try:
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                except Exception as e:
                                    text = " "
                                    print(e)
                                    
                            elif(row1.label == 'Vehicle_Information_Address_Line_1'):
                                try:
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                except Exception as e:
                                    text = " "
                                    print(e)
                                    
                            elif(row1.label == 'Vehicle_Information_VIN'):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^A-Za-z0-9]', '', text)
                                except:
                                    text = " "
                                    
                            elif(row1.label == 'Incident_Information_Longitude'):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^0-9.]', '', text)
                                    text = "-"+text
                                except:
                                    text = " "
                                    
                                    
                                    
                                    
#Fixes Start 
                            #Formatting error: Phone                                  
                            elif(('Phone' in row1.label) or ('PHONE' in row1.label) or ('phone' in row1.label)):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^0-9]', '', text)
                                    text = text.strip()
                                    text = text[:3] + "-" + text[3:6] + "-" + text[6:]
                                except:
                                    text = " "
                                    
                            
                            #Formatting error: Date
                            elif(row1.label in ["Incident_Information_Date_Of_Crash", "Driver_Information_Date_of_Birth", 
                                               "Occupants_Date_Of_Birth", "Collision_Witnesses_Date_Of_Birth", 
                                               "Vehicle_Information_Insurance_1_End_Date", "Witnesses_Date_of_Birth", 
                                               "Occupants_Date_Of_Birth","Damaged_Properties_Date_of_Birth","Owner_Date_of_Birth",
                                               ]):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^0-9]', ' ', text)
                                    text = text.strip()
                                    day = text.split()[0]
                                    month = text.split()[1]
                                    year = text.split()[-1]
                                    
                                    if(len(day) == 1):
                                        day = "0"+day
                                        
                                    if(len(month) == 1):
                                        month = "0"+month
                                        
                                    text = month + "/" + day + "/" + year
                                except:
                                    text = " "  
                                    
                                    
                            #Formatting error: Speed        
                            elif(row1.label in ["Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit",
                                                "Vehicle_Damage_and_Roadway_Characteristics_Speed_Limit"]):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^0-9]', '', text)
                                    text = text.strip()
                                except:
                                    text = " "
                                    
                                    
                            #Formatting error: Time        
                            elif(row1.label == 'Incident_Information_Time_Notified'):
                                try:
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    text = re.sub('[^0-9]', '', text)
                                    text = text.strip()
                                    minute = text[-2:]
                                    hour = text.replace(minute,"")
                                    if(len(hour) == 1):
                                        hour = "0"+hour
                                    text = hour + ":" + minute
                                except:
                                    text = " " 
#Fixes End                                   
                            elif(row1.label == 'Incident_Information_Time_Notified' or row1.label == 'Incident_Information_Time_Arrived'):
                                try:
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                    listToStr = ' '.join([str(elem) for elem in add_list])
                                except:
                                    text = " "
                                    print("exception in --> Incident_Information_Time_Notified")

                            elif(row1.label == 'Vehicle_Information_Vehicle_Make_Model_Year' or row1.label == 'Vehicle_Information_License_Plate_Number_Plate_Expiration'):
                                try:
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = " ".join(text_list)
                                except:
                                    text = " "
                                    print("exception in --> Vehicle_Information_Vehicle_Make_Model_Year")
                                    
                            else:
                                text_list = [x[2] for x in add_list]
                                text = " ".join(text_list)
                                
                                text = re.sub(r'^[\W\.\_]*', '', text)
                                text = re.sub(r'\W*$', '', text)
                                if((re.match("[a-zA-Z0-9]*", text)) ==None):
                                    text = ''
                                text = re.sub(r"(\d+)\s(-)\s(\d+)", r"\1\2\3", text.rstrip())
                                text = re.sub(r"(\d+)(-)\s(\d+)", r"\1\2\3", text.rstrip())
                                text = re.sub(r"(\d+)\s(-)(\d+)", r"\1\2\3", text.rstrip())
                                text = re.sub(r"(\d+)\s(\d+)", r"\1\2", text.rstrip())
                                char_check_end = re.compile('[(]')
                                if(char_check_end.search(text)!= None):
                                    text = text+')'
                                char_check_beg = re.compile('[)]')
                                if(char_check_beg.search(text)!= None):
                                    if(char_check_end.search(text) ==None):
                                        text = '('+text
    
                                if(text =='I'):
                                    text = '1'
                            
                            text = re.sub(' +', ' ',text).strip()

                    except:
                        text = ' '

                    
                data_list.append((row1.filename, int(row1.xmin), int(row1.ymin), int(row1.xmax), int(row1.ymax), row1.label, text))

            temptext_df = pd.DataFrame(data_list, columns = ['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])
            temptext_df['page_no'] = temptext_df['path'].apply(lambda x: 'page_no_' +x[-1])
            temptext_df.sort_values(by = ['path'], inplace = True, ascending = True)
            temptext_df_final = temptext_df_final.append(temptext_df, ignore_index = True)
            # temptext_df_final = desc_to_code(temptext_df_final, code_description_lookup_path)
            
    temptext_df_final_code = desc_to_code(temptext_df_final, code_description_lookup_path)    
    return temptext_df_final_code
