# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 00:23:28 2020

@author: saugatapaul
"""

import pandas as pd
import re
from fuzzywuzzy import fuzz



def changeKey(text):
    text = re.sub(r'[^a-zA-Z\s]+','',text)
    text = re.sub(r'\b[a-zA-Z]\b','',text)
    text = re.sub('\s+',' ',text)
    return(text)

def _get_code_desc(dic, get_desc_this_text):
    token_sorted_dic = dict()
    max_value = 0
    for k,v in dic.items():
        Token_Sort_Ratio = fuzz.token_sort_ratio(get_desc_this_text,k)
        token_sorted_dic[k.title()] = Token_Sort_Ratio
        
        code = ""
        desc = ""
        
        for key, val in token_sorted_dic.items():
            if(val > max_value):
                max_value = val
    
    if(max_value > 85):  
        desc = list(token_sorted_dic.keys())[list(token_sorted_dic.values()).index(max_value)]
        code = dic[desc.upper().strip()]
    else:
        desc = ""
        code = ""
    
    return code, desc

    
def desc_to_code(df, code_description_lookup_path):
    try:
    
        label_list = ['Incident_Information_Weather_Conditions', 'Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions',
                      'Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions', 'Driver_Information_Safety_Equipment', "Occupants_Safety_Equipment",
                      "Driver_Information_Ejected", "Occupants_Ejected", "Vehicle_Information_1st_Factor", "Vehicle_Information_2nd_Factor", "Vehicle_Information_3rd_Factor",
                      "Driver_Conditions_and_Actions_Drivers_1st_Action", "Driver_Conditions_and_Actions_Drivers_2nd_Action", "Driver_Conditions_and_Actions_Drivers_3rd_Action",
                      "Driver_Conditions_and_Actions_Drivers_4th_Action", "Alcohol_and_Drugs_Presence_of_Alcohol", "Occupants_Alcohol_and_Drugs_Presence_of_Alcohol", 
                      "Driver_Information_Alcohol_and_Drugs_Presence_of_Alcohol", "Alcohol_and_Drugs_Presence_of_Drugs", "Driver_Information_Alcohol_and_Drugs_Presence_of_Drugs",
                      "Occupants_Alcohol_and_Drugs_Presence_of_Drugs","Driver_Conditions_and_Actions_Distraction","Driver_Information_Driver_Conditions_and_Actions_Distraction",
                      "Driver_Information_Alcohol_and_Drugs_Presence_of_Drugs", "Driver_Information_Alcohol_and_Drugs_Presence_of_Alcohol", 
                      "Driver_Information_Driver_Conditions_and_Actions_Drivers_Action"]
        
        list_df = pd.read_csv(code_description_lookup_path)
        
        Weather_Condition =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Weather_Condition'].values) if (type(x) == str)}
        Roadway_Surface_Condition =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Road_Surface_Condition'].values) if (type(x) == str)}
        Safety_Equipment_Restraint = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Safety_Equipment_Restraint'].values) if (type(x) == str)}
        Ejection = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Ejection'].values) if (type(x) == str)}
        Pedestrian_Action = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Non_Motorist_Actions_At_Time_Of_Crash'].values) if (type(x) == str)}
        Driver_Actions_at_Time_Of_Crash =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Driver_Actions_at_Time_Of_Crash'].values) if (type(x) == str)}
        Alcohol_Use_Suspected =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Alcohol_Use_Suspected'].values) if (type(x) == str)}
        Drug_Use_Suspected =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Drug_Use_Suspected'].values) if (type(x) == str)}
        Driver_Distracted_By =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Driver_Distracted_By'].values) if (type(x) == str)}
        Photographs_Taken  =  {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Photographs_Taken'].values) if (type(x) == str)}
        Contributing_Circumstances_Vehicle = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['Contributing_Circumstances_Vehicle'].values) if (type(x) == str)}
      
        code_list = []
        code_df = pd.DataFrame()
        for ind,row in df.iterrows():    
            temp_var = ''
            if(row.label in label_list):
                if(row.label == "Incident_Information_Weather_Conditions"):
                    print(row.label)
                # df.at[ind, 'text'] = row.text[0]
                if(str(row.text)[0].isdigit()):
                    code_list.append((row.path, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', row.text, row.page_no))
                else:
                    # text = changeKey(str(row.text).strip(' ').upper())
                    text = row.text
                    if(row.label == 'Incident_Information_Weather_Conditions'):
                        temp_code, temp_desc =  _get_code_desc(Weather_Condition, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Vehicle_Information_Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions'):
                        temp_code, temp_desc =  _get_code_desc(Roadway_Surface_Condition, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Vehicle_Damage_and_Roadway_Characteristics_Roadway_Surface_Conditions'):
                        temp_code, temp_desc =  _get_code_desc(Roadway_Surface_Condition, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Driver_Information_Safety_Equipment'):
                        temp_code, temp_desc =  _get_code_desc(Safety_Equipment_Restraint, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Occupants_Safety_Equipment'):
                        temp_code, temp_desc =  _get_code_desc(Safety_Equipment_Restraint, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Driver_Information_Ejected'):
                        temp_code, temp_desc =  _get_code_desc(Ejection, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Occupants_Ejected'):
                        temp_code, temp_desc =  _get_code_desc(Ejection, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Vehicle_Information_1st_Factor'):
                        temp_code, temp_desc =  _get_code_desc(Contributing_Circumstances_Vehicle, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Vehicle_Information_2nd_Factor'):
                        temp_code, temp_desc =  _get_code_desc(Contributing_Circumstances_Vehicle, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Vehicle_Information_3rd_Factor'):
                        temp_code, temp_desc =  _get_code_desc(Contributing_Circumstances_Vehicle, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Driver_Conditions_and_Actions_Drivers_1st_Action' or \
                         row.label == 'Driver_Conditions_and_Actions_Drivers_2nd_Action' or \
                             row.label == 'Driver_Conditions_and_Actions_Drivers_3rd_Action' or \
                                 row.label == 'Driver_Conditions_and_Actions_Drivers_4th_Action' or \
                                     row.label == 'Driver_Information_Driver_Conditions_and_Actions_Drivers_Action'):
                        if(fuzz.token_sort_ratio(text,"No contributing actions") > 80):
                            temp_code = "00"
                            temp_desc = "No Contributing Actions"
                        else:
                            temp_code, temp_desc =  _get_code_desc(Driver_Actions_at_Time_Of_Crash, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    # elif(row.label == 'Driver_Conditions_and_Actions_Drivers_2nd_Action'):
                    #     temp_code, temp_desc =  _get_code_desc(Driver_Actions_at_Time_Of_Crash, text)
                    #     df.at[ind, 'text' ] = temp_desc
                        
                    # elif(row.label == 'Driver_Information_Driver_Conditions_and_Actions_Drivers_Action'):
                    #     temp_code, temp_desc =  _get_code_desc(Driver_Actions_at_Time_Of_Crash, text)
                    #     df.at[ind, 'text'] = temp_desc

                        
                    # elif(row.label == 'Driver_Conditions_and_Actions_Drivers_3rd_Action'):
                    #     temp_code, temp_desc =  _get_code_desc(Driver_Actions_at_Time_Of_Crash, text)
                    #     df.at[ind, 'text'] = temp_desc
                    
                    # elif(row.label == 'Driver_Conditions_and_Actions_Drivers_4th_Action'):
                    #     temp_code, temp_desc =  _get_code_desc(Driver_Actions_at_Time_Of_Crash, text)
                    #     df.at[ind, 'text'] = temp_desc
        
                    elif(row.label == 'Alcohol_and_Drugs_Presence_of_Alcohol'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Alcohol_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Occupants_Alcohol_and_Drugs_Presence_of_Alcohol'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Alcohol_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Driver_Information_Alcohol_and_Drugs_Presence_of_Alcohol'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Alcohol_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
                        
        
                    elif(row.label == 'Alcohol_and_Drugs_Presence_of_Drugs'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Drug_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
        
                    elif(row.label == 'Driver_Information_Alcohol_and_Drugs_Presence_of_Drugs'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Drug_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Occupants_Alcohol_and_Drugs_Presence_of_Drugs'):
                        if("NO" in text.upper()):
                            text = "No"
                        elif("YES" in text.upper()):
                            text = "YES"
                        temp_code, temp_desc =  _get_code_desc(Drug_Use_Suspected, text)
                        df.at[ind, 'text'] = temp_desc
                        
                    elif(row.label == 'Driver_Conditions_and_Actions_Distraction'):
                        temp_code, temp_desc =  _get_code_desc(Driver_Distracted_By, text)
                        df.at[ind, 'text'] = temp_desc
                    
                    elif(row.label == 'Driver_Information_Driver_Conditions_and_Actions_Distraction'):
                        temp_code, temp_desc =  _get_code_desc(Driver_Distracted_By, text)
                        df.at[ind, 'text'] = temp_desc
        
                    else:
                        pass
                
                if(len(temp_code.strip()) == 0):
                    df.at[ind, 'text'] = ''
                    code_list.append((row.path, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', '', row.page_no))
                else:
                    code_list.append((row.path, row.xmin, row.ymin, row.xmax, row.ymax, row.label+'_code', temp_code, row.page_no))
                    
        code_df = pd.DataFrame(code_list,columns=['path','xmin','ymin','xmax','ymax','label','text','page_no'])   
        df = df.append(code_df)
        df.sort_values(by=['page_no','ymin','xmin'],inplace=True)
    except Exception as e:
        print(e)
    return df
        
# path = "D:/Tonix_JSON/306509965 - Exp.csv"   
# code_description_lookup_path = "D:/_Deployed/TN_16_Element_List.csv"
# df = pd.read_csv(path)
# p_df = df.copy()

# c_df = desc_code(df, code_description_lookup_path)
# c_df.to_csv(path, index=None)  
    
        

