import os
import pandas as pd
import sys
import TENNESSEE.tennessee_text_extractor as tennessee_text_extractor
import TENNESSEE.tennessee_json as tennessee_json


city_lookup_path = os.path.join(os.getcwd(), "TENNESSEE", "CityList.txt")
business_name_lookup_path = os.path.join(os.getcwd(), "TENNESSEE", "Business_Name.csv")
infos_csv_path = os.path.join(os.getcwd(), "TENNESSEE", "driver_infos_list.csv")
code_description_lookup_path = os.path.join(os.getcwd(), "TENNESSEE", "TN_16_Element_List.csv")


def Process(csv_file_path, temp_path):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    text_extracted_df = pd.DataFrame()

    try:
        print("Process : PDF Content Extraction & Post-Processing Layer")
        
        text_extracted_df = tennessee_text_extractor.content_extraction(predicted_df, os.path.join(temp_path, csv_file_name), os.path.join(temp_path, code_description_lookup_path))
    except Exception as e:
        print("Error : PDF Content Extraction & Post-Processing Layer")
        return sys.exc_info(), "error"

    try:
        print("Process : JSON Conversion")
        data, tif_name = tennessee_json.extract_json_tennessee(text_extracted_df, infos_csv_path, city_lookup_path, business_name_lookup_path)
        return data, tif_name
    except:
        print("Error : Error occured during JSON Conversion")
        return sys.exc_info(), "error"