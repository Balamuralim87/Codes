# -*- coding: utf-8 -*-
"""
Created on Fri Oct  2 19:32:45 2020

@author: 206011
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 01:03:18 2020

@author: 206011
"""



from typing import List
import json
import re
import tqdm
import os
import pandas as pd
import numpy as np
from fuzzywuzzy import fuzz
# import OHIO
import warnings
warnings.filterwarnings(r"ignore")
page_df = None


class Safety_Equipment_Restraint(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Helmet(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
        
class Alcohol_Drug_Use(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description


class Driver_Actions_At_Time_Of_Crash(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
        
class Non_Motorist_Actions_At_Time_Of_Crash(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

        
class Contributing_Circumstances(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description


class Weather_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Road_Surface_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
           

class Violation_Code(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Driver_Distracted_By(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description
        


class Incident(object):
    def __init__(self, Report_Date: str, Crash_Date: str, Case_Identifier: str, State_Report_Number: str, Crash_City: str,
                 Loss_Street: str, Loss_Cross_Street: str, Latitude: str, Longitude: str, Loss_State_Abbr: str,
                 Report_Type_Id:str, Gps_Other:str, Fatality_Involved:str, Incident_Hit_and_Run:str, Dispatch_Time:str,
                 Weather_Condition: List[Weather_Condition], Road_Surface_Condition: List[Road_Surface_Condition]):
        self.Report_Date = Report_Date
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Fatality_Involved = Fatality_Involved
        self.Incident_Hit_and_Run = Incident_Hit_and_Run
        self.Dispatch_Time = Dispatch_Time
        self.Weather_Condition = Weather_Condition
        self.Road_Surface_Condition = Road_Surface_Condition
       


class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: int, First_Name: str, Middle_Name: str, Last_Name: str,
                Name_Suffix: str, Address:str, Address2:str, City:str, State:str, Zip_Code: str, Home_Phone: str,
                Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str, Injury_Status:str,
                Safety_Equipment_Restraint:List[Safety_Equipment_Restraint], Ejection: str, Transported_To: str, Alcohol_Drug_Use:List[Alcohol_Drug_Use], 
                Driver_Distracted_By: List[Driver_Distracted_By], Contributing_Circumstances: List[Contributing_Circumstances]):
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        self.Safety_Equipment_Restraint = Safety_Equipment_Restraint
        self.Ejection = Ejection
        self.Transported_To = Transported_To
        self.Alcohol_Drug_Use= Alcohol_Drug_Use
        self.Driver_Distracted_By = Driver_Distracted_By
        self.Contributing_Circumstances = Contributing_Circumstances
    
        

class Vehicles(object):
   def __init__(self, VinValidation_VinStatus: str, Unit_Number:str, Trailer_Unit_Number: str, License_Plate: str, Registration_State: str, VIN:str,
                Vehicle_Towed: str, Model_Year: str, Make: str, Model: str, Insurance_Company: str, Insurance_Policy_Number:str,
                Insurance_Expiration_Date: str,Damaged_Areas:str,Air_Bag_Deployed:str,
                Contributing_Circumstances:List[Contributing_Circumstances], Posted_Statutory_SpeedLimit: str):
       self.VinValidation_VinStatus = VinValidation_VinStatus
       self.Unit_Number = Unit_Number
       self.Trailer_Unit_Number = Trailer_Unit_Number
       self.License_Plate = License_Plate
       self.Registration_State = Registration_State
       self.VIN = VIN
       self.Vehicle_Towed= Vehicle_Towed
       self.Model_Year = Model_Year
       self.Make = Make
       self.Model= Model
       self.Insurance_Company = Insurance_Company
       self.Insurance_Policy_Number=Insurance_Policy_Number
       self.Insurance_Expiration_Date=Insurance_Expiration_Date
       self.Damaged_Areas=Damaged_Areas
       self.Air_Bag_Deployed=Air_Bag_Deployed
       self.Contributing_Circumstances=Contributing_Circumstances
       self.Posted_Statutory_SpeedLimit=Posted_Statutory_SpeedLimit

 

class Citations(object):
    def __init__(self, Citation_Detail: str, Violation_Code: List[Violation_Code], Citation_Issued: str, Party_Id: str, Unit_Number: str):
        self.Party_Id = Party_Id
        self.Unit_Number = Unit_Number
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code
        self.Citation_Issued = Citation_Issued
        
       
class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations


def format_text(value):
    value = value.replace('—', '-')
    if(value != ''):
        value = re.sub('[^a-zA-Z0-9@#$^&}{:<>/\\-\'\.\,\s]+', '', str(value))
        value = value.upper()
    return value

def format_name(value):
    value = value.replace('—', '-')
    if(value != ''):
        value = re.sub('[^a-zA-Z&\-\\s]+', '', str(value))
        value = value.upper()
    return value

def format_date(value):
    text = str(value)
    date_list = []
    full_date = ''
    date = ''
    month = ''
    year = ''
    if (text != ''):
        text = re.sub('[^0-9]', '/', text)
        if (text.find('/') != -1):
            date_list = text.split('/')
        else:
            date_list = [text[:2], text[2:4], text[4:]]
    if (len(date_list) == 3):
        if (len(date_list[0]) == 4):
            year = date_list[0]
            if (len(date_list[1]) == 2 and int(date_list[1]) <= 12):
                month = date_list[1]
            else:
                date = date_list[1]
            if (date == ''):
                date = date_list[2]
            else:
                month = date_list[2]
        elif (len(date_list[0]) == 2 and int(date_list[0]) <= 12):
            month = date_list[0]
            if (len(date_list[1]) == 2):
                date = date_list[1]
            else:
                year = date_list[1]
            if (len(date_list[2]) == 4):
                year = date_list[2]
            else:
                date = date_list[2]
        elif (len(date_list[0]) == 2 and int(date_list[0]) > 12):
            date = date_list[0]
            if (len(date_list[1]) == 2):
                month = date_list[1]
            else:
                year = date_list[1]
            if (len(date_list[2]) == 4):
                year = date_list[2]
            else:
                month = date_list[2]
        full_date = month + '/' + date + '/' + year
    else:
        full_date = text
    return full_date

def format_time(value):
    value = str(value)
    value = re.sub('[^0-9:]+','',value)
    if(value.find(':') == -1 and len(value) == 4):
        value = value[:2]+':'+value[2:]
    elif(value.find(':') == -1 and len(value) == 3):
        value = '0'+value[:1] + ':' + value[1:]
    else:
        pass
    return value

def format_phone_no(value):
    value = str(value)
    value = re.sub('[^0-9]+','',value)
    if(len(value) == 10):
        value = value[:3]+'-'+value[3:6]+'-'+value[6:]
    return value



def get_person_type(value):
    person_type = ''
    if(value == ''):
        person_type = ''
    else:
        if(int(value) == 1):
            person_type = 'DRIVER'
        elif(int(value)>1 and int(value)<=14):
            person_type = 'PASSENGER'
        elif(int(value) == 15):
            person_type = 'NONMOTORIST'
        elif(int(value) == 99):
            person_type = 'UNKNOWN'
        else:
            person_type = ''
    return person_type

    
def get_check_value(chk):
    value = ''
    if(chk == 'Checked'):
        value = '1'
    elif(chk == 'Unchecked'):
        value = '0'
    else:
        value = ''
    return value
   
def get_value_from_df(df,label_name):
    if len(df.loc[df['label'] == label_name]) > 0:
        value = df.loc[df['label'] == label_name]['text'].iloc[0]
        if str(value) != 'nan':
            return value
        else:
            return ''
    else:
        return ''
    

def change_towed_value(page_df):
    towed = get_value_from_df(page_df,'Vehicle_Towed_By')
    vehicle_no = get_value_from_df(page_df,'Vehicle_License_No')
    if(towed == '' and vehicle_no == ''):
        value = ''
    elif(towed == '' and vehicle_no != ''):
        value = '0'
    elif(towed.upper().find('DRIVE') != -1 or towed.upper().find('LEFT') != -1):
        value = '0'
    else:
        value = '1'
    return value


def change_abbr_value(value):
    if(value != ''):
        value = str(value).upper()
    if(value == 'YES' or value.find('Y')!=-1):
        value = 'Y'
    elif(value == 'NO' or value.find('N')!=-1):
        value = 'N'
    else:
        value = ''
    return value

def detect_alcohol_value(page_df, i):
    value = ''
    alcohol = get_value_from_df(page_df,'Driver_Alcohol_Suspected'+'_'+str(i))
    if(alcohol == 'Checked'):
        value = 'ALCOHOL'
    return value
def detect_drug_value(page_df, i):
    value = ''
    drug = get_value_from_df(page_df,'Driver_Drug_Suspected'+'_'+str(i))
    if(drug == 'Checked'):
        value = 'DRUG'
    return value

def detect_marijuana_value(page_df, i):
    value = ''
    marijuana = get_value_from_df(page_df, 'Driver_Marijuana_Suspected' + '_' + str(i))
    if (marijuana == 'Checked'):
        value = 'MARIJUANA'
    return value



def assign_no(df):
    temp_df_sub = df.copy()
    temp_df_sub.sort_values(by=['ymin','xmin'], inplace=True)
    unique_labels = temp_df_sub['label'].unique().tolist()
    group_df_sub = temp_df_sub.groupby('label')
    group_df_sub['label'].size().sort_values(ascending=False, inplace=True)
    max_value = group_df_sub['label'].value_counts()
    max_count = max_value.mode().max()
    # max_count = max_mode.values.item()
    label_no_df = pd.DataFrame()
    check_df = pd.DataFrame()
    label_chk = []
    flag = 0
    for label in unique_labels:
        group = group_df_sub.get_group(label)
        if(group.shape[0] == max_count):
            count = 1
            if(flag == 0):
                check_df = group
                flag = 1
            for i, row in group.iterrows():
                group.at[i,'label'] = row.label+'_'+str(count)
                count = count+1
            label_no_df = label_no_df.append(group)
       
        elif(len(check_df)!=0):
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if(diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1,'label'] = row1.label+'_'+str(no)
            label_no_df = label_no_df.append(group)
        else:
            label_chk.append(label)
            
    for label in label_chk:
        group = group_df_sub.get_group(label)
        if(len(check_df)!=0):  
            for i1, row1 in group.iterrows():
                prevdiff = 9999999
                no = 0
                for i2, row2 in check_df.iterrows():
                    diff = row1.ymin - row2.ymin
                    if(diff >= 0 and diff <= prevdiff):
                        no = row2.label.split('_')[-1]
                        prevdiff = diff
                group.at[i1,'label'] = row1.label+'_'+str(no)
            label_no_df = label_no_df.append(group)
    df = label_no_df.sort_values(by=['ymin','xmin'])
    return df
    

def create_group(df):
    df['no'] = df['label'].apply(lambda x: x.split('_')[-1])  
    temp_df = df[df['text']!='']
    temp_df.dropna(inplace=True)
    df_dict = temp_df['no'].value_counts().to_dict()
    return df_dict


def incident_extraction(page_df, form_type):
    latitude = ''
    longitude = ''
    temp_loss_street = get_value_from_df(page_df,'Location_Route_Type')+' '+get_value_from_df(page_df,'Location_Route_Number')+' '+get_value_from_df(page_df,'Location_Prefix')+' '+get_value_from_df(page_df,'Location_Road_Name') +' '+get_value_from_df(page_df,'Location_Road_Type')
    temp_cross_street = get_value_from_df(page_df,'Reference_Route_Type')+' '+get_value_from_df(page_df,'Reference_Route_Number')+' '+get_value_from_df(page_df,'Reference_Prefix')+' '+get_value_from_df(page_df,'Reference_Road_Name') +' '+get_value_from_df(page_df,'Reference_Road_Type')
    temp_loss_street = re.sub(r'^(\s+)','',temp_loss_street)
    temp_cross_street = re.sub(r'^(\s+)','',temp_cross_street)
    road_condition = []
    if(form_type == 'form_type_1'):
        if(len(get_value_from_df(page_df, 'Latitude_Decimal')) > 0):
            latitude = get_value_from_df(page_df, 'Latitude_Decimal')
        else:
            latitude = get_value_from_df(page_df, 'Latitude_Degree')
        if(len(get_value_from_df(page_df, 'Longitude_Decimal')) > 0):
            longitude = get_value_from_df(page_df, 'Longitude_Decimal')
        else:
            longitude = get_value_from_df(page_df, 'Longitude_Degree')
        road_condition = [Road_Surface_Condition(get_value_from_df(page_df,'Conditions_Primary_code'), get_value_from_df(page_df,'Conditions_Primary_desc')),
                           Road_Surface_Condition(get_value_from_df(page_df,'Conditions_Secondary_code'),get_value_from_df(page_df,'Conditions_Secondary_desc'))]

    else:
        latitude = get_value_from_df(page_df, 'Latitude')
        longitude = get_value_from_df(page_df, 'Longitude')
        road_condition = [Road_Surface_Condition(get_value_from_df(page_df, 'Road_Conditions_code'),
                                                 get_value_from_df(page_df, 'Road_Conditions_desc'))]

    incident = Incident(Report_Date='',
                        Crash_Date=format_date(get_value_from_df(page_df,'Crash_Date')),
                        Case_Identifier=format_text(get_value_from_df(page_df,'Local_Report_Number')),
                        State_Report_Number='',
                        Crash_City=format_text(get_value_from_df(page_df,'Location')),
                        Loss_Street=format_text(temp_loss_street),
                        Loss_Cross_Street=format_text(temp_cross_street),
                        Latitude=format_text(latitude),
                        Longitude=format_text(longitude),
                        Loss_State_Abbr='OH',
                        Report_Type_Id='A',
                        Gps_Other='',
                        Fatality_Involved='',
                        Incident_Hit_and_Run=get_value_from_df(page_df,'HIT_SKIP'),
                        Dispatch_Time=format_time(get_value_from_df(page_df,'Dispatch_Time')),
                        Weather_Condition=[Weather_Condition(get_value_from_df(page_df,'Weather_code'),
                                           get_value_from_df(page_df,'Weather_desc'))],
                        Road_Surface_Condition=road_condition)
    return(incident)

def vehicle_detail_extraction(page_df,vehicle_list,per_veh_list,unit_count,form_type):
    if(form_type == 'form_type_1'):
        per_veh_list.append((unit_count, get_value_from_df(page_df,'Contibuting_Circumstances_Primary_code'), get_value_from_df(page_df,'Contibuting_Circumstances_Secondary_code'),
                             get_value_from_df(page_df,'Contibuting_Circumstances_Primary_desc'), get_value_from_df(page_df,'Contibuting_Circumstances_Secondary_desc')))
    else:
        per_veh_list.append((unit_count, get_value_from_df(page_df,'Contributing_Circumstances_code'),
                             get_value_from_df(page_df,'Contributing_Circumstances_desc')))
    vehicle_info=Vehicles(VinValidation_VinStatus = '',
                          Unit_Number = unit_count,
                          Trailer_Unit_Number = '',
                          License_Plate = format_text(get_value_from_df(page_df,'Vehicle_License_No')),
                          Registration_State = get_value_from_df(page_df,'Vehicle_License_State'),
                          VIN = get_value_from_df(page_df,'Vehicle_VIN'),
                          Vehicle_Towed = change_towed_value(page_df),
                          Model_Year = get_value_from_df(page_df,'Vehicle_Year'),
                          Make = get_value_from_df(page_df,'Vehicle_Make'),
                          Model = get_value_from_df(page_df,'Vehicle_Model'),
                          Insurance_Company = get_value_from_df(page_df,'Vehicle_Insurance_Company'),
                          Insurance_Policy_Number = get_value_from_df(page_df,'Vehicle_Insurance_Policy_No'),
                          Insurance_Expiration_Date = '',
                          Damaged_Areas = '',
                          Air_Bag_Deployed = '',
                          Contributing_Circumstances = [Contributing_Circumstances(get_value_from_df(page_df,'Vehicle_Defects_code'),
                                                        get_value_from_df(page_df,'Vehicle_Defects_desc'))],
                          Posted_Statutory_SpeedLimit = get_value_from_df(page_df,'Posted_Speed'))        
    vehicle_list.append(vehicle_info)
    return(vehicle_list, per_veh_list)

def owner_extraction(page_df, people_list, owner_driver_list, unit_no, person_no, person_type, hit_run):
    people_info = People(Party_Id=person_no,
                        Person_Type=person_type,
                        Unit_Number=unit_no,
                        First_Name=format_name(get_value_from_df(page_df,'Owner_First_Name')),
                        Middle_Name=format_name(get_value_from_df(page_df,'Owner_Middle_Name')),
                        Last_Name=format_name(get_value_from_df(page_df,'Owner_Last_Name')),
                        Name_Suffix=format_name(get_value_from_df(page_df,'Owner_Suffix')),
                        Address=format_text(get_value_from_df(page_df,'Owner_Street_Address')),
                        Address2=format_text(get_value_from_df(page_df,'Owner_Street_Address2')),
                        City=get_value_from_df(page_df,'Owner_City'),
                        State=get_value_from_df(page_df,'Owner_State'),
                        Zip_Code=format_text(get_value_from_df(page_df,'Owner_Zip Code')),
                        Home_Phone=format_phone_no(get_value_from_df(page_df,'Vehicle_Owner_Phone_No')),
                        Date_Of_Birth='',
                        Drivers_License_Number= '',
                        Drivers_License_Jurisdiction='',
                        Injury_Status='',
                        Safety_Equipment_Restraint=[],
                        Ejection='',
                        Transported_To='',
                        Alcohol_Drug_Use=[],
                        Driver_Distracted_By=[],
                        Contributing_Circumstances=[])
    people_list.append(people_info)
    owner_driver_list.append((unit_no, get_value_from_df(page_df,'Same_as_Driver_Name'), get_value_from_df(page_df,'Same_as_Driver_Address'), get_value_from_df(page_df,'Same_as_Driver_Phone')))
    text = get_value_from_df(page_df, 'Hit_Skip_Unit')
    if(text == 'Checked'):
        hit_run = '1'
    return(people_list, owner_driver_list, hit_run)

def driver_extraction(driver_df,people_list,veh_per_list,citation_list,person_type,form_type,person_count,driver_count):
    driver_df['old_label']= driver_df['label']
    driver_df = assign_no(driver_df)
    driver_dict = create_group(driver_df)
    if(len(driver_dict)>0):
        for i in range(1,len(driver_dict)+1):
             if(driver_dict.get(str(i))!=None and driver_dict.get(str(i))>10):  
                person_count = person_count+1
                driver_count = driver_count+1
                temp_person_type = get_person_type(get_value_from_df(driver_df,'Driver_Seat_Pos'+'_'+str(i)))
                temp_unit_no = get_value_from_df(driver_df,'Driver_Unit_No'+'_'+str(i))
                if(temp_unit_no == ''):
                    temp_unit_no = driver_count
                if(temp_person_type != ''):
                    person_type = temp_person_type
                else:
                    person_type = "DRIVER"
                if(form_type == 'form_type_1'):
                    alcohol_drug=[Alcohol_Drug_Use(get_value_from_df(driver_df,'Driver_Alcohol_Drug_Suspected_code'+'_'+str(i)),
                                                   get_value_from_df(driver_df,'Driver_Alcohol_Drug_Suspected_desc'+'_'+str(i)))]
                    driver_distracted=[Driver_Distracted_By(get_value_from_df(driver_df,'Driver_Distracted_By_1_code'+'_'+str(i)),
                                                            get_value_from_df(driver_df,'Driver_Distracted_By_1_desc'+'_'+str(i))),
                                          Driver_Distracted_By(get_value_from_df(driver_df,'Driver_Distracted_By_2_code'+'_'+str(i)),
                                                               get_value_from_df(driver_df,'Driver_Distracted_By_2_desc'+'_'+str(i)))]
                    contrib_circum=[Contributing_Circumstances('',''),Contributing_Circumstances('','')]
                else:
                    alcohol_drug=[Alcohol_Drug_Use(detect_alcohol_value(driver_df, i), detect_alcohol_value(driver_df, i)),
                                  Alcohol_Drug_Use(detect_drug_value(driver_df, i), detect_drug_value(driver_df, i)),
                                  Alcohol_Drug_Use(detect_marijuana_value(driver_df, i), detect_marijuana_value(driver_df, i))]
                    driver_distracted=[Driver_Distracted_By(get_value_from_df(driver_df,'Driver_Distracted_By_code'+'_'+str(i)),
                                                            get_value_from_df(driver_df,'Driver_Distracted_By_desc'+'_'+str(i)))]
                    contrib_circum=[Contributing_Circumstances('','')]         
    
                people_info = People(Party_Id=person_count,
                                    Person_Type=person_type,
                                    Unit_Number=temp_unit_no,
                                    First_Name=format_name(get_value_from_df(driver_df,'Driver_First_Name'+'_'+str(i))),
                                    Middle_Name=format_name(get_value_from_df(driver_df,'Driver_Middle_Name'+'_'+str(i))),
                                    Last_Name=format_name(get_value_from_df(driver_df,'Driver_Last_Name'+'_'+str(i))),
                                    Name_Suffix=format_name(get_value_from_df(driver_df,'Driver_Suffix'+'_'+str(i))),
                                    Address=format_text(get_value_from_df(driver_df,'Driver_Street_Address'+'_'+str(i))),
                                    Address2=format_text(get_value_from_df(driver_df,'Driver_Street_Address2'+'_'+str(i))),
                                    City=get_value_from_df(driver_df,'Driver_City'+'_'+str(i)),
                                    State=get_value_from_df(driver_df,'Driver_State'+'_'+str(i)),
                                    Zip_Code=format_text(get_value_from_df(driver_df,'Driver_Zip Code'+'_'+str(i))),
                                    Home_Phone=format_phone_no(get_value_from_df(driver_df,'Driver_Phone_No'+'_'+str(i))),
                                    Date_Of_Birth=format_date(get_value_from_df(driver_df,'Driver_Date_of_Birth'+'_'+str(i))),
                                    Drivers_License_Number=get_value_from_df(driver_df,'Driver_License_No'+'_'+str(i)),
                                    Drivers_License_Jurisdiction=get_value_from_df(driver_df,'Driver_License_State'+'_'+str(i)),
                                    Injury_Status=get_value_from_df(driver_df,'Driver_Injuries_code'+'_'+str(i)),
                                    Safety_Equipment_Restraint=[Safety_Equipment_Restraint(get_value_from_df(driver_df,'Driver_Safety_Equipment_code'+'_'+str(i)),
                                                                                           get_value_from_df(driver_df,'Driver_Safety_Equipment_desc'+'_'+str(i)))],
                                    Ejection=get_value_from_df(driver_df,'Driver_Ejection_code'+'_'+str(i)),
                                    Transported_To=get_value_from_df(driver_df,'Driver_Medical_Facility'+'_'+str(i)),
                                    Alcohol_Drug_Use=alcohol_drug,
                                    Driver_Distracted_By=driver_distracted,
                                    Contributing_Circumstances=contrib_circum)
               
                cite_detail = get_value_from_df(driver_df,'Driver_Offense_Charged'+'_'+str(i))
                v_code = get_value_from_df(driver_df,'Driver_Offense_Description'+'_'+str(i))
                if(cite_detail != '' or v_code != ''):
                    cite_info = Citations(Party_Id=person_count,
                                          Unit_Number=temp_unit_no,
                                          Citation_Detail=cite_detail,
                                          Violation_Code=v_code,
                                          Citation_Issued='')
                    citation_list.append(cite_info) 
                people_list.append(people_info)
                veh_per_list.append((temp_unit_no, get_value_from_df(driver_df,'Driver_Air_Bag'+'_'+str(i))))
    return(people_list, veh_per_list, citation_list, person_count, driver_count)

def passenger_extraction(pass_df,people_list,person_type,form_type,pass_count):
    temp_person_type = ''
    pass_df['old_label']= pass_df['label']
    pass_df = assign_no(pass_df)
    pass_dict = create_group(pass_df)
    if(len(pass_dict)>0):
        for i in range(1,len(pass_dict)+1):
             if(pass_dict.get(str(i))!=None and pass_dict.get(str(i))>5):  
                pass_count = pass_count+1
                temp_person_type = get_person_type(get_value_from_df(pass_df,'Person_Seat_Pos'+'_'+str(i)))
                if(temp_person_type == ''):
                    person_type = 'UNKNOWN'
                else:
                    person_type = temp_person_type
                people_info = People(Party_Id=pass_count,
                                    Person_Type=person_type,
                                    Unit_Number=get_value_from_df(pass_df,'Person_Unit_No'+'_'+str(i)),
                                    First_Name=format_name(get_value_from_df(pass_df,'Person_First_Name'+'_'+str(i))),
                                    Middle_Name=format_name(get_value_from_df(pass_df,'Person_Middle_Name'+'_'+str(i))),
                                    Last_Name=format_name(get_value_from_df(pass_df,'Person_Last_Name'+'_'+str(i))),
                                    Name_Suffix=format_name(get_value_from_df(pass_df,'Person_Suffix'+'_'+str(i))),
                                    Address=format_text(get_value_from_df(pass_df,'Person_Street_Address'+'_'+str(i))),
                                    Address2=format_text(get_value_from_df(pass_df,'Person_Street_Address2'+'_'+str(i))),
                                    City=get_value_from_df(pass_df,'Person_City'+'_'+str(i)),
                                    State=get_value_from_df(pass_df,'Person_State'+'_'+str(i)),
                                    Zip_Code=format_text(get_value_from_df(pass_df,'Person_Zip Code'+'_'+str(i))),
                                    Home_Phone=format_phone_no(get_value_from_df(pass_df,'Person_Phone_No'+'_'+str(i))),
                                    Date_Of_Birth=format_date(get_value_from_df(pass_df,'Person_Date_of_Birth'+'_'+str(i))),
                                    Drivers_License_Number='',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status=get_value_from_df(pass_df,'Person_Injuries_code'+'_'+str(i)),
                                    Safety_Equipment_Restraint=[Safety_Equipment_Restraint(get_value_from_df(pass_df,'Person_Safety_Equipment_code'+'_'+str(i)),
                                                                                           get_value_from_df(pass_df,'Person_Safety_Equipment_desc'+'_'+str(i)))],
                                    Ejection=get_value_from_df(pass_df,'Person_Ejection_code'+'_'+str(i)),
                                    Transported_To=get_value_from_df(pass_df,'Person_Medical_Facility'+'_'+str(i)),
                                    Alcohol_Drug_Use=[],
                                    Driver_Distracted_By=[],
                                    Contributing_Circumstances=[])
                people_list.append(people_info)
    return(people_list, pass_count)
    
    
def witness_extraction(witness_df,people_list,person_type,form_type,witness_count):
    witness_df['old_label']= witness_df['label']
    witness_df = assign_no(witness_df)
    wit_dict = create_group(witness_df)
    if(len(wit_dict)>0):
        for i in range(1,len(wit_dict)+1):
              if(wit_dict.get(str(i))!= None and wit_dict.get(str(i))>5):  
                witness_count = witness_count+1
                people_info = People(Party_Id=pass_count,
                                    Person_Type=person_type,
                                    Unit_Number=get_value_from_df(witness_df,'Witness_Unit_No'+'_'+str(i)),
                                    First_Name=format_name(get_value_from_df(witness_df,'Witness_First_Name'+'_'+str(i))),
                                    Middle_Name=format_name(get_value_from_df(witness_df,'Witness_Middle_Name'+'_'+str(i))),
                                    Last_Name=format_name(get_value_from_df(witness_df,'Witness_Last_Name'+'_'+str(i))),
                                    Name_Suffix=format_name(get_value_from_df(witness_df,'Witness_Suffix'+'_'+str(i))),
                                    Address=format_text(get_value_from_df(witness_df,'Witness_Street_Address'+'_'+str(i))),
                                    Address2=format_text(get_value_from_df(witness_df,'Witness_Street_Address2'+'_'+str(i))),
                                    City=get_value_from_df(witness_df,'Witness_City'+'_'+str(i)),
                                    State=get_value_from_df(witness_df,'Witness_State'+'_'+str(i)),
                                    Zip_Code=format_text(get_value_from_df(witness_df,'Witness_Zip Code'+'_'+str(i))),
                                    Home_Phone=format_phone_no(get_value_from_df(witness_df,'Witness_Phone_No'+'_'+str(i))),
                                    Date_Of_Birth=format_date(get_value_from_df(witness_df,'Witness_Date_of_Birth'+'_'+str(i))),
                                    Drivers_License_Number='',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status='',
                                    Safety_Equipment_Restraint='',
                                    Ejection='',
                                    Transported_To='',
                                    Alcohol_Drug_Use=[],
                                    Driver_Distracted_By=[],
                                    Contributing_Circumstances=[])
                people_list.append(people_info)
    return(people_list, witness_count)
    



class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report
      
        
        
def json_convert(df, form_type):
    """
        This Function writes the annoations in a xml format compatible with label me toolself.
        Args:
        data frame: --datafrmae

        Returns:
        Json String: --str
        """
    
    global page_df
    veh_per_list = []
    per_veh_list = []
    owner_driver_list = []
    people_list = []
    vehicle_list = []
    citation_list = []
    owner_list = []
    driver_list = []
    other_list = []
    trailer_list = []
    ped_list = []
    incident = None  
    is_checked = '1'
    tmpdf = df
    unit_count = 0
    person_count = 0
    driver_count = 0
    pass_count = 0
    witness_count = 0
    hit_run = ''
    local_report_no = ''
    air_bag_dict = {'1':'0', '2':'1', '3':'1', '4':'1', '5':'', '9':''}
    
    try:
        tmpdf.sort_values(by=['page_no', 'ymin', 'xmin'], inplace=True)
        inner_img_list = tmpdf['path'].unique().tolist()
        inner_group_df = tmpdf.groupby('path')
        for inner_img in inner_img_list:
            page_df = inner_group_df.get_group(inner_img)
            incident_page_labels = []
            vehicle_page_labels = []
            person_page_labels = []
            witness_page_labels = []
            pd_page_labels = []
            incident_page_labels = list(filter(lambda x: 'Weather' in x or 'Surface' in x or 'Direction' in x or 'Work_Zone_Related' in x or 'Contour' in x or 'Distance' in x, page_df.label))
            vehicle_page_labels = list(filter(lambda x: 'Vehicle_License_No' in x or 'Vehicle_Year' in x or 'Vehicle_Color' in x or 'Vehicle_Towed_By' in x or 'Vehicle_Model' in x or 'Vehicle_Insurance_Company' in x, page_df.label))
            driver_page_labels = list(filter(lambda x: 'Driver_Unit_No' in x or 'Driver_Age' in x or 'Driver_Gender' in x or 'Driver_First_Name' in x or 'Driver_Seat_Position' in x, page_df.label))
            person_page_labels = list(filter(lambda x: 'Person_Unit_No' in x or 'Person_Age' in x or 'Person_Gender' in x or 'Person_First_Name' in x or 'Person_Seat_Position' in x, page_df.label))
            witness_page_labels  = list(filter(lambda x: 'Witness_Age' in x or 'Witness_Gender' in x or 'Witness_First_Name' in x or 'Witness_Last_Name' in x or 'Witness_Date_of_Birth' in x, page_df.label))
            if(len(incident_page_labels)>=3):
                print("Incident extraction in progress!!!!")
                incident = incident_extraction(page_df, form_type)
                local_report_no = get_value_from_df(page_df,'Local_Report_Number')
            elif(len(vehicle_page_labels)>=3):
                unit_count = unit_count+1
                person_count = person_count+1
                person_type = 'VEHICLE OWNER'
                unit_type = get_value_from_df(page_df,'')
                print("Vehicle detail extraction in progress!!!")
                if(form_type == 'form_type_1' and unit_type != ''):
                    if(int(unit_type) == 26):
                        person_type = 'PEDESTRIAN'
                    elif (int(unit_type) == 25):
                        person_type = 'PEDALCYCLIST'
                    elif(int(unit_type) == 23 or int(unit_type) == 24 or int(unit_type) == 27):
                        person_type = 'NONMOTORIST'
                    else:
                        pass
                elif(form_type == 'form_type_2' and unit_type != ''):
                    if (int(unit_type) == 23):
                        person_type = 'PEDESTRIAN'
                    elif (int(unit_type) == 26):
                        person_type = 'PEDALCYCLIST'
                    elif (int(unit_type) == 22 or int(unit_type) == 25):
                        person_type = 'NONMOTORIST'
                    else:
                        pass
                else:
                    pass
                # if(person_type == 'VEHICLE OWNER'):
                vehicle_list, per_veh_list = vehicle_detail_extraction(page_df,vehicle_list,per_veh_list,unit_count,form_type)
                owner_list, owner_driver_list, hit_run = owner_extraction(page_df,owner_list, owner_driver_list, unit_count, person_count, person_type, hit_run)
                # else:
                #     owner_list, owner_driver_list, hit_run = owner_extraction(page_df, owner_list, owner_driver_list,
                #                                                               unit_count, person_count, person_type, hit_run)
                if(local_report_no == ''):
                    local_report_no = get_value_from_df(page_df, 'Local_Report_Number')
            elif(len(driver_page_labels)>=3 or len(person_page_labels)>=3 or len(witness_page_labels)>=3):
                driver_df = page_df[page_df['label'].str.contains('Driver')]
                if(len(driver_df)!=0):
                    print("Driver extraction in progress!!!!")
                    driver_df['new_index'] = np.arange(len(driver_df))
                    driver_df.set_index('new_index', inplace=True)
                    driver_list,veh_per_list,citation_list,person_count,driver_count = driver_extraction(driver_df,driver_list,veh_per_list,citation_list,"DRIVER",form_type,person_count, driver_count)
                pass_df = page_df[page_df['label'].str.contains('Person')]
                if(len(pass_df)!=0):
                    print("Passenger extraction in progress!!!!")
                    pass_df['new_index'] = np.arange(len(pass_df))
                    pass_df.set_index('new_index', inplace=True)
                    # other_list,pass_count = passenger_extraction(pass_df,other_list,"PASSENGER",form_type,pass_count)
                    other_list, person_count = passenger_extraction(pass_df, other_list, "PASSENGER", form_type, person_count)
                witness_df = page_df[page_df['label'].str.contains('Witness')]
                if(len(witness_df)!=0):
                    print("Witness extraction in progress!!!!")
                    witness_df['new_index'] = np.arange(len(witness_df))
                    witness_df.set_index('new_index', inplace=True)
                    # other_list,witness_count = witness_extraction(witness_df,other_list,"WITNESS",form_type,witness_count)
                    other_list, person_count = witness_extraction(witness_df, other_list, "WITNESS", form_type, person_count)
                if (local_report_no == ''):
                    local_report_no = get_value_from_df(page_df, 'Local_Report_Number')
            else:
                pass

        # Incident hit and run changes based value in vehicle page
        if (incident.Incident_Hit_and_Run == '' and hit_run == '1'):
            incident.Incident_Hit_and_Run = '1'
        elif (incident.Incident_Hit_and_Run == '0'):
            incident.Incident_Hit_and_Run = ''
        else:
            pass

        veh_count = len(vehicle_list)    
        for i in range(0, veh_count):
            for j in range(len(veh_per_list)):
                if(vehicle_list[i].Unit_Number == int(veh_per_list[j][0])):
                    air_bag = air_bag_dict.get(veh_per_list[j][1])
                    if(air_bag != None):
                        vehicle_list[i].Air_Bag_Deployed = air_bag
                    else:
                        vehicle_list[i].Air_Bag_Deployed = '0'
        driver_count = len(driver_list)    
        for i in range(0, driver_count):
            for j in range(len(per_veh_list)):
                if(int(driver_list[i].Unit_Number) == per_veh_list[j][0]):
                    if(form_type == 'form_type_1'):
                        driver_list[i].Contributing_Circumstances[0].Code = per_veh_list[j][1]
                        driver_list[i].Contributing_Circumstances[0].Description = per_veh_list[j][3]
                        driver_list[i].Contributing_Circumstances[1].Code = per_veh_list[j][2]
                        driver_list[i].Contributing_Circumstances[1].Description = per_veh_list[j][4]
                    else:
                        driver_list[i].Contributing_Circumstances[0].Code = per_veh_list[j][1]
                        driver_list[i].Contributing_Circumstances[0].Description = per_veh_list[j][2]
                        
            
        for i in range(len(owner_list)):
            for j in range(len(driver_list)):
                owner_name = owner_list[i].First_Name+' '+owner_list[i].Middle_Name+' '+owner_list[i].Last_Name+' '+owner_list[i].Name_Suffix
                driver_name = driver_list[j].First_Name+' '+driver_list[j].Middle_Name+' '+driver_list[j].Last_Name+' '+owner_list[i].Name_Suffix
                owner_name = re.sub('\s+', ' ',owner_name)
                if not (re.match('[a-zA-Z]+', owner_name)):
                    owner_name = ''
                fuzzy_ratio = fuzz.ratio(owner_name, driver_name)
                if(fuzzy_ratio >= 90 and int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number)):
                    owner_list[i].Address = driver_list[j].Address
                    owner_list[i].Address2 = driver_list[j].Address2
                    owner_list[i].City = driver_list[j].City
                    owner_list[i].State = driver_list[j].State
                    owner_list[i].Zip_Code = driver_list[j].Zip_Code
                    owner_list[i].Home_Phone = driver_list[j].Home_Phone
                    owner_list[i].Date_Of_Birth = driver_list[j].Date_Of_Birth
                    owner_list[i].Drivers_License_Number = driver_list[j].Drivers_License_Number
                    owner_list[i].Drivers_License_Jurisdiction = driver_list[j].Drivers_License_Jurisdiction
                    owner_list[i].Injury_Status = driver_list[j].Injury_Status
                    owner_list[i].Safety_Equipment_Restraint = driver_list[j].Safety_Equipment_Restraint
                    owner_list[i].Ejection = driver_list[j].Ejection
                    owner_list[i].Transported_To = driver_list[j].Transported_To
                    owner_list[i].Alcohol_Drug_Use = driver_list[j].Alcohol_Drug_Use
                    owner_list[i].Driver_Distracted_By = driver_list[j].Driver_Distracted_By
                    owner_list[i].Contributing_Circumstances = driver_list[j].Contributing_Circumstances
                if(len(owner_name) < 3 and len(owner_list[i].Address) < 3 and
                     owner_list[i].City == '' and owner_list[i].State == '' and
                     len(owner_list[i].Home_Phone) < 3 and incident.Incident_Hit_and_Run == '' and
                    int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number)):
                    owner_list[i].First_Name = driver_list[j].First_Name
                    owner_list[i].Middle_Name = driver_list[j].Middle_Name
                    owner_list[i].Last_Name = driver_list[j].Last_Name
                    owner_list[i].Name_Suffix = driver_list[j].Name_Suffix
                    owner_list[i].Address = driver_list[j].Address
                    owner_list[i].Address2 = driver_list[j].Address2
                    owner_list[i].City = driver_list[j].City
                    owner_list[i].State = driver_list[j].State
                    owner_list[i].Zip_Code = driver_list[j].Zip_Code
                    owner_list[i].Home_Phone = driver_list[j].Home_Phone
                    owner_list[i].Date_Of_Birth = driver_list[j].Date_Of_Birth
                    owner_list[i].Drivers_License_Number = driver_list[j].Drivers_License_Number
                    owner_list[i].Drivers_License_Jurisdiction = driver_list[j].Drivers_License_Jurisdiction
                    owner_list[i].Injury_Status = driver_list[j].Injury_Status
                    owner_list[i].Safety_Equipment_Restraint = driver_list[j].Safety_Equipment_Restraint
                    owner_list[i].Ejection = driver_list[j].Ejection
                    owner_list[i].Transported_To = driver_list[j].Transported_To
                    owner_list[i].Alcohol_Drug_Use = driver_list[j].Alcohol_Drug_Use
                    owner_list[i].Driver_Distracted_By = driver_list[j].Driver_Distracted_By
                    owner_list[i].Contributing_Circumstances = driver_list[j].Contributing_Circumstances
                # elif(owner_driver_list[i][2] == 'Checked' and owner_driver_list[i][3] == 'Checked' and
                #      int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number)):
                if(len(owner_list[i].Address) < 3 and
                     owner_list[i].City == '' and owner_list[i].State == '' and incident.Incident_Hit_and_Run == '' and
                     int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number)):
                    owner_list[i].Address = driver_list[j].Address
                    owner_list[i].Address2 = driver_list[j].Address2
                    owner_list[i].City = driver_list[j].City
                    owner_list[i].State = driver_list[j].State
                    owner_list[i].Zip_Code = driver_list[j].Zip_Code
                    # owner_list[i].Home_Phone = driver_list[j].Home_Phone
                # elif(owner_driver_list[i][2] == 'Checked' and (int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number))):
                # elif(owner_driver_list[i][3] == 'Checked' and (int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number))):
                if(len(owner_list[i].Home_Phone) < 3 and incident.Incident_Hit_and_Run == '' and
                        int(owner_driver_list[i][0]) == int(driver_list[j].Unit_Number)):
                    owner_list[i].Home_Phone = driver_list[j].Home_Phone
                else:
                    pass
        if(incident.Case_Identifier == ''):
            incident.Case_Identifier = local_report_no

        if(len(owner_list) != 0):
            for i in range(len(owner_list)):
                people_list.append(owner_list[i])
        if (len(driver_list) != 0):
            for i in range(len(driver_list)):
                people_list.append(driver_list[i])
        if(len(other_list) != 0):
            for i in range(len(other_list)):
                people_list.append(other_list[i])
        if(len(vehicle_list) != 0):
            for i in range(len(vehicle_list)):
                vehicle_list[i].Unit_Number = '0'+str(vehicle_list[i].Unit_Number)

        report = Report(FormName="Universal", CountKeyed=44, Incident=incident, People=people_list, Vehicles=vehicle_list, Citations=citation_list)
        main_cls = MainCls(Report=report)
        # Serializing
        data = json.dumps(main_cls, default=lambda o: o.__dict__, indent=4)
       
        img_name = os.path.basename(df.iloc[0]['path']).split('_')[0]
        tif_name = img_name + '.tif'
        return data, tif_name
    except Exception as e:
        print(e)

