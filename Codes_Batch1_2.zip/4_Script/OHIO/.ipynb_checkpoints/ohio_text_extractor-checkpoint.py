
import os
import time
import cv2
import pandas as pd
import xml.etree.ElementTree as ET                            
import re
from fuzzywuzzy import process
import OHIO.name_address_split as split_text
import OHIO.common_util as common_util
import OHIO.text_extract as text_extract
import OHIO.preproceesor as preproceesor
import OHIO.ohio_code_to_description as code_to_description
from keras.models import load_model


def changeKey(text):
    text = re.sub(r'[^a-zA-Z\s]+','',text)
    text = re.sub(r'\b[a-zA-Z]\b','',text)
    text = re.sub('\s+',' ',text)
    return(text)

"""----------------------------- TEXT EXTRACTION - START --------------------------------"""


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
df: DataFrame 
    DataFrame containing the image name, label name(object) and their coordinates obtained after applying the developed model on the images.
csv_path: String
          Path where the output csv in the following format ('path','xmin','ymin','xmax','ymax','label','text') has to be created.
model_path: string
            Path where the model to identify whether the given checkbox is checked or unchecked.
Returns:
Extracted text for each predicted bounding box is calculated and saved in the csv file where the input image are present.
"""

def replace_class_name(y1, classname, img_height):
    if(int(y1) < (img_height*(2/3)) and classname.find('Person') != -1):
        classname = classname.replace('Person','Driver')
    return classname

def content_extraction(df, xml_out_path, model, address_split_lookup_path, business_name_lookup_path, code_description_lookup_path, tif_file_name):
    try:
        list_df = pd.read_csv(code_description_lookup_path)
        State = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in list(list_df['State'].values)
                 if (type(x) == str)}

        check_box_list_1 = ['Photos_Taken', 'OH-2', 'OH-3', 'OH-1P', 'Other', 'Locality_City', 'Locality_Village',
                            'Locality_Township', 'PDO', 'Private_Property', 'Roadway_Divided', 'Roadway_Undivided',
                            'Distance_Unit_Miles', 'Distance_Unit_Feet', 'Distance_Unit_Yards', 'Intersection_Related',
                            'School_Zone_Related', 'School_Bus_Related_Direct', 'School_Bus_Related_Indirect', 'Work_Zone_Related',
                            'Workers_Present', 'Law_Enforcement_Officer', 'Law_Enforcement_Vehicle', 'Report_Taken_Police_Agency',
                            'Report_Taken_Motorist', 'Report_Taken_Supplement', 'Same_as_Driver_Name', 'Same_as_Driver_Address',
                            'Same_as_Driver_Phone', 'Vehicle_Insurance_Verified', 'Haz_Mat_Released',
                            'Hit_Skip_Unit', 'Type_of_Use_ER', 'Haz_Mat_Placard', 'Unit_Speed_Stated', 'Unit_Speed_Estimated',
                            'Person_DOT_Compliant', 'Driver_DOT_Compliant', 'Driver_No_Valid_OL', 'Driver_Local_Code',
                            'Driver_Hands_Free_Device', 'Driver_MC_End']
        check_box_list_2 = ['Photos_Taken', 'OH-2', 'OH-3', 'OH-1P', 'Other', 'Secondary_Crash', 'Private_Property', 'Intersection_on_Approach',
                            'Interchange_Area', 'Roadway_Divided', 'Work_Zone_Related', 'Workers_Present', 'Law_Enforcement',
                            'Active_School_Zone', 'Report_Taken_Police_Agency', 'Report_Taken_Motorist', 'Report_Taken_Supplement',
                             'Same_as_Driver_Name', 'Same_as_Driver_Address', 'Same_as_Driver_Phone', 'Vehicle_Insurance_Verified',
                             'Type_of_Use_Commercial', 'Type_of_Use_Government', 'Type_of_Use_ER', 'Interlock_Device', 'Hit_Skip_Unit',
                             'Haz_Mat_Released', 'Haz_Mat_Placard', 'Damage_Area_No_Damage', 'Damage_Area_Top', 'Damage_Area_Undercarriage',
                             'Damage_Area_All_Areas', 'Damage_Area_Unit_not_at_Scene', 'Person_DOT_Compliant', 'Driver_DOT_Compliant', 
                             'Driver_Local_Code', 'Driver_Alcohol_Suspected', 'Driver_Marijuana_Suspected', 'Driver_Drug_Suspected']
        numeric_label_list = ['Scene_Cleared_Time', 'Investigation_Time', 'Arrival_Time', 'Total_Minutes',
                               'Reported_Date', 'Vehicle_Defects', 'Vehicle_Year', 
                              'Driver_Unit_No', 'Person_Unit_No', 'Witness_Unit_No', 'Vehicle_Unit_No', 'Location_Route_Number', 'No_of_Lanes', 
                              'Crash_Time', 'Unit_in_Error', 'NCIC', 'No_of_Units', 'HIT_SKIP', 'Unit_in_Error',
                              'Reference_Route_Number', 'Reference_Point', 'Distance', 'Location_First_Harmful_Event', 'Crash_Location', 'Contour',
                              'Conditions_Secondary', 'Conditions_Primary', 'Weather', 'Manner_of_Crash', 'Surface', 'Light_Condition_Secondary',
                              'Light_Condition_Primary', 'Work_Zone_Type', 'Location_of_Crash_in_Work_Zone',
                               'Damage_Scale', 'Officer_Badge_No', 'Contributing_Circumstances',
                              'Driver_Seat_Pos', 'Person_Seat_Pos', 'No_of_Occupants', 'Vehicle_Year', 'US_Dot_No', 'Cargo_Body_Type',
                              'Vehicle_Weight', 'Trafficway_Flow', 'Haz_Mat_Placard_No', 'Haz_Mat_Class_No', 'Unit_Type', 'Non_Motorist_Location_Impact', 
                              'Non_Motorist_Action', 'Most_Damaged_Area', 'Special_Function', 'Impact_Area', 'Pre_Crash_Actions', 'Vehicle_Defects',
                              'Contibuting_Circumstances_Primary', 'Contibuting_Circumstances_Secondary', 'Sequence_of_Events_1', 'Sequence_of_Events_2',
                              'Sequence_of_Events_3', 'Sequence_of_Events_4', 'Sequence_of_Events_5', 'Sequence_of_Events_6', 'First_Harmful_Event',
                              'Most_Harmful_Event', 'Unit_Speed', 'Posted_Speed', 'Unit_Direction_1', 'Unit_Direction_2', 'Traffic_Control',
                              'Driver_Age', 'Driver_Unit_No', 'Driver_Safety_Equipment', 'Driver_Ejection', 'Driver_Air_Bag', 'Driver_Trapped',
                              'Driver_Injuries', 'Driver_Alcohol_Drug_Suspected', 'Driver_Drug_Test_Type', 'Driver_Alcohol_Test_Status',
                              'Driver_Alcohol_Test_Type', 'Driver_Drug_Test_Status', 'Driver_Condition', 'Driver_Class', 'Person_Air_Bag',
                              'Driver_Distracted_By_1', 'Driver_Distracted_By_2', 'Driver_Distracted_By', 'Person_Age', 'Person_Seat_Pos', 'Person_Trapped',
                              'Person_Injuries','Driver_Date_of_Birth','Person_Date_of_Birth','Witness_Date_of_Birth',
                              'Person_Ejection','Person_Safety_Equipment']

        df.rename(columns={'label': 'classes'}, inplace=True)
        df['image_path'] = df['filename'].apply(lambda x: x.split('.')[0] + '_' + x.split('_')[-1] + '.jpg')
        df['x1'] = df['xmin'] * df['img_width']
        df['y1'] = df['ymin'] * df['img_height']
        df['x2'] = df['xmax'] * df['img_width']
        df['y2'] = df['ymax'] * df['img_height']
        
        data_list = []
        # model = load_model(model_path)
        img_list = df['image_path'].unique().tolist()
        img_list.sort() # 28 July 2020
        group_df = df.groupby('image_path')
        page_occur_count = 0
        temp_df = pd.DataFrame()
        form_type = preproceesor.form_type_detection(xml_out_path)
        if (form_type == 'invalid'):
            return temp_df, 'invalid'
        else:
            # print(form_type)
            # ===============================
            # Checkbox model - TIF to JPG
            output_jpg_dir = os.path.join(xml_out_path ,'jpg')
            if not os.path.exists(output_jpg_dir):
                os.makedirs(output_jpg_dir)
            preproceesor.tiff_to_jpg(tif_file_name, output_jpg_dir)
            # ===============================
            for img in img_list:
                page_occur_count += 1
                temp_df = group_df.get_group(img)
                temp_df = temp_df.sort_values(by=['y1', 'x1'])
                # ==========================================
                # to execute output locally
                # xml_path = os.path.join(xml_out_path, os.path.basename(img).split('.')[0] + '.xml')
                # xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')

                # image = cv2.imread(img)
                # img_height = image.shape[0]
                # ==========================================
                # ==========================================
                # uncomment this for docker model output
                # img_height = df['img_height'][0]
                # xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
                # ==========================================

                # ==========================================
                # Temporary fix for OCR not generating page in pdf which page was actually present in tif file

                img_height = df['img_height'][0]
                xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
                xml_path = xml_path.replace('_OH', '_oh')
                if os.path.exists(xml_path) == False:
                    continue
                # =========================================
                xml_str = open(xml_path, 'r', encoding='utf-8').read()
                upd_xml_str = common_util.str_replace_xml(xml_str)
                xml_tree = ET.XML(upd_xml_str)
                page_list = xml_tree.findall('.//page')
                page_height = page_list[0].attrib['height']
                c = round(img_height / float(page_height), 2)
                hit_run_checked = 0
                image = cv2.imread(os.path.join(output_jpg_dir, img))
                narr_df=temp_df[temp_df['classes']=='narration']
                temp_df=temp_df[temp_df['classes']!='narration']
                if(len(narr_df)!=0):
                    narr_df.sort_values(by='score',inplace=True)
                    narr_df.drop_duplicates(subset=['image_path','classes'],keep='first',inplace=True)
                    temp_df = pd.concat([temp_df,narr_df],ignore_index=True)
                len_driver_classes = len(temp_df[temp_df['classes'].str.contains('Driver')])
                len_person_classes = len(temp_df[temp_df['classes'].str.contains('Person')])
                if(len_driver_classes != 0 and len_person_classes != 0 and len_driver_classes < len_person_classes):
                    temp_df['classes'] = temp_df['classes'].apply(lambda x: x.replace('Driver','Person'))
                if(form_type == 'form_type_1'):
                    if(len_driver_classes != 0 and len_person_classes != 0 and len_person_classes < len_driver_classes):
                        # temp_df['classes'] = temp_df[['classes','y1']].apply(lambda x: x.classes.replace('Person','Driver') if int(x.y1) < (img_height*(2/3)) else x)
                        temp_df['classes'] = temp_df.apply(lambda x: replace_class_name(x.y1, x.classes, img_height), axis=1)
                elif(form_type == 'form_type_2'):
                    if(len_driver_classes != 0 and len_person_classes != 0 and len_person_classes < len_driver_classes):
                        temp_df['classes'] = temp_df['classes'].apply(lambda x: x.replace('Person','Driver'))


                check_box_df = pd.DataFrame()
                temptext_df = pd.DataFrame()
                if(form_type=='form_type_1'):
                    check_box_df = temp_df[temp_df['classes'].isin(check_box_list_1)]
                    text_temp_df = temp_df[~temp_df['classes'].isin(check_box_list_1)]
                else:
                    check_box_df = temp_df[temp_df['classes'].isin(check_box_list_2)]
                    text_temp_df = temp_df[~temp_df['classes'].isin(check_box_list_2)]
                for i, row1 in check_box_df.iterrows():
                    text_list = []
                    bb_xmin = int(row1.x1)
                    bb_ymin = int(row1.y1)
                    bb_xmax = int(row1.x2)
                    bb_ymax = int(row1.y2)
                    text = common_util.detect_check_box(image,bb_xmin,bb_ymin,bb_xmax,bb_ymax,model)
                    if(row1.classes == 'Hit_Skip_Unit' and text == 'Checked'):
                        hit_run_checked = 1
                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                temp_df = text_temp_df.copy()
                for i,row1 in temp_df.iterrows():
                    bb_xmin = int(row1.x1)
                    bb_ymin = int(row1.y1)
                    bb_xmax = int(row1.x2)
                    bb_ymax = int(row1.y2)
                    text_list = []
                    text=''
                    bb_coord=(bb_xmin,bb_ymin,bb_xmax,bb_ymax)
                    try:
                        if(row1.classes == 'Driver_Offense_Description'):
                            line_list = text_extract.find_line_text(xml_tree,bb_coord,c)
                            text = ' '.join(line_list)
                            data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                        else:
                            add_list = text_extract.find_text(xml_tree,bb_coord,c)
                            if(row1.classes!='narration' ):
                                if(len(add_list)>0):
                                    add_list = sorted(add_list, key = lambda x: x[0])
                                    text_list = [x[2] for x in add_list]
                                    text = ' '.join(text_list)
                                text = common_util.cleaning(text)
                                if(row1.classes in numeric_label_list):
                                    text = re.sub('[^0-9]+','', text)
                                    text = re.sub('\s+','',text)
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Crash_Date', 'Reported_Date', 'Driver_Date_of_Birth', 'Person_Date_of_Birth',
                                                        'Witness_Date_of_Birth']):
                                    text = text.replace('—', '-')
                                    text = re.sub('[^0-9\/\-]+','', text)
                                    text = re.sub('\s+','',text)
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes == 'HIT_SKIP'):
                                    if(text == '1' or text == '2'):
                                        text = '1'
                                    else:
                                        text = ''
                                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                                elif(row1.classes in ['Reported_Time', 'Dispatch_Time', 'Arrival_Time', 'Investigation_Time',
                                                      'Crash_Time', 'Scene_Cleared_Time']):
                                    text = re.sub('[^0-9\:]+','', text)
                                    text = re.sub('\s+','',text)
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Vehicle_Owner_Phone_No', 'Driver_Phone_No', 'Person_Phone_No', 'Witness_Phone_No']):
                                    text = text.replace('—', '-')
                                    text = re.sub('[^0-9\(\)\-]+','', text)
                                    text = re.sub('\s+','',text)
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Local_Report_Number', 'Vehicle_VIN', 'Vehicle_License_No', 'Vehicle_Insurance_Policy_No',
                                                    'Driver_License_No', 'Driver_Citation_No']):
                                     text = text.replace('—', '-')
                                     text = re.sub('[^0-9a-zA-Z\-]+', '', text)
                                     text = re.sub('\s+','',text)
                                     if(text == 'REDACTED'):
                                         text = ''
                                     data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Location_Road_Type', 'Location_Route_Type', 'Location_Road_Name',
                                                      'Reference_Road_Name', 'Reference_Road_Type', 'Reference_Route_Type',
                                                      'Location']):
                                     text = text.replace('—', '-')
                                     text  = re.sub('[^0-9a-zA-Z@#$^&}{:<>/\\-\'\,\s)]+','', text)
                                     text = re.sub('\s+','',text)
                                     data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Vehicle_License_State','Driver_License_State']):
                                    text = text.replace('0','O')
                                    text  = re.sub('[^a-zA-Z]+','', text)
                                    text = re.sub('\s+','',text)
                                    State = dict((changeKey(k), v) for k, v in State.items())
                                    if (text != ''):
                                        match_state_text = process.extractOne(text, State.keys())[0]
                                        text = State.get(match_state_text)
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                                elif(row1.classes in ['Crash_Date_Time', 'Dispatch_Date_Time', 'Scene_Cleared_Date_Time',
                                                      'Arrival_Date_Time', 'Reported_Date_Time']):
                                    text = re.sub('[^0-9]+','',text)
                                    text = re.sub('\s+','',text)
                                    date = text[:-4]
                                    time = text[-4:]
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Date',date))
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Time',time))
                                elif (row1.classes in ['Latitude', 'Longitude']):
                                    text = text.replace('—', '-')
                                    text = re.sub('[^0-9\'\-\—\.]+', '', text)
                                    text = re.sub('\s+', '', text)
                                    if(row1.classes == 'Longitude' and text.find('-') == -1):
                                        text = '-'+text
                                    data_list.append(
                                        (row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
                                elif (row1.classes == 'Latitude_Longitude_Decimal'):
                                    latitude = ''
                                    longitude = ''
                                    lat_list = []
                                    long_list = []
                                    if (len(add_list) > 0):
                                        add_list = sorted(add_list, key=lambda x: x[0])
                                        text_list = [x[2] for x in add_list]
                                        text = ' '.join(text_list)
                                        if(text != ''):
                                            text = text.replace('—', '-')
                                            text = re.sub('[^0-9\.\-\—\s]+', '', text)
                                            text = re.sub('\s+', '', text)
                                        if(text != ''):
                                            if(text.find('-') != -1):
                                                latitude = text.split('-')[0]
                                                longitude = text.split('-')[1]
                                                if(latitude != '' and latitude.find('.') == -1):
                                                    latitude = latitude[:2] + '.' +latitude[2:]
                                                if(longitude != '' and longitude.find('.') == -1):
                                                    longitude = '-'+longitude[:2] + '.' + longitude[2:]
                                            else:
                                                if(len(add_list) > 0):
                                                    text_xmin = add_list[0][0]
                                                    for x in add_list:
                                                        if ((x[0] - text_xmin) < 100):
                                                            lat_list.append(x[2])
                                                            add_list.remove(x)
                                                    text_xmin = add_list[0][0]
                                                    for x in add_list:
                                                        if ((x[0] - text_xmin) < 100):
                                                            long_list.append(x[2])
                                                            add_list.remove(x)
                                                if(len(lat_list) > 0):
                                                    latitude = ''.join(lat_list)
                                                    if (latitude.find('.') == -1):
                                                        latitude = latitude[:2] + '.' + latitude[2:]
                                                if(len(long_list) > 0):
                                                    longitude = ''.join(long_list)
                                                    if (longitude.find('.') == -1):
                                                        longitude = '-' + longitude[:2] + '.' + longitude[2:]
                                    data_list.append(
                                        (row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Latitude_Decimal', latitude))
                                    data_list.append(
                                        (row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Longitude_Decimal',
                                         longitude))
                                elif (row1.classes == 'Latitude_Longitude'):
                                    latitude = ''
                                    longitude = ''
                                    if (len(add_list) > 0):
                                        text_list = [x[2] for x in add_list]
                                        text = ' '.join(text_list)
                                    text = text.replace('—', '-')
                                    text = re.sub('[^0-9\-\—]+', '', text)
                                    text = re.sub('\s+', '', text)
                                    deg = u'\u00b0'
                                    if(len(text) > 3):
                                        latitude = text.split('-')[0]
                                        longitude = text.split('-')[1]
                                    if (len(latitude) > 0):
                                        latitude = latitude[:2] + str(deg) + latitude[2:4] + '\'' + latitude[
                                                                                                    4:6] + '.' + latitude[
                                                                                                                  6:] + '\"'
                                    if (len(longitude) > 0):
                                        longitude = '-'+longitude[:2] + str(deg) + longitude[2:4] + '\'' + longitude[
                                                                                                       4:6] + '.' + longitude[
                                                                                                                     6:] + '\"'

                                    data_list.append(
                                        (row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Latitude_Degree', latitude))
                                    data_list.append(
                                        (
                                        row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, 'Longitude_Degree', longitude))

                                elif(row1.classes in ['Vehicle_Owner_Name','Driver_Name','Person_Name','Witness_Name']):
                                    row1.classes = row1.classes.replace('Vehicle_Owner','Owner')
                                    name_dict = {'first_name':'','middle_name':'','last_name':'','suffix':''}
                                    flag,text = common_util.check_text(text)
                                    text = re.sub('[^a-zA-Z&,\-\\s]+', '', text)
                                    if((text.upper() == 'UNKNOWN') and (row1.classes == 'Driver_Name' or
                                                                                      row1.classes == 'Owner_Name') and (hit_run_checked == 1)):
                                        name_dict.update({'last_name': 'HIT & RUN'})
                                    else:
                                        name_dict = split_text.name_split_using_pattern(text.upper(), business_name_lookup_path, 'LFM')
                                    if(name_dict is not None):
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_First_Name',name_dict.get('first_name')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Middle_Name',name_dict.get('middle_name')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Last_Name',name_dict.get('last_name')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Suffix',name_dict.get('suffix')))
                                elif(row1.classes in ['Vehicle_Owner_Address','Driver_Address','Person_Address','Witness_Address']):
                                    row1.classes = row1.classes.replace('Vehicle_Owner','Owner')
                                    add_dict = {'address':'','city':'','state':'','zipcode':'', 'phone_no': ''}
                                    text = text.replace('—', '-')
                                    add_dict = split_text.name_address_split_using_lookup(text, address_split_lookup_path)
                                    State = dict((changeKey(k), v) for k, v in State.items())
                                    if (add_dict.get('state') != ''):
                                        match_state_text = process.extractOne(add_dict.get('state'), State.keys())[0]
                                        add_dict.update({'state': State.get(match_state_text)})
                                    if(add_dict is not None):
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Street_Address',add_dict.get('address')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_City',add_dict.get('city')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_State',add_dict.get('state')))
                                        data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes.split('_')[0]+'_Zip Code',add_dict.get('zipcode')))
                                else:
                                    data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))
                            else:
                                if(len(add_list)>0):
                                    text_list = [x[2] for x in add_list]
                                    text = ' '.join(text_list)
                                text = common_util.cleaning(text)
                                data_list.append((row1.image_path,row1.x1,row1.y1,row1.x2,row1.y2,row1.classes,text))

                    except Exception as e:
                        print(e)


            temptext_df = pd.DataFrame(data_list,columns=['path','xmin','ymin','xmax','ymax','label','text'])
            #print(temptext_df.info())

            temptext_df['page_no'] = temptext_df['path'].apply(lambda x: int(os.path.basename(x).split('.')[0].split('_')[-1]))
            temptext_df = temptext_df[['path','page_no','xmin','ymin','xmax','ymax','label','text']]
            tempdesc_df = code_to_description.desc_code(temptext_df, code_description_lookup_path, form_type)
            return tempdesc_df, form_type

    except Exception as e:
        print(e)

"""----------------------------- TEXT EXTRACTION - END --------------------------------"""

# if __name__ == "__main__":
#     # model_out_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\OH\MODEL\WatchFolder1\Model\OUT\"
#     # OCR_out_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\OH\MODEL\WatchFolder1\OCR\OUT\\"
#     temp_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\OH\MODEL\WatchFolder1\TextExtraction\Temp\\"
#     text_extraction_out_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\OH\MODEL\WatchFolder1\TextExtraction\result\\"
#     address_split_lookup_path = os.path.join(os.getcwd(), "OHIO", "OH_city.txt")
#     business_name_lookup_path = os.path.join(os.getcwd(), "OHIO", "business_name.txt")
#     # code_description_lookup_path = os.path.join(os.getcwd(), "OHIO", "PA_list.csv")
#     csv_file_path = r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\OH\MODEL\WatchFolder1\Model\OUT\277061897_OH.csv"
#     tif_file_name = csv_file_path.split('.')[0]+'.tif'
#     df = pd.read_csv(csv_file_path)
#     check_box_model_path = os.path.join(os.getcwd(), 'Model', 'checkbox_classification.h5')
#     check_box_model = load_model(check_box_model_path)
#     predicted_df,form_type = content_extraction(df, temp_path, check_box_model, address_split_lookup_path, business_name_lookup_path, tif_file_name)
