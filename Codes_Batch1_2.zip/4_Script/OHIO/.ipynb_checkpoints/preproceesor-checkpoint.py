import os
import subprocess
import PyPDF2
import glob
from PIL import Image
import shutil
from tqdm import tqdm
import xml.etree.ElementTree as ET
import time as time1
import sys, traceback
import OHIO.common_util as common_util


"""
Create output directories which are not present.
Args:
out_jpg_dir:  String
              Path where the output jpg images are saved.
out_xml_dir:  String
              Path where the output xml obtained from searchable pdf are saved.
form_type_path: String
                Path where the outcomes of different form types are saved.
Returns:
Directories are created
Nothing is returned to calling function.
"""

def create_dirs(out_jpg_dir, out_xml_dir, form_type_path):
    #print(out_jpg_dir)
    if not os.path.exists(out_jpg_dir):
        os.makedirs(out_jpg_dir)
    if not os.path.exists(out_xml_dir):
        os.makedirs(out_xml_dir)
    if not os.path.exists(form_type_path[0]):
        os.makedirs(form_type_path[0])
    if not os.path.exists(form_type_path[1]):
        os.makedirs(form_type_path[1])


"""---------------------------- TIF TO JPG CONVERTION - STARTS ---------------------------------------"""

"""
Convert the given tiff image with multiple pages into individual jpg image.
Args:
tif_path: String
          Path of the input tif image.
out_jpg_dir: String
             Path where the output jpg images are saved.

Returns:
JPG images are created and saved in corresponding folder.
Nothing is returned to calling function.
"""

def tiff_to_jpg(i, out_jpg_dir):
    img_list = glob.glob(i)
    for j in img_list:
        im = Image.open(j)
        img_dpi = im.info['dpi']
        no_of_frames = im.n_frames
        input_img = os.path.basename(j).split('.')[0]
        # im_path = os.path.join(out_jpg_dir, input_img)
        # if not os.path.exists(im_path):
        #     os.mkdir(im_path)
        for i in range(no_of_frames):
            im.seek(i)
            upd_i = i + 1
            im_name = input_img + "_" + str(upd_i) + ".jpg"
            im_name = os.path.join(out_jpg_dir, im_name)
            try:
                im1 = im.convert("RGB")
                # im1.save(im_name, "JPEG")
                im1.save(im_name, "JPEG", dpi=img_dpi)
            except Exception as e:
                print(e)
                im1 = im.convert("RGB")
                im1.save(im_name, "JPEG", dpi=img_dpi)

"""---------------------------- TIF TO JPG CONVERTION - END ---------------------------------------"""

"""---------------------------- PDF TO XML CONVERTION - START -------------------------------------"""
"""

Create xml file for specified page of pdf.

Args:
pdf_path: String
          Path of the input pdf document.
save_path: String
           Path where the xml file are saved.
page_num: Int
          Indicates the page to be referred in pdf to create corresponding xml.
Returns:
XML file for particular page is created.
Nothing is returned to calling function.
"""

#def pdf_convert_text(pdf_path, save_path, page_num):
#   if os.path.exists(save_path) == False:
#        os.chdir(r'D:\sivaselvi\PROJECTS\Ecrash\CODES\poppler-0.68.0')
#        argument = 'pdftotext.exe -bbox-layout' + ' -f ' + str(page_num) + ' -l ' + str(
#            page_num) + ' ' + pdf_path + ' ' + save_path
#        mysubproces = subprocess.Popen(argument, creationflags=subprocess.SW_HIDE, shell=True)
#       mysubproces.wait()

def pdf_convert_text(pdf_path, save_path, page_num):
    if os.path.exists(save_path) == False:
        if sys.platform == 'win32' and os.path.basename(os.getcwd()) != 'POPPLER':
            os.chdir(os.path.join(os.getcwd(), 'POPPLER'))
        os.umask(0x000)
        argument = 'pdftotext -bbox-layout' + ' -f ' + str(page_num) + ' -l ' + str(page_num) + ' ' + pdf_path + ' ' + save_path
        argument = argument.split()
        mysubproces = subprocess.Popen(argument)
        mysubproces.wait()

#=====================================================
# convert pdf to html - local
#=====================================================
def __SubProcess(pdfpath, savepath, pagenum):
    if os.path.exists(savepath) == False:
        os.chdir('D:/Softwares/poppler')
        argument = 'pdftotext.exe -bbox-layout' + ' -f ' + str(pagenum) + ' -l ' + str(
            pagenum) + ' ' + pdfpath + ' ' + savepath
        mysubproces = subprocess.Popen(argument, creationflags=subprocess.SW_HIDE, shell=True)
        mysubproces.wait()
#=====================================================



"""
Convert the given OCRed pdf which is searchable into xml document.
So multiple xml files are created for single pdf.
This function in turn calls pdf_convert_text for each page in pdf.
Args:
pdf_path: String
          Path of the input pdf document.
out_xml_dir: String
             Path where the output xml obtained from searchable pdf are saved.
Returns:
Nothing is returned to calling function.
"""

#def extract_text(pdf_path, out_xml_dir):
#    pdf_object = PyPDF2.PdfFileReader(pdf_path)
#    page_number = pdf_object.getNumPages()
#    ind_xml_path = out_xml_dir + os.path.basename(pdf_path).split('.')[0]
#    if not os.path.exists(ind_xml_path):
#        os.makedirs(ind_xml_path)
#    for page_num in range(1, page_number + 1):
#        save_path = ind_xml_path + '\\' + os.path.basename(pdf_path).split('.')[0] + '_' + str(page_num) + '.xml'
#        pdf_convert_text(pdf_path, save_path, page_num)

def extract_text(pdf_path, out_xml_dir):
    #print('entered extract_text')
    #mysubproces1 = subprocess.Popen(["sudo","chmod", "777",pdf_path])
    #mysubproces1.wait()
    try:
        time1.sleep(2)
        pdf_object = PyPDF2.PdfFileReader(pdf_path)
        page_number = pdf_object.getNumPages()
    except Exception as e:
        print('Exception in preprocessor.extract_text')
    #print('page number is',page_number)
    ind_xml_path = out_xml_dir + os.path.basename(pdf_path).split('.')[0]
    if not os.path.exists(ind_xml_path):
        oldmask=os.umask(0x000)
        os.makedirs(ind_xml_path,0o777)
        os.umask(oldmask)
        
    for page_num in range(1, page_number + 1):
        save_path = ind_xml_path + '/' + os.path.basename(pdf_path).split('.')[0] + '_' + str(page_num) + '.xml'

        # if os.getlogin() == '204286':
        #     __SubProcess(pdf_path, save_path, page_num)
        #     continue
        try:
            pdf_convert_text(pdf_path, save_path, page_num)
        except:
            print('Exception in extract_text.pdf_convert_text')

"""
Convert the given OCRed pdf which is searchable into xml document.
So multiple xml files are created for single pdf.
This function calls extract_text function for each pdf document.
Args:
pdf_path: String
          Path of the folder which contains all pdf document.
out_xml_dir: String
             Path where the output xml obtained from searchable pdf are saved.
Returns:
Nothing is returned to calling function.
"""

def xml_convertion(pdf_path, out_xml_dir):
    pdf_list = os.listdir(pdf_path)
    for i in tqdm(pdf_list):
        path = os.path.join(pdf_path, i)
        extract_text(path, out_xml_dir)


"""----------------------------- PDF TO XML CONVERTION - END -------------------------------------"""

"""----------------------------- FORM TYPE DETECTION - START -------------------------------------"""


# def identify_form_type(xml_tree, page_height, form_type):
#     text_list=[]
#     for elem in xml_tree.findall('.//page/flow/block/line/word'):
#         if(float(elem.attrib['yMax'])<(float(page_height)/6)):
#             text_list.append(elem.text)
#     if ('LOCAL' in text_list and 'PDO' in text_list) or ('LOCAL' in text_list and 'DOLLAR' in text_list) or ('LOCAL' in text_list and 'WEEK' in text_list):
#         # print('form type 1')
#         form_type = 'form_type_1'
#     elif('LOCAL' in text_list and 'SECONDARY' in text_list) or ('LOCAL' in text_list and 'SUPPLEMENT' in text_list) or ('LOCAL' in text_list and 'OTHER' in text_list):
#         form_type = 'form_type_2'
#     else:
#         form_type = 'invalid'
#     return form_type


def identify_form_type(xml_tree, page_height, form_type):
    text_list=[]
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        if(float(elem.attrib['yMax'])<(float(page_height)/6)):
            text_list.append(elem.text)
    upd_text_list = [str(x).upper() for x in text_list]
    form_type_1_labels = ['LOCAL', 'CRASH', 'PDO', 'DOLLAR', 'REPORTABLE', 'DAY', 'WEEK', 'MINUTES', 'SECONDS', 'ROADWAY','DIVISION']
    form_type_2_labels = ['LOCAL', 'CRASH', 'SECONDARY','SUPPLEMENT','MANDATORY','FIELD','SUSPECTED', 'POSSIBLE']
    if(len(set(upd_text_list) & set(form_type_1_labels)) >= 4):
        form_type = 'form_type_1'
    elif(len(set(upd_text_list) & set(form_type_2_labels)) >= 4):
        form_type = 'form_type_2'
    else:
        form_type = 'invalid'
    return form_type



"""
Detect type of input forms based on the keyword in specific form. This function in turn calls str_replace_xml 
and identify_form_type functions.

Args:
out_jpg_dir: String
             Path of the jpg images created from tif image.
out_xml_dir: String
             Path where the xml file are stored.
form_type_path: String
                Path where the jpg and xml of forms belonging to specific category are stored.
Returns:
JPG and XML folders are deleted as those information are moved to specific folders now.
Nothing is returned to calling function.
"""

def form_type_detection(out_xml_dir): 
    form_type = ''
    xml_list = glob.glob(out_xml_dir + '*.xml')    
    try:
        for i in range(len(xml_list)):
            xml_str = open(xml_list[i],'r',encoding="utf-8").read()
            upd_xml_str=common_util.str_replace_xml(xml_str)
            xml_tree=ET.XML(upd_xml_str)
            page_list=xml_tree.findall('.//page')
            page_height = page_list[0].attrib['height']
            form_type = identify_form_type(xml_tree, page_height, form_type)
            if(form_type == 'invalid'):
                continue
            else:
                return form_type
    except Exception as e:
        print(e)
    return form_type



"""----------------------------- FORM TYPE DETECTION - END -------------------------------------"""