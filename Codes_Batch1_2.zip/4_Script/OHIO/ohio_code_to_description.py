# -*- coding: utf-8 -*-
"""
Created on Mon Jul 27 20:16:01 2020

@author: 206011
"""
import os
import pandas as pd
import re
from fuzzywuzzy import process

# list_df = pd.read_csv(os.path.join(os.getcwd(),"PA_list.csv"))


def changeKey(text):
    text = re.sub(r'[^\s]+','',text)
    text = re.sub(r'\b[a-zA-Z]\b','',text)
    text = re.sub('\s+',' ',text)
    return(text)


def get_match_text(temp_dict, text):
    match_text = process.extractOne(text, temp_dict.keys())[0]
    temp_var = temp_dict.get(match_text)
    return temp_var

def assign_desc_code(row, temp_var, desc_list):
    if (temp_var != None):
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_desc', temp_var))
    else:
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_desc', ''))
    return desc_list

def assign_code_desc(row, temp_var, desc_list):
    if (temp_var != None):
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_code', temp_var))
    else:
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_code', ''))
    return desc_list


def desc_code(df, code_description_lookup_path, form_type):
    try:
        list_df = pd.read_csv(code_description_lookup_path)
        Weather_Condition_1 =  {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Weather Condition Type 1'].values) if (type(x) == str)}
        Weather_Condition_2 =  {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Weather Condition Type 2'].values) if (type(x) == str)}
        Roadway_Surface_Condition_1 =  {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Road Surface Condition Type 1'].values) if (type(x) == str)}
        Roadway_Surface_Condition_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Road Surface Condition Type 2'].values) if (type(x) == str)}
        Safety_Equipment_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Safety Equipment Type 1'].values) if (type(x) == str)}
        Safety_Equipment_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Safety Equipment Type 2'].values) if (type(x) == str)}
        Ejection_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Ejection Type 1'].values) if (type(x) == str)}
        Ejection_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Ejection Type 2'].values) if (type(x) == str)}
        Alcohol_Drug_Use_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Alcohol Drug Use Type 1'].values) if (type(x) == str)}
        Driver_Distracted_By_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Driver Distracted By Type 1'].values) if (type(x) == str)}
        Driver_Distracted_By_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Driver Distracted By Type 2'].values) if (type(x) == str)}
        Contributing_Circumstances_Person_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Contributing Circumstances Person Type 1'].values) if(type(x) == str)}
        Contributing_Circumstances_Person_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Contributing Circumstances Person Type 2'].values) if(type(x) == str)}
        Contributing_Circumstances_Vehicle_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Contributing Circumstances Vehicle Type 1'].values) if(type(x) == str)}
        Contributing_Circumstances_Vehicle_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Contributing Circumstances Vehicle Type 2'].values) if (type(x) == str)}
        Injury_Status_1 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Injury Status Type 1'].values) if (type(x) == str)}
        Injury_Status_2 = {x.split("=")[0].upper().strip(' '): x.split("=")[1].strip(' ') for x in list(list_df['Injury Status Type 2'].values) if (type(x) == str)}

        Weather_Condition = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                               list(list_df['Weather Condition'].values) if (type(x) == str)}
        Roadway_Surface_Condition = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                                       list(list_df['Road Surface Condition'].values) if (type(x) == str)}
        Safety_Equipment = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                              list(list_df['Safety Equipment'].values) if (type(x) == str)}
        Ejection = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                      list(list_df['Ejection'].values) if (type(x) == str)}
        Alcohol_Drug_Use = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                              list(list_df['Alcohol Drug Use'].values) if (type(x) == str)}
        Driver_Distracted_By = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                                  list(list_df['Driver Distracted By'].values) if (type(x) == str)}
        Contributing_Circumstances_Person = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                                               list(list_df['Contributing Circumstances Person'].values) if(type(x) == str)}
        Contributing_Circumstances_Vehicle = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                                                list(list_df['Contributing Circumstances Vehicle'].values) if(type(x) == str)}
        Injury_Status = {x.split("=")[1].upper().strip(' '): x.split("=")[0].strip(' ') for x in
                           list(list_df['Injury Status'].values) if (type(x) == str)}

        Weather_Condition_list = [x.split('=')[1].upper().strip() for x in list(list_df['Weather Condition'].values)
                               if(type(x) == str)]
        Roadway_Surface_list = [x.split('=')[1].upper().strip() for x in list(list_df['Road Surface Condition'].values)
                               if(type(x) == str)]
        Safety_Equipment_list = [x.split('=')[1].upper().strip() for x in list(list_df['Safety Equipment'].values)
                               if(type(x) == str)]
        Ejection_list = [x.split('=')[1].upper().strip() for x in list(list_df['Ejection'].values)
                               if(type(x) == str)]
        Alcohol_Drug_Use_list = [x.split('=')[1].upper().strip() for x in list(list_df['Alcohol Drug Use'].values)
                               if(type(x) == str)]
        Driver_Distracted_By_list= [x.split('=')[1].upper().strip() for x in list(list_df['Driver Distracted By'].values)
                               if(type(x) == str)]
        Contrib_Circum_list = [x.split('=')[1].upper().strip() for x in list(list_df['Contributing Circumstances Person'].values)
                               if(type(x) == str)]
        Contrib_Circum_Vehicle_list = [x.split('=')[1].upper().strip() for x in list(list_df['Contributing Circumstances Vehicle'].values)
                               if(type(x) == str)]
        Injury_Status_list = [x.split('=')[1].upper().strip() for x in list(list_df['Injury Status'].values)
                               if(type(x) == str)]



        label_list = ['Weather', 'Conditions_Primary', 'Conditions_Secondary', 'Road_Conditions',
                      'Person_Safety_Equipment', 'Driver_Safety_Equipment', 'Driver_Ejection', 'Person_Ejection',
                      'Driver_Alcohol_Drug_Suspected', 'Driver_Distracted_By_1', 'Driver_Distracted_By_2',
                      'Driver_Distracted_By', 'Contibuting_Circumstances_Primary', 'Contibuting_Circumstances_Secondary',
                      'Contributing_Circumstances', 'Vehicle_Defects', 'Person_Injuries', 'Driver_Injuries']

        desc_list = []
        desc_df = pd.DataFrame()
        for ind,row in df.iterrows():    
            temp_desc = ''
            temp_code = ''
            if(row.label in label_list and len(str(row.text)) != 0):
                # df.at[ind, 'text'] = row.text[0]
                text = row.text
                text = re.sub('[^0-9]','',text)
                if(form_type == 'form_type_1'):
                    if(row.label == 'Weather'):
                        if (text != ''):
                            temp_desc = get_match_text(Weather_Condition_1, text)
                        if(temp_desc != None and Weather_Condition_list.count(temp_desc) > 1):
                            temp_code = text
                        elif(temp_desc != None):
                            temp_code = get_match_text(Weather_Condition, temp_desc)
                    elif(row.label == 'Conditions_Primary'):
                        if (text != ''):
                            temp_desc = get_match_text(Roadway_Surface_Condition_1, text)
                        if (temp_desc != None and Roadway_Surface_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Roadway_Surface_Condition, temp_desc)
                    elif (row.label == 'Conditions_Secondary'):
                        if (text != ''):
                            temp_desc = get_match_text(Roadway_Surface_Condition_1, text)
                        if (temp_desc != None and Roadway_Surface_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Roadway_Surface_Condition, temp_desc)
                    elif(row.label == 'Driver_Safety_Equipment'):
                        if (text != ''):
                            temp_desc = get_match_text(Safety_Equipment_1, text)
                        if (temp_desc != None and Safety_Equipment_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Safety_Equipment, temp_desc)
                    elif (row.label == 'Person_Safety_Equipment'):
                        if (text != ''):
                            temp_desc = get_match_text(Safety_Equipment_1, text)
                        if (temp_desc != None and Safety_Equipment_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Safety_Equipment, temp_desc)
                    elif (row.label == 'Driver_Ejection'):
                        if (text != ''):
                            temp_desc = get_match_text(Ejection_1, text)
                        if (temp_desc != None and Ejection_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Ejection, temp_desc)
                    elif (row.label == 'Person_Ejection'):
                        if (text != ''):
                            temp_desc = get_match_text(Ejection_1, text)
                        if (temp_desc != None and Ejection_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Ejection, temp_desc)
                    elif (row.label == 'Driver_Alcohol_Drug_Suspected'):
                        if (text != ''):
                            temp_desc = get_match_text(Alcohol_Drug_Use_1, text)
                        if (temp_desc != None and Alcohol_Drug_Use_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Alcohol_Drug_Use, temp_desc)
                    elif (row.label == 'Driver_Distracted_By_1'):
                        if (text != ''):
                            temp_desc = get_match_text(Driver_Distracted_By_1, text)
                        if (temp_desc != None and Driver_Distracted_By_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Driver_Distracted_By, temp_desc)
                    elif (row.label == 'Driver_Distracted_By_2'):
                        if (text != ''):
                            temp_desc = get_match_text(Driver_Distracted_By_1, text)
                        if (temp_desc != None and Driver_Distracted_By_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Driver_Distracted_By, temp_desc)
                    elif (row.label == 'Contibuting_Circumstances_Primary'):
                        if (text != ''):
                            temp_desc = get_match_text(Contributing_Circumstances_Person_1, text)
                        if (temp_desc != None and Contrib_Circum_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Contributing_Circumstances_Person, temp_desc)
                    elif (row.label == 'Contibuting_Circumstances_Secondary'):
                        if (text != ''):
                            temp_desc = get_match_text(Contributing_Circumstances_Person_1, text)
                        if (temp_desc != None and Contrib_Circum_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Contributing_Circumstances_Person, temp_desc)

                    elif (row.label == 'Vehicle_Defects'):
                        if (text != ''):
                            temp_desc = get_match_text(Contributing_Circumstances_Vehicle_1, text)
                        if (temp_desc != None and Contrib_Circum_Vehicle_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Contributing_Circumstances_Vehicle, temp_desc)
                    elif (row.label == 'Driver_Injuries'):
                        if (text != ''):
                            temp_desc = get_match_text(Injury_Status_1, text)
                        if (temp_desc != None and Injury_Status_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Injury_Status, temp_desc)
                    elif (row.label == 'Person_Injuries'):
                        if (text != ''):
                            temp_desc = get_match_text(Injury_Status_1, text)
                        if (temp_desc != None and Injury_Status_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Injury_Status, temp_desc)
                    else:
                        pass
                elif (form_type == 'form_type_2'):
                    if (row.label == 'Weather'):
                        if (text != ''):
                            temp_desc = get_match_text(Weather_Condition_2, text)
                        if (temp_desc != None and Weather_Condition_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Weather_Condition, temp_desc)
                    elif (row.label == 'Road_Conditions'):
                        if (text != ''):
                            temp_desc = get_match_text(Roadway_Surface_Condition_2, text)
                        if (temp_desc != None and Roadway_Surface_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Roadway_Surface_Condition, temp_desc)
                    elif (row.label == 'Driver_Safety_Equipment'):
                        if (text != ''):
                            temp_desc = get_match_text(Safety_Equipment_2, text)
                        if (temp_desc != None and Safety_Equipment_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Safety_Equipment, temp_desc)
                    elif (row.label == 'Person_Safety_Equipment'):
                        if (text != ''):
                            temp_desc = get_match_text(Safety_Equipment_2, text)
                        if (temp_desc != None and Safety_Equipment_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Safety_Equipment, temp_desc)
                    elif (row.label == 'Driver_Ejection'):
                        if (text != ''):
                            temp_desc = get_match_text(Ejection_2, text)
                        if (temp_desc != None and Ejection_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Ejection, temp_desc)
                    elif (row.label == 'Person_Ejection'):
                        if (text != ''):
                            temp_desc = get_match_text(Ejection_2, text)
                        if (temp_desc != None and Ejection_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Ejection, temp_desc)
                    elif (row.label == 'Contributing_Circumstances'):
                        if (text != ''):
                            temp_desc = get_match_text(Contributing_Circumstances_Person_2, text)
                        if (temp_desc != None and Contrib_Circum_list.count(temp_desc) > 1):
                            temp_code = text
                        elif(temp_desc != None):
                            temp_code = get_match_text(Contributing_Circumstances_Person, temp_desc)
                    elif (row.label == 'Vehicle_Defects'):
                        if (text != ''):
                            temp_desc = get_match_text(Contributing_Circumstances_Vehicle_2, text)
                        if (temp_desc != None and Contrib_Circum_Vehicle_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Contributing_Circumstances_Vehicle, temp_desc)
                    elif (row.label == 'Driver_Injuries'):
                        if (text != ''):
                            temp_desc = get_match_text(Injury_Status_2, text)
                        if (temp_desc != None and Injury_Status_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Injury_Status, temp_desc)
                    elif (row.label == 'Person_Injuries'):
                        if (text != ''):
                            temp_desc = get_match_text(Injury_Status_2, text)
                        if (temp_desc != None and Injury_Status_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Injury_Status, temp_desc)
                    elif (row.label == 'Driver_Distracted_By'):
                        if (text != ''):
                            temp_desc = get_match_text(Driver_Distracted_By_2, text)
                        if (temp_desc != None and Driver_Distracted_By_list.count(temp_desc) > 1):
                            temp_code = text
                        elif (temp_desc != None):
                            temp_code = get_match_text(Driver_Distracted_By, temp_desc)
                    else:
                        pass
                else:
                    pass
                if(temp_desc != None):
                    desc_list = assign_desc_code(row, temp_desc, desc_list)
                else:
                    desc_list = assign_desc_code(row, '', desc_list)
                if (temp_code != None):
                    desc_list = assign_code_desc(row, temp_code, desc_list)
                else:
                    desc_list = assign_code_desc(row, '', desc_list)
                if(text == ''):
                    desc_list = assign_desc_code(row, '', desc_list)
                    desc_list = assign_code_desc(row, '', desc_list)


        desc_df = pd.DataFrame(desc_list,columns=['path','page_no','xmin','ymin','xmax','ymax','label','text'])
        df = df.append(desc_df)
        df.sort_values(by=['page_no','ymin','xmin'],inplace=True)
    except Exception as e:
        print(e)    
    return(df)


# if __name__ == '__main__':
#     df = pd.read_csv(r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\OUT3\CSV\287857297_final.csv")
#     df  = desc_code(df)
#     df.to_csv(r"D:\sivaselvi\PROJECTS\Ecrash\TEXT_EXTRACTION\PA\OUT3\CSV\287857297_final.csv")