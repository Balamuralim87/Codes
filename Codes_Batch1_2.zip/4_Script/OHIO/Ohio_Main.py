import os
import sys
import pandas as pd
import OHIO.ohio_text_extractor as OH_text_extractor
import OHIO.ohio_json_convertor as OH_json_convertor
code_description_lookup_path =  os.path.join(os.getcwd(), "OHIO", "OH_list.csv")
address_split_lookup_path = os.path.join(os.getcwd(), "OHIO", "city_list.txt")
business_name_lookup_path = os.path.join(os.getcwd(), "OHIO", "business_name.txt")


def Process(csv_file_path, temp_path, check_box_model):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    text_extracted_df = pd.DataFrame()
    tif_file_name = csv_file_path.split('.')[0]+'.tif'
    xml_path = os.path.join(temp_path, csv_file_name + '/')
    try:
        print("Process : PDF Content Extraction" )
        text_extracted_df, form_type = OH_text_extractor.content_extraction(predicted_df, xml_path, check_box_model, address_split_lookup_path, business_name_lookup_path, code_description_lookup_path, tif_file_name)
        if (form_type == 'invalid'):
            return 'invalid file received', 'invalid'
    except Exception as e:
        print(e)
        print("Error : Error occured during PDF Content Extraction")
        return sys.exc_info(),"error"



    try:
        print("Process : JSON Conversion")
        data, tif_name = OH_json_convertor.json_convert(text_extracted_df, form_type)
        return data, tif_name
    except:
        print("Error : Error occured during JSON Conversion")
        return sys.exc_info(), "error"

