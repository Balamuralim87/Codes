"""
Created on 20/04/2023

@author: e407841: Aarushi Gupta
"""

import sys

from COLORADO.form_5 import co_form_5_postprocess as postprocessor

class Incident():
    """
    Class defining Incident Report
    """
    def __init__(self, case_identifier='', crash_date='', loss_street='', crash_time='',
        crash_city='', loss_cross_street='', hit_run=''):
        """
        Initialize the Incident Report's objects

        Args:
            case_identifier (str, optional): case_identifier. Defaults to ''.
            crash_date (str, optional): crash_date. Defaults to ''.
            loss_street (str, optional): loss_street. Defaults to ''.
            crash_time (str, optional): crash_time. Defaults to ''.
            loss_cross_street (str, optional): loss_cross_street. Defaults to ''.
            crash_city (str, optional): crash_city. Defaults to ''.
        """
        self.Incident_Hit_and_Run = hit_run
        self.Case_Identifier = case_identifier
        self.State_Report_Number = ''
        self.Crash_Date = crash_date
        self.Crash_Time = crash_time
        self.Loss_State_Abbr = 'CO'
        self.Crash_City = crash_city
        self.Report_Type_Id = ''
        self.Loss_Street = loss_street
        self.Loss_Cross_Street = loss_cross_street
        self.Latitude = ''
        self.Longitude = ''
        self.Gps_Other = ''
        self.Weather_Condition = ''
        self.Road_Surface_Condition = ''

def incident_extraction(data_frame):
    """
    Passes Incident Report data to the Incident Class
    Args:
        data_frame (DataFrame): Predicted DataFrame
    Returns:
        List : Incident Report List
    """
    incident_report = []
    try:
        hit_and_run = postprocessor.get_hit_run(
            postprocessor.get_df_value(data_frame, 'Hit_And_Run'))
        case_identifier = postprocessor.get_case_identifier(postprocessor.get_df_value(
            data_frame, 'Case_Identifier'))
        crash_date = postprocessor.get_df_value(data_frame, 'Crash_Date')
        crash_time = postprocessor.get_df_value(data_frame, 'Crash_Time')
        loss_street = postprocessor.modify_location(
            postprocessor.get_df_value(data_frame, 'Location_of_occurance'))
        crash_city = postprocessor.get_df_value(data_frame, 'Crash_City')
        loss_street, cross_street = postprocessor.split_location(loss_street)    
        if 'UNKNOWN' in loss_street:
            loss_street = ''
        incident_report = Incident(
                            hit_run = hit_and_run,
                            case_identifier = case_identifier,
                            crash_date = crash_date,
                            crash_time = crash_time,
                            loss_street = loss_street,
                            loss_cross_street = cross_street,
                            crash_city = crash_city.upper()
                            )
        if not hit_and_run:
            del incident_report.Incident_Hit_and_Run
    except:
        pass
    return incident_report

class People():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', person_type='', first_name='',
        middle_name='', last_name='', suffix='', address='', state='', city='', zip_code='',
        date_of_birth='', home_phone=''):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.
            person_type (str, optional): person_type. Defaults to ''.
            first_name (str, optional): first_name. Defaults to ''.
            middle_name (str, optional): middle_name. Defaults to ''.
            last_name (str, optional): last_name. Defaults to ''.
            suffix (str, optional): suffix. Defaults to ''.
            address (str, optional): address. Defaults to ''.
            state (str, optional): state. Defaults to ''.
            city (str, optional): city. Defaults to ''.
            zip_code (str, optional): zip_code. Defaults to ''.
            date_of_birth (str, optional): date_of_birth. Defaults to ''.
            home_phone (str, optional): home_phone. Defaults to ''.
        """
        self.Party_Id = party_id
        self.Person_Type = person_type
        self.Unit_Number = unit_number
        self.First_Name = first_name
        self.Middle_Name = middle_name
        self.Last_Name = last_name
        self.Name_Suffix = suffix
        self.Address = address
        self.Address2 = ''
        self.State = state
        self.City = city
        self.Zip_Code = zip_code
        self.Home_Phone = home_phone
        self.Date_Of_Birth = date_of_birth
        self.Drivers_License_Number = ''
        self.Drivers_License_Jurisdiction = ''
        self.Injury_Status = ''
        self.Alcohol_Use_Suspected = ''
        self.Marijuana_Use_Suspected = ''
        self.Drug_Use_Suspected = ''
        self.Contributing_Circumstances_Person = ''
        self.Non_Motorist_Actions_At_Time_Of_Crash = ''
        self.Safety_Equipment_Restraint = ''
        self.Safety_Equipment_Available_Or_Used = ''
        self.Safety_Equipment_Helmet = ''
        self.Ejection = ''

def get_owner_list(data_frame, business_name_lookup_path):
    """
    Return Owner list
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        list: owner list
    """
    owner_list = []
    try:
        owner_names = []
        d_frames_list = postprocessor.get_information(data_frame, 'vehicle')
        owner_count = postprocessor.get_count(data_frame, 'vehicle')
        for index in range(owner_count):
            d_frame = d_frames_list[index]
            owner_names_list = postprocessor.get_owner_name_list(d_frame)
            for owner_name in owner_names_list:
                name, p_type = postprocessor.modify_name(owner_name)
                if name and name in owner_names:
                    continue
                owner_names.append(name)
                name = postprocessor.process_name(name, business_name_lookup_path)
                owner = People(
                                unit_number = str(index+1),
                                person_type = p_type.upper(),
                                first_name = name['first_name'],
                                middle_name = name['middle_name'],
                                last_name = name['last_name'],
                                suffix = name['suffix']
                            )
                owner_list.append(owner)
        if not ''.join(owner_names):
            owner_list = []
        owner_list = sorted(owner_list, key=lambda v: v.Unit_Number)
    except:
        pass
    return owner_list

def get_people_list(data_frame, business_name_lookup_path):
    """
    Return driver and owner list
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        list, list: driver list, owner list
    """
    owner_list, driver_list = [], []
    try:
        d_frames_list = postprocessor.get_information(data_frame, 'people')
        owner_list = get_owner_list(data_frame, business_name_lookup_path)
        owner_list_length = len(owner_list)
        driver_list = [0] * owner_list_length
        people_count = postprocessor.get_count(data_frame, 'people')
        for index in range(people_count):
            d_frame = d_frames_list[index]
            name = postprocessor.get_df_value(d_frame, 'Name')
            person_type = postprocessor.get_df_value(d_frame, 'Person_Type')
            if not person_type and not name:
                continue
            name = postprocessor.process_name(name,
                                    business_name_lookup_path)
            address = postprocessor.get_df_value(d_frame, 'Address')
            apartment = postprocessor.get_df_value(d_frame, 'Apartment')
            if apartment:
                address = address + ' ' + apartment
            person = People(
                        person_type = person_type.upper(),
                        first_name = name['first_name'],
                        middle_name = name['middle_name'],
                        last_name = name['last_name'],
                        suffix = name['suffix'],
                        address = address.upper(),
                        state = postprocessor.get_df_value(d_frame, 'State').upper(),
                        city = postprocessor.get_df_value(d_frame, 'City').upper(),
                        zip_code = postprocessor.get_df_value(d_frame, 'Zipcode'),
                        date_of_birth = postprocessor.get_df_value(d_frame, 'Date_Of_Birth'),
                        home_phone = postprocessor.clean_home_phone(
                            postprocessor.get_df_value(d_frame, 'Home_Phone'))
                        )
            empty_person = People()
            if people_count and not owner_list_length:
                driver_list, owner_list = postprocessor.compare_name_1(person,
                        owner_list, driver_list, empty_person, people_count)
            else:
                driver_list, owner_list = postprocessor.compare_name_2(person,
                        owner_list, driver_list, owner_list_length, empty_person)
        if not people_count:
            owner_list.append(People(person_type = 'VEHICLE OWNER'))
            driver_list.append(People(person_type = 'DRIVER'))
    except:
        pass
    return driver_list, owner_list


def people_extraction(data_frame, business_name_lookup_path):
    """
    This function assigns party_id to the final people list
    This also assign unit number to both vehicle owner and driver
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        list: final people list
    """
    people_list = []
    try:
        driver_list, owner_list = get_people_list(data_frame,
                                        business_name_lookup_path)
        driver = People()
        driver_list, other_list = postprocessor.get_final_people_list(driver_list, driver)
        for index, owner in enumerate(owner_list):
            if not owner.Unit_Number:
                if index>0:
                    owner.Unit_Number = str(int(owner_list[index-1].Unit_Number)+1)
                else:
                    owner.Unit_Number = str(index+1)
            driver_list[index].Unit_Number = owner.Unit_Number
            postprocessor.delete_invalid_keys(owner)
        people_list = postprocessor.merge_lists(owner_list, driver_list)
        people_list = people_list + other_list
        for p_id, person in enumerate(people_list):
            person.Party_Id = str(p_id+1)
    except:
        pass
    return people_list

class Vehicle():
    """
    Class defining Vehicle
    """
    def __init__(self, unit_number='', make='', model='', vin = '', model_year='',
        license_plate='', registration_state='', insurance_company='', policy_number='',
        expiration_date=''):
        """
        Initialize the Vehicle objects

        Args:
            unit_number (str, optional): unit_number. Defaults to ''.
            make (str, optional): make. Defaults to ''.
            vin (str, optional): vin. Defaults to ''.
            model_year (str, optional): model_year. Defaults to ''.
            license_plate (str, optional): license_plate. Defaults to ''.
            registration_state (str, optional): registration_state. Defaults to ''.
            insurance_company (str, optional): insurance_company. Defaults to ''.
            damaged_areas (str, optional): damaged_areas. Defaults to ''.
        """
        self.Unit_Number = unit_number
        self.License_Plate = license_plate
        self.Registration_State = registration_state
        self.VIN = vin
        self.VinValidation_VinStatus = ''
        self.Model_Year = model_year
        self.Make = make
        self.Model = model
        self.Insurance_Company = insurance_company
        self.Insurance_Policy_Number = policy_number
        self.Insurance_Expiration_Date = expiration_date
        self.Vehicle_Towed = ''
        self.Air_Bag_Deployed = ''
        self.Damaged_Areas = ''
        self.Contributing_Circumstances_Vehicle = ''
        self.Posted_Statutory_SpeedLimit = ''

def vehicle_extraction(data_frame):
    """
    Passes Vehicle data to the Vehicle Class
    Args:
        d_frame (DataFrame): Predicted DataFrame
    Returns:
        List : Vehicle List
    """
    vehicle_list = []
    try:     
        d_frames_list = postprocessor.get_information(data_frame, 'vehicle')
        vehicle_count = postprocessor.get_count(data_frame, 'vehicle')
        for index in range(vehicle_count):
            d_frame = d_frames_list[index]
            expiration_date = postprocessor.modify_date(
                postprocessor.get_df_value(d_frame, 'Insurance_Expiration_Date'))
            vehicle = Vehicle(
                        unit_number = str(index+1),
                        vin = postprocessor.get_df_value(d_frame, 'VIN').upper(),
                        make = postprocessor.get_df_value(d_frame, 'Make').upper(),
                        model = postprocessor.get_df_value(d_frame, 'Model').upper(),
                        model_year = postprocessor.get_df_value(d_frame, 'Model_Year'),
                        license_plate = postprocessor.get_df_value(d_frame,
                                                    'License_Plate').upper(),
                        registration_state = postprocessor.get_df_value(d_frame,
                                                    'Registration_State').upper(),
                        insurance_company = postprocessor.get_df_value(d_frame,
                                                    'Insurance_Company').upper(),
                        policy_number = postprocessor.get_df_value(d_frame,
                                                    'Policy_Number').upper(),
                        expiration_date = expiration_date
                        )
            vehicle_list.append(vehicle)
        if not vehicle_list:
            vehicle_list.append(Vehicle(unit_number = '1'))
    except:
        pass
    return vehicle_list


class Report():
    """
    Class defining Report
    """
    def __init__(self, form_name, count_keyed, incident, people, vehicles, citations, form_type):
        """
        Initialize the Report objects

        Args:
            form_name (str): form_name
            count_keyed (str): count_keyed
            incident (List): incident
            people (List): people
            vehicles (List): vehicles
            citations (List): citations
        """
        self.FormName = form_name
        self.CountKeyed = count_keyed
        self.Incident = incident
        self.People = people
        self.Vehicles = vehicles
        self.Citations = citations
        self.Form_Type = form_type

class MainCls():
    """
    Class: Defines MainCls
    """
    def __init__(self, report):
        """
        Initialize the MainCls objects

        Args:
            report (class): report
        """
        self.Report = report

def json_convertion(text_extracted_df, form_type,  business_name_lookup_path):
    """
    Function to form json from the predicted DataFrame

    Args:
        text_extracted_df (DataFrame): Predicted DataFrame
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path

    Returns:
        JSON: Json data created from predicted DataFrame
    """
    try:
        incident_report = incident_extraction(text_extracted_df)

        people_list = people_extraction(text_extracted_df, business_name_lookup_path)

        vehicle_list = vehicle_extraction(text_extracted_df)

        if (incident_report or people_list or vehicle_list):
            tif_name = (text_extracted_df['path'][0].split("_")[0]) + '_CO.tif'
            report = Report(form_name = 'Universal',
                            count_keyed = '',
                            incident = incident_report,
                            people = people_list,
                            vehicles = vehicle_list,
                            citations = [],
                            form_type = ('CO_'+ form_type))
            main_cls = MainCls(report = report)
            return main_cls, tif_name
    except:
        pass
    return sys.exc_info(), 'error'
