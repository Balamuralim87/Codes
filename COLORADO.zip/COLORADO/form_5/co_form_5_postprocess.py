"""
Created on 20/04/2023

@author: e407841: Aarushi Gupta
"""

import re
from copy import deepcopy
import pandas as pd
from fuzzywuzzy import fuzz

from COLORADO.config import Config
from COLORADO.name_address_split import name_split_using_pattern

def get_predefined_labels(key):
    """
    Function holds predefined labels for Incident, People and Vehicle
    Args:
        key (str): Key of predefined_labels
    Returns:
        List: Value of predefined_labels
    """
    try:
        return Config.FORM_5_PREDEFINED_LABELS[key]
    except:
        pass
    return []

def get_df_value(d_frame, label_name, index=0):
    """
    Function retrive value from df (predicted dataframe) based on label_name and index
    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.
    Returns:
        str: Value from df (predicted dataframe)
    """
    try:
        data_df = d_frame.loc[d_frame['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            value = data_df['text'].iloc[index]
            if str(value) != 'nan':
                if label_name == 'Make':
                    value = re.sub(r'[^A-Za-z ]', '', value)
                elif label_name in ['Model', 'Zipcode']:
                    value = re.sub(r'[^A-Za-z0-9- ]', '', value)
                elif label_name == 'Crash_Time':
                    value = re.sub(r'[^[0-9]', '', value)
                    value = value[0:-2] + ':' + value[-2:]
                return value.strip()
    except:
        pass
    return ''

def get_owner_name_list(d_frame):
    """
    Function retrive value from df (predicted dataframe) based on owner name and index
    Args:
        d_frame (DataFrame): Predicted DataFrame
    Returns:
        list: Values of owner names
    """
    owner_names_list = []
    try:        
        label_name = 'Vehicle_Owner'
        data_df = d_frame.loc[d_frame['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            for owner in list(data_df['text']):
                owner_names_list.append(owner)
    except:
        pass
    return owner_names_list

def get_case_identifier(text):
    """
    Process the case Identifier
    Args:
        text (str): case Identifier
    Returns:
        str: case Identifier
    """
    try:
        if text:
            text = text.replace('#', '')
    except:
        pass
    return text.strip()

def get_hit_run(text):
    """
    Return hit and run value depending on text
    Args:
        text (str): text of hit_and_run
    Returns:
        str: hit and run value
    """
    hit_run = ''
    try:
        if text:
            text = text.upper()
            if 'HIT' in text and 'RUN' in text:
                hit_run = '1'
    except:
        pass
    return hit_run

def modify_location(text):
    """
    Function to modify location and removing unnecessary symbols
    Args:
        text (str): text of address
    Returns:
        str: modified address
    """
    try:
        if text:
            text = re.sub(r'[^A-Za-z0-9@ ]', ' ', text)
            text = ' '.join(text.split())
            text = text.upper()
    except:
        pass
    return text.strip()


def modify_name(text):
    """
    Function to modify name of the function and split name and person type
    Args:
        text (str): text of name
    Returns:
        str, str: name of person, person type
    """
    person_type = ''
    try:
        if text:
            person_type = re.findall(r"\([A-Za-z ]+\)", text)
            if person_type:
                person_type = person_type[0]
                text = text.replace(person_type, '')
                text = text.replace('(', '').replace(')', '')
                person_type = person_type.replace('(', '').replace(')', '')
    except:
        pass
    return text.strip(), person_type.strip()

def split_location(text):
    """
    This function splits the address into loss street and loss cross street
    Args:
        text (str): case Identifier
    Returns:
        str, str: loss street, loss cross street
    """
    loss_street, cross_street = '', ''
    try:
        if text:
            if '@' in text:
                text_split = text.split('@')
                loss_street = text_split[0].strip()
                cross_street = text_split[-1].strip()
            else:
                loss_street = text.strip()
                cross_street = ''
    except:
        pass
    return loss_street.upper(), cross_street.upper()


def clean_home_phone(text):
    """
    Cleans the Home phone text
    Args:
        text (str): text
    Returns:
        str: updated text
    """
    try:
        text = '-'.join(re.sub('[^0-9]+', ' ', text).split())
    except:
        pass
    return text

def change_labels(label, text):
    """
    This function changes label name in dataframe columns if incorrect label assigned
    Args:
        label (str): label name
        text (str): text for the label name
    Returns:
        str: updated label name
    """
    try:
        found_date = re.search(r'\d{1,2}/\d{1,2}/\d{4}', text)
        if label == 'Zipcode' and found_date:
            label = 'Date_Of_Birth'
    except:
        pass
    return label

def get_information(d_frame, label):
    """
    This function creates separate dataframe for each person alond with
    individual person details and return list of all such dataframes
    Args:
        d_frame (DataFrame): original dataframe
        label (str): label(person or vehicle)
    Returns:
        list: dataframe list
    """
    df_list = []
    try:
        d_frame['label'] = d_frame[['label','text']].apply(lambda x:
                                            change_labels(x.label, x.text), axis=1)
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])
        if label == 'people':
            index_numbers = list(data_df['label'].loc[lambda x: x=='Person_Type'].index)
        elif label == 'vehicle':
            if 'Vehicle' in list(data_df['label'].unique()):
                index_numbers = list(data_df['label'].loc[lambda x: x=='Vehicle'].index)
            else:
                index_numbers = list(data_df['label'].loc[lambda x: x=='Model_Year'].index)
        len_index = len(index_numbers)
        for index in range(len_index):
            if len_index == 1:
                data_df_new = data_df.loc[index_numbers[0]:]
            elif index_numbers[index] == index_numbers[-1]:
                data_df_new = data_df.loc[index_numbers[index]:]
            else:
                data_df_new = data_df.loc[index_numbers[index]:index_numbers[index+1]]
            df_list.append(data_df_new)
    except:
        pass
    return df_list


def compare_name_1(person, owner_list, driver_list, empty_person, people_count):
    """
    This function compare owner names with the given person 
    If it matches then chnages in people and owner lists are made accordingly
    Args:
        person (class object): current person which needs to be compared
        owner_list (list): owner_list
        driver_list (list): people_list
        empty_person (class object): empty person
        people_count (int): count to total people
    Returns:
        list: modified driver_list
        list: modified owner_list
    """
    try:
        p_name = person.First_Name + person.Last_Name + person.Middle_Name
        person_type = person.Person_Type
        if 'UNKNOWN' not in p_name:
            if person_type == 'DRIVER' and people_count == 1:
                empty_person.Person_Type = 'VEHICLE OWNER'
                owner_list.append(empty_person)
                driver_list.append(person)
            elif person_type in ['VICTIM', 'RPTG PARTY', 'OTHER INV']:
                person.Person_Type = 'VEHICLE OWNER'
                empty_person.Person_Type = 'DRIVER'
                owner_list.append(person)
                driver_list.append(empty_person)
            elif person_type in ['SUSPECT', 'DRIVER']:
                person.Person_Type = 'DRIVER'
                empty_person.Person_Type = 'VEHICLE OWNER'
                owner_list.append(empty_person)
                driver_list.append(person)
            elif person_type == 'WITNESS':
                driver_list.append(person)
    except:
        pass
    return driver_list, owner_list


def compare_name_2(person, owner_list, driver_list, owner_list_length, empty_person):
    """
    This function compare owner names with the given person 
    If it matches then chnages in people and owner lists are made accordingly
    Args:
        person (class object): current person which needs to be compared
        owner_list (list): owner_list
        driver_list (list): people_list
        owner_list_length (int): length of initial owner list
        empty_person (class object): empty person
    Returns:
        list: modified driver_list
        list: modified owner_list
    """
    try:
        final_score = 0
        p_name = person.First_Name + person.Last_Name + person.Middle_Name
        person_type = person.Person_Type
        if owner_list_length and 'UNKNOWN' not in p_name:
            for index, owner in enumerate(owner_list):
                o_name = owner.First_Name + owner.Last_Name + owner.Middle_Name
                o_type = owner.Person_Type
                score = fuzz.ratio(o_name, p_name)
                if score >= 80 or (p_name in o_name):
                    final_score = score
                    if ((o_type == 'VICTIM' and person_type == 'VICTIM') or
                        (o_type == 'OWNER' and person_type == 'OWNER')):
                        person.Unit_Number = owner.Unit_Number
                        owner = deepcopy(person)
                        owner.Person_Type = 'VEHICLE OWNER'
                        empty_person.Person_Type = 'DRIVER'
                        owner_list[index] = owner
                        driver_list[index] = empty_person
                    elif person_type in ['SUSPECT', 'DRIVER']:
                        person.Unit_Number = owner.Unit_Number
                        owner = deepcopy(person)
                        owner.Person_Type = 'VEHICLE OWNER'
                        person.Person_Type = 'DRIVER'
                        person.Same_as_Driver_GUI = 'Y'
                        owner_list[index] = owner
                        driver_list[index] = person
                    elif o_type == 'PASSENGER' and person_type == 'PASSENGER':
                        person.Unit_Number = owner.Unit_Number
                        driver_list.append(person)
                        owner_list.remove(owner)
                        driver_list.pop(index)
            if person_type in ['PASSENGER', 'WITNESS'] and not final_score:
                driver_list.append(person)
            elif person_type in ['DRIVER', 'SUSPECT'] and not final_score:
                person.Person_Type = 'DRIVER'
                empty_person.Person_Type = 'VEHICLE OWNER'
                owner_list.append(empty_person)
                driver_list.append(person)
    except:
        pass
    return driver_list, owner_list

def get_final_people_list(driver_list, driver):
    """
    This function separates other people from driver list and assign unit number to passenger
    Args:
        driver_list (list): people_list
        driver (class object): empty driver
    Returns:
        list: modified driver_list
        list: modified other_list
    """
    other_list = []
    try:
        for index, person in enumerate(driver_list):
            if person.Person_Type in ['PASSENGER', 'WITNESS']:
                other_list.append(person)
            if not person:
                driver.Person_Type = 'DRIVER'
                driver_list[index] = driver
        driver_list = [item for item in driver_list if item not in other_list]
        other_list = sorted(other_list, key=lambda v: v.Unit_Number)
        other_list = sorted(other_list, key=lambda v: ['PASSENGER','WITNESS'].index(v.Person_Type))
        for index, person in enumerate(other_list):
            if person.Person_Type == 'PASSENGER':
                if person.Unit_Number == '':
                    person.Unit_Number = str(index+1)
            elif person.Person_Type != 'PASSENGER':
                del person.Unit_Number
    except:
        pass
    return driver_list, other_list

def modify_date(text):
    """
    This function extracts date format from the text
    Args:
        text (str): text containing date
    Returns:
        str: date from the text
    """
    try:
        if text:
            date = re.findall(r'\d{1,2}/\d{1,2}/\d{4}', text)
            if date:
                text = date[0]
    except:
        pass
    return text.strip()


def get_count(d_frame, key):
    """
    Returns count of the given key
    Args:
        d_frame (dataframe): d_frame
        key (str): key
    Returns:
        int: Total count
    """
    max_count = 0
    try:
        labels = get_predefined_labels(key)
        for label in labels:
            count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                (label.lower())) & (d_frame['text'].str.strip()), 'label'])
            max_count = max(max_count, count)
    except:
        pass
    return max_count

def get_business_name(text, business_name_lookup_path):
    """
    Check given name is business name or not
    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        bool: business name or not
    """
    try:
        business_name_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', text).split())
        with open(business_name_lookup_path,encoding='utf-8', errors='ignore') as file:
            business_name_lookup = file.readlines()
            business_name_lookup = [x.strip() for x in business_name_lookup]
        file.close()
        business_names = '|'.join(business_name_lookup)
        business_name_match = re.search(r'((\s|,)(' + business_names + r')(\s|,)?)$',
            business_name_text, re.IGNORECASE)
        if business_name_match:
            return True
    except:
        pass
    return False

def process_name(text, business_name_lookup_path):
    """
    Returns Person Name
    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        str: Person Name
    """
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    try:
        text = re.sub('[^A-Za-z- ]', '', text)
        text = text.lower().replace('name', '').split(':')[-1].strip()
        is_business_name = get_business_name(text, business_name_lookup_path)
        if not is_business_name:
            add_dict = name_split_using_pattern(text, business_name_lookup_path, 'LFM')
            add_dict['first_name'] = add_dict['first_name'].upper()
            add_dict['middle_name'] = add_dict['middle_name'].upper()
            add_dict['last_name'] = add_dict['last_name'].upper()
            add_dict['suffix'] = add_dict['suffix'].upper()
        else:
            text = text.replace(',', '')
            add_dict['last_name'] = text.upper()
    except:
        pass
    return add_dict


def delete_invalid_keys(people):
    """
    Deletes keys that not required from class
    Args:
        people (class): People
    """
    try:
        del people.Alcohol_Use_Suspected
        del people.Marijuana_Use_Suspected
        del people.Drug_Use_Suspected
        del people.Contributing_Circumstances_Person
        del people.Non_Motorist_Actions_At_Time_Of_Crash
        del people.Safety_Equipment_Restraint
        del people.Safety_Equipment_Available_Or_Used
        del people.Safety_Equipment_Helmet
        del people.Ejection
    except:
        pass

def merge_lists(list1, list2):
    """
    This function merge two lists in alternate manner
    Args:
        list1 (list): first list
        list2 (list): second list
    Returns:
        list: merged list
    """
    merged_list = []
    try:
        if len(list1) != len(list2):
            shorter_list_length = min(len(list1), len(list2))
        else:
            shorter_list_length = len(list1)
        for i in range(shorter_list_length):
            merged_list.append(list1[i])
            merged_list.append(list2[i])
        if len(list1) < len(list2):
            merged_list.extend(list2[shorter_list_length:])
    except:
        pass
    return merged_list
