"""
Created on 06/09/2023

@author: e503370: Gokul Rathan
"""

import sys
import copy
import pandas as pd
import re

from COLORADO.form_2 import co_form_2_postprocess as postprocessor

def get_df_value_coord(d_frame, label_name, index=0):
    """
    Function retrive coordinates from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.

    Returns:
        str: Value from df (predicted coordinates)
    """
    try:
        d_frame['page_no'] = d_frame['path'].apply(lambda x: x.split('_')[-1])
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[
                ['label', 'text','xmin','ymin','xmax','ymax','page_no']]])

        data_df = data_df.loc[data_df['label'].str.lower()==(label_name.lower()),
                              ['label', 'text','xmin','ymin','xmax','ymax','page_no']]

        if len(data_df) > 0:
            xmin_value = data_df['xmin'].iloc[index]
            ymin_value = data_df['ymin'].iloc[index]
            xmax_value = data_df['xmax'].iloc[index]
            ymax_value = data_df['ymax'].iloc[index]
            page_no_value = data_df['page_no'].iloc[index]


            value = f"{int(xmin_value)},{int(ymin_value)},{int(xmax_value)},{int(ymax_value)},{int(page_no_value)}"

            if str(value) != 'nan':
                return str(value)

    except:
        pass
    return ''


def get_damage_coord (d_frame , index=0):
    damaged_areas = ''
    try:

        no_damage = postprocessor.get_df_value(d_frame, 'No_Damage', index)
        under_carriage = postprocessor.get_df_value(d_frame, 'under_carriage', index)
        # under_carriage = ""

        if no_damage == 'Unchecked':
            df_list = []
            for i in range(1,20):
            # print(f"Damage_{i}")
                damage = postprocessor.get_df_value(d_frame, f"Damage_{i}", index)
                damage = re.sub(r'[^0-9]', '', damage)
                if len(damage)>1 :
                    df_list.append(damage[-1]) 
                else:
                    df_list.append(damage)


            non_empty_indices = [index for index, value in enumerate(df_list) if value]
            # print(non_empty_indices[0])

            value_1 = str(non_empty_indices[0]+1)

            damaged_areas = get_df_value_coord(d_frame,"damage_"+value_1 ,index)

            

        else:
            damaged_areas = get_df_value_coord(d_frame,'No_Damage' ,index)

    except:
        pass

    return damaged_areas

class Incident():
    """
    Class defining Incident Report
    """
    def __init__(self, case_identifier='', crash_date='', loss_street='', crash_time='',
        loss_cross_street = '', crash_city='', latitude='', longitude='', weather_condition='',
        road_surface_condition=''):
        """
        Initialize the Incident Report's objects

        Args:
            case_identifier (str, optional): case_identifier. Defaults to ''.
            crash_date (str, optional): crash_date. Defaults to ''.
            loss_street (str, optional): loss_street. Defaults to ''.
            crash_time (str, optional): crash_time. Defaults to ''.
            loss_cross_street (str, optional): loss_cross_street. Defaults to ''.
            crash_city (str, optional): crash_city. Defaults to ''.
            latitude (str, optional): latitude. Defaults to ''.
            longitude (str, optional): longitude (. Defaults to ''.
            weather_condition (str, optional): weather_condition. Defaults to ''.
            road_surface_condition (str, optional): road_surface_condition. Defaults to ''.
        """
        self.Case_Identifier = case_identifier
        self.State_Report_Number = ''
        self.Crash_Date = crash_date
        self.Crash_Time = crash_time
        self.Loss_State_Abbr = 'CO'
        self.Crash_City = crash_city
        self.Report_Type_Id = ''
        self.Loss_Street = loss_street
        self.Loss_Cross_Street = loss_cross_street
        self.Latitude = latitude
        self.Longitude = longitude
        self.Gps_Other = ''
        self.Weather_Condition = weather_condition
        self.Road_Surface_Condition = road_surface_condition

def incident_extraction(data_frame):
    """
    Passes Incident Report data to the Incident Class

    Args:
        data_frame (DataFrame): Predicted DataFrame

    Returns:
        List : Incident Report List
    """
    try:
        # changes : inseted the code to extract coordinates
        case_identifier = get_df_value_coord(data_frame, 'Case_Identifier')
        crash_date = get_df_value_coord(data_frame, 'Crash_Date')
        crash_time = get_df_value_coord(data_frame, 'Crash_Time')
        city = get_df_value_coord(data_frame, 'Crash_City')

        loss_street = get_df_value_coord(data_frame, 'Crash_Location')
        loss_cross_street = get_df_value_coord(data_frame, 'Loss_Cross_Street')

        latitude = get_df_value_coord(data_frame, 'Latitude')
        longitude = get_df_value_coord(data_frame, 'Longitude')

        is_hit_and_run = postprocessor.is_hit_and_run(data_frame)
        is_hit_and_run_coord = get_df_value_coord(data_frame,'hit_and_run')

        weather_condition = postprocessor.get_df_value(data_frame, 'Weather_Condition', index=0,
                            is_code=True, code='weather_condition')
        weather_condition_coord = get_df_value_coord(data_frame, 'Weather_Condition', index=0)
        if not weather_condition:
            weather_condition =  postprocessor.get_df_value(data_frame, 'Weather_Condition', index=1,
                            is_code=True, code='weather_condition')
            weather_condition_coord = get_df_value_coord(data_frame, 'Weather_Condition', index=1)

        road_surface_condition = get_df_value_coord(data_frame,'Road_Condition', index=0)
        incident_report = Incident(
                            case_identifier = case_identifier,
                            crash_date = crash_date,
                            loss_street = loss_street,
                            loss_cross_street = loss_cross_street,
                            crash_city = city,
                            crash_time = crash_time,
                            latitude = latitude,
                            longitude = longitude,
                            weather_condition = weather_condition_coord,
                            road_surface_condition = road_surface_condition
                            )
        if is_hit_and_run:
            incident_report.Incident_Hit_and_Run = is_hit_and_run_coord
        return incident_report
    except:
        pass
    return []

class People():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', person_type='', first_name='',
        middle_name='', last_name='', suffix='', address='', state='', city='', zip_code='',
        date_of_birth='', home_phone='', driver_license_number='', driver_jurisdiction='',
        alcohol_use = '', marijuana_use = '', drug_use = '', safety_equipment_restraint = '',
        safety_equipment_available_or_used = '', safety_equipment_helmet = '', ejection = '',
        injury = '',first_name_coord = '',middle_name_coord = '',last_name_coord = '',
        contributing_circumstances_person = ''):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.
            person_type (str, optional): person_type. Defaults to ''.
            first_name (str, optional): first_name. Defaults to ''.
            middle_name (str, optional): middle_name. Defaults to ''.
            last_name (str, optional): last_name. Defaults to ''.
            suffix (str, optional): suffix. Defaults to ''.
            address (str, optional): address. Defaults to ''.
            state (str, optional): state. Defaults to ''.
            city (str, optional): city. Defaults to ''.
            zip_code (str, optional): zip_code. Defaults to ''.
            date_of_birth (str, optional): date_of_birth. Defaults to ''.
            home_phone (str, optional): home_phone. Defaults to ''.
            driver_license_number (str, optional): driver_license_number. Defaults to ''.
            driver_jurisdiction (str, optional): driver_jurisdiction. Defaults to ''.
            alcohol_use (str, optional): alcohol_use. Defaults to ''.
            marijuana_use (str, optional): marijuana_use. Defaults to ''.
            drug_use (str, optional): drug_use. Defaults to ''.
            safety_equipment_restraint (str, optional): safety_equipment_restraint. Defaults to ''.
            safety_equipment_available_or_used (str, optional):
                                            safety_equipment_available_or_used. Defaults to ''.
            safety_equipment_helmet (str, optional): safety_equipment_helmet. Defaults to ''.
            ejection (str, optional): ejection. Defaults to ''.
            alcohol_use (str, optional): alcohol_use. Defaults to ''.
        """
        self.Party_Id = party_id
        self.Person_Type = person_type
        self.Unit_Number = unit_number
        self.First_Name = first_name
        self.Middle_Name = middle_name
        self.Last_Name = last_name
        self.Name_Suffix = suffix
        self.Address = address
        self.Address2 = ''
        self.State = state
        self.City = city
        self.Zip_Code = zip_code
        self.Home_Phone = home_phone
        self.Date_Of_Birth = date_of_birth
        self.Drivers_License_Number = driver_license_number
        self.Drivers_License_Jurisdiction = driver_jurisdiction
        self.Injury_Status = injury
        self.Alcohol_Use_Suspected = alcohol_use
        self.Marijuana_Use_Suspected = marijuana_use
        self.Drug_Use_Suspected = drug_use
        self.Contributing_Circumstances_Person = contributing_circumstances_person
        self.Non_Motorist_Actions_At_Time_Of_Crash = ''
        self.Safety_Equipment_Restraint = safety_equipment_restraint
        self.Safety_Equipment_Available_Or_Used = safety_equipment_available_or_used
        self.Safety_Equipment_Helmet = safety_equipment_helmet
        self.Ejection = ejection
        self.First_Name_Coord = first_name_coord
        self.Middle_Name_Coord = middle_name_coord
        self.Last_Name_Coord = last_name_coord

def get_people(d_frame, index, person_type, party_id, unit_number=''):
    """
    Return People class

    Args:
        d_frame (dataframe): Predicted Dataframe
        index (int): index
        person_type (str): Person Type
        party_id (int): party_id
        unit_number (str, optional): unit_number

    Returns:
        class: People
    """
    if person_type == 'VEHICLE OWNER':
        keys = [
            'V_Owner_Last_Name', 'V_Owner_First_Name', 'V_Owner_Middle_Name',
            'V_Owner_Address', 'V_Owner_City', 'V_Owner_State', 'V_Owner_Zipcode',
            '', '', '', '', '', '', '', '', '', '', '', '','','',''
            ]
    elif person_type == 'DRIVER':
        keys = [
            'Driver_Last_Name', 'Driver_First_Name', 'Driver_Middle_Name',
            'Driver_Street_Address', 'Driver_City', 'Driver_State', 'Driver_Zipcode',
            'Driver_DOB', 'Driver_Home_Phone', 'Driver_License_Number', 'Drivers_License_Jurisdiction',
            'Driver_I', 'Driver_K', 'Driver_M', 'Driver_F1', 'Driver_F2', 'Driver_F3',
            'Driver_D', 'Driver_H','human_factor_1','human_factor_2'
            ]
    else:
        keys = [
            'Owner_Last_Name', 'Owner_First_Name', 'Owner_Middle_Name',
            'Owner_Address', 'Owner_City', 'Owner_State', 'Owner_Zipcode',
            '', '', '', '', '', '', '', '', '', '', '', '','','','',''
            ]

    person = People()
    try:
        # changes : inseted the code to extract coordinates
        last_name = postprocessor.get_df_value(d_frame, keys[0], index).upper()
        first_name = postprocessor.get_df_value(d_frame, keys[1], index).upper()
        middle_name = postprocessor.get_df_value(d_frame, keys[2], index).upper()
        # name coordinates
        last_name_coord = get_df_value_coord(d_frame, keys[0], index)
        first_name_coord = get_df_value_coord(d_frame, keys[1], index)
        middle_name_coord = get_df_value_coord(d_frame, keys[2], index)


        address = get_df_value_coord(d_frame, keys[3], index)
        city = get_df_value_coord(d_frame, keys[4], index)
        state = get_df_value_coord(d_frame, keys[5], index)
        zip_code = get_df_value_coord(d_frame, keys[6], index)
        date_of_birth = get_df_value_coord(d_frame, keys[7], index)

        home_phone = get_df_value_coord(d_frame, keys[8], index)

        driver_license_number = get_df_value_coord(d_frame, keys[9], index)
        driver_jurisdiction = get_df_value_coord(d_frame, keys[10], index)

        alcohol_use = get_df_value_coord(d_frame, keys[11], index)
        marijuana_use = get_df_value_coord(d_frame, keys[12], index)
        drug_use = get_df_value_coord(d_frame, keys[13], index)
        safety_equipment_restraint = get_df_value_coord(d_frame, keys[14], index)
        safety_equipment_available_or_used = get_df_value_coord(d_frame, keys[15], index)
        safety_equipment_helmet = get_df_value_coord(d_frame, keys[16], index)
        ejection = get_df_value_coord(d_frame, keys[17], index)
        injury = get_df_value_coord(d_frame, keys[18],index)
        contributing_person_1 = get_df_value_coord(d_frame, keys[19], index)


        person = People(party_id = str(party_id),
                    unit_number = str(unit_number),
                    person_type = person_type,
                    first_name = first_name,
                    middle_name = middle_name,
                    last_name = last_name,
                    address = address,
                    state = state,
                    city = city,
                    zip_code = zip_code,
                    home_phone = home_phone,
                    date_of_birth = date_of_birth,
                    driver_license_number = driver_license_number,
                    driver_jurisdiction = driver_jurisdiction,
                    alcohol_use = alcohol_use,
                    marijuana_use = marijuana_use,
                    drug_use = drug_use,
                    safety_equipment_restraint = safety_equipment_restraint,
                    safety_equipment_available_or_used = safety_equipment_available_or_used,
                    safety_equipment_helmet = safety_equipment_helmet,
                    ejection = ejection,
                    injury = injury,
                    contributing_circumstances_person = contributing_person_1,

                    last_name_coord=last_name_coord,
                    first_name_coord=first_name_coord,
                    middle_name_coord=middle_name_coord

                    )
    except:
        pass
    return person

def people_extraction(d_frame):
    """
    Passes People data to the People Class

    Args:
        d_frame (DataFrame): Predicted DataFrame

    Returns:
        List : People List
    """
    try:
        # changes : inseted the code to extract coordinates
        party_id = 1
        unit_number = 1
        people_list = []
        people_count = postprocessor.get_count(d_frame, 'people')
        total_vehicle = postprocessor.get_total_vehicle_count(d_frame)
        people_count = max(people_count, total_vehicle)

        for index in range(people_count):
            is_same_name =  postprocessor.get_df_value(d_frame,
                            'V_Owner_Name_Same_as_Driver', index).lower()
            is_same_address =  postprocessor.get_df_value(d_frame,
                            'V_Owner_Address_Same_as_Driver', index).lower()
            is_hit_and_run = postprocessor.get_df_value(d_frame, 'Hit_and_Run', index).lower()
            is_parked = postprocessor.get_df_value(d_frame, 'Parked', index).lower()

            owner = get_people(d_frame, index, 'VEHICLE OWNER', party_id, unit_number)
            driver = get_people(d_frame, index, 'DRIVER', party_id+1, unit_number)

            if is_hit_and_run == 'checked':
                driver = People(party_id = str(party_id+1), unit_number=str(unit_number),
                        person_type='DRIVER')
                driver.Person_Type = 'DRIVER'
                driver.Last_Name = 'HIT & RUN'
            elif is_parked == 'checked':
                driver = People(party_id = str(party_id+1), unit_number=str(unit_number),
                        person_type='DRIVER')
                driver.Person_Type = 'DRIVER'
                driver.Last_Name = 'PARKED'
            elif is_same_name == 'checked' or is_same_address == 'checked':
                owner_name = owner.First_Name + owner.Last_Name + owner.Middle_Name
                driver_name = driver.First_Name + driver.Last_Name + driver.Middle_Name

                if len(owner_name) < len(driver_name):
                    owner = copy.deepcopy(driver)
                    owner.Party_Id = str(party_id)
                    owner.Person_Type = 'VEHICLE OWNER'
                else:
                    driver.First_Name = owner.First_Name
                    driver.Middle_Name = owner.Middle_Name
                    driver.Last_Name = owner.Last_Name
                    driver.Address = owner.Address
                    driver.City = owner.City
                    driver.State = owner.State
                    driver.Zip_Code = owner.Zip_Code
                driver.Same_as_Driver_GUI = 'Y'
            postprocessor.delete_invalid_keys(owner)
            party_id += 2
            unit_number += 1
            people_list.extend([owner, driver])
        if not people_list:
            owner = People(party_id = str(1), person_type='VEHICLE OWNER')
            postprocessor.delete_invalid_keys(owner)
            driver = People(party_id = str(2), person_type='DRIVER')
            people_list.extend([owner, driver])
        return people_list
    except:
        pass
    return []

def passenger_extraction(d_frame, people_list, business_name_lookup_path, city_lookup_path):
    """
    Return People class

    Args:
        d_frame (dataframe): Predicted Dataframe
        people_list (list): People List
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path

    Returns:
        class: People
    """
    try:
        # changes : inseted the code to extract coordinates
        party_id = len(people_list) + 1
        unit_number = 1
        total_vehicle = postprocessor.get_total_vehicle_count(d_frame)
        keys = ['Passenger_F1', 'Passenger_F2', 'Passenger_F3', 'Passenger_D', 'Passenger_H']
        keys_count = 0
        for index in range(total_vehicle):
            passenger_id = 1
            for _ in range(3):
                passenger = postprocessor.get_df_value(d_frame, 'Passenger_'+ str(passenger_id),
                            index)
                if passenger:
                    name = passenger.split('\n')[0].strip()
                    name = postprocessor.process_name(name, business_name_lookup_path)
                    address = passenger.split('\n')[1].strip()
                    address = postprocessor.address_split_using_lookup(address, city_lookup_path)

                    safety_equipment_restraint = get_df_value_coord(d_frame,keys[0], keys_count)
                    safety_equipment_available_or_used = get_df_value_coord(d_frame, keys[1], keys_count)
                    safety_equipment_helmet = get_df_value_coord(d_frame, keys[2], keys_count)
                    ejection = get_df_value_coord(d_frame, keys[3], keys_count)
                    injury = get_df_value_coord(d_frame, keys[4], keys_count)
                    
                    passenger_coord = get_df_value_coord(d_frame, 'Passenger_'+ str(passenger_id),index)
                    address = passenger_coord

                    person = People(party_id = str(party_id),
                        unit_number = str(unit_number),
                        person_type = 'PASSENGER',
                        first_name = name['first_name'],
                        middle_name = name['middle_name'],
                        last_name = name['last_name'],
                        address = address,
                        state = address,
                        city = address,
                        zip_code = address,
                        safety_equipment_restraint = safety_equipment_restraint,
                        safety_equipment_available_or_used = safety_equipment_available_or_used,
                        safety_equipment_helmet = safety_equipment_helmet,
                        ejection = ejection,
                        injury = injury,
                        first_name_coord=passenger_coord,
                        middle_name_coord=passenger_coord,
                        last_name_coord=passenger_coord
                        )
                    party_id += 1
                    people_list.append(person)
                keys_count += 1
                passenger_id += 1
                if passenger_id > 3:
                    passenger_id = 1
            unit_number += 1
    except:
        pass
    return people_list

def property_extraction(d_frame, people_list):
    """
    Passes People data to the People Class

    Args:
        d_frame (DataFrame): Predicted DataFrame
        people_list (list): people_list
    Returns:
        List : People List
    """
    try:
        party_id = len(people_list) + 1
        people_count = postprocessor.get_count(d_frame, 'property')
        for index in range(people_count):
            property_owner = get_people(d_frame, index, 'PROPERTY OWNER', party_id, '')
            party_id += 1
            people_list.append(property_owner)
    except:
        pass
    return people_list

class Vehicle():
    """
    Class defining Vehicle
    """
    def __init__(self, unit_number='', make='', vin = '', model_year='', model='',
        license_plate='', registration_state='', insurance_company='', damaged_areas='',
        police_number = '', expiration_date='', vehicle_towed='', speed_limit='',
        circumstance_vehicle='', air_bag_deployed=''):
        """
        Initialize the Vehicle objects

        Args:
            unit_number (str, optional): unit_number. Defaults to ''.
            make (str, optional): make. Defaults to ''.
            vin (str, optional): vin. Defaults to ''.
            model_year (str, optional): model_year. Defaults to ''.
            license_plate (str, optional): license_plate. Defaults to ''.
            registration_state (str, optional): registration_state. Defaults to ''.
            insurance_company (str, optional): insurance_company. Defaults to ''.
            damaged_areas (str, optional): damaged_areas. Defaults to ''.
            police_number (str, optional): police_number. Defaults to ''.
            expiration_date (str, optional): expiration_date. Defaults to ''.
            vehicle_towed (str, optional): vehicle_towed. Defaults to ''.
            speed_limit (str, optional): speed_limit. Defaults to ''.
            circumstance_vehicle (str, optional): circumstance_vehicle. Defaults to ''.
            air_bag_deployed (str, optional): air_bag_deployed. Defaults to ''.
        """
        self.Unit_Number = unit_number
        self.License_Plate = license_plate
        self.Registration_State = registration_state
        self.VIN = vin
        self.VinValidation_VinStatus = ''
        self.Model_Year = model_year
        self.Make = make
        self.Model = model
        self.Insurance_Company = insurance_company
        self.Insurance_Policy_Number = police_number
        self.Insurance_Expiration_Date = expiration_date
        self.Vehicle_Towed = vehicle_towed
        self.Air_Bag_Deployed = air_bag_deployed
        self.Damaged_Areas = damaged_areas
        self.Contributing_Circumstances_Vehicle = circumstance_vehicle
        self.Posted_Statutory_SpeedLimit = speed_limit

def vehicle_extraction(d_frame):
    """
    Passes Vehicle data to the Vehicle Class

    Args:
        d_frame (DataFrame): Predicted DataFrame

    Returns:
        List : Vehicle List
    """
    try:
        # changes : inseted the code to extract coordinates
        vehicle_list = []
        vehicle_count = postprocessor.get_count(d_frame, 'vehicle')
        total_vehcile = postprocessor.get_total_vehicle_count(d_frame)
        vehicle_count = max(vehicle_count, total_vehcile)

        for index in range(vehicle_count):
            vin = get_df_value_coord(d_frame, 'VIN', index)
            make = get_df_value_coord(d_frame, 'Make', index)
            model_year = get_df_value_coord(d_frame, 'Year', index)
            model = get_df_value_coord(d_frame, 'Model', index)
            license_plate = get_df_value_coord(d_frame, 'License_Plate', index)
            registration_state = get_df_value_coord(d_frame, 'License_State', index)
            insurance_company = get_df_value_coord(d_frame,'Insurance_Company', index)
            police_number = get_df_value_coord(d_frame, 'Policy_Number', index)
            expiration_date = get_df_value_coord(d_frame,'Insurance_Expiration_Date', index)
            speed_limit = get_df_value_coord(d_frame, 'Posted_Statutory_SpeedLimit', index)
            vehicle_towed = get_df_value_coord(d_frame, 'Vehicle_Towed',index)
            air_bag_deployed = get_df_value_coord(d_frame, 'Driver_A', index)
            circumstance_vehicle = get_df_value_coord(d_frame,'Contributing_Circumstances_Vehicle', index)
            damaged_areas = get_damage_coord(d_frame,index)

            vehicle = Vehicle(
                        unit_number = str(index+1),
                        vin = vin,
                        make = make,
                        model_year = model_year,
                        model = model,
                        license_plate = license_plate,
                        registration_state = registration_state,
                        insurance_company = insurance_company,
                        police_number = police_number,
                        expiration_date = expiration_date,
                        vehicle_towed = vehicle_towed,
                        speed_limit = speed_limit,
                        circumstance_vehicle = circumstance_vehicle,
                        air_bag_deployed = air_bag_deployed,
                        damaged_areas = damaged_areas
                        )
            vehicle_list.append(vehicle)
        if not vehicle_list:
            vehicle_list.append(Vehicle(unit_number = '1'))
        return vehicle_list
    except:
        pass
    return []

class Citation():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', primary_violation='',
                violation_code = '' , citation_number = '' ):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.

       
        """
        self.Party_Id = party_id
        self.Unit_Number = unit_number
        self.Primary_Violation = primary_violation
        self.Violation_Code = violation_code
        self.Citation_Number = citation_number
        

def citations_extraction(d_frame):
    try :
        citation_list = []
        party_id = 1
        unit_number = 1
        citation_count = postprocessor.get_count(d_frame, 'citation')

        for index in range(citation_count):
            primary_violation = get_df_value_coord(d_frame, 'primary_violation', index)
            violation_code = get_df_value_coord(d_frame, 'violation_code', index)
            citation_number = get_df_value_coord(d_frame, 'citation_number', index)

            citation  = Citation(
                                party_id = party_id,
                                unit_number = unit_number,
                                primary_violation = primary_violation,
                                violation_code = violation_code,
                                citation_number = citation_number
            )
            citation_list.append(citation)
            if not citation_list:
                citation_list.append(Citation(party_id=party_id))

            party_id += 1
            unit_number += 1
        
        return citation_list
    
    except :
        pass
    return  []

class Report():
    """
    Class defining Report
    """
    def __init__(self, form_name, count_keyed, incident, people, vehicles, citations, form_type):
        """
        Initialize the Report objects

        Args:
            form_name (str): form_name
            count_keyed (str): count_keyed
            incident (List): incident
            people (List): people
            vehicles (List): vehicles
            citations (List): citations
        """
        self.FormName = form_name
        self.CountKeyed = count_keyed
        self.Incident = incident
        self.People = people
        self.Vehicles = vehicles
        self.Citations = citations
        self.Form_Type = form_type

class MainCls():
    """
    Class: Defines MainCls
    """
    def __init__(self, report):
        """
        Initialize the MainCls objects

        Args:
            report (class): report
        """
        self.Report = report

def modify_people(people):
        people.First_Name = people.First_Name_Coord
        people.Middle_Name = people.Middle_Name_Coord
        people.Last_Name = people.Last_Name_Coord

        del people.First_Name_Coord
        del people.Last_Name_Coord
        del people.Middle_Name_Coord

def json_convertion_coordinate(text_extracted_df, form_type, business_name_lookup_path,
                               city_lookup_path):
    """
    Function to form json from the predicted DataFrame

    Args:
        text_extracted_df (DataFrame): Predicted DataFrame
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path

    Returns:
        JSON: Json data created from predicted DataFrame
    """
    try:
        incident_report = incident_extraction(text_extracted_df)

        people_list = people_extraction(text_extracted_df)

        people_list = passenger_extraction(text_extracted_df, people_list,
                    business_name_lookup_path, city_lookup_path)
        
        people_list = property_extraction(text_extracted_df, people_list)
        for people in people_list:
            modify_people(people)

        vehicle_list = vehicle_extraction(text_extracted_df)
        citation_list = citations_extraction(text_extracted_df)
        

        if (incident_report or people_list or vehicle_list):
            tif_name = (text_extracted_df['path'][0].split("_")[0]) + '_CO.tif'
            report = Report(form_name = 'Universal',
                            count_keyed = '',
                            incident = incident_report,
                            people = people_list,
                            vehicles = vehicle_list,
                            citations = citation_list,
                            form_type = ('CO_'+ form_type))
            main_cls = MainCls(report = report)
            return main_cls, tif_name
    except:
        pass
    return sys.exc_info(), 'error'
