"""
Created on 13/04/2023

@author: e406679: Srikandan Raju
"""

import re

import pandas as pd

from COLORADO.config import Config
from COLORADO.name_address_split import name_split_using_pattern

def get_predefined_labels(key):
    """
    Function holds predefined labels for Incident, People and Vehicle

    Args:
        key (str): Key of predefined_labels

    Returns:
        List: Value of predefined_labels
    """
    try:
        return Config.FORM_2_PREDEFINED_LABELS[key]
    except:
        pass
    return []

def get_df_value(d_frame, label_name, index=0, is_code=False, code=None):
    """
    Function retrive value from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.
        is_code (boolean, optional): is_code. Defaults to False.
        code (boolean, str): code. Defaults to None.

    Returns:
        str: Value from df (predicted dataframe)
    """
    try:
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])

        data_df = data_df.loc[data_df['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            value = data_df['text'].iloc[index]
            if str(value) != 'nan':
                if not is_code:
                    return value.strip()
                else:
                    return get_code_description(value.strip(), code)
    except:
        pass
    return ''

def get_case_identifier(text):
    """
    Process the case Identifier

    Args:
        text (str): case Identifier

    Returns:
        str: case Identifier
    """
    try:
        if text.strip():
            text = text.replace('.', '-')
            text = ''.join(re.sub('[^0-9a-zA-Z]+', ' ', text).strip().split())
            return text
    except:
        pass
    return ''

def address_split_using_lookup(address_text, city_lookup_path, is_incident=False):
    """
    splits Address, City, State, Zipcode from text

    Args:
        address_text (str): address_text
        city_lookup_path (str): location of Cities
        is_incident (boolean, optional): is_incident

    Returns:
        dict: add_dict
    """
    add_dict = {'address': '', 'city': '', 'state': '', 'zipcode': ''}
    if address_text:
        try:
            city = ''
            state = ''
            zipcode = ''

            address_text = address_text.lower()
            address_text = address_text.replace('address', '').rsplit(':', 1)[-1]
            address_text = ' '.join(address_text.split()).strip()

            if address_text.find('los angeles') != -1:
                city = 'los angeles'
                address_text = address_text.replace(city, '').strip()

            zipcode = address_text.split()[-1]
            address_text = address_text.replace(zipcode, '').strip()
            zipcode = re.sub('[^0-9]+', ' ', zipcode)

            address_text = re.sub('[^a-zA-Z0-9/]+', ' ', address_text)

            with open(city_lookup_path, encoding='utf-8', errors='ignore') as file:
                city_lookup = file.readlines()
                city_lookup = [x.encode('ascii', 'ignore').decode().strip() for x in city_lookup]
            file.close()

            cities = '|'.join([i.lower() for i in city_lookup])

            states = '|'.join([i.lower() for i in Config.STATE_LIST])
            state_match = re.search(r'((\s|,)(' + states + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if state_match:
                state_match = state_match.group(3)
                if 'ca california' in state_match:
                    state = 'CA'
                else:
                    state = state_match
                address_text = re.sub(r'\s+'+state_match, '', address_text).strip()
            city_match = re.search(r'((\s|,)(' + cities + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if city_match:
                city = city_match.group(3)
                address_text = re.sub(r'\s+'+city, '', address_text).strip()

            if is_incident:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z/]+', ' ', address_text).strip().split())
            else:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', address_text).strip().split())

            add_dict.update({'address': address_text.upper()})
            add_dict.update({'city': city.upper()})
            add_dict.update({'state': state.upper()})
            add_dict.update({'zipcode': zipcode})
        except:
            pass
    return add_dict

def get_total_vehicle_count(d_frame):
    """
    Returns total vehicle count

    Args:
        d_frame (dataframe): d_frame

    Returns:
        int: Total vehicle count
    """
    total_vehicle_count = 0
    try:
        total_vehicle = get_df_value(d_frame, 'Total_Vehicle')
        total_vehicle = ''.join(re.sub('[^0-9]+', ' ', total_vehicle).split()).strip()
        total_vehicle_count = int(total_vehicle)
        # if total_vehicle == '':
        #     total_vehicle = 0
    except:
        pass
    return total_vehicle_count

def get_count(d_frame, key):
    """
    Returns count of the given key

    Args:
        d_frame (dataframe): d_frame
        key (str): key

    Returns:
        int: Total count
    """
    max_count = 0
    try:
        if key == 'citation':
            labels = get_predefined_labels(key)
            for label in labels:
                count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                    (label.lower())), 'label'])
                max_count = max(max_count, count)
        elif key == 'people':
            labels = get_predefined_labels(key)
            for label in labels:
                count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                    (label.lower())), 'label'])
                max_count = max(max_count, count)       


        else:
            labels = get_predefined_labels(key)
            for label in labels:
                count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                    (label.lower())) & (d_frame['text'].str.strip()), 'label'])
                max_count = max(max_count, count)
    except:
        pass
    return max_count

def get_business_name(text, business_name_lookup_path):
    """
    Check given name is business name or not

    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path

    Returns:
        bool: business name or not
    """
    try:
        business_name_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', text).split())
        with open(business_name_lookup_path,encoding='utf-8', errors='ignore') as file:
            business_name_lookup = file.readlines()
            business_name_lookup = [x.strip() for x in business_name_lookup]
        file.close()
        business_names = '|'.join(business_name_lookup)
        business_name_match = re.search(r'((\s|,)(' + business_names + r')(\s|,)?)$',
            business_name_text, re.IGNORECASE)
        if business_name_match:
            return True
    except:
        pass
    return False

def process_name(text, business_name_lookup_path):
    """
    Returns Person Name

    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path

    Returns:
        str: Person Name
    """
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    try:
        text = text.replace('0', 'O')
        text = text.replace('.', '')
        text = text.lower().replace('name', '').split(':')[-1].strip()
        is_business_name = get_business_name(text, business_name_lookup_path)
        if not is_business_name:
            add_dict = name_split_using_pattern(text, business_name_lookup_path)
            add_dict['first_name'] = add_dict['first_name'].upper()
            add_dict['middle_name'] = add_dict['middle_name'].upper()
            add_dict['last_name'] = add_dict['last_name'].upper()
            add_dict['suffix'] = add_dict['suffix'].upper()
        else:
            text = text.replace(',', '')
            add_dict['last_name'] = text.upper()
    except:
        pass
    return add_dict

def get_street(text):
    """
    Splits the Loss street and Loss Cross street from text

    Args:
        text (str): text

    Returns:
        str, str: Loss street and Loss Cross street from text
    """
    try:
        text = text.strip().lower()
        if 'and' in text:
            splitted_text = text.split('and')
            return splitted_text[0].strip().upper(), splitted_text[1].strip().upper()
        elif '/' in text:
            splitted_text = text.split('/')
            return splitted_text[0].strip().upper(), splitted_text[1].strip().upper()
    except:
        pass
    return text.upper(), ''

def is_hit_and_run(data_frame):
    """
    Returns True if "Hit and Run" is checked else false

    Args:
        d_frame (dataframe): d_frame

    Returns:
        boolean: True if "Hit and Run" is checked else false
    """
    try:
        group_df = data_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])
        data_df = data_df.loc[data_df['label'].str.lower()==('hit_and_run'),
            ['label', 'text']]
        values = list(data_df['text'])
        for value in values:
            if value.lower() in ['checked']:
                return True
    except:
        pass
    return False

def get_code_description(text, key):
    """
    Returns code and its description based on key

    Args:
        text (str): text
        key (str): key

    Returns:
        list: code and its description
    """
    try:
        if text.strip():
            key = key.lower()
            is_int = True
            code_dict = {}
            if key == 'weather_condition':
                code_dict = Config.FORM_2_WEATHER_CONDITION
            elif key == 'road_surface_condition':
                code_dict = Config.FORM_2_ROAD_SURFACE_CONDITION
            elif key == 'vehicle_towed':
                code_dict = Config.FORM_2_VEHICLE_TOWED
            elif key == 'contributing_circumstances_vehicle':
                code_dict = Config.FORM_2_CONTRIBUTING_CIRCUMSTANCES_VEHICLE
            elif key == 'driver_i':
                code_dict = Config.FORM_2_ALCOHOL_SUSPECTED
            elif key == 'driver_k':
                code_dict = Config.FORM_2_MARIJUANA_SUSPECTED
            elif key == 'driver_m':
                code_dict = Config.FORM_2_DRUG_SUSPECTED
            elif (key == 'driver_f1' or key == 'passenger_f1'):
                code_dict = Config.FORM_2_SAFETY_EQUIPMENT_RESTRAINT
                is_int = False
            elif (key == 'driver_f2' or key == 'passenger_f2'):
                code_dict = Config.FORM_2_SAFETY_EQUIPMENT_AVAILABLE_OR_USED
            elif (key == 'driver_f3' or key == 'passenger_f3'):
                code_dict = Config.FORM_2_SAFETY_EQUIPMENT_HELMET
                is_int = False
            elif (key == 'driver_d' or key == 'passenger_d'):
                code_dict = Config.FORM_2_EJECTION
            elif (key == 'driver_h' or key == 'passenger_h'):
                code_dict = Config.FORM_2_INJURY
            elif key == 'air_bag_deployed':
                code_dict = Config.AIR_BAG_DEPLOYED
            elif key == 'human_factor_1':
                code_dict = Config.FORM_2_CONTRIBUTING_CIRCUMSTANCES_PERSON
            elif key == 'damages_areas':
                code_dict = Config.FORM_2_DAMAGED_AREAS
            if code_dict:
                if is_int:
                    text = text.split()
                    text = text[0] + '' + text[len(text) - 1]
                    text = ''.join(text)
                    code = str(int(text))
                else:
                    text = ''.join(re.sub('[^a-zA-Z]+', ' ', text).split()).strip().upper()
                    code = text
                if code_dict.get(code, None):
                    return [{'Code': text, 'Description': code_dict[code]}]
    except:
        pass
    return ''

def get_geo_data(text):
    """
    Post-processes the latitude/longitude

    Args:
        text (str): text

    Returns:
        str: latitude/longitude
    """
    try:
        text = text.replace(' ', '')
        text = text.replace('--', '-')
    except:
        pass
    return text.upper()

def get_speed_limit(text):
    """
    Returns Speed-limit

    Args:
        text (str): text

    Returns:
        list: Speed-limit
    """
    try:
        text = ''.join(re.sub('[^0-9]+', ' ', text).split()).strip()
        if text:
            return [{'Code': '', 'Description': text}]
    except:
        pass
    return [{'Code': '', 'Description': '0'}]

def get_home_phone(text):
    """
    Post-process home-phone

    Args:
        text (str): text

    Returns:
        str: home-phone
    """
    try:
        if text:
            text = '-'.join(re.sub('[^0-9]+', ' ', text).split()).strip()
    except:
        pass
    return text

def get_registration_state(text):
    """
    Returns State code based on its name

    Args:
        text (str): text

    Returns:
        str: State code
    """
    try:
        text = text.upper().strip()
        if text:
            for key, value in Config.STATE_WITH_CODE.items():
                if text == key:
                    return value
    except:
        pass
    return ''

def get_value_from_list(data):
    """
    Returns description from list

    Args:
        data (list): data

    Returns:
        str: description
    """
    try:
        if isinstance(data, list):
            return data[0]['Description']
    except:
        pass
    return data

def delete_invalid_keys(people):
    """
    Deletes keys that not required from class

    Args:
        people (class): People
    """
    try:
        del people.Alcohol_Use_Suspected
        del people.Marijuana_Use_Suspected
        del people.Drug_Use_Suspected
        del people.Contributing_Circumstances_Person
        del people.Non_Motorist_Actions_At_Time_Of_Crash
        del people.Safety_Equipment_Restraint
        del people.Safety_Equipment_Available_Or_Used
        del people.Safety_Equipment_Helmet
        del people.Ejection
    except:
        pass


def get_damage_value (d_frame , index=0):
    damaged_areas = ''
    try:

        no_damage = get_df_value(d_frame, 'No_Damage', index)
        under_carriage = get_df_value(d_frame, 'under_carriage', index)

        Front = ['14','15','16','1']
        Right = ['2','3','4','5']
        Rear = ['6','7','8','9']
        Left  = ['10','11','12','13']
        Top = ['17','18','19']

        damage_dict = {
                    '0' : "None",
                    '1' : "Slight",
                    '2' : "Moderate",
                    '3' : "Severe"
        }

        if no_damage == 'Unchecked':
            df_list = []
            for i in range(1,20):
            # print(f"Damage_{i}")
                damage = get_df_value(d_frame, f"Damage_{i}", index)
                damage = re.sub(r'[^0-9]', '', damage)
                if len(damage)>1 :
                    df_list.append(damage[-1]) 
                else:
                    df_list.append(damage)


            non_empty_indices = [index for index, value in enumerate(df_list) if value]

            damaged_areas = []
            
            for j in non_empty_indices:
                code = str(j + 1)
                description = damage_dict[df_list[j]]
                area = ""

                if code in Front:
                    area = "Front"
                elif code in Right:
                    area = "Right"
                elif code in Rear:
                    area = "Rear"
                elif code in Left:
                    area = "Left"
                elif code in Top:
                    area = "Top"

                if area:
                    # damaged_areas.append({"Code": code, "Area": area, "Description": description})
                    damaged_areas.append({"Code": code, "Description": description + " DAMAGE AT THE " + area})

            if under_carriage:
                damaged_areas.append({"Code": under_carriage, "Description": damage_dict[under_carriage] + " DAMAGE UNDER CARRIAGE"})

        else:
            damaged_areas = [{"Code": '0', "Description": "NO DAMAGE"}]

    except:
        pass

    return damaged_areas
    
