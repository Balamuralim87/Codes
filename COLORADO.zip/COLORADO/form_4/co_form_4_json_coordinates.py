"""
Created on 04/09/2023

@author: e408118 : Supriya Raj
"""

import sys
import pandas as pd

from COLORADO.form_4 import co_form_4_postprocess as postprocessor

#General function to extract coordinates
def get_df_value_coord(text_extracted_df, label_name, index=0):
    """
    Function retrive coordinates from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.

    Returns:
        str: Value from df (predicted coordinates)
    """
    try:
        d_frame = text_extracted_df.copy()
        d_frame['page_no'] = d_frame['path'].apply(lambda x: x.split('_')[-1])
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[
                ['label', 'text','xmin','ymin','xmax','ymax','page_no']]])

        data_df = data_df.loc[data_df['label'].str.lower()==(label_name.lower()),
                              ['label', 'text','xmin','ymin','xmax','ymax','page_no']]

        if len(data_df) > 0:
            xmin_value = data_df['xmin'].iloc[index]
            ymin_value = data_df['ymin'].iloc[index]
            xmax_value = data_df['xmax'].iloc[index]
            ymax_value = data_df['ymax'].iloc[index]
            page_no_value = data_df['page_no'].iloc[index]
            value = f"{int(xmin_value)},{int(ymin_value)},{int(xmax_value)},{int(ymax_value)},{int(page_no_value)}"

            if str(value) != 'nan':
                return str(value)

    except:
        pass
    return ''

# function to extract coordinates for data spread over two labels
def get_address_coord(data_frame, label_name_1,label_name_2, index=0):
    """
    Function retrive coordinates from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name_1 (str): Used to retrive value from df (predicted dataframe)
        label_name_2 (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.

    Returns:
        str: Value from df (predicted coordinates)
    """
    try:
        d_frame = data_frame.copy()
        d_frame['page_no'] = d_frame['path'].apply(lambda x: x.split('_')[-1])
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[
                ['label', 'text','xmin','ymin','xmax','ymax','page_no']]])

        data_df_1 = data_df.loc[data_df['label'].str.lower()==(label_name_1.lower()),
                                ['label', 'text','xmin','ymin','xmax','ymax','page_no']]
        data_df_2 = data_df.loc[data_df['label'].str.lower()==(label_name_2.lower()),
                                ['label', 'text','xmin','ymin','xmax','ymax','page_no']]                      

        if len(data_df_1) > 0:
            xmin_value = data_df_1['xmin'].iloc[index]
            ymin_value = data_df_1['ymin'].iloc[index]
        if len(data_df_2) > 0:    
            xmax_value = data_df_2['xmax'].iloc[index]
            ymax_value = data_df_2['ymax'].iloc[index]
            page_no_value = data_df_2['page_no'].iloc[index]
                

            value = f"{int(xmin_value)},{int(ymin_value)},{int(xmax_value)},{int(ymax_value)},{int(page_no_value)}"

            if str(value) != 'nan':
                return str(value)

    except:
        pass
    return ''  

def get_information(d_frame, label):
    """
    This function creates separate dataframe for each person alond with
    individual person details and return list of all such dataframes
    Args:
        d_frame (DataFrame): original dataframe
        label (str): label(person or vehicle)
    Returns:
        list: dataframe list
    """
    df_list = []
    try:
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)])
        if label == 'people':
            index_numbers = list(data_df['label'].loc[lambda x: x=='Person_Name'].index)
        elif label == 'vehicle':
            if 'Vehicle' in list(data_df['label'].unique()):
                index_numbers = list(data_df['label'].loc[lambda x: x=='Vehicle'].index)
            else:
                index_numbers = list(data_df['label'].loc[lambda x: x=='License_Plate'].index)
        len_index = len(index_numbers)
        for index in range(len_index):
            if len_index == 1:
                data_df_new = data_df.loc[index_numbers[0]:]
            elif index_numbers[index] == index_numbers[-1]:
                data_df_new = data_df.loc[index_numbers[index]:]
            else:
                data_df_new = data_df.loc[index_numbers[index]:index_numbers[index+1]]
            df_list.append(data_df_new)
    except:
        pass
    return df_list      

class Incident():
    """
    Class defining Incident Report
    """
    def __init__(self, case_identifier='', crash_date='', loss_street='', crash_time='',
        crash_city='', loss_cross_street=''):
        """
        Initialize the Incident Report's objects

        Args:
            case_identifier (str, optional): case_identifier. Defaults to ''.
            crash_date (str, optional): crash_date. Defaults to ''.
            loss_street (str, optional): loss_street. Defaults to ''.
            crash_time (str, optional): crash_time. Defaults to ''.
            loss_cross_street (str, optional): loss_cross_street. Defaults to ''.
            crash_city (str, optional): crash_city. Defaults to ''.
        """
        self.Case_Identifier = case_identifier
        self.State_Report_Number = ''
        self.Crash_Date = crash_date
        self.Crash_Time = crash_time
        self.Loss_State_Abbr = 'CO'
        self.Crash_City = crash_city
        self.Report_Type_Id = ''
        self.Loss_Street = loss_street
        self.Loss_Cross_Street = loss_cross_street
        self.Latitude = ''
        self.Longitude = ''
        self.Gps_Other = ''
        self.Weather_Condition = ''
        self.Road_Surface_Condition = ''

def incident_extraction(data_frame):
    """
    Passes Incident Report data to the Incident Class
    Args:
        data_frame (DataFrame): Predicted DataFrame
    Returns:
        List : Incident Report List
    """
    try:
        #Changed the functions to get coordinates
        case_identifier = get_df_value_coord(data_frame, 'Case_Identifier')
        crash_date_time = get_df_value_coord(data_frame, 'Crash_Date_Time')
        location = get_df_value_coord(data_frame, 'Location_of_occurance')
        crash_city = get_df_value_coord(data_frame, 'Crash_City')

        incident_report = Incident(
                            case_identifier = case_identifier,
                            crash_date = crash_date_time,
                            crash_time = crash_date_time,
                            loss_street = location,
                            loss_cross_street = location,
                            crash_city = crash_city
                            )
        return incident_report
    except:
        pass
    return []

class People():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', person_type='', first_name='',
        middle_name='', last_name='', suffix='', address='', state='', city='', zip_code='',
        date_of_birth='', home_phone='', driver_license_number='', driver_jurisdiction='',
        name_coord ='',add_coord='',phone_coord='',state_city_zip_coord='',dob_coord=''):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.
            person_type (str, optional): person_type. Defaults to ''.
            first_name (str, optional): first_name. Defaults to ''.
            middle_name (str, optional): middle_name. Defaults to ''.
            last_name (str, optional): last_name. Defaults to ''.
            suffix (str, optional): suffix. Defaults to ''.
            address (str, optional): address. Defaults to ''.
            state (str, optional): state. Defaults to ''.
            city (str, optional): city. Defaults to ''.
            zip_code (str, optional): zip_code. Defaults to ''.
            date_of_birth (str, optional): date_of_birth. Defaults to ''.
            home_phone (str, optional): home_phone. Defaults to ''.
            driver_license_number (str, optional): driver_license_number. Defaults to ''.
            driver_jurisdiction (str, optional): driver_jurisdiction. Defaults to ''.
        """
        #Modified : to extract coordinates
        self.Party_Id = party_id
        self.Person_Type = person_type
        self.Unit_Number = unit_number
        self.First_Name = first_name
        self.Middle_Name = middle_name
        self.Last_Name = last_name
        self.Name_Suffix = suffix
        self.Address = address
        self.Address2 = ''
        self.State = state
        self.City = city
        self.Zip_Code = zip_code
        self.Home_Phone = home_phone
        self.Date_Of_Birth = date_of_birth
        self.Drivers_License_Number = driver_license_number
        self.Drivers_License_Jurisdiction = driver_jurisdiction
        self.Injury_Status = ''
        self.Alcohol_Use_Suspected = ''
        self.Marijuana_Use_Suspected = ''
        self.Drug_Use_Suspected = ''
        self.Contributing_Circumstances_Person = ''
        self.Non_Motorist_Actions_At_Time_Of_Crash = ''
        self.Safety_Equipment_Restraint = ''
        self.Safety_Equipment_Available_Or_Used = ''
        self.Safety_Equipment_Helmet = ''
        self.Ejection = ''
        self.Name_Coord = name_coord
        self.Address_Coord = add_coord
        self.Phone_Coord = phone_coord
        self.State_City_Zip_Coord = state_city_zip_coord
        self.DOB_Coord = dob_coord

def get_owner_list(data_frame, business_name_lookup_path, city_lookup_path):
    """
    Return Owner list
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        list: owner list
    """
    #Modified function to extract coordinates
    owner_list = []
    try:
        owner_names = []
        d_frames_list = get_information(data_frame, 'vehicle')
        owner_count = postprocessor.get_count(data_frame, 'vehicle')
        for index in range(owner_count):
            d_frame = d_frames_list[index]
            name = postprocessor.process_labels(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner'))
            owner_names.append(name)
            name = postprocessor.process_name(name, business_name_lookup_path)
            name_coord = get_df_value_coord(d_frame, 'Vehicle_Owner')
            owner = People(
                            unit_number = postprocessor.get_serial_number(
                                    postprocessor.get_df_value(d_frame, 'Vehicle')),
                            first_name = name['first_name'],
                            middle_name = name['middle_name'],
                            last_name = name['last_name'],
                            suffix = name['suffix'],
                            name_coord = name_coord
                        )
            owner_list.append(owner)
        if not ''.join(owner_names):
            owner_list = []
        owner_list_length = len(owner_list)
        business_count = postprocessor.get_count(data_frame, 'business person')
        for index in range(business_count):
            name = postprocessor.get_person_type_name(
                postprocessor.get_df_value(data_frame, 'Business_Name'))[1]
            name = postprocessor.process_name(name,
                                    business_name_lookup_path)
            municipality = postprocessor.process_labels(
                postprocessor.get_df_value(data_frame, 'Business_City_State_Zip'))
            municipality = postprocessor.name_address_split(
                municipality, city_lookup_path)

            municipality_coord = get_df_value_coord(data_frame, 'Business_City_State_Zip')
            phone_coord = get_df_value_coord(data_frame, 'Business_Home_Phone')
            name_coord =  get_df_value_coord(data_frame, 'Business_Name') 
            add_coord = get_df_value_coord(data_frame, 'Business_Address')
            person = People(
                        unit_number = postprocessor.get_serial_number(
                                postprocessor.get_df_value(data_frame, 'Business_Name')),
                        person_type = 'BUSINESS OWNER',
                        first_name = name['first_name'],
                        middle_name = name['middle_name'],
                        last_name = name['last_name'],
                        suffix = name['suffix'],
                        address = postprocessor.process_labels(
                                postprocessor.get_df_value(data_frame, 'Business_Address')),
                        state = postprocessor.modify_state(municipality['state']),
                        city = municipality['city'].upper(),
                        zip_code = municipality['zipcode'],
                        home_phone = postprocessor.clean_home_phone(
                            postprocessor.get_df_value(data_frame, 'Business_Home_Phone')),
                        name_coord = name_coord,  
                        add_coord = add_coord ,
                        phone_coord = phone_coord,
                        state_city_zip_coord = municipality_coord
                        )
            driver = People(person_type='DRIVER')
            if owner_list_length:
                owner_list = postprocessor.compare_name(person,
                                owner_list, driver, owner_list_length)[1]
        owner_list = sorted(owner_list, key=lambda v: v.Unit_Number)
    except:
        pass
    return owner_list

def get_people_list(data_frame, business_name_lookup_path, city_lookup_path):
    """
    Return People List
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path
    Returns:
        list: people list
    """
    #Modified function to extract coordinates
    owner_list, driver_list = [], []
    try:
        d_frames_list = get_information(data_frame, 'people')
        owner_list = get_owner_list(data_frame, business_name_lookup_path, city_lookup_path)
        owner_list_length = len(owner_list)
        driver_list = [0] * owner_list_length
        people_count = postprocessor.get_count(data_frame, 'people')
        for index in range(people_count):
            d_frame = d_frames_list[index]
            person_type, name = postprocessor.get_person_type_name(
                postprocessor.get_df_value(d_frame, 'Person_Name'))
            if not person_type and not name:
                continue

            municipality_coord = get_df_value_coord(d_frame, 'City_State_Zip')
            add_coord = get_df_value_coord(d_frame, 'Address')
            phone_coord = get_df_value_coord(d_frame, 'Home_Phone')
            name_coord =  get_df_value_coord(d_frame, 'Person_Name')
            dob_coord = get_df_value_coord(d_frame, 'Date_Of_Birth')

            name = postprocessor.process_name(name,
                                    business_name_lookup_path)
            municipality = postprocessor.process_labels(
                postprocessor.get_df_value(d_frame, 'City_State_Zip'))
            municipality = postprocessor.name_address_split(
                municipality, city_lookup_path)
            address = postprocessor.process_labels(
                postprocessor.get_df_value(d_frame, 'Address'))
            apartment = postprocessor.process_labels(
                postprocessor.get_df_value(d_frame, 'Apartment'))
            if apartment:
                address = address + ' ' + apartment
                add_coord = get_address_coord(d_frame, 'Address','Apartment')

            person = People(
                        unit_number = postprocessor.get_serial_number(
                                postprocessor.get_df_value(d_frame, 'Person_Name')),
                        person_type = person_type,
                        first_name = name['first_name'],
                        middle_name = name['middle_name'],
                        last_name = name['last_name'],
                        suffix = name['suffix'],
                        address = address,
                        state = postprocessor.modify_state(municipality['state']),
                        city = municipality['city'].upper(),
                        zip_code = municipality['zipcode'],
                        date_of_birth = postprocessor.get_crash_date_time(
                                postprocessor.get_df_value(d_frame, 'Date_Of_Birth'), False)[0],
                        home_phone = postprocessor.clean_home_phone(
                            postprocessor.get_df_value(d_frame, 'Home_Phone')),
                        name_coord = name_coord,
                        add_coord = add_coord,
                        phone_coord = phone_coord,
                        state_city_zip_coord = municipality_coord,
                        dob_coord = dob_coord
                        )
            driver = People(person_type='DRIVER')
            if people_count and not owner_list_length:
                if people_count == 1 or (people_count != 1 and person.Person_Type == 'VICTIM'):
                    person.Person_Type = 'VEHICLE OWNER'
                    person.Unit_Number = '1'
                    postprocessor.delete_invalid_keys(person)
                    driver.Unit_Number = '1'
                    driver_list.extend([person, driver])
            else:
                driver_list, owner_list = postprocessor.compare_name(person,
                                owner_list, driver_list, owner_list_length)
        if not people_count:
            owner_list.append(People(person_type = 'VEHICLE OWNER'))
            driver_list.append(People(person_type = 'DRIVER'))
                 
    except:
        pass
    return driver_list, owner_list


def people_extraction(data_frame, business_name_lookup_path, city_lookup_path):
    """
    This function assigns party_id to the final people list
    This also creates empty driver if vehicle owner does not already have driver
    associated with it.
    Args:
        d_frame (dataframe): Predicted Dataframe
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path
    Returns:
        list: final people list
    """
    people_list = []
    try:
        driver_list, owner_list = get_people_list(data_frame,
                                        business_name_lookup_path, city_lookup_path)
        for owner in owner_list:
            postprocessor.delete_invalid_keys(owner)
        for index, driver in enumerate(driver_list):
            if not driver:
                driver = People(person_type='DRIVER')
                driver.Unit_Number = str(index+1)
                driver_list[index] = driver       
        people_list = postprocessor.merge_lists(owner_list, driver_list)
        for p_id, person in enumerate(people_list):
            person.Party_Id = str(p_id+1)
     
    except:
        pass
    return people_list

class Vehicle():
    """
    Class defining Vehicle
    """
    def __init__(self, unit_number='', make='', model='', vin = '', model_year='',
        license_plate='', registration_state='', insurance_company='', policy_number='',
        expiration_date='', vehicle_towed=''):
        """
        Initialize the Vehicle objects

        Args:
            unit_number (str, optional): unit_number. Defaults to ''.
            make (str, optional): make. Defaults to ''.
            vin (str, optional): vin. Defaults to ''.
            model_year (str, optional): model_year. Defaults to ''.
            license_plate (str, optional): license_plate. Defaults to ''.
            registration_state (str, optional): registration_state. Defaults to ''.
            insurance_company (str, optional): insurance_company. Defaults to ''.
            damaged_areas (str, optional): damaged_areas. Defaults to ''.
        """
        self.Unit_Number = unit_number
        self.License_Plate = license_plate
        self.Registration_State = registration_state
        self.VIN = vin
        self.VinValidation_VinStatus = ''
        self.Model_Year = model_year
        self.Make = make
        self.Model = model
        self.Insurance_Company = insurance_company
        self.Insurance_Policy_Number = policy_number
        self.Insurance_Expiration_Date = expiration_date
        self.Vehicle_Towed = vehicle_towed
        self.Air_Bag_Deployed = ''
        self.Damaged_Areas = ''
        self.Contributing_Circumstances_Vehicle = ''
        self.Posted_Statutory_SpeedLimit = ''

def vehicle_extraction(data_frame, city_lookup_path):
    """
    Passes Vehicle data to the Vehicle Class
    Args:
        d_frame (DataFrame): Predicted DataFrame
    Returns:
        List : Vehicle List
    """
    vehicle_list = []
    try:     
        d_frames_list = get_information(data_frame, 'vehicle')
        vehicle_count = postprocessor.get_count(data_frame, 'vehicle')
        for index in range(vehicle_count):
            d_frame = d_frames_list[index]
            vin_coord =  get_df_value_coord(d_frame, 'VIN')
            make_model_coord =  get_df_value_coord(d_frame, 'Make_Model')
            model_year_coord =  get_df_value_coord(d_frame, 'Model_Year')
            license_plate_coord =  get_df_value_coord(d_frame, 'License_Plate')
            registration_state_coord =  get_df_value_coord(d_frame, 'Registration_State')
            vehicle_towed_coord =  get_df_value_coord(d_frame, 'Vehicle_Towed')
            insurance_company_coord =  get_df_value_coord(d_frame, 'Insurance_Company')
            policy_number_coord =  get_df_value_coord(d_frame, 'Policy_Number')
            expiration_date_coord =  get_df_value_coord(d_frame, 'Insurance_Expiration_Date')
            
            vehicle = Vehicle(
                        unit_number = str(index+1),
                        vin = vin_coord,
                        make = make_model_coord,
                        model = make_model_coord,
                        model_year = model_year_coord,
                        license_plate = license_plate_coord,
                        registration_state = registration_state_coord,
                        insurance_company = insurance_company_coord,
                        policy_number = policy_number_coord,
                        expiration_date = expiration_date_coord,
                        vehicle_towed = vehicle_towed_coord
                        )
            vehicle_list.append(vehicle)
        if not vehicle_list:
            vehicle_list.append(Vehicle(unit_number = '1'))
    except:
        pass
    return vehicle_list

class Citation():
    """
    Class defining Citation
    """
    def __init__(self, party_id='', citation_detail=''):
        """
        Initialize the Vehicle objects
        Args:
            party_id (str, optional): party_id. Defaults to ''.
            citation_detail (str, optional): citation_detail. Defaults to ''.
        """
        self.Party_Id = party_id
        self.Citation_Detail = citation_detail
        self.Violation_Code = ''

def citation_extraction(data_frame, people_list):
    """
    Passes Citation data to the Citation Class
    Args:
        d_frame (DataFrame): Predicted DataFrame
    Returns:
        List : Citation List
    """
    citation_list = []
    try:
        d_frames_list = postprocessor.get_information(data_frame, 'people')
        people_count = postprocessor.get_count(data_frame, 'people')
        for index in range(people_count):
            d_frame = d_frames_list[index]
            serial_number = postprocessor.get_serial_number(
                postprocessor.get_df_value(d_frame, 'Person_Name'))
            offense_list = postprocessor.get_offense(d_frame, 'Offense')
            for offense in offense_list:
                citation_detail = [{'Code': '', 'Description':offense}]
                citation = Citation(
                            party_id = str(int(serial_number)+1),
                            citation_detail = citation_detail
                        )
                citation_list.append(citation)
        citation = Citation()
        citation_list = postprocessor.get_final_citation(citation_list, people_list, citation)
    except:
        pass
    return citation_list

class Report():
    """
    Class defining Report
    """
    def __init__(self, form_name, count_keyed, incident, people, vehicles, citations, form_type):
        """
        Initialize the Report objects

        Args:
            form_name (str): form_name
            count_keyed (str): count_keyed
            incident (List): incident
            people (List): people
            vehicles (List): vehicles
            citations (List): citations
        """
        self.FormName = form_name
        self.CountKeyed = count_keyed
        self.Incident = incident
        self.People = people
        self.Vehicles = vehicles
        self.Citations = citations
        self.Form_Type = form_type

class MainCls():
    """
    Class: Defines MainCls
    """
    def __init__(self, report):
        """
        Initialize the MainCls objects

        Args:
            report (class): report
        """
        self.Report = report

def modify_people(people):
    try:
        people.First_Name = people.Name_Coord
        people.Middle_Name = people.Name_Coord
        people.Last_Name = people.Name_Coord
        people.Name_Suffix = people.Name_Coord
        people.Address = people.Address_Coord
        people.State = people.State_City_Zip_Coord
        people.City = people.State_City_Zip_Coord
        people.Zip_Code = people.State_City_Zip_Coord
        people.Home_Phone = people.Phone_Coord
        people.Date_Of_Birth = people.DOB_Coord
        del people.Name_Coord
        del people.Address_Coord
        del people.State_City_Zip_Coord
        del people.Phone_Coord
        del people.DOB_Coord
    except:
        pass         

def json_convertion_coordinate(text_extracted_df, form_type, business_name_lookup_path, city_lookup_path):
    """
    Function to form json from the predicted DataFrame

    Args:
        text_extracted_df (DataFrame): Predicted DataFrame
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path

    Returns:
        JSON: Json data created from predicted DataFrame
    """
    try:
        incident_report = incident_extraction(text_extracted_df)

        people_list = people_extraction(text_extracted_df,city_lookup_path,
                    business_name_lookup_path)
        for people in people_list:
            modify_people(people)                

        vehicle_list = vehicle_extraction(text_extracted_df, city_lookup_path)

        citation_list = citation_extraction(text_extracted_df, people_list)

        if (incident_report or people_list or vehicle_list or citation_list):
            tif_name = (text_extracted_df['path'][0].split("_")[0]) + '_CO.tif'
            report = Report(form_name = 'Universal',
                            count_keyed = '',
                            incident = incident_report,
                            people = people_list,
                            vehicles = vehicle_list,
                            citations = citation_list,
                            form_type = ('CO_'+ form_type))
            main_cls = MainCls(report = report)
            return main_cls, tif_name
    except:
        pass
    return sys.exc_info(), 'error'
