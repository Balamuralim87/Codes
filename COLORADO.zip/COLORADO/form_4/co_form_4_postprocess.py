"""
Created on 20/04/2023

@author: e407841: Aarushi Gupta
"""

import re
from datetime import datetime
from copy import deepcopy
import pandas as pd
from fuzzywuzzy import fuzz, process

from COLORADO.config import Config
from COLORADO.name_address_split import name_split_using_pattern, name_address_split_using_lookup

def get_predefined_labels(key):
    """
    Function holds predefined labels for Incident, People and Vehicle
    Args:
        key (str): Key of predefined_labels
    Returns:
        List: Value of predefined_labels
    """
    try:
        return Config.FORM_4_PREDEFINED_LABELS[key]
    except:
        pass
    return []

def get_df_value(d_frame, label_name, index=0):
    """
    Function retrive value from df (predicted dataframe) based on label_name and index
    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.
    Returns:
        str: Value from df (predicted dataframe)
    """
    try:
        data_df = d_frame.loc[d_frame['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            value = data_df['text'].iloc[index]
            if str(value) != 'nan':
                return value.strip()
    except:
        pass
    return ''

def get_case_identifier(text):
    """
    Process the case Identifier
    Args:
        text (str): case Identifier
    Returns:
        str: case Identifier
    """
    try:
        if text:
            text = text.replace('#', '')
    except:
        pass
    return text.strip()

def get_crash_date_time(text, is_expiration = False):
    """
    Extracts the crash date and time
    Args:
        text (str): crash date and time
        is_expiration (boolean): This is set True only when dealing with expiration date
    Returns:
        str, str: crash date and time
    """
    date, time = '', ''
    try:
        match_str = re.findall(r'\w{3,}-\d{2}-\d{4}', text)
        if is_expiration:
            date = match_str[0]
        else:
            date = datetime.strptime(match_str[0], '%b-%d-%Y').strftime('%m/%d/%Y')
        if match_str:
            text = text.replace(match_str[0], '')
        else:
            date = ''
        time = re.findall(r'\d{3,4}', text)
        if time:
            time = (time[0][-4:-2]).zfill(2) + ':' + time[0][-2:]
        else:
            time = ''
    except:
        pass
    return date, time


def get_serial_number(text):
    """
    Extracts  the unit number for the vehicle/person
    Args:
        text (str): text
    Returns:
        str: serial or unit number
    """
    serial_no = '1'
    try:
        if text:
            if '#' in text:
                text_split = text.split('#')
                if len(text_split) > 2:
                    text = text_split[1]
                else:
                    text = text_split[-1]
            serial_no = re.findall(r'\d{1,2}', text)
            serial_no = serial_no[0]
    except:
        pass
    return serial_no

def process_labels(text):
    """
    Extracts values from labels removing keys/labels from the entire text
    Args:
        text (str): text
    Returns:
        str: correct value with labels removed
    """
    value = ''
    try:
        if text:
            if ':' in text:
                value = text.split(':')[-1]
            else:
                text = (text.strip(',')).text.upper()
                words = ["ADDRESS", "APARTMENT", "MUNICIPALITY", "TOWED",
                        "OWNER", "NAME", "MAKE", "MODEL", "YEAR", "INSURANCE",
                        "OFFENSE"]
                similarity_scores = {}
                for word in text.split():
                    similarity_scores[word] = process.extractOne(word, words,
                                                scorer=fuzz.token_sort_ratio)
                for word, score in similarity_scores.items():
                    if score[1] >= 80:
                        value = text.replace(word, score[0])
                        value = text.replace(score[0], '')
            if not value and text:
                value = text
            value = value.replace('#', '')
            value = value.upper()
    except:
        pass
    return value.strip()

def split_location(text):
    """
    This function splits the address into loss street and loss cross street
    Args:
        text (str): case Identifier
    Returns:
        str, str: loss street, loss cross street
    """
    loss_street, cross_street = '', ''
    try:
        if text:
            if '/' in text:
                text_split = text.split('/')
                loss_street = text_split[0].strip()
                cross_street = text_split[-1].strip()
            else:
                loss_street = text.strip()
                cross_street = ''
    except:
        pass
    return loss_street.upper(), cross_street.upper()

def name_address_split(text, city_lookup_path):
    """
    Returns Address, City, State, Zipcode
    Args:
        text (str): text
        city_lookup_path (str): city_lookup_path
    Returns:
        dict: address
    """
    name_add_dict = {'name': '', 'address': '', 'city': '', 'state': '', 'zipcode': ''}
    try:
        text = re.sub(r'[^A-Za-z0-9 ]', '', text)
        name_add_match = name_address_split_using_lookup(text, city_lookup_path)
        name_add_dict['name'] = name_add_match['names'].upper()
        name_add_dict['address'] = name_add_match['address'].upper()
        name_add_dict['city'] = name_add_match['city'].upper()
        name_add_dict['state'] = name_add_match['state'].upper()
        name_add_dict['zipcode'] = name_add_match['zipcode'].upper()
    except:
        pass
    return name_add_dict


def get_person_type_name(text):
    """
    This function splits the text into name and person type
    Args:
        text (str): text(person details)
    Returns:
        str, str: person type, name
    """
    name, person_type = '', ''
    try:
        if '#' in text:
            person_type = text.split('#')[0]
        else:
            serial_no = re.findall(r'\d{1,}', text)
            serial_no = serial_no[0]
            person_type = text.split(serial_no)[0]
        name = text.replace(person_type, '')
        name = (re.sub(r'[^A-Za-z- ]', '', name)).strip()
        name = name.strip('-')
        person_type = re.sub(r'[^A-Za-z ]', '', person_type)
    except:
        pass
    return person_type.strip(), name.strip()

def clean_home_phone(text):
    """
    Cleans the Home phone text
    Args:
        text (str): text
    Returns:
        str: updated text
    """
    try:
        text = '-'.join(re.sub('[^0-9]+', ' ', text).split())
    except:
        pass
    return text

def get_information(d_frame, label):
    """
    This function creates separate dataframe for each person alond with
    individual person details and return list of all such dataframes
    Args:
        d_frame (DataFrame): original dataframe
        label (str): label(person or vehicle)
    Returns:
        list: dataframe list
    """
    df_list = []
    try:
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])
        if label == 'people':
            index_numbers = list(data_df['label'].loc[lambda x: x=='Person_Name'].index)
        elif label == 'vehicle':
            if 'Vehicle' in list(data_df['label'].unique()):
                index_numbers = list(data_df['label'].loc[lambda x: x=='Vehicle'].index)
            else:
                index_numbers = list(data_df['label'].loc[lambda x: x=='License_Plate'].index)
        len_index = len(index_numbers)
        for index in range(len_index):
            if len_index == 1:
                data_df_new = data_df.loc[index_numbers[0]:]
            elif index_numbers[index] == index_numbers[-1]:
                data_df_new = data_df.loc[index_numbers[index]:]
            else:
                data_df_new = data_df.loc[index_numbers[index]:index_numbers[index+1]]
            df_list.append(data_df_new)
    except:
        pass
    return df_list


def compare_name(person, owner_list, driver_list, owner_list_length):
    """
    This function compare owner names with the given person 
    If it matches then chnages in people and owner lists are made accordingly
    Args:
        person (class object): current person which needs to be compared
        owner_list (list): owner_list
        driver_list (list): people_list
        owner_list_length (int): length of initial owner list
    Returns:
        list: modified driver_list
        list: modified owner_list
    """
    final_score = 0
    try:
        p_name = person.First_Name + person.Last_Name + person.Middle_Name
        person_type = person.Person_Type
        p_unit_number = int(person.Unit_Number)
        for index, owner in enumerate(owner_list):
            o_name = owner.First_Name + owner.Last_Name + owner.Middle_Name
            score = fuzz.ratio(o_name, p_name)
            if score >= 80 or (p_name in o_name):
                final_score = score
                if 'SUMMONS' in person_type and (p_unit_number == int(owner.Unit_Number)):
                    owner = deepcopy(person)
                    owner.Person_Type = 'VEHICLE OWNER'
                    person.Person_Type = 'DRIVER'
                    person.Same_As_Driver = 'Y'
                    owner_list[index] = owner
                    driver_list[(p_unit_number-1)] = person
                else:
                    owner = deepcopy(person)
                    owner.Person_Type = 'VEHICLE OWNER'
                    owner_list[index] = owner
                    if person.Person_Type != 'BUSINESS OWNER':
                        person.Same_As_Driver = 'Y'
        if 'DRIV' in person_type and (p_unit_number <= owner_list_length):
            person.Person_Type = 'DRIVER'
            driver_list[(p_unit_number-1)] = person
        elif person_type == 'COMPLAINANT' and not final_score:
            person.Person_Type = 'WITNESS'
            person.Unit_Number = ''
            driver_list.append(person)
        elif 'SUMMON' in person_type and not final_score:
            person.Person_Type = 'DRIVER'
            driver_list[(p_unit_number-1)] = person
    except:
        pass
    return driver_list, owner_list


def modify_state(text):
    """
    This function return the abbrevations for full state names
    Args:
        text (str): value of registration state
    Returns:
        str: abbrevation of the state
    """
    try:
        text = text.upper()
        state_with_code = Config.STATE_WITH_CODE
        keys_list = list(state_with_code.keys())
        if text in keys_list:
            text = state_with_code.get(text, '')
    except:
        pass
    return text.strip()

def get_count(d_frame, key):
    """
    Returns count of the given key
    Args:
        d_frame (dataframe): d_frame
        key (str): key
    Returns:
        int: Total count
    """
    max_count = 0
    try:
        labels = get_predefined_labels(key)
        for label in labels:
            count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                (label.lower())) & (d_frame['text'].str.strip()), 'label'])
            max_count = max(max_count, count)
    except:
        pass
    return max_count

def get_business_name(text, business_name_lookup_path):
    """
    Check given name is business name or not
    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        bool: business name or not
    """
    try:
        business_name_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', text).split())
        with open(business_name_lookup_path,encoding='utf-8', errors='ignore') as file:
            business_name_lookup = file.readlines()
            business_name_lookup = [x.strip() for x in business_name_lookup]
        file.close()
        business_names = '|'.join(business_name_lookup)
        business_name_match = re.search(r'((\s|,)(' + business_names + r')(\s|,)?)$',
            business_name_text, re.IGNORECASE)
        if business_name_match:
            return True
    except:
        pass
    return False

def process_name(text, business_name_lookup_path):
    """
    Returns Person Name
    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path
    Returns:
        str: Person Name
    """
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    try:
        text = re.sub('[^A-Za-z- ]', '', text)
        text = text.lower().replace('name', '').split(':')[-1].strip()
        is_business_name = get_business_name(text, business_name_lookup_path)
        if not is_business_name:
            add_dict = name_split_using_pattern(text, business_name_lookup_path, 'LFM')
            add_dict['first_name'] = add_dict['first_name'].upper()
            add_dict['middle_name'] = add_dict['middle_name'].upper()
            add_dict['last_name'] = add_dict['last_name'].upper()
            add_dict['suffix'] = add_dict['suffix'].upper()
        else:
            text = text.replace(',', '')
            add_dict['last_name'] = text.upper()
    except:
        pass
    return add_dict


def delete_invalid_keys(people):
    """
    Deletes keys that not required from class
    Args:
        people (class): People
    """
    try:
        del people.Alcohol_Use_Suspected
        del people.Marijuana_Use_Suspected
        del people.Drug_Use_Suspected
        del people.Contributing_Circumstances_Person
        del people.Non_Motorist_Actions_At_Time_Of_Crash
        del people.Safety_Equipment_Restraint
        del people.Safety_Equipment_Available_Or_Used
        del people.Safety_Equipment_Helmet
        del people.Ejection
    except:
        pass

def merge_lists(list1, list2):
    """
    This function merge two lists in alternate manner
    Args:
        list1 (list): first list
        list2 (list): second list
    Returns:
        list: merged list
    """
    merged_list = []
    try:
        if len(list1) != len(list2):
            shorter_list_length = min(len(list1), len(list2))
        else:
            shorter_list_length = len(list1)
        for i in range(shorter_list_length):
            merged_list.append(list1[i])
            merged_list.append(list2[i])
        if len(list1) < len(list2):
            merged_list.extend(list2[shorter_list_length:])
    except:
        pass
    return merged_list

def get_make_model(text):
    """
    This function extracts make and model from the text
    Args:
        text (str): text containing vehicle information
    Returns:
        str, str: make, model
    """
    make, model = '', ''
    try:
        if text:
            text = text.strip("and")
            text.replace(":", '')
            make = (text.strip()).split()[0]
            if make:
                text = text.replace(make, '')
            model = text.strip()
    except:
        pass
    return make.upper(), model.upper()

def get_vin_plate_number(text):
    """
    This function extracts vin, license and policy number from the text
    Args:
        text (str): text containing vehicle information
    Returns:
        str: correct value
    """
    value = ''
    try:
        if text:
            text_split = text.split()
            for word in text_split:
                if word.isalnum() and not word.isalpha() or '-' in word:
                    value = word.strip()
                    break
    except:
        pass
    return value.upper()

def vehicle_towed(text):
    """
    This function returns value depending on vehicle towed text
    Args:
        text (str): text from vehicle towed
    Returns:
        str: vehicle towed value
    """
    towed = ''
    try:
        if text:
            text = text.upper()
            if text == 'NO':
                towed = '0'
            elif text == 'YES':
                towed = '1'
    except:
        pass
    return towed

def get_offense(d_frame, label_name):
    """
    This function extracts all offenses for individual driver in the form of list
    Args:
        d_frame (DataFrame): dataframe for individual person
        label_name (str): label name for the offense
    Returns:
        list: list with all the offenses
    """
    offense_list = []
    try:
        data_df = d_frame.loc[d_frame['label'].str.lower()==(label_name.lower()),
                ['label', 'text']]

        if len(data_df) > 0:
            for offense in list(data_df['text']):
                offense = process_labels(offense)
                offense_list.append(offense)
    except:
        pass
    return offense_list

def get_final_citation(citation_list, people_list, empty_citation):
    """
    This function returns the final citation list 
    Args:
        citation_list (list): incomplete citation list
        people_list (list): final people list
        empty_citation (class object): empty citation needed depending on driver length
    Returns:
        list: final citation list
    """
    try:
        party_ids, new_list = [], []
        for citation in citation_list:
            party_ids.append(citation.Party_Id)
        for person in people_list:
            if person.Person_Type == 'DRIVER' and person.Party_Id not in party_ids:
                citation = deepcopy(empty_citation)
                citation.Party_Id = person.Party_Id
                citation.Citation_Detail = ''
                new_list.append(citation)
        citation_list= citation_list + new_list
        citation_list = sorted(citation_list, key=lambda v: v.Party_Id)
    except:
        pass
    return citation_list
