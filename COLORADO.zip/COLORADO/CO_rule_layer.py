import re


def rule_layer_main(df):
    img_list = df['path'].unique().tolist()
    img_list.sort()  # 28 July 2020
    group_df = df.groupby('path')

    for img in img_list:

        temp_df = group_df.get_group(img)
        temp_df = temp_df.sort_values(by='ymin')

        UnitNumList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), temp_df['label']))
        # Model not able to identify the UnitNumber block
        if len(UnitNumList) == 1:
            if UnitNumList[0] == 'UnitNum1':
                text = ''
                try:
                    if temp_df['page_no'][0] == '1': text = '2'
                    elif temp_df['page_no'][0] == '2': text = '4'
                except:
                    pass
                if text != '':
                    new_row = {'path': temp_df['path'].values[0], 'page_no': temp_df['page_no'].values[0],
                               'xmin': '0',
                               'ymin': '0',
                               'xmax': '0', 'ymax': '0', 'label': 'UnitNum2', 'text': text}
                    df = df.append(new_row, ignore_index=True)

            elif UnitNumList[0] == 'UnitNum2':
                text = ''
                try:
                    if temp_df['page_no'][0] == '1': text = '1'
                    elif temp_df['page_no'][0] == '2': text = '3'
                except:
                    pass

                if text != '':
                    new_row = {'path': temp_df['path'].values[0], 'page_no': temp_df['page_no'].values[0],
                               'xmin': '0',
                               'ymin': '0',
                               'xmax': '0', 'ymax': '0', 'label': 'UnitNum1', 'text': text}
                    df = df.append(new_row, ignore_index=True)

    return df