import os
import xml.etree.ElementTree as ET

import pandas as pd
from tqdm import tqdm
import cv2

import COLORADO.preproceesor as preproceesor
import COLORADO.common_util as common_util
from COLORADO import text_extract

def __str_replace_xml(xml_str):
    xml_str=xml_str.replace('http://www.w3.org/1999/xhtml','')
    xml_str=xml_str.replace('❑','')
    xml_str=xml_str.replace('•','')
    xml_str=xml_str.replace('■','')
    return xml_str

def separate_key_value(add_list, text):
    """
    Function to seperate labels from text(key-value) from single text
    according to the coordinates of each word in the text
    Args:
        add_list (list): list of all sorted extracted information
        text (str): actual text which has both key and value
    Returns:
        str: final text with label name separated
    """
    new_text = ''
    try:
        first_ymin = add_list[0][1]
        key_name = [add_list[0][2]]
        for word in add_list[1:]:
            y_min = word[1]
            if abs(first_ymin - y_min) <=4:
                key_name.append(word[2])
        final_label = ' '.join(key_name)
        new_text = (text.replace(final_label, '')).strip()
    except:
        pass
    return new_text

def split_text(add_list, space):
    try:
        if add_list:
            ymin = add_list[0][1]
            top_words = ' '.join([x[2] for x in add_list if x[1] <= ymin + space])
            bottom_words = ' '.join([x[2] for x in add_list if x[1] >= ymin + space])
            return top_words + ' \n ' + bottom_words
    except:
        pass
    text_list = [x[2] for x in add_list]
    text = ' '.join(text_list)
    return text


def content_extraction(p_df, xml_out_path, form_type, tif_file_name, check_box_model):
    try:
        d_frame = p_df
        d_frame['filename'] = d_frame['filename'].apply(lambda x: x.replace('.tif',''))

        d_frame['xmin'] = d_frame['xmin']*d_frame['img_width']
        d_frame['ymin'] = d_frame['ymin']*d_frame['img_height']
        d_frame['xmax'] = d_frame['xmax']*d_frame['img_width']
        d_frame['ymax'] = d_frame['ymax']*d_frame['img_height']

        d_frame = d_frame[['filename','xmin','ymin','xmax','ymax','label', 'img_width',
            'img_height']]
        d_frame['image_path'] = d_frame['filename'].apply(lambda x: x.split('.')[0]+ '.jpg')

        img_list = d_frame['image_path'].unique().tolist()
        group_df = d_frame.groupby('image_path')

        temptext_df_final = pd.DataFrame()

        img_width = list(d_frame['img_width'])[0]
        img_height = list(d_frame['img_height'])[0]

        output_jpg_dir = os.path.join(xml_out_path ,'jpg')
        if not os.path.exists(output_jpg_dir):
            os.makedirs(output_jpg_dir)
        preproceesor.tiff_to_jpg(tif_file_name, output_jpg_dir)

        for img in tqdm(img_list):
            tmpdf = group_df.get_group(img)
            inner_img_list = tmpdf['filename'].unique().tolist()
            inner_group_df = tmpdf.groupby('filename')
            data_list = []

            for inner_img in inner_img_list:
                xml_name = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
                xml_str = open(xml_name, 'r', encoding = 'utf-8').read()
                upd_xml_str = __str_replace_xml(xml_str)
                xml_tree = ET.XML(upd_xml_str)
                page_list = xml_tree.findall('.//page')
                page_height = page_list[0].attrib['height']
                centre = round((d_frame['img_height'][0])/float(page_height), 2)

                temp_df = inner_group_df.get_group(inner_img)

                image = cv2.imread(os.path.join(output_jpg_dir, img))

                for _, row1 in temp_df.iterrows():
                    bb_xmin = int(row1.xmin)
                    bb_ymin = int(row1.ymin)
                    bb_xmax = int(row1.xmax)
                    bb_ymax = int(row1.ymax)

                    text_list = []
                    text = ''

                    bb_coord=(bb_xmin,bb_ymin,bb_xmax,bb_ymax)
                    if form_type == 'form_type_2':
                        if row1.label in ['Hit_and_Run', 'V_Owner_Name_Same_as_Driver',
                                          'V_Owner_Address_Same_as_Driver', 'No_Damage',
                                          'Parked']:
                            text = common_util.detect_check_box(image, bb_xmin, bb_ymin,
                                                                bb_xmax, bb_ymax,
                                                                check_box_model)
                        elif row1.label in ['Passenger_1', 'Passenger_2', 'Passenger_3']:
                            add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                            add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                            text = split_text(add_list, 5)
                        elif row1.label == 'narrative_new':
                            add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                            add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                            text_list = [x[2] for x in add_list]
                            text = ' '.join(text_list)
                        else:
                            add_list = text_extract.find_text(xml_tree, bb_coord, centre)
                            add_list = sorted(add_list, key=lambda x: x[0])
                            text_list = [x[1] for x in add_list]
                            text = ' '.join(text_list)
                    elif ((form_type == 'form_type_3') and row1.label in ['Vehicle_Owner_Address',
                        'Victim_Address', 'Crash_Location','Victim_First_Name',
                        'Victim_Mid_Name','Victim_Last_Name','Vehicle_Owner_First_Name',
                        'Vehicle_Owner_Mid_Name','Vehicle_Owner_Last_Name']):
                        add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                        add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                        text_list = [x[2] for x in add_list]
                        text = ' '.join(text_list)
                    elif form_type == 'form_type_4' and row1.label == 'Offense':
                        add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                        add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                        text_list = [x[2] for x in add_list]
                        text = ' '.join(text_list)
                    elif ((form_type == 'form_type_5') and (row1.label not in ['Case_Identifier',
                                    'Person_Type', 'Event_Info_Incident_Report'])):
                        add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                        add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                        text_list = [x[2] for x in add_list]
                        text = ' '.join(text_list)
                        text = separate_key_value(add_list, text)
                    elif row1.label == 'narrative_new':
                        add_list = text_extract.find_text(xml_tree, bb_coord, centre, True)
                        add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                        text_list = [x[2] for x in add_list]
                        text = ' '.join(text_list)
                    else:
                        add_list = text_extract.find_text(xml_tree, bb_coord, centre)
                        add_list = sorted(add_list, key=lambda x: x[0])
                        text_list = [x[1] for x in add_list]
                        text = ' '.join(text_list)

                    data_list.append((row1.filename, int(row1.xmin), int(row1.ymin), int(row1.xmax),
                        int(row1.ymax), row1.label, text, img_width, img_height))

                temptext_df = pd.DataFrame(data_list, columns = ['path', 'xmin', 'ymin', 'xmax',
                    'ymax', 'label', 'text', 'img_width', 'img_height'])
                temptext_df['page_no'] = temptext_df['path'].apply(lambda x: 'page_no_' +x[-1])
                temptext_df.sort_values(by = ['path'], inplace = True, ascending = True)
                # temptext_df_final = temptext_df_final.append(temptext_df, ignore_index = True)
                temptext_df_final = pd.concat([temptext_df_final,temptext_df], ignore_index = True)


        return temptext_df_final
    except Exception as error:
        print(error)
