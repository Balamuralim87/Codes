# -*- coding: utf-8 -*-
"""
Created on Wed Feb 18 19:01:30 2019

@author: Priyanga

This script is a utility to convert model predicted data to JSON format.
"""

from typing import List
import json
import re
import os
import COLORADO.same_as_name_address_checker as same_as_name_address_checker
import COLORADO.CO_xml_patch as xml_patcher
import COLORADO.CO_patch as patcher

page_df = None

class Violation_Code(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class TransportedTo(object):
    def __init__(self, unit_num:str, prsn_num: str, transported_to: str):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.transported_to = transported_to

class CitationsDetails(object):
    def __init__(self, unit_num:str, prsn_num: str, Citation_Detail: str, Violation_Code: Violation_Code):
        self.unit_num = unit_num
        self.prsn_num = prsn_num
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code

class ContributingFactorDetails(object):
    def __init__(self, unit_num: str, Contributing_Factors: List):
        self.unit_num = unit_num
        self.Contributing_Factors = Contributing_Factors

class Transported_To(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Ejection(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Weather_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Photographs_Taken(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Road_Surface_Condition(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Restraint(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Available_Or_Used(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Safety_Equipment_Helmet(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Alcohol_Use_Suspected(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Marijuana_Use_Suspected(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Drug_Use_Suspected(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Contributing_Circumstances_Person(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Contributing_Circumstances_Vehicle(object):
    def __init__(self, Code: str, Description: str):
        self.Code = Code
        self.Description = Description

class Citations(object):
    def __init__(self, Unit_Number: str, Party_Id: str, Citation_Detail: str, Violation_Code: List[Violation_Code]):
        self.Unit_Number = Unit_Number
        self.Party_Id = Party_Id
        self.Citation_Detail = Citation_Detail
        self.Violation_Code = Violation_Code

class Incident(object):
    def __init__(self, Crash_Date: str, Case_Identifier: str, State_Report_Number: str, Crash_City: str,
                 Loss_Street: str, Loss_Cross_Street: str, Latitude: str, Longitude: str, Loss_State_Abbr: str,
                Report_Type_Id:str, Gps_Other:str, Weather_Condition: List[Weather_Condition],
                 Road_Surface_Condition: List[Road_Surface_Condition], Photographs_Taken: str):
        self.Crash_Date = Crash_Date
        self.Case_Identifier = Case_Identifier
        self.State_Report_Number = State_Report_Number
        self.Crash_City = Crash_City
        self.Loss_Street = Loss_Street
        self.Loss_Cross_Street = Loss_Cross_Street
        self.Latitude = Latitude
        self.Longitude = Longitude
        self.Loss_State_Abbr = Loss_State_Abbr
        self.Report_Type_Id = Report_Type_Id
        self.Gps_Other = Gps_Other
        self.Weather_Condition = Weather_Condition
        self.Road_Surface_Condition = Road_Surface_Condition
        self.Photographs_Taken = Photographs_Taken

class Report(object):
    def __init__(self, FormName: str, CountKeyed: int, Incident: Incident, People: List, Vehicles: List, Citations: List , form_type :str):
        self.FormName = FormName
        self.CountKeyed = CountKeyed
        self.Incident = Incident
        self.People = People
        self.Vehicles = Vehicles
        self.Citations = Citations
        self.Form_Type = form_type
        

class People(object):
    def __init__(self, Party_Id: str, Person_Type: str, Unit_Number: str, First_Name: str, Middle_Name: str, Last_Name: str,
                 Name_Suffix: str, Address:str, Address2:str, City:str, State:str, Zip_Code: str, Home_Phone: str,
                 Date_Of_Birth: str, Drivers_License_Number: str, Drivers_License_Jurisdiction: str, Injury_Status:str,
                 **kwargs):
        self.Party_Id = Party_Id
        self.Person_Type = Person_Type
        self.Unit_Number = Unit_Number
        self.First_Name = First_Name
        self.Middle_Name = Middle_Name
        self.Last_Name = Last_Name
        self.Name_Suffix = Name_Suffix
        self.Address = Address
        self.Address2 = Address2
        self.City = City
        self.State = State
        self.Zip_Code = Zip_Code
        self.Home_Phone = Home_Phone
        self.Date_Of_Birth = Date_Of_Birth
        self.Drivers_License_Number = Drivers_License_Number
        self.Drivers_License_Jurisdiction = Drivers_License_Jurisdiction
        self.Injury_Status = Injury_Status
        for key in kwargs:
            setattr(self, key, kwargs[key])

class Vehicles(object):
    def __init__(self, VinValidation_VinStatus: str, Unit_Number:str, License_Plate: str, Registration_State: str, VIN:str,
                 Vehicle_Towed: str, Model_Year: str, Make: str, Model: str, Insurance_Company: str, Insurance_Policy_Number:str,
                 Insurance_Expiration_Date: str, Damaged_Areas:str, Air_Bag_Deployed:str,
                 Contributing_Circumstances_Vehicle:List[Contributing_Circumstances_Vehicle], Posted_Statutory_SpeedLimit: str):
        self.VinValidation_VinStatus = VinValidation_VinStatus
        self.Unit_Number = Unit_Number
        self.License_Plate = License_Plate
        self.Registration_State = Registration_State
        self.VIN = VIN
        self.Vehicle_Towed= Vehicle_Towed
        self.Model_Year = Model_Year
        self.Make = Make
        self.Model= Model
        self.Insurance_Company = Insurance_Company
        self.Insurance_Policy_Number=Insurance_Policy_Number
        self.Insurance_Expiration_Date=Insurance_Expiration_Date
        self.Damaged_Areas=Damaged_Areas
        self.Air_Bag_Deployed=Air_Bag_Deployed
        self.Contributing_Circumstances_Vehicle=Contributing_Circumstances_Vehicle
        self.Posted_Statutory_SpeedLimit = Posted_Statutory_SpeedLimit
        # self.Citations=Citations

class MainCls(object):
    def __init__(self, Report: Report):
        self.Report = Report

def get_inner_details(second_page_df, label_name, unit_num, prsn_num):
    if len(second_page_df) > 0:
        for i, j in second_page_df.iterrows():
            if j.label == label_name and (label_name == 'ContributingFactor' or label_name == 'VehiDefects_Contrib'):
                if j.value.unit_num == unit_num:
                    return j.value.Contributing_Factors
            elif j.label == label_name:
                if j.value.prsn_num == prsn_num and j.value.unit_num == unit_num:
                    return  j.value
    return ''
def get_checkbox_status(label_name):
    if len(page_df.loc[page_df['label'] == label_name]) > 0:
        value = page_df.loc[page_df['label'] == label_name]['text'].iloc[0]
        if str(value) == 'Checked':
            return True
        else:
            return False
    else:
        return False

def is_object_has_values(user_object):
    # if user_object.Party_Id == '' and user_object.Person_Type =='' and user_object.First_Name =='' and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == ''  and user_object.Drivers_License_Jurisdiction =='':
    if user_object.Injury_Status == '' and (user_object.First_Name == '' or user_object.Last_Name == '') and user_object.Address == '' and user_object.Date_Of_Birth == '' and user_object.Drivers_License_Number == '' and user_object.Drivers_License_Jurisdiction == '':
    # if user_object.Injury_Status == '' and (user_object.First_Name == '' or user_object.Last_Name == ''):
        return False
    else:
        return True

def person_details_extraction(people_list, party_id , people_list_coord):
    UnitNumList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), page_df['label']))
    UnitNumList.sort()
    for unit in UnitNumList:
        OwnerFlag = 1
        unit_num = re.sub(r'^((UnitNum)([0-9]))$', r'\3', unit)
        img_unit_num = get_value_from_df('UnitNum' + unit_num)
        img_unit_num = re.sub('([^0-9])', '', img_unit_num)

        is_owner_same_as_driver = get_checkbox_status('OwnerSameAsDriver' + unit_num)
        is_owner_address_as_driver = get_checkbox_status('OwnerAddressSameAsDriver' + unit_num)

        Injury_Status = ''
        Ejection_Code =''
        Safety_Equipment_Restraint_List = []
        Safety_Equipment_Available_or_Used_List = []
        Safety_Equipment_Helmet_List = []
        Ejection_List = []
        Alcohol_Use_Suspected_List =[]
        Drug_Use_Suspected_List = []
        Non_Motorist_Actions_At_Time_Of_Crash_List = []
        ContributingFactorsPeople_List = []
        # changes========================
        Injury_Status_coord = ''
        Ejection_Code_coord =''
        Safety_Equipment_Restraint_List_coord = ""
        Safety_Equipment_Available_or_Used_List_coord = ""
        Safety_Equipment_Helmet_List_coord = ""
        Ejection_List_coord = ""
        Alcohol_Use_Suspected_List_coord =""
        Drug_Use_Suspected_List_coord = ""
        Non_Motorist_Actions_At_Time_Of_Crash_List_coord = ""
        ContributingFactorsPeople_List_coord = ""
        # ===============================

        ContributingFactorsPeople = get_value_from_df('R' + unit_num)
        if re.match('^([0-9]+)$', ContributingFactorsPeople):
            if re.match('^([^0])$', ContributingFactorsPeople): 
                ContributingFactorsPeople = '0' + ContributingFactorsPeople
            ContributingFactorsPeople_List.append(Contributing_Circumstances_Person(ContributingFactorsPeople, get_value_from_df('R' + unit_num + '_desc')))
            # changes========================
            ContributingFactorsPeople_List_coord = get_value_from_df_coord('R' + unit_num)
            # ===============================

        Non_Motorist_Actions = get_value_from_df('S' + unit_num)
        if Non_Motorist_Actions != '':
            Non_Motorist_Actions_At_Time_Of_Crash_List.append(Contributing_Circumstances_Person(Non_Motorist_Actions,get_value_from_df('S' + unit_num + '_desc')))
            # changes=========================
            Non_Motorist_Actions_At_Time_Of_Crash_List_coord = get_value_from_df_coord('S' + unit_num)
            # ================================

        person_type = 'DRIVER'
        First_Name = get_value_from_df('DriverFirstName' + str(unit_num))
        Middle_Name = get_value_from_df('DriverMiddelName' + str(unit_num))
        Last_Name = get_value_from_df('DriverLastName' + str(unit_num))
        Name_Suffix = ''
        Date_Of_Birth = get_value_from_df('DriverDOB' + unit_num)
        Date_Of_Birth = date_fomat_maker(Date_Of_Birth)
        Drivers_License_Number = get_value_from_df('DriverLicenseNumber' + unit_num)
        Drivers_License_Number = Drivers_License_Number.replace(' ', '')
        Drivers_License_Jurisdiction = get_value_from_df('DriverLicenseState' + unit_num)
        Address = get_value_from_df('DriverAddress' + unit_num)
        City = get_value_from_df('DriverCity' + unit_num)
        State = get_value_from_df('DriverState' + unit_num)
        ZipCode = get_value_from_df('DriverZip' + unit_num)
        Home_Phone = get_value_from_df('DriverPhoneNumber'+ unit_num)
        Home_Phone = Home_Phone.replace('(', '')
        Home_Phone = re.sub('\)\s?', '-', Home_Phone)

        OwnerName = get_value_from_df('OwnerFirstName' + unit_num) + ' ' + get_value_from_df('OwnerMiddelName' + unit_num) \
                    + ' ' + get_value_from_df('OwnerLastName' + unit_num)
        DriverName = First_Name + ' ' + Middle_Name + ' ' + Last_Name

        # changes========================
        First_Name_coord = get_value_from_df_coord('DriverFirstName' + str(unit_num))
        Middle_Name_coord = get_value_from_df_coord('DriverMiddelName' + str(unit_num))
        Last_Name_coord = get_value_from_df_coord('DriverLastName' + str(unit_num))
        Name_Suffix_coord = ''
        Date_Of_Birth_coord = get_value_from_df_coord('DriverDOB' + unit_num)
        Drivers_License_Number_coord = get_value_from_df_coord('DriverLicenseNumber' + unit_num)
        Drivers_License_Jurisdiction_coord = get_value_from_df_coord('DriverLicenseState' + unit_num)
        Address_coord = get_value_from_df_coord('DriverAddress' + unit_num)
        City_coord = get_value_from_df_coord('DriverCity' + unit_num)
        State_coord = get_value_from_df_coord('DriverState' + unit_num)
        ZipCode_coord = get_value_from_df_coord('DriverZip' + unit_num)
        Home_Phone_coord = get_value_from_df_coord('DriverPhoneNumber'+ unit_num)

        # OwnerName = get_value_from_df('OwnerFirstName' + unit_num) + ' ' + get_value_from_df('OwnerMiddelName' + unit_num) \
        #             + ' ' + get_value_from_df('OwnerLastName' + unit_num)
        # DriverName = First_Name + ' ' + Middle_Name + ' ' + Last_Name
        # ===============================

        if is_owner_same_as_driver == False:
            if OwnerName != None:
                OwnerName = OwnerName.replace(',', '')
                OwnerName = OwnerName.replace('s ', '')

            if DriverName != '' and OwnerName != '' and OwnerName != None:
                if OwnerName.lower() == DriverName.lower():
                    is_owner_same_as_driver = True

        if DriverName == '':
            is_parked_veh = get_checkbox_status('Parked' + unit_num)
            if is_parked_veh:
                Last_Name = 'PARKED'
                Last_Name_coord = get_value_from_df_coord('Parked'+ unit_num)


        for row in range(1, 5):
            veh_occ = get_value_from_df('Unit' + str(row))
            veh_occ = veh_occ.replace('0', '')
            seat_position = get_value_from_df('Pos' + str(row))
            seat_position = seat_position.replace('0', '')
            if unit_num == veh_occ and '1' in seat_position:
                Safety_Equipment = get_value_from_df('SafetyEquip1_' + str(row))
                if Safety_Equipment != '':
                    Safety_Equipment_Restraint_List.append(Safety_Equipment_Restraint(Safety_Equipment, get_value_from_df('SafetyEquip1_' + str(row) + '_desc')))
                    # changes====================
                    Safety_Equipment_Restraint_List_coord =  get_value_from_df_coord('SafetyEquip1_' + str(row))
                    # ===========================

                Safety_Equipment_Available = get_value_from_df('SafetyEquip2_' + str(row))
                if Safety_Equipment_Available != '':
                    if re.match('^([^0])$', Safety_Equipment_Available): Safety_Equipment_Available = '0' + Safety_Equipment_Available
                    Safety_Equipment_Available_or_Used_List.append(Safety_Equipment_Available_Or_Used(Safety_Equipment_Available, get_value_from_df('SafetyEquip2_' + str(row) + '_desc')))
                    # changes====================
                    Safety_Equipment_Available_or_Used_List_coord =  get_value_from_df_coord('SafetyEquip2_' + str(row))
                    # ===========================

                Safety_Equip_Helmet = get_value_from_df('SafetyEquip3_' + str(row))
                if Safety_Equip_Helmet != '':
                    Safety_Equipment_Helmet_List.append(Safety_Equipment_Helmet(Safety_Equip_Helmet, get_value_from_df('SafetyEquip3_' + str(row) + '_desc')))
                    # changes======================
                    Safety_Equipment_Helmet_List_coord =  get_value_from_df_coord('SafetyEquip3_' + str(row))
                    # =============================

                Alcohol_Use_Susp = get_value_from_df('Alco' + str(row))
                if Alcohol_Use_Susp != '':
                    if re.match('^([0-9]+)$', Alcohol_Use_Susp) and re.match('^([^0])$', Alcohol_Use_Susp): Alcohol_Use_Susp = '0' + Alcohol_Use_Susp
                    Alcohol_Use_Suspected_List.append(Safety_Equipment_Helmet(Alcohol_Use_Susp,get_value_from_df('Alco' + str(row) + '_desc')))
                    # changes========================
                    Alcohol_Use_Suspected_List_coord =  get_value_from_df_coord('Alco' + str(row))
                    # ===============================

                Drug_Use_Susp = get_value_from_df('Drug' + str(row))
                if Drug_Use_Susp != '':
                    if re.match('^([0-9]+)$', Drug_Use_Susp) and re.match('^([^0])$', Drug_Use_Susp): Drug_Use_Susp = '0' + Drug_Use_Susp
                    Drug_Use_Suspected_List.append(Safety_Equipment_Helmet(Drug_Use_Susp, get_value_from_df('Drug' + str(row) + '_desc')))
                    # changes=========================
                    Drug_Use_Suspected_List_coord =  get_value_from_df_coord('Drug' + str(row))
                    # ================================

                Ejection_Code = get_value_from_df('Eject' + str(row))
                if Ejection_Code != '':
                    if re.match('^([^0])$', Ejection_Code): Ejection_Code = '0' + Ejection_Code
                    Ejection_List.append(Ejection(Ejection_Code, get_value_from_df('Eject' + str(row) + '_desc')))
                    # changes==========================
                    Ejection_List_coord = get_value_from_df_coord('Eject' + str(row))
                    # =================================

                Injury_Status = get_value_from_df('InjSev' + str(row))
                Injury_zero_match = re.search('^((0)([0-9]))$', Injury_Status)
                if Injury_zero_match: Injury_Status = Injury_zero_match.group(3)
                # hcnages=========================
                Injury_Status_coord = get_value_from_df_coord('InjSev' + str(row))
                # ================================

                break

        people_info = People(Party_Id=str(party_id),
                             Person_Type=person_type,
                             Unit_Number=img_unit_num,
                             First_Name=First_Name,
                             Middle_Name=Middle_Name,
                             Last_Name=Last_Name,
                             Name_Suffix=Name_Suffix,
                             Address=Address,
                             Address2='',
                             City=City,
                             State=State,
                             Zip_Code=ZipCode,
                             Home_Phone=Home_Phone,
                             Date_Of_Birth=Date_Of_Birth,
                             Drivers_License_Number=Drivers_License_Number,
                             Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                             Injury_Status=Injury_Status,
                             Alcohol_Use_Suspected = Alcohol_Use_Suspected_List,
                             Marijuana_Use_Suspected = [],
                             Drug_Use_Suspected = Drug_Use_Suspected_List,
                             Contributing_Circumstances_Person = ContributingFactorsPeople_List,
                             Non_Motorist_Actions_At_Time_Of_Crash = Non_Motorist_Actions_At_Time_Of_Crash_List,
                             Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                             Safety_Equipment_Available_Or_Used = Safety_Equipment_Available_or_Used_List,
                             Safety_Equipment_Helmet = Safety_Equipment_Helmet_List,
                             Ejection=Ejection_Code,
                             Same_as_Driver_GUI=''
                             )
        # changes===================
        people_info_coord = People(Party_Id=str(party_id),
                                    Person_Type=person_type,
                                    Unit_Number=img_unit_num,
                                    First_Name=First_Name_coord,
                                    Middle_Name=Middle_Name_coord,
                                    Last_Name=Last_Name_coord,
                                    Name_Suffix=Name_Suffix_coord,
                                    Address=Address_coord,
                                    Address2='',
                                    City=City_coord,
                                    State=State_coord,
                                    Zip_Code=ZipCode_coord,
                                    Home_Phone=Home_Phone_coord,
                                    Date_Of_Birth=Date_Of_Birth_coord,
                                    Drivers_License_Number=Drivers_License_Number_coord,
                                    Drivers_License_Jurisdiction=Drivers_License_Jurisdiction_coord,
                                    Injury_Status=Injury_Status_coord,
                                    Alcohol_Use_Suspected = Alcohol_Use_Suspected_List_coord,
                                    Marijuana_Use_Suspected = "",
                                    Drug_Use_Suspected = Drug_Use_Suspected_List_coord,
                                    Contributing_Circumstances_Person = ContributingFactorsPeople_List_coord,
                                    Non_Motorist_Actions_At_Time_Of_Crash = Non_Motorist_Actions_At_Time_Of_Crash_List_coord,
                                    Safety_Equipment_Restraint=Safety_Equipment_Restraint_List_coord,
                                    Safety_Equipment_Available_Or_Used = Safety_Equipment_Available_or_Used_List_coord,
                                    Safety_Equipment_Helmet = Safety_Equipment_Helmet_List_coord,
                                    Ejection=Ejection_Code_coord,
                                    Same_as_Driver_GUI=''
                                    )
        # ==========================

        if is_object_has_values(people_info) == True or Last_Name == 'PARKED' or Last_Name == 'HIT&RUN':
            people_list.append(people_info)
            # changes===================
            people_list_coord.append(people_info_coord)

            # ==========================

        if is_owner_same_as_driver == True and OwnerFlag == 1:
            OwnerFlag = 0
            people_info = People(Party_Id=str(party_id),
                                 Person_Type='VEHICLE OWNER',
                                 Unit_Number=img_unit_num,
                                 First_Name=First_Name,
                                 Middle_Name=Middle_Name,
                                 Last_Name=Last_Name,
                                 Name_Suffix=Name_Suffix,
                                 Address=Address,
                                 Address2='',
                                 City=City,
                                 State=State,
                                 Zip_Code=ZipCode,
                                 Home_Phone=Home_Phone,
                                 Date_Of_Birth=Date_Of_Birth,
                                 Drivers_License_Number=Drivers_License_Number,
                                 Drivers_License_Jurisdiction=Drivers_License_Jurisdiction,
                                 Injury_Status=Injury_Status,
                                 Address_Same_as_Driver_GUI=''
                                 )
            # changes==========================
            people_info_coord = People(Party_Id=str(party_id),
                                 Person_Type='VEHICLE OWNER',
                                 Unit_Number=img_unit_num,
                                 First_Name=First_Name_coord,
                                 Middle_Name=Middle_Name_coord,
                                 Last_Name=Last_Name_coord,
                                 Name_Suffix=Name_Suffix_coord,
                                 Address=Address_coord,
                                 Address2='',
                                 City=City_coord,
                                 State=State_coord,
                                 Zip_Code=ZipCode_coord,
                                 Home_Phone=Home_Phone_coord,
                                 Date_Of_Birth=Date_Of_Birth_coord,
                                 Drivers_License_Number=Drivers_License_Number_coord,
                                 Drivers_License_Jurisdiction=Drivers_License_Jurisdiction_coord,
                                 Injury_Status=Injury_Status_coord,
                                 Address_Same_as_Driver_GUI=''
                                 )
            # =================================

            if is_object_has_values(people_info) == True:
                people_list.append(people_info)
                people_list_coord.append(people_info_coord)
        else:
            OwnerAddress = get_value_from_df('OwnerAddress' + unit_num)
            if OwnerName != '' or OwnerAddress != '' and OwnerFlag == 1:
                if is_owner_address_as_driver:
                    owner_addrs = Address
                    owner_city = City
                    owner_state = State
                    owner_zip = ZipCode
                    # changes================
                    owner_addrs_coord = Address_coord
                    owner_city_coord = City_coord
                    owner_state_coord = State_coord
                    owner_zip_coord = ZipCode_coord
                    # =======================
                else:
                    owner_addrs = OwnerAddress
                    owner_city = get_value_from_df('OwnerCity' + unit_num)
                    owner_state = get_value_from_df('OwnerState' + unit_num)
                    owner_zip = get_value_from_df('OwnerZip1' + unit_num)
                    # changes================
                    owner_addrs_coord = get_value_from_df_coord('OwnerAddress' + unit_num)
                    owner_city_coord = get_value_from_df_coord('OwnerCity' + unit_num)
                    owner_state_coord = get_value_from_df_coord('OwnerState' + unit_num)
                    owner_zip_coord = get_value_from_df_coord('OwnerZip1' + unit_num)
                    # =======================



                people_info = People(
                                     Party_Id = str(party_id),
                                     Person_Type='VEHICLE OWNER',
                                     Unit_Number=img_unit_num,
                                     First_Name=get_value_from_df('OwnerFirstName' + unit_num),
                                     Middle_Name=get_value_from_df('OwnerMiddelName' + unit_num),
                                     Last_Name=get_value_from_df('OwnerLastName' + unit_num),
                                     Name_Suffix='',
                                     Address=owner_addrs,
                                     Address2='',
                                     City=owner_city,
                                     State=owner_state,
                                     Zip_Code=owner_zip,
                                     Home_Phone='',
                                     Date_Of_Birth='',
                                     Drivers_License_Number='',
                                     Drivers_License_Jurisdiction='',
                                     Injury_Status='',
                                     Address_Same_as_Driver_GUI=''
                                     )
                # changes========================
                people_info_coord = People(
                                     Party_Id = str(party_id),
                                     Person_Type='VEHICLE OWNER',
                                     Unit_Number=img_unit_num,
                                     First_Name=get_value_from_df_coord('OwnerFirstName' + unit_num),
                                     Middle_Name=get_value_from_df_coord('OwnerMiddelName' + unit_num),
                                     Last_Name=get_value_from_df_coord('OwnerLastName' + unit_num),
                                     Name_Suffix='',
                                     Address=owner_addrs_coord,
                                     Address2='',
                                     City=owner_city_coord,
                                     State=owner_state_coord,
                                     Zip_Code=owner_zip_coord,
                                     Home_Phone='',
                                     Date_Of_Birth='',
                                     Drivers_License_Number='',
                                     Drivers_License_Jurisdiction='',
                                     Injury_Status='',
                                     Address_Same_as_Driver_GUI=''
                                     )
                # ===============================


                if is_object_has_values(people_info) == True:
                    people_list.append(people_info)
                    people_list_coord.append(people_info_coord)

        party_id += 1



    return party_id

def other_party_details_extraction(people_list, vehicle_list, party_id,
                                   people_list_coord, vehicle_list_coord):
 

    unit_num = len(vehicle_list)

    for row in range(1, 5):
        Safety_Equipment_Restraint_List = []
        Safety_Equipment_Available_or_Used_List = []
        Safety_Equipment_Helmet_List = []
        Ejection_List = []
        Alcohol_Use_Suspected_List = []
        Drug_Use_Suspected_List = []
        Non_Motorist_Actions_At_Time_Of_Crash_List = []
        ContributingFactorsPeople_List = []

        # changes============================
        Safety_Equipment_Restraint_List_coord = ""
        Safety_Equipment_Available_or_Used_List_coord = ""
        Safety_Equipment_Helmet_List_coord = ""
        Ejection_List_coord = ""
        Alcohol_Use_Suspected_List_coord = ""
        Drug_Use_Suspected_List_coord = ""
        Non_Motorist_Actions_At_Time_Of_Crash_List_coord = ""
        ContributingFactorsPeople_List_coord = ""
        # ===================================

        veh_occ = get_value_from_df('Unit' + str(row))
        veh_occ = re.sub('([^0-9])', '', veh_occ)
        is_pedalcyclist = get_checkbox_status('Bicycle' + veh_occ)
        is_pedestrain = get_checkbox_status('Pedestrain' + veh_occ)
        is_non_motorist = get_checkbox_status('NonVehicle' + veh_occ)
        is_non_contact_motorist = get_checkbox_status('NonContractVeh' + veh_occ)

        if veh_occ == 'B' or is_pedalcyclist:
            prsn_type = 'PEDALCYCLIST'
            unit_num += 1
        elif veh_occ == 'P' or is_pedestrain:
            prsn_type = 'PEDESTRIAN'
            unit_num += 1
        elif veh_occ == 'W':
            prsn_type = 'WITNESS'
        elif is_non_motorist or is_non_contact_motorist:
            prsn_type = 'NONMOTORIST'
        else:
            prsn_type = 'PASSENGER'
            unit_num = veh_occ

        seat_position = get_value_from_df('Pos' + str(row))
        seat_position = seat_position.replace('0', '')

        if seat_position != '1':
            Safety_Equipment = get_value_from_df('SafetyEquip1_' + str(row))
            if Safety_Equipment != '':
                Safety_Equipment_Restraint_List.append(Safety_Equipment_Restraint(Safety_Equipment, get_value_from_df('SafetyEquip1_' + str(row) + '_desc')))
                # changes======================
                Safety_Equipment_Restraint_List_coord = get_value_from_df_coord('SafetyEquip1_' + str(row))
                # =============================

            Safety_Equipment_Available = get_value_from_df('SafetyEquip2_' + str(row))
            if Safety_Equipment_Available != '':
                if re.match('^([^0])$',Safety_Equipment_Available): Safety_Equipment_Available = '0' + Safety_Equipment_Available
                Safety_Equipment_Available_or_Used_List.append(Safety_Equipment_Available_Or_Used(Safety_Equipment_Available,get_value_from_df('SafetyEquip2_' + str(row) + '_desc')))
                # changes======================
                Safety_Equipment_Available_or_Used_List_coord = get_value_from_df_coord('SafetyEquip2_' + str(row))
                # =============================


            Safety_Equip_Helmet = get_value_from_df('SafetyEquip3_' + str(row))
            if Safety_Equip_Helmet != '':
                Safety_Equipment_Helmet_List.append(Safety_Equipment_Helmet(Safety_Equip_Helmet, get_value_from_df('SafetyEquip3_' + str(row) + '_desc')))
                # changes======================
                Safety_Equipment_Helmet_List_coord = get_value_from_df_coord('SafetyEquip3_' + str(row))
                # =============================


            Alcohol_Use_Susp = get_value_from_df('Alco' + str(row))
            Alcohol_Use_Susp_Desc = get_value_from_df('Alco' + str(row) + '_desc')
            if Alcohol_Use_Susp != '':
                if re.match('^([0-9]+)$', Alcohol_Use_Susp) and re.match('^([^0])$', Alcohol_Use_Susp): Alcohol_Use_Susp = '0' + Alcohol_Use_Susp
                if Alcohol_Use_Susp == '01':
                    Alcohol_Use_Susp = 'Yes'
                    Alcohol_Use_Susp_Desc = 'Yes'
                Alcohol_Use_Suspected_List.append(Safety_Equipment_Helmet(Alcohol_Use_Susp, Alcohol_Use_Susp_Desc))
                # changes======================
                Alcohol_Use_Suspected_List_coord = get_value_from_df_coord('Alco' + str(row))
                # =============================


            Drug_Use_Susp = get_value_from_df('Drug' + str(row))
            if Drug_Use_Susp != '':
                if re.match('^([0-9]+)$', Drug_Use_Susp) and re.match('^([^0])$',Drug_Use_Susp): Drug_Use_Susp = '0' + Drug_Use_Susp
                Drug_Use_Suspected_List.append(Safety_Equipment_Helmet(Drug_Use_Susp, get_value_from_df('Drug' + str(row) + '_desc')))
                # changes======================
                Drug_Use_Suspected_List_coord = get_value_from_df_coord('Drug' + str(row))
                # =============================
            Ejection_Code = get_value_from_df('Eject' + str(row))
            # changes======================
            Ejection_Code_coord = get_value_from_df_coord('Eject' + str(row))
            # =============================

            if Ejection_Code != '':
                if re.match('^([^0])$', Ejection_Code): Ejection_Code = '0' + Ejection_Code
                Ejection_List.append(Ejection(Ejection_Code, get_value_from_df('Eject' + str(row) + '_desc')))
                # changes======================
                Ejection_List_coord = get_value_from_df_coord('Eject' + str(row))
                # =============================
            Injury_Status = get_value_from_df('InjSev' + str(row))
            Injury_Status_coord = get_value_from_df_coord('InjSev' + str(row))

            Injury_zero_match = re.search('^((0)([0-9]))$', Injury_Status)
            if Injury_zero_match: 
                Injury_Status = Injury_zero_match.group(3)
                # changes======================

                # =============================

            people_info = People(
                Party_Id=str(party_id),
                Person_Type=prsn_type,
                Unit_Number=unit_num,
                First_Name=get_value_from_df('NameAddress' + str(row) + '_first_name'),
                Middle_Name=get_value_from_df('NameAddress' + str(row) + '_middle_name'),
                Last_Name=get_value_from_df('NameAddress' + str(row) + '_last_name'),
                Name_Suffix=get_value_from_df('NameAddress' + str(row) + '_suffix'),
                Address=get_value_from_df('NameAddress' + str(row) + '_address'),
                Address2='',
                City=get_value_from_df('NameAddress' + str(row) + '_city'),
                State=get_value_from_df('NameAddress' + str(row) + '_state'),
                Zip_Code=get_value_from_df('NameAddress' + str(row) + '_zipcode'),
                Home_Phone='',
                Date_Of_Birth='',
                Drivers_License_Number='',
                Drivers_License_Jurisdiction='',
                Injury_Status=Injury_Status,
                Alcohol_Use_Suspected=Alcohol_Use_Suspected_List,
                Marijuana_Use_Suspected=[],
                Drug_Use_Suspected=Drug_Use_Suspected_List,
                Contributing_Circumstances_Person=ContributingFactorsPeople_List,
                Non_Motorist_Actions_At_Time_Of_Crash=Non_Motorist_Actions_At_Time_Of_Crash_List,
                Safety_Equipment_Restraint=Safety_Equipment_Restraint_List,
                Safety_Equipment_Available_Or_Used=Safety_Equipment_Available_or_Used_List,
                Safety_Equipment_Helmet=Safety_Equipment_Helmet_List,
                Ejection=Ejection_Code,
                Address_Same_as_Driver_GUI='',
                Address_Same_as_Owner_GUI=''
            )


            people_info_coord  = People(
                                    Party_Id=str(party_id),
                                    Person_Type=prsn_type,
                                    Unit_Number=unit_num,
                                    First_Name=get_value_from_df_coord('NameAddress' + str(row) + '_first_name'),
                                    Middle_Name=get_value_from_df_coord('NameAddress' + str(row) + '_middle_name'),
                                    Last_Name=get_value_from_df_coord('NameAddress' + str(row) + '_last_name'),
                                    Name_Suffix=get_value_from_df_coord('NameAddress' + str(row) + '_suffix'),
                                    Address=get_value_from_df_coord('NameAddress' + str(row) + '_address'),
                                    Address2='',
                                    City=get_value_from_df_coord('NameAddress' + str(row) + '_city'),
                                    State=get_value_from_df_coord('NameAddress' + str(row) + '_state'),
                                    Zip_Code=get_value_from_df_coord('NameAddress' + str(row) + '_zipcode'),
                                    Home_Phone='',
                                    Date_Of_Birth='',
                                    Drivers_License_Number='',
                                    Drivers_License_Jurisdiction='',
                                    Injury_Status=Injury_Status_coord,
                                    Alcohol_Use_Suspected=Alcohol_Use_Suspected_List_coord,
                                    Marijuana_Use_Suspected="",
                                    Drug_Use_Suspected=Drug_Use_Suspected_List_coord,
                                    Contributing_Circumstances_Person=ContributingFactorsPeople_List_coord,
                                    Non_Motorist_Actions_At_Time_Of_Crash=Non_Motorist_Actions_At_Time_Of_Crash_List_coord,
                                    Safety_Equipment_Restraint=Safety_Equipment_Restraint_List_coord,
                                    Safety_Equipment_Available_Or_Used=Safety_Equipment_Available_or_Used_List_coord,
                                    Safety_Equipment_Helmet=Safety_Equipment_Helmet_List_coord,
                                    Ejection=Ejection_Code_coord,
                                    Address_Same_as_Driver_GUI='',
                                    Address_Same_as_Owner_GUI=''
                                )

            if is_object_has_values(people_info) == True:
                people_list.append(people_info)
                people_list_coord.append(people_info_coord)

                if prsn_type == 'PEDESTRIAN' or prsn_type == 'PEDESTRIAN' or prsn_type == 'NONMOTORIST':
                    empty_vehicle_block(vehicle_list, unit_num , vehicle_list_coord)


                party_id += 1

    return party_id

def property_owner_details_extraction(people_list, vehicle_list, party_id,
                                      people_list_coord, vehicle_list_coord):
    for item in range(1,3):
        LastName = get_value_from_df('OtherDamagedProp' + str(item))
        FristName = get_value_from_df('OtherDamagedPropOwnerFirstName' + str(item))
        MiddelName = get_value_from_df('OtherDamagedPropOwnerMiddelName' + str(item))
        unit_num = len(vehicle_list) + 1
        # changes===================
        LastName_coord = get_value_from_df_coord('OtherDamagedProp' + str(item))
        FristName_coord = get_value_from_df_coord('OtherDamagedPropOwnerFirstName' + str(item))
        MiddelName_coord = get_value_from_df_coord('OtherDamagedPropOwnerMiddelName' + str(item))
        # ==========================

        if LastName == '':
            continue

        people_info = People(Party_Id=str(party_id),
                             Person_Type='VEHICLE OWNER',
                             Unit_Number= str(unit_num),
                             First_Name=FristName,
                             Middle_Name=MiddelName,
                             Last_Name=LastName,
                             Name_Suffix='',
                             Address=get_value_from_df('OtherDamagedPropOwnerAddress' + str(item)),
                             Address2='',
                             City=get_value_from_df('OtherDamagedPropOwnerCity' + str(item)),
                             State=get_value_from_df('OtherDamagedPropOwnerState' + str(item)),
                             Zip_Code=get_value_from_df('OtherDamagedPropOwnerZip' + str(item)),
                             Home_Phone='',
                             Date_Of_Birth='',
                             Drivers_License_Number='',
                             Drivers_License_Jurisdiction='',
                             Injury_Status='',
                             Address_Same_as_Driver_GUI='')
        # changes=======================
        people_info_coord = People(Party_Id=str(party_id),
                             Person_Type='VEHICLE OWNER',
                             Unit_Number= str(unit_num),
                             First_Name=FristName_coord,
                             Middle_Name=MiddelName_coord,
                             Last_Name=LastName_coord,
                             Name_Suffix='',
                             Address=get_value_from_df_coord('OtherDamagedPropOwnerAddress' + str(item)),
                             Address2='',
                             City=get_value_from_df_coord('OtherDamagedPropOwnerCity' + str(item)),
                             State=get_value_from_df_coord('OtherDamagedPropOwnerState' + str(item)),
                             Zip_Code=get_value_from_df_coord('OtherDamagedPropOwnerZip' + str(item)),
                             Home_Phone='',
                             Date_Of_Birth='',
                             Drivers_License_Number='',
                             Drivers_License_Jurisdiction='',
                             Injury_Status='',
                             Address_Same_as_Driver_GUI='')
        # ==============================

        people_list.append(people_info)
        # changes========================
        people_list_coord.append(people_info_coord)
        # ===============================
        empty_driver_blcok(unit_num, party_id, people_list , people_list_coord)
        empty_vehicle_block(vehicle_list, unit_num , vehicle_list_coord)
        party_id += 1

def empty_vehicle_block(vehicle_list, unit_num, vehicle_list_coord):
    vehicle = Vehicles(
        VinValidation_VinStatus='V',
        Unit_Number=str(unit_num),
        License_Plate='',
        Registration_State='',
        VIN='',
        Vehicle_Towed='',
        Model_Year='',
        Make='',
        Model='',
        Insurance_Company='',
        Insurance_Policy_Number='',
        Insurance_Expiration_Date='',
        Damaged_Areas='',
        Air_Bag_Deployed='',
        Contributing_Circumstances_Vehicle=[],
        Posted_Statutory_SpeedLimit=''
    )
    # changes====================
    vehicle_coord = Vehicles(
                    VinValidation_VinStatus='V',
                    Unit_Number=str(unit_num),
                    License_Plate='',
                    Registration_State='',
                    VIN='',
                    Vehicle_Towed='',
                    Model_Year='',
                    Make='',
                    Model='',
                    Insurance_Company='',
                    Insurance_Policy_Number='',
                    Insurance_Expiration_Date='',
                    Damaged_Areas='',
                    Air_Bag_Deployed='',
                    Contributing_Circumstances_Vehicle='',
                    Posted_Statutory_SpeedLimit=''
                )
    # ===========================
    vehicle_list.append(vehicle)
    vehicle_list_coord.append(vehicle_coord)

def empty_driver_blcok(unit_num, party_id, people_list , people_list_coord):
    people_info = People(Party_Id=str(party_id),
                         Person_Type='DRIVER',
                         Unit_Number=str(unit_num),
                         First_Name='',
                         Middle_Name='',
                         Last_Name='',
                         Name_Suffix='',
                         Address='',
                         Address2='',
                         City='',
                         State='',
                         Zip_Code='',
                         Home_Phone='',
                         Date_Of_Birth='',
                         Drivers_License_Number='',
                         Drivers_License_Jurisdiction='',
                         Injury_Status='',
                         Alcohol_Use_Suspected=[],
                         Marijuana_Use_Suspected=[],
                         Drug_Use_Suspected=[],
                         Contributing_Circumstances_Person=[],
                         Non_Motorist_Actions_At_Time_Of_Crash=[],
                         Safety_Equipment_Restraint=[],
                         Safety_Equipment_Available_Or_Used=[],
                         Safety_Equipment_Helmet=[],
                         Ejection='',
                         Same_as_Driver_GUI=''
                         )
    # changes====================
    people_info_coord = People(Party_Id=str(party_id),
                         Person_Type='DRIVER',
                         Unit_Number=str(unit_num),
                         First_Name='',
                         Middle_Name='',
                         Last_Name='',
                         Name_Suffix='',
                         Address='',
                         Address2='',
                         City='',
                         State='',
                         Zip_Code='',
                         Home_Phone='',
                         Date_Of_Birth='',
                         Drivers_License_Number='',
                         Drivers_License_Jurisdiction='',
                         Injury_Status='',
                         Alcohol_Use_Suspected='',
                         Marijuana_Use_Suspected='',
                         Drug_Use_Suspected='',
                         Contributing_Circumstances_Person='',
                         Non_Motorist_Actions_At_Time_Of_Crash='',
                         Safety_Equipment_Restraint='',
                         Safety_Equipment_Available_Or_Used='',
                         Safety_Equipment_Helmet='',
                         Ejection='',
                         Same_as_Driver_GUI=''
                         )
    # ===========================
    people_list.append(people_info)
    people_list_coord.append(people_info_coord)



def vehicle_details_extraction(vehicle_list , vehicle_list_coord):
    UnitNumList = list(filter(lambda x: re.search(r'^(UnitNum[0-9])$', x), page_df['label']))
    UnitNumList.sort()

    # ============================================
    # Air Bag Deployed
    air_bag_deployed_1 = ''
    air_bag_deployed_2 = ''
    # changes=====================
    air_bag_deployed_1_coord = ''
    air_bag_deployed_2_coord = ''
    # ============================


    for row in range(1, 5):
        veh_occ = get_value_from_df('Unit' + str(row))
        seat_position = get_value_from_df('Pos' + str(row))
        seat_position = seat_position.replace('0', '')
        if ('1' in veh_occ or '3' in veh_occ or '5' in veh_occ) and '1' in seat_position:
            air_bag_deployed_1 = get_value_from_df('AirBag1_' + str(row))
            # changes=================
            air_bag_deployed_1_coord = get_value_from_df_coord('AirBag1_' + str(row))
            # ========================

            zero_match = re.search('^((0)([0-9]))$', air_bag_deployed_1)
            if zero_match: air_bag_deployed_1 = zero_match.group(3)
        elif ('2' in veh_occ or '4' in veh_occ or '6' in veh_occ) and '1' in seat_position:
            air_bag_deployed_2 = get_value_from_df('AirBag1_' + str(row))
            # changes=================
            air_bag_deployed_2_coord = get_value_from_df_coord('AirBag1_' + str(row))
            # ========================

            zero_match = re.search('^((0)([0-9]))$', air_bag_deployed_2)
            if zero_match: air_bag_deployed_2 = zero_match.group(3)
    # ============================================


    for unit in UnitNumList:
        Contributing_Circumstances_Vehicle_List = []
        Contributing_Circumstances_Vehicle_List_coord = ""

        unit_num = re.sub(r'^((UnitNum)([0-9]))$', r'\3', unit)

        img_unit_num = get_value_from_df('UnitNum' + unit_num)
        img_unit_num = re.sub('([^0-9])', '', img_unit_num)

        VIN = get_value_from_df('VIN' + unit_num)
        VIN = VIN.replace(' ', '')

        ModelYear = get_value_from_df('VehicleYear' + unit_num)
        ModelYear = ModelYear.replace(' ', '')
        vehicle_make = get_value_from_df('Make' + unit_num)
        vehicle_model = get_value_from_df('Model' + unit_num)
        license_plate = get_value_from_df('LicensePlateNumber' + unit_num)
        policy_number = get_value_from_df('PolicyNumber' + unit_num)
        policy_number = policy_number.replace(' ', '')
        contri_fact_appender('T' + unit_num, Contributing_Circumstances_Vehicle_List)
        damaged_area_desc = damged_ratings_extractor(unit_num)
        # changes==========================
        VIN_coord = get_value_from_df_coord('VIN' + unit_num)
        ModelYear_coord = get_value_from_df_coord('VehicleYear' + unit_num)
        vehicle_make_coord = get_value_from_df_coord('Make' + unit_num)
        vehicle_model_coord = get_value_from_df_coord('Model' + unit_num)
        license_plate_coord = get_value_from_df_coord('LicensePlateNumber' + unit_num)
        policy_number_coord = get_value_from_df_coord('PolicyNumber' + unit_num)
        Contributing_Circumstances_Vehicle_List_coord = get_value_from_df_coord('T' + unit_num)
        # contri_fact_appender('T' + unit_num, Contributing_Circumstances_Vehicle_List)
        damaged_area_desc_coord = ""
        # =================================

        # ============================================
        air_bag_deployed = ''
        speed_limit = ''
        # changes=================
        air_bag_deployed_coord = ''
        speed_limit_coord = ''
        # ========================
        if unit_num == '1':
            air_bag_deployed = air_bag_deployed_1
            speed_limit = get_value_from_df('N1')
            # changes======================
            air_bag_deployed_coord = air_bag_deployed_1_coord
            speed_limit_coord = get_value_from_df_coord('N1')
            # =============================
        elif unit_num == '2':
            air_bag_deployed = air_bag_deployed_2
            speed_limit = get_value_from_df('N2')
            # changes======================
            air_bag_deployed_coord = air_bag_deployed_2_coord
            speed_limit_coord = get_value_from_df_coord('N2')
            # =============================


        # ============================================
        # Vehicle towed by and to
        is_towed_checked = get_checkbox_status('TowedDriven' + unit_num)

        towed_to_content = get_value_from_df('TownerTo' + unit_num)
        towed_by_content = get_value_from_df('TownerBy' + unit_num)
        towed_content = towed_by_content + ' ' + towed_to_content.lower()
        towed_content = re.sub('^(\s?\\bBy\\b\s?)$', '', towed_content)
        towed_status = ''
        # changes=================
        towed_content_coord = get_value_from_df_coord('TownerTo' + unit_num)
        towed_status_coord = towed_content_coord
        # ========================


        if is_towed_checked:
            towed_status = '1'
        elif 'driver' in towed_content or 'left' in towed_content or 'scene' in towed_content or 'not towed' in towed_content \
                or 'owner' in towed_content or (towed_content == ' ' and vehicle_make != '' and vehicle_model != '' and license_plate != ''):
            towed_status = '0'
        elif 'N/A' in towed_content or 'NA' in towed_content or 'Unknown' in towed_content \
                or (towed_content == ' ' and vehicle_make == '' and vehicle_model == '' and license_plate == ''):
            towed_status = ''
        elif towed_content == ' ' or '------------' in towed_content:
            towed_status = ''
        elif towed_content != '':
            towed_status = '1'
        # ============================================

        vehicle = Vehicles(
            VinValidation_VinStatus = 'V',
            Unit_Number = img_unit_num,
            License_Plate = license_plate,
            Registration_State=get_value_from_df('LicenseState' + unit_num),
            VIN = VIN,
            Vehicle_Towed = towed_status,
            Model_Year = ModelYear,
            Make = vehicle_make,
            Model = vehicle_model,
            Insurance_Company = get_value_from_df('InsuranceCompany' + unit_num),
            Insurance_Policy_Number = policy_number,
            Insurance_Expiration_Date = get_value_from_df('InsuranceExpDate' + unit_num),
            Damaged_Areas =  damaged_area_desc,
            Air_Bag_Deployed = air_bag_deployed,
            Contributing_Circumstances_Vehicle = Contributing_Circumstances_Vehicle_List,
            Posted_Statutory_SpeedLimit = speed_limit
        )
        # changes=======================

        vehicle_coord = Vehicles(
                                VinValidation_VinStatus = 'V',
                                Unit_Number = img_unit_num,
                                License_Plate = license_plate_coord,
                                Registration_State=get_value_from_df_coord('LicenseState' + unit_num),
                                VIN = VIN_coord,
                                Vehicle_Towed = towed_status_coord,
                                Model_Year = ModelYear_coord,
                                Make = vehicle_make_coord,
                                Model = vehicle_model_coord,
                                Insurance_Company = get_value_from_df_coord('InsuranceCompany' + unit_num),
                                Insurance_Policy_Number = policy_number_coord,
                                Insurance_Expiration_Date = get_value_from_df_coord('InsuranceExpDate' + unit_num),
                                Damaged_Areas =  damaged_area_desc_coord,
                                Air_Bag_Deployed = air_bag_deployed_coord,
                                Contributing_Circumstances_Vehicle = Contributing_Circumstances_Vehicle_List_coord,
                                Posted_Statutory_SpeedLimit = speed_limit_coord
                            )
        # ==============================



        if_object_empty = False
        if vehicle.License_Plate == '' and vehicle.Registration_State == '' and vehicle.Make == '' \
                and vehicle.Damaged_Areas == '' and vehicle.Model == '' and vehicle.VIN == '':
            if_object_empty = True

        if if_object_empty == False:
            vehicle_list.append(vehicle)
            # changes=====================
            vehicle_list_coord.append(vehicle_coord)
            # ============================

    return vehicle_list , vehicle_list_coord

def damged_ratings_extractor(unit_num):
    # ============================================
    # Vehicle damaged ratings
    damaged_area_desc = ''
    T1 = get_value_from_df('T' + unit_num + '_1')
    T2 = get_value_from_df('T' + unit_num + '_2')
    T3 = get_value_from_df('T' + unit_num + '_3')
    T4 = get_value_from_df('T' + unit_num + '_4')
    T5 = get_value_from_df('T' + unit_num + '_5')
    T6 = get_value_from_df('T' + unit_num + '_6')
    T7 = get_value_from_df('T' + unit_num + '_7')
    T8 = get_value_from_df('T' + unit_num + '_8')
    T9 = get_value_from_df('T' + unit_num + '_9')
    T10 = get_value_from_df('T' + unit_num + '_10')
    T11 = get_value_from_df('T' + unit_num + '_11')
    T12 = get_value_from_df('T' + unit_num + '_12')
    T13 = get_value_from_df('T' + unit_num + '_13')
    T14 = get_value_from_df('T' + unit_num + '_14')
    T15 = get_value_from_df('T' + unit_num + '_15')
    T16 = get_value_from_df('T' + unit_num + '_16')

    count = 0
    right = 0
    left = 0
    rear = 0
    front = 0
    for item in range(1, 17):
        if (get_value_from_df('T' + unit_num + '_' + str(item)) != '') and (item == 2 or item == 3 or item == 4 or item == 5):
            right += 1
        elif (get_value_from_df('T' + unit_num + '_' + str(item)) != '') and (
                item == 10 or item == 11 or item == 12 or item == 13):
            left += 1
        elif (get_value_from_df('T' + unit_num + '_' + str(item)) != '') and (item == 7 or item == 8):
            rear += 1
        elif (get_value_from_df('T' + unit_num + '_' + str(item)) != '') and (item == 15 or item == 16):
            front += 1
        elif get_value_from_df('T' + unit_num + '_' + str(item)) != '':
            count += 1

    if count > 1 or (right > 1 and left > 1) or (right > 1 or rear > 1) or (right > 1 or front > 1) or (
            left > 1 or rear > 1) \
            or (left > 1 or front > 1) or (rear > 1 or front > 1):
        damaged_area_desc = 'Multiple'
    elif T1 != '':
        damaged_area_desc = 'RIGHT FRONT'
    elif T2 != '' or T3 != '' or T4 != '' or T5 != '':
        damaged_area_desc = 'RIGHT SIDE'
    elif T6 != '':
        damaged_area_desc = 'RIGHT REAR'
    elif T7 != '' or T8 != '':
        damaged_area_desc = 'REAR'
    elif T9 != '':
        damaged_area_desc = 'LEFT REAR'
    elif T10 != '' or T11 != '' or T12 != '' or T13 != '':
        damaged_area_desc = 'LEFT SIDE'
    elif T14 != '':
        damaged_area_desc = 'LEFT FRONT'
    elif T15 != '' or T16 != '':
        damaged_area_desc = 'FRONT'
    return damaged_area_desc


def contri_fact_appender(label_name, Contributing_Circumstances_Vehicle_List):
    ContributingFactorsVehicle = get_value_from_df(label_name)
    if re.match('^([0-9]+)$', ContributingFactorsVehicle):
        if re.match('^([^0])$',ContributingFactorsVehicle): ContributingFactorsVehicle = '0' + ContributingFactorsVehicle
        # ContributingFactorsVehicle = re.sub(r'[^0-9]', '', ContributingFactorsVehicle)
        Contributing_Circumstances_Vehicle_List.append(Contributing_Circumstances_Vehicle(ContributingFactorsVehicle, get_value_from_df(label_name  + '_desc')))


def get_value_from_df(label_name):
    try:
        if len(page_df.loc[page_df['label'] == label_name]) > 0:
            value = page_df.loc[page_df['label'] == label_name]['text'].iloc[0]
            if str(value) != 'nan':
                return value
            else:
                return ''
        else:
            return ''
    except:
        d = 1

# changes================
def get_value_from_df_coord(label_name):
    try:
        filtered_rows = page_df[page_df['label'] == label_name]
            # value = df.loc[df['label'] == label_name]['text'].iloc[0]
           
        if len(filtered_rows) > 0:
            xmin_value = filtered_rows['xmin'].iloc[0]
            ymin_value = filtered_rows['ymin'].iloc[0]
            xmax_value = filtered_rows['xmax'].iloc[0]
            ymax_value = filtered_rows['ymax'].iloc[0]
            page_no_value = filtered_rows['page_no'].iloc[0]
            # text = filtered_rows['text'].iloc[0]
            # text = text
 
            value = f"{int(xmin_value)},{int(ymin_value)},{int(xmax_value)},{int(ymax_value)},{int(page_no_value)}"
 
 
        if str(value) != 'nan':
            return value
        else:
            return ''
    except:
        return ''   


def Latitude_Longitude_Converter(text):
    if text != '':
        text= text.replace(' ', '')
        text_match = re.search('^(([0-9]{2})([0-9]+))$', text)
        if text_match:
            text = text_match.group(2) + '.' + text_match.group(3)
    return text

def date_fomat_maker(date):
    new_date = ''
    if date != '':
        date = date.replace(' ', '')
        date = date.replace('-', '/')
        date_match = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{4}))$', date)
        date_match2 = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{3}))$', date)
        date_match3 = re.search('^(([0-9]{2})(\/)?([0-9]{2})([0-9]{2}))$', date)
        if date_match:
            new_date = date_match.group(2) + '/' + date_match.group(4) + '/'  + date_match.group(5)
        elif date_match3:
            year = int(date_match3.group(5))
            if year >= 0 and year <= 20:
                if len(str(year)) == 1:
                    year = '200' + str(year)
                else:
                    year = '20' + str(year)
            elif year >= 21:
                if len(str(year)) == 1:
                    year = '190' + str(year)
                else:
                    year = '19' + str(year)
            new_date = date_match3.group(2) + '/' + date_match3.group(4) + '/' + year
        elif date_match2:
            new_date = date_match2.group(2) + '/' + date_match2.group(4) + '/' + date_match2.group(5)
        else:
            new_date = date
    return new_date

def citation_details_extraction(citations_list, people_list):
    for unit in range(1,3):
        unit_num = get_value_from_df('UnitNum' + str(unit))
        unit_num = unit_num.replace('0', '')
        citation_detail = get_value_from_df('PrimaryViolation' + str(unit))
        violation_code = get_value_from_df('ViolationCode' + str(unit))
        Violation_Code_List = []
        Violation_Code_List.append(Violation_Code('', violation_code))
        ppl_info = list(filter(lambda x: x.Unit_Number == unit_num and x.Person_Type == 'DRIVER', people_list))

        if len(ppl_info) > 0:
            CitationCls = Citations(unit_num, ppl_info[0].Party_Id, citation_detail, Violation_Code_List)
        else:
            CitationCls = Citations(unit_num, unit_num, citation_detail, Violation_Code_List)

        if CitationCls.Citation_Detail != '' and CitationCls.Party_Id != '':
            citations_list.append(CitationCls)

def first_page_extraction(people_list, vehicle_list, party_id,
                          people_list_coord, vehicle_list_coord):
    is_photos_taken = get_checkbox_status('PhotosTaken')
    CrashDate = get_value_from_df('DateOfAccident')
    CrashDate = date_fomat_maker(CrashDate)

    Latitude = Latitude_Longitude_Converter(get_value_from_df('Latitude'))
    Longitude = Latitude_Longitude_Converter(get_value_from_df('Longitude'))
    if Longitude != '': 
        Longitude = '-' + Longitude
    # changes=================
    is_photos_taken_coord = get_value_from_df_coord('PhotosTaken')
    CrashDate_coord = get_value_from_df_coord('DateOfAccident')

    Latitude_coord = get_value_from_df_coord('Latitude')
    Longitude_coord = get_value_from_df_coord('Longitude')
    # ========================


    Photographs_Taken_List = []
    Weather_Condition_List = []
    Road_Surface_Condition_List = []
    # changes==================
    Photographs_Taken_List_coord = ""
    Weather_Condition_List_coord = ""
    Road_Surface_Condition_List_coord = ""
    # =========================
    # if is_photos_taken: Photographs_Taken_List.append(Photographs_Taken('', 'Yes'))
    Photo_Taken =''
    Photo_Taken_coord = is_photos_taken_coord
    if is_photos_taken: 
        Photo_Taken = 'Y'
    weather_condition = get_value_from_df('J')
    weather_condition_desc = get_value_from_df('J_desc')
    if weather_condition == '00':
        weather_condition = 'None'
        weather_condition_desc = 'None'
    # weather_condition = re.sub('(\s?J\s?)', '', weather_condition)
    road_surface_condition = get_value_from_df('G')
    # road_surface_condition = re.sub('([^0-9])', '', road_surface_condition)
    if weather_condition != '': 
        Weather_Condition_List.append(Weather_Condition(weather_condition, weather_condition_desc))
        # changes=====================
        Weather_Condition_List_coord =get_value_from_df_coord('J')
        # ============================
    if road_surface_condition != '': 
        Road_Surface_Condition_List.append(Road_Surface_Condition(road_surface_condition, get_value_from_df('G_desc')))
        # changes=====================
        Road_Surface_Condition_List_coord = get_value_from_df_coord('G')
        # ============================

    incident = Incident(
                        Crash_Date=CrashDate,
                        Case_Identifier=get_value_from_df('CaseNo'),
                        State_Report_Number='',
                        Crash_City=get_value_from_df('City'),
                        Loss_Street=get_value_from_df('LocationRouteSt1'),
                        Loss_Cross_Street=get_value_from_df('LocationRouteSt2'),
                        Latitude=Latitude,
                        Longitude=Longitude,
                        Loss_State_Abbr='CO',
                        Report_Type_Id='A',
                        Gps_Other='',
                        Weather_Condition=Weather_Condition_List,
                        Road_Surface_Condition=Road_Surface_Condition_List,
                        Photographs_Taken = Photo_Taken
                        )
    # changes======================
    
    incident_coord = Incident(
                        Crash_Date=CrashDate_coord,
                        Case_Identifier=get_value_from_df_coord('CaseNo'),
                        State_Report_Number='',
                        Crash_City=get_value_from_df_coord('City'),
                        Loss_Street=get_value_from_df_coord('LocationRouteSt1'),
                        Loss_Cross_Street=get_value_from_df_coord('LocationRouteSt2'),
                        Latitude=Latitude_coord,
                        Longitude=Longitude_coord,
                        Loss_State_Abbr='CO',
                        Report_Type_Id='A',
                        Gps_Other='',
                        Weather_Condition=Weather_Condition_List_coord,
                        Road_Surface_Condition=Road_Surface_Condition_List_coord,
                        Photographs_Taken = Photo_Taken_coord
                        )
    # =============================

    vehicle_details_extraction(vehicle_list,vehicle_list_coord)
    party_id = person_details_extraction(people_list, party_id , people_list_coord)
    party_id = other_party_details_extraction(people_list, vehicle_list, party_id ,
                                              people_list_coord, vehicle_list_coord)
    

    return incident, party_id , incident_coord

def grouping_pages_paths(img_path_list, inner_group_df):
    sorted_path_list = []
    flag = 0
    f_id = 0
    second_page_path = ''
    first_page_path = ''
    if len(img_path_list) == 1:
        sorted_path_list.append((1, img_path_list[0]))
        return sorted_path_list

    for inner_img in img_path_list:
        page_df = inner_group_df.get_group(inner_img)
        first_page_labels = list(filter(lambda x: 'DriverName' in x or 'InsuranceCompany' in x or 'VIN' in x or
                                                  'OwnerAddress' in x or 'DriverDOB' in x, page_df.label))

        second_page_labels = list(filter(lambda x: 'DORCode' in x or 'Narrative' in x or 'Diagram' in x or
                                                   'CarrierName' in x or 'StateDot' in x, page_df.label))
        #
        # not_second_page_label = list(filter(lambda x: 'DriverName' not in x and 'HitAndRun' not in x and 'OwnerAddress' not in x, page_df.label))

        if len(first_page_labels) >=3 and f_id == 1 and first_page_path != '':
            sorted_path_list.append((f_id, first_page_path))
            sorted_path_list.append((f_id, inner_img))
            first_page_path = ''
            second_page_path = ''
            flag += 1
        elif len(first_page_labels) >= 3:
            first_page_path = inner_img
            f_id = 1
        elif len(second_page_labels) >= 3:
            second_page_path = inner_img
            s_id = 2

        if first_page_path != '' and second_page_path != '':
            sorted_path_list.append((f_id + flag, first_page_path))
            sorted_path_list.append((s_id + flag, second_page_path))
            first_page_path = ''
            second_page_path = ''
            flag += 2
        elif first_page_path == '' and second_page_path != '' and flag != 0:
            sorted_path_list.append((1 + flag, second_page_path))
            first_page_path = ''
            second_page_path = ''
            flag += 2
        elif first_page_path != '' and second_page_path == '' and flag != 0:
            sorted_path_list.append((1 + flag, first_page_path))
            first_page_path = ''
            second_page_path = ''
            flag += 2

    return sorted_path_list
"""
    This Function writes the annoations in a xml format compatible with label me toolself.
    Args:
    data frame: --datafrmae

    Returns:
    Json String: --str
    """

def json_convertion(df, xml_path,form_type):
    input_form_type = 'CO_' + form_type
    global page_df

    img_list = df['path'].unique().tolist()
    group_df = df.groupby('path')

    sorted_paths_list = grouping_pages_paths(img_list, group_df)

    people_list = []
    vehicle_list = []
    citations_list = []
    incident = None
    # changes==============
    people_list_coord = []
    vehicle_list_coord = []
    incident_coord = None
    # =====================

    party_id = 1
    for pg_id, img in sorted_paths_list:
        page_df = group_df.get_group(img)

        if pg_id == 2 or pg_id == 4 or pg_id == 6:
            continue
            # party_id = other_party_details_extraction(people_list, vehicle_list, party_id)
        else:
            # incident, party_id = first_page_extraction(people_list, vehicle_list, party_id)
            incident, party_id , incident_coord = first_page_extraction(people_list, vehicle_list, party_id,
                                                            people_list_coord, vehicle_list_coord)
            citation_details_extraction(citations_list, people_list)
    

    for pg_id, img in sorted_paths_list:
        page_df = group_df.get_group(img)

        if pg_id == 2 or pg_id == 4 or pg_id == 6:
            d = 1
        else:
            property_owner_details_extraction(people_list, vehicle_list, party_id,
                                              people_list_coord, vehicle_list_coord)
            


    OwnerList = list(filter(lambda x: x.Person_Type == 'VEHICLE OWNER', people_list))
    DriverList = list(filter(lambda x: x.Person_Type == 'DRIVER', people_list))
    OtherPartyList = list(filter(lambda x: x.Person_Type != 'VEHICLE OWNER' and x.Person_Type != 'DRIVER', people_list))

    # changes=======================
    OwnerList_coord = list(filter(lambda x: x.Person_Type == 'VEHICLE OWNER', people_list_coord))
    DriverList_coord = list(filter(lambda x: x.Person_Type == 'DRIVER', people_list_coord))
    OtherPartyList_coord = list(filter(lambda x: x.Person_Type != 'VEHICLE OWNER' and x.Person_Type != 'DRIVER', people_list_coord))
    # ==============================

    same_as_name_address_checker.same_as_name_addrs_checker(OwnerList, DriverList, OtherPartyList,
                                                            OwnerList_coord, DriverList_coord, OtherPartyList_coord)
    
    if (incident != None):
        if (incident.Photographs_Taken == ''):
            del incident.Photographs_Taken
            # changes==================
            del incident_coord.Photographs_Taken
            # =========================

    if (not incident and not people_list and not vehicle_list):
        print('Invalid File received')
        return 'Invalid File received', 'invalid', ''

    report = Report(FormName="Universal", 
                    CountKeyed=44, 
                    Incident=incident, 
                    People=people_list,
                    Vehicles=vehicle_list, 
                    Citations=citations_list,
                    form_type = input_form_type)
    # changes======================
    report_coord = Report(FormName="Universal", 
                          CountKeyed=44, 
                          Incident=incident_coord, 
                          People=people_list_coord,
                          Vehicles=vehicle_list_coord, 
                          Citations=citations_list,
                          form_type = input_form_type)
    # =============================

    try:
        xml_patcher.patch_xml(xml_path, report)
        patcher.patch_incident_data(incident)
        patcher.patch_people_data(people_list)
    except:
        pass

    main_cls = MainCls(Report=report)
    # changes=======================
    main_cls_coord = MainCls(Report=report_coord)
    # ==============================
    # data = json.dumps(main_cls, default=lambda o: o.__dict__, indent=4)
    img_name = os.path.basename(df.iloc[0]['path']).split('_')[0]
    tif_name = img_name + '_CO.tif'

    return main_cls, tif_name , main_cls_coord


