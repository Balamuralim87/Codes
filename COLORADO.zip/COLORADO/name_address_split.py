"""
Created on March 27 2020
@author: Priyanga (203367)

This script is a utility to split name and address to "names, address, city, state, zipcode".
Usage: Could be used by calling in command prompt.
"""

import re
import COLORADO.text_extract as text_extract
import pandas as pd

"""
This Function using lookup of city and state, splits name and address into "names, address, city, state, zipcode".

Args:
address_text: string
              Name address text / address text to split.
city_lookup_path: string 
                  The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_lookup(address_text, city_lookup_path, is_text_has_name = False):

    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': '', 'phone_no': ''}
    state_list = ['AK','AL','AR','AZ','BC','CA','CO','CT','DC','DE','FL','GA','GU','HI','IA','ID','IL','IN','KS','KY','LA','MA',
                  'MD','ME','MI','MN','MO','MS','MT','NB','NC','ND','NE','NH','NJ','NM','NS','NV','NY','OH','OK','ON','OR','PA',
                  'PE','PQ','PR','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY','Alaska','Alabama','Arkansas',
                  'Arizona','British Columbia','California','Colorado','Connecticut','Dist.Of Columbia','Delaware','Florida',
                  'Georgia','Guam','Hawaii','Iowa','Idaho','Illinois','Indiana','Kansas','Kentucky','Louisiana','Massachusetts',
                  'Maryland','Maine','Michigan','Minnesota','Missouri','Mississippi','Montana','New Brunswick','North Carolina',
                  'North Dakota','Nebraska','New Hampshire','New Jersey','New Mexico','Nova Scotia','Nevada','New York',                  'Ohio',
                  'Oklahoma','Ontario','Oregon','Pennsylvania','Prince Edward','Quebec','Puerto Rico','Rhode Island',
                  'South Carolina','South Dakota','Tennessee','Texas','Utah','Virginia','Vermont','Washington','Wisconsin',
                  'West Virginia','Wyoming']

    city = ''
    state = ''
    zipcode = ''
    names = ''
    phone_no = ''

    with open(city_lookup_path, encoding='utf-8', errors='ignore') as f:
        city_lookup = f.readlines()
        city_lookup = [x.strip() for x in city_lookup]
    states = '|'.join(state_list)
    cities = '|'.join(city_lookup)
    cities = cities.replace(' ', '\s')

    if is_text_has_name:
        name_match = re.search('^(([A-Za-z\,?\s&-\.\/]+)(\,|\s))', address_text)
        if name_match:
            names = name_match.group(2)
            address_text = address_text.replace(name_match.group(1), '')

    phone_no_match = re.search('((\([0-9]+\)\s)([0-9]+(\-))[0-9]+)$', address_text, re.IGNORECASE)
    if phone_no_match:
        phone_no = phone_no_match.group(1)
        address_text = address_text.replace(phone_no_match.group(1), '')

    zipcode_match = re.search('((\s|,)([0-9\-]{5,})(\s|,)?)$', address_text, re.IGNORECASE)
    if zipcode_match:
        zipcode = zipcode_match.group(3)
        address_text = address_text.replace(zipcode_match.group(1), '')

    state_match = re.search('((\s|,)(' + states + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if state_match:
        state = state_match.group(3)
        address_text = address_text.replace(state_match.group(1), '')

    city_match = re.search('((\s|,|\\b)(' + cities + ')(\s|,)?)$', address_text, re.IGNORECASE)
    if city_match:
        city = city_match.group(3)
        address_text = address_text.replace(city_match.group(1), '')

    address = address_text
    address = address.strip(', ')

    add_dict.update({'names': names})
    add_dict.update({'address': address})
    add_dict.update({'city': city})
    add_dict.update({'state': state})
    add_dict.update({'zipcode': zipcode})
    add_dict.update({'phone_no': phone_no})

    return add_dict

"""
This Function using patterns, splits name and address into "names, address, city, state, zipcode".

Args:
address_text:       string
                    Name address text / address text to split.
                    
city_lookup_path:   string 
                    The text file path to the city lookup, it should have the data of each city separated by an enter mark.

Returns:
    The dictionary which contains splitted names, address city, state and zipcode.
"""

def name_address_split_using_pattern(address_text):
    add_dict = {'names': '', 'address': '', 'city': '', 'state': '', 'zipcode': ''}
    
    name_address_match = re.search("^([A-Za-z\,?\s&-\.\/]+)(\,?\s((([0-9\s]{2,}\s)?([A-Za-z0-9#\s]+))\,?\s([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9\s]{5,10}))?)$",
        address_text)
    address_match = re.search("^((([0-9]{2,}\s([A-Za-z0-9#\s]+))(\,|\s)([A-Za-z\s]+)\s?\,?\s([A-Z]{2}))(\,?\s([0-9]{5}))?)$", address_text)
    city_state_zip_match = re.search(r"^(([A-Za-z\s\,\-\.]+)(\s\,|\s|\,)([A-Z]{2})\s([0-9]{5,}))$", address_text)
    if name_address_match:
        name = name_address_match.group(1)
        name = name.strip(',')
        add_dict.update({'name': name})
        add_dict.update({'address': name_address_match.group(4)})
        add_dict.update({'city': name_address_match.group(7)})
        add_dict.update({'state': name_address_match.group(8)})
        add_dict.update({'zipcode': name_address_match.group(10)})
        return add_dict
    elif address_match:
        add_dict.update({'address': address_match.group(3)})
        add_dict.update({'city': address_match.group(6)})
        add_dict.update({'state': address_match.group(7)})
        add_dict.update({'zipcode': address_match.group(9)})
        return (add_dict)
    elif city_state_zip_match:
        add_dict.update({'city': city_state_zip_match.group(2)})
        add_dict.update({'state': city_state_zip_match.group(4)})
        add_dict.update({'zipcode': city_state_zip_match.group(5)})
        return (add_dict)
    else:
        return None

def name_split_using_pattern(name_text, business_name_lookup_path, name_order='', ischecked = False):
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    name_text = name_text.strip()
    name_text = re.sub('(\s*\-\s*)$', '', name_text)
    name_text = name_text.replace('.', '')
    # =====================================
    # Business name - logic
    if ischecked == True:
        add_dict.update({'last_name': name_text.upper()})
        add_dict.update({'name': name_text.upper()})
        return add_dict
    
    with open(business_name_lookup_path) as f:
        business_name_lookup = f.readlines()
        business_name_lookup = [x.strip() for x in business_name_lookup]
    business_names = '|'.join(business_name_lookup)
    business_names = business_names.replace(' ', '\s')
    input_words = name_text.split()
    for word in input_words:
        business_name_match = re.search('(\\b(' + business_names + ')\\b)', word, re.IGNORECASE)
        if business_name_match:
            add_dict.update({'last_name': name_text.upper()})
            add_dict.update({'name': name_text.upper()})
            return add_dict
        
    suffix_list = ['JR', 'BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC', 'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                   'ESQ', 'II', 'III', 'IV', 'INC', 'JD', 'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                   'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM', 'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                   'USCG', 'USMC', 'USMCR', '3RD', '4TH']
    suffix_found = ''
    for suffix in suffix_list:
        suffix_match = re.search(r'\b' + suffix + r'\b', name_text, re.IGNORECASE)
        if suffix_match:
            suffix_found = suffix_match.group(0)
            name_text = re.sub('(\s)' + suffix_match.group(0), '', name_text, re.IGNORECASE)
            name_text = re.sub(suffix_match.group(0) + '(\s)', '', name_text, re.IGNORECASE)
            break

    name_match_1 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_2 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_3 = re.search("^(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_4 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text)  
    name_match_5 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)  
    name_match_6 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+\s+[A-Za-z]+))$", name_text)
    name_match_7 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)
    name_match_8 = re.search("^(([A-Za-z]+)\s*,\s*([A-Za-z]+))$", name_text)
    name_match_9 = re.search("^(([A-Za-z]+),\s*([A-Za-z]+)\s+([A-Z]\s?\.\s?[A-Za-z]+))$", name_text) 
    name_match_10 = re.search("^(([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{3,})\s+([A-Za-z]{1}))$", name_text)  
    name_match_11 = re.search("^(([A-Za-z]{3,}\s*-\s*[A-Za-z]{3,})\s+([A-Za-z]{3,}))$", name_text) 
    name_match_12 = re.search("^(([A-Za-z]+\s+[A-Za-z]+)\s*,\s*([A-Za-z]+)\s+([A-Za-z]+))$", name_text) 
    name_match_13 = re.search("^(([A-Za-z]+)\s*\,\s*([A-Za-z]+\s+[A-Za-z]+)\s*\,\s*([A-Za-z]+))$", name_text)
    name_match_14 = re.search("^(([A-Za-z]+)\s*(\-|\&)\s*([A-Za-z]+))$", name_text)
    name_match_15 = re.search("^(([A-Za-z]+)\s([A-Za-z]+)(\s?\;\s?[A-Z]{2})?)$",name_text)
    name_match_16 = re.search("^(([A-Za-z]+)\s([A-Za-z]+)\s([A-Za-z]+)(\s?\;\s?[A-Z]{2})?)$",name_text)
    name_match_17 = re.search("^(([A-Za-z\-]+)\s+([A-Za-z\-]+))$", name_text)
    name_match_18 = re.search("^(([A-Za-z\-]+)\s+([A-Za-z\-]+)\s+([A-Za-z\-]+))$", name_text)
    name_match_19 = re.search("^(([A-Za-z]+\-[A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+\s+[A-Za-z]+))$", name_text)
    name_match_20 = re.search("^(([A-Za-z]+)\s+(([A-Za-z]+)\s+([A-Za-z]+)\s+([A-Za-z]+)))\s*([A-Za-z]+)$",
                    name_text)

    if name_match_1:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_1, add_dict)
        else:
            add_dict.update({'first_name': name_match_1.group(2).upper()})
            add_dict.update({'last_name': name_match_1.group(3).upper()})
    elif name_match_2:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_2, add_dict)
        else:
            add_dict.update({'first_name': name_match_2.group(2).upper()})
            add_dict.update({'middle_name': name_match_2.group(3).upper()})
            add_dict.update({'last_name': name_match_2.group(4).upper()})
    elif name_match_10:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_10, add_dict)
        else:
            add_dict.update({'first_name': name_match_10.group(2).upper()})
            add_dict.update({'middle_name': name_match_10.group(3).upper() + ' ' + name_match_10.group(5).upper()})
            add_dict.update({'last_name': name_match_10.group(4).upper()})
    elif name_match_3:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_3, add_dict)
        else:
            add_dict.update({'first_name': name_match_3.group(2).upper()})
            add_dict.update({'middle_name': name_match_3.group(3).upper()})
            add_dict.update({'last_name': name_match_3.group(4).upper() + ' ' + name_match_3.group(5).upper()})
    elif name_match_4:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_4, add_dict)
        else:
            add_dict.update({'first_name': name_match_4.group(3).upper()})
            add_dict.update({'middle_name': name_match_4.group(4).upper()})
            add_dict.update({'last_name': name_match_4.group(2).upper()})
    elif name_match_5:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_5, add_dict)
        else:
            add_dict.update({'first_name': name_match_5.group(2).upper()})
            add_dict.update({'middle_name': name_match_5.group(3).upper()})
            add_dict.update({'last_name': name_match_5.group(4).upper()})
    elif name_match_6:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_6, add_dict)
        else:
            add_dict.update({'first_name': name_match_6.group(3).upper()})
            add_dict.update({'middle_name': name_match_6.group(4).upper()})
            add_dict.update({'last_name': name_match_6.group(2).upper()})
    elif name_match_7:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_7, add_dict)
        else:
            add_dict.update({'first_name': name_match_7.group(3).upper()})
            add_dict.update({'last_name': name_match_7.group(2).upper()})
    elif name_match_8:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_8, add_dict)
        else:
            add_dict.update({'first_name': name_match_8.group(3).upper()})
            add_dict.update({'last_name': name_match_8.group(2).upper()})
    elif name_match_9:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_9, add_dict)
        else:
            add_dict.update({'first_name': name_match_9.group(3).upper()})
            add_dict.update({'middle_name': name_match_9.group(4).upper()})
            add_dict.update({'last_name': name_match_9.group(2).upper()})
    elif name_match_11:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_11, add_dict)
        else:
            add_dict.update({'first_name': name_match_11.group(3).upper()})
            add_dict.update({'last_name': name_match_11.group(2).upper()})
    elif name_match_12:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_12, add_dict)
        else:
            add_dict.update({'first_name': name_match_12.group(3).upper()})
            add_dict.update({'middle_name': name_match_12.group(4).upper()})
            add_dict.update({'last_name': name_match_12.group(2).upper()})
    elif name_match_13:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_13, add_dict)
        else:
            add_dict.update({'first_name': name_match_13.group(2).upper()})
            add_dict.update({'middle_name': name_match_13.group(3).upper()})
            add_dict.update({'last_name': name_match_13.group(4).upper()})
    elif name_match_14:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_14, add_dict)
        else:
            add_dict.update({'first_name': name_match_14.group(2).upper()})
            add_dict.update({'last_name': name_match_14.group(4).upper()})
    elif name_match_15:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_15, add_dict)
        else:
            add_dict.update({'first_name': name_match_15.group(2).upper()})
            add_dict.update({'last_name': name_match_15.group(3).upper()})
    elif name_match_16:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_16, add_dict)
        else:
            add_dict.update({'first_name': name_match_16.group(2).upper()})
            add_dict.update({'middle_name': name_match_16.group(3).upper()})
            add_dict.update({'last_name': name_match_16.group(4).upper()})
    elif name_match_17:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_17, add_dict)
        else:
            add_dict.update({'first_name': name_match_17.group(2).upper()})
            add_dict.update({'last_name': name_match_17.group(3).upper()})
    elif name_match_18:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_18, add_dict)
        else:
            add_dict.update({'first_name': name_match_18.group(2).upper()})
            add_dict.update({'middle_name': name_match_18.group(3).upper()})
            add_dict.update({'last_name': name_match_18.group(4).upper()})
    elif name_match_19:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_19, add_dict)
        else:
            add_dict.update({'first_name': name_match_19.group(4).upper()})
            add_dict.update({'middle_name': name_match_19.group(3).upper()})
            add_dict.update({'last_name': name_match_19.group(2).upper()})
    elif name_match_20:
        if name_order != '':
            name_split_in_given_order(name_order, name_match_20, add_dict)
        else:
            add_dict.update({'first_name': name_match_20.group(2).upper()})
            add_dict.update({'last_name': name_match_20.group(3).upper() + ' ' +
                             name_match_20.group(7).upper()})
    else:
        add_dict.update({'last_name': name_text.upper()})

    add_dict.update({'suffix': suffix_found.upper()})
    add_dict.update({'name': name_text.upper()})

    return add_dict

def name_split_in_given_order(name_order, name_match, add_dict):
    if name_order == 'FML':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'last_name': name_match.group(3).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'middle_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
        elif len(name_match.groups()) == 7:
            add_dict.update({'first_name': name_match.group(2).upper()})
            add_dict.update({'last_name': name_match.group(3).upper() + ' ' + name_match.group(7).upper()})
    if name_order == 'LFM':
        if len(name_match.groups()) == 3:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 4:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 5:
            add_dict.update({'first_name': name_match.group(3).upper()})
            add_dict.update({'middle_name': name_match.group(4).upper() + ' ' + name_match.group(5).upper()})
            add_dict.update({'last_name': name_match.group(2).upper()})
        elif len(name_match.groups()) == 7:
            add_dict.update({'first_name': name_match.group(7).upper()})
            add_dict.update({'last_name': name_match.group(1).upper()})

def find_address_text(xml_tree, bb_coord, c, label):
    add_list = []
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        coord = (elem.attrib['xMin'], elem.attrib['yMin'], elem.attrib['xMax'], elem.attrib['yMax'])
        ocr_coord = text_extract.update_coord(coord, c)
        result_text = text_extract.check_text_in_BB(ocr_coord, bb_coord, elem.text)
        if (result_text is not None and result_text != ''):
            if 'OwnerLesseeNameAddress' in label and re.match("^([0-9]+)$", result_text):
                return add_list
            add_list.append([float(elem.attrib['xMin']), result_text])
    return (add_list)

def find_text_lines(xml_tree, bb_coord, c):
    new_df = pd.DataFrame(columns = ['xMin', 'yMin', 'text'])
    ymin_list = []
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        coord = (elem.attrib['xMin'], elem.attrib['yMin'], elem.attrib['xMax'], elem.attrib['yMax'])
        ocr_coord = text_extract.update_coord(coord, c)
        result_text = text_extract.check_text_in_BB(ocr_coord, bb_coord, elem.text)
        if (result_text is not None and result_text != ''):
            # new_row = pd.DataFrame({'xMin': float(elem.attrib['xMin']), 'yMin': float(elem.attrib['yMin']), 'text': result_text},index=[0,1,2])
            new_df = new_df.append({'xMin': float(elem.attrib['xMin']), 'yMin': float(elem.attrib['yMin']), 'text': result_text}, ignore_index=True)
            if float(elem.attrib['yMin']) not in ymin_list:
                ymin_list.append(float(elem.attrib['yMin']))

    # new_df = pd.DataFrame(add_list)
    ymin_list.sort()
    sorted_df = new_df.sort_values(by=['yMin', 'xMin'])
    group_df = sorted_df.groupby('yMin')
    line_list = []
    for ymin in ymin_list:
        temp_df = group_df.get_group(ymin)
        line = ' '.join(temp_df['text'])
        line_list.append(line)
    return (line_list)

def find_text_lines_new(xml_tree, bb_coord, c):
    new_df = pd.DataFrame(columns = ['xMin', 'yMin', 'text'])
    for elem in xml_tree.findall('.//page/flow/block/line/word'):
        coord = (elem.attrib['xMin'], elem.attrib['yMin'], elem.attrib['xMax'], elem.attrib['yMax'])
        ocr_coord = text_extract.update_coord(coord, c)
        result_text = text_extract.check_text_in_BB(ocr_coord, bb_coord, elem.text)
        if (result_text is not None and result_text != ''):
            new_df = new_df.append({'xMin': float(elem.attrib['xMin']), 'yMin': float(elem.attrib['yMin']),
                                    'xMax': float(elem.attrib['xMax']), 'yMax': float(elem.attrib['yMax']),
                                    'text': result_text}, ignore_index=True)

    sorted_df = new_df.sort_values(by=['xMin'])
    line_desc = {'ymin': '', 'line': ''}
    line_list = []
    line_df = pd.DataFrame(columns=['yMin', 'line'])
    if len(sorted_df) > 1:
        lines_count = []

        if sorted_df.iloc[0].yMin == sorted_df.iloc[1].yMin:
            for i, row in sorted_df.iterrows():
                line_list.append(row.text)
            return (line_list)

        lines_count.append(sorted_df.iloc[0])
        lines_count.append(sorted_df.iloc[1])
        for line_count in lines_count:
            line = ''
            ymin = line_count.yMin
            for i, word in sorted_df.iterrows():
                bb_coord_new  = (line_count.xMin, line_count.yMin,
                             bb_coord[2], line_count.yMax)
                coord = (word.xMin, word.yMin, word.xMax, word.yMax)
                result_text = text_extract.check_text_in_BB(coord, bb_coord_new, word.text)
                if (result_text is not None and result_text != ''):
                    line += result_text + ' '
            line_df = line_df.append({'yMin': ymin, 'line': line}, ignore_index=True)
        sorted_line_df = line_df.sort_values(by = ['yMin'])
        for i, line in sorted_line_df.iterrows():
            line_list.append(line.line)
    return (line_list)




