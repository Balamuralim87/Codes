"""
Created on 22/04/2023

@author: e408118: Supriya Raj
"""

import re
from datetime import datetime

import pandas as pd

from COLORADO.config import Config

def get_predefined_labels(key):
    """
    Function holds predefined labels for Incident, People and Vehicle

    Args:
        key (str): Key of predefined_labels

    Returns:
        List: Value of predefined_labels
    """
    try:
        return Config.FORM_3_PREDEFINED_LABELS[key]
    except:
        pass
    return []

def get_df_value(d_frame, label_name, index=0):
    """
    Function retrive value from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.

    Returns:
        str: Value from df (predicted dataframe)
    """
    try:
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])

        data_df = data_df.loc[data_df['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            value = data_df['text'].iloc[index]
            if str(value) != 'nan':
                return value.strip()
    except:
        pass
    return ''

def get_case_identifier(text):
    """
    Process the case Identifier

    Args:
        text (str): case Identifier

    Returns:
        str: case Identifier
    """
    text_list=[]
    try:
        if text.strip():
            text_list = text.split(" ")
            text = text_list[-1].upper().strip()
            return text
    except:
        pass
    return 'UNK'

def get_crash_date(text):
    """
    Extracts the crash date and time

    Args:
        text (str): crash date and time

    Returns:
        str, str: crash date and time
    """
    try:
        date = re.findall(r'\s*(\d{1,2}\s*\/\s*\d{1,2}\s*\/*\s*\d{2})', text, re.IGNORECASE)
        if date:
            date = clean_date(date[0])
            if date =='':
                date = clean_date(date[-1])
        else:
            date = ''
        time = re.findall(r'\s*(\d{1,2}\s*:\s*\d{2}\s*:\s*\d{2})', text, re.IGNORECASE)
        try:
            if time:
                time = time[0]
                time = time[:5]
        except:
            time = ''
            pass
        return date.strip(), time.strip()
    except:
        pass
    return '', ''

def get_vehicle_owner(d_frame):
    """
    Returns list of vehicle owner name
    Args:
        d_frame (dataframe): d_frame

    Returns:
        list: vehicle owner name
    """
    first_name=''
    middle_name=''
    last_name=''
    v_o_name_list=[]
    try:
        v_owner_count = get_count(d_frame,'vehicle_owner')
        for index in range(v_owner_count):
            first_name, middle_name, last_name, suffix = filter_name(
                get_df_value(d_frame, 'Vehicle_Owner_First_Name', index),get_df_value(
                    d_frame, 'Vehicle_Owner_Mid_Name', index),get_df_value(
                        d_frame, 'Vehicle_Owner_Last_Name', index))
            v_o_name_list.append((first_name + " " +middle_name + " " +last_name + " " +suffix))
        return v_o_name_list
    except:
        pass
    return []

def remove_extra_space(text):
    try:
        if '-' in text:
            return text.replace(' ', '')
    except:
        pass
    return text


def filter_name(first_name,mid_name,last_name):
    """
    Filters first , middle and last name
    Args:
        first_name (str): unfiltered first name
        mid_name (str): unfiltered middle name
        last_name (str): unfiltered last name

    Returns:
        str,str,str,str : filtered first, middle , lastname and suffix
    """
    suffix_list = ['JR', 'BVM', 'CFRE', 'CLU', 'CPA', 'CSC', 'CSJ', 'DC',
                    'DD', 'DDS', 'DMD', 'DO', 'DVM', 'EDD',
                    'ESQ', 'II', 'III', 'IV', 'INC', 'JD',
                    'LLD', 'LTD', 'MD', 'OD', 'OSB', 'PC', 'PE', 'PHD',
                    'RET', 'RGS', 'RN', 'RNC', 'SHCJ', 'SJ', 'SNJM',
                    'SR', 'SSMO', 'USA', 'USAF', 'USAFR', 'USAR',
                    'USCG', 'USMC', 'USMCR', '3RD', '4TH', 'ER']
    last_name_suffix_list=[]
    suffix=''
    try:
        first_name = first_name.upper().replace("FIRST","").replace(":","").strip()
        mid_name = mid_name.upper().replace("MID","").replace(":","").strip()
        last_name = last_name.upper().replace("LAST","").replace(":","").strip()
        last_name_suffix_list = last_name.split(" ")
        for name in last_name_suffix_list:
            if name in suffix_list:
                suffix=name
                last_name=last_name.replace(suffix,"").replace(" ","").strip()
        return (remove_extra_space(first_name), remove_extra_space(mid_name),
                remove_extra_space(last_name), suffix)
    except:
        pass
    return (remove_extra_space(first_name), remove_extra_space(mid_name),
                remove_extra_space(last_name), suffix)

def get_address(text):
    """
    Filters address
    Args:
        text (str): unfiltered address

    Returns:
        str: filtered address
    """
    address_text=''
    try:
        address_text = text.lower()
        address_text = address_text.replace('address', '').rsplit(':', 1)[-1]
        address_text = ' '.join(address_text.split()).strip()
        text = re.sub('[^a-zA-Z0-9/]+', ' ', address_text)
        return text.upper().strip()
    except:
        pass
    return text

def get_phone(text):
    """
    Filters phone number
    Args:
        text (str): unfiltered phone number

    Returns:
        str: filtered phone number (text)
    """
    try:
        text = text.upper()
        text = text.replace("PHONE","").replace(":","").replace("(","").replace(")","-")
        return text.strip()
    except:
        pass
    return text

def get_city_state_zip(text):
    """
    Filters phone number
    Args:
        text (str): unfiltered city_state_zip text

    Returns:
        str,str,str: filtered city, state, zipcode
    """
    text_list=[]
    city=''
    state=''
    zipcode=''
    try:
        text = text.upper()
        text = text.replace("CITY","").replace(":","").replace(",","").strip()
        text_list = text.split(" ")
        city = text_list[0].strip()
        state = text_list[1].strip()
        zipcode = text_list[2].strip()
        return city, state, zipcode
    except:
        pass
    return '','',''
def get_dob(text):
    """
    Filters phone number
    Args:
        text (str): unfiltered date of birth

    Returns:
        str: filtered ate of birth (text)
    """
    date=''
    try:
        date = re.findall(r'\s*(\d{1,2}\s*\/\s*\d{1,2}\s*\/*\s*\d{2})', text, re.IGNORECASE)
        if date:
            date = clean_date(date[-1])
        else:
            date = ''
        return date.strip()
    except:
        pass
    return ''

def get_index(d_frame,driver_count,vehicle_owner_list):
    """
    Filters phone number
    Args:
        d_frame :dataFrame
        driver_count (int): driver count
        vehicle_owner_list (list): vehicle_owner_list

    Returns:
        list,list,list: driver_index,other_index,owner_index
    """
    driver_name_list =[]
    driver_index,other_index=[],[]
    owner_index =[]
    try:
        for index in range(driver_count):
            driver_first_name, driver_middle_name, driver_last_name,suffix = filter_name(
                get_df_value(d_frame, 'Victim_First_Name', index),get_df_value(
                    d_frame, 'Victim_Mid_Name', index), get_df_value(
                        d_frame, 'Victim_Last_Name', index))
            name = (
                driver_first_name + " " + driver_middle_name + " " + driver_last_name + " " +suffix)
            victim_type = get_df_value(d_frame, 'Victim_Offender_Type', index)
            if name not in vehicle_owner_list:
                if name not in driver_name_list:
                    if 'OWNER' not in victim_type:
                        if ('VICTIM' in victim_type) or ('OFFENDER' in victim_type) or (
                            'SUSPECT' in victim_type):
                            driver_name_list.append(name)
                            driver_index.append(index)
                        else:
                            other_index.append(index)
                    else:
                        owner_index.append(index)
        return driver_index,other_index, owner_index
    except:
        pass
    return [],[]

def get_p_type(text):
    """
    Extracts person type
    Args:
        text (str): unfiltered person type

    Returns:
        str: filtered person type (text)
    """
    p_type=''
    try:
        if 'WITNESS' in text.upper():
            p_type = 'WITNESS'
        elif 'PASSANGER' in text.upper():
            p_type = 'PASSANGER'
        else:
            p_type = 'UNKNOWN'
        return p_type
    except:
        pass
    return ''

def address_split_using_lookup(address_text, city_lookup_path, is_incident=False):
    """
    splits Address, City, State, Zipcode from text

    Args:
        address_text (str): address_text
        city_lookup_path (str): location of Cities
        is_incident (boolean, optional): is_incident

    Returns:
        dict: add_dict
    """
    add_dict = {'address': '', 'city': '', 'state': '', 'zipcode': ''}
    if address_text:
        try:
            city = ''
            state = ''
            zipcode = ''

            address_text = address_text.lower()
            address_text = address_text.replace(":","").replace('address', '').strip()

            zipcode = address_text.split()[-1]
            if zipcode.isnumeric():
                address_text = address_text.replace(zipcode, '').strip()
            zipcode = re.sub('[^0-9]+', '', zipcode)

            address_text = re.sub('[^a-zA-Z0-9/]+', ' ', address_text)

            with open(city_lookup_path, encoding='utf-8', errors='ignore') as file:
                city_lookup = file.readlines()
                city_lookup = [x.encode('ascii', 'ignore').decode().strip() for x in city_lookup]
            file.close()

            cities = '|'.join([i.lower() for i in city_lookup])

            states = '|'.join([i.lower() for i in Config.STATE_LIST])
            state_match = re.search(r'((\s|,)(' + states + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if state_match:
                state_match = state_match.group(3)
                state = state_match
                address_text = re.sub(r'\s+'+state_match, '', address_text).strip()
            city_match = re.search(r'((\s|,)(' + cities + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if city_match:
                city = city_match.group(3)
                address_text = re.sub(r'\s+'+city, '', address_text).strip()

            if is_incident:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z/]+', ' ', address_text).strip().split())
            else:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', address_text).strip().split())

            add_dict.update({'address': address_text.upper()})
            add_dict.update({'city': city.upper()})
            add_dict.update({'state': state.upper()})
            add_dict.update({'zipcode': zipcode})
        except:
            pass
    return add_dict

def get_count(d_frame, key):
    """
    Returns count of the given key

    Args:
        d_frame (dataframe): d_frame
        key (str): key

    Returns:
        int: Total count
    """
    max_count = 0
    try:
        labels = get_predefined_labels(key)
        for label in labels:
            count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                (label.lower())) & (d_frame['text'].str.strip()), 'label'])
            max_count = max(max_count, count)
        return max_count
    except:
        pass
    return 0

def clean_date(text):
    """
    Cleans the date

    Args:
        text (str): text

    Returns:
        str: updated text
    """
    try:
        text = text.strip().replace(' ', '')
        text = text.split('/')
        if len(text) > 1:
            if len(text[0]) < 2:
                text[0] = '0' + text[0]
            if len(text[0]) == 3:
                text[0] = text[0][1:]
            if len(text[1]) < 2:
                text[1] = '0' + text[1]
            if len(text[2]) < 3:
                if int(text[2]) > int(str(datetime.today().year)[-2:]):
                    text[2] = '19' + text[2]
                else:
                    text[2] = '20' + text[2]
            return '/'.join(text).replace(' ', '')
    except:
        pass
    return ''

def get_street(text):
    """
    Splits the Loss street and Loss Cross street from text

    Args:
        text (str): text

    Returns:
        str, str: Loss street and Loss Cross street from text
    """
    try:
        text = text.strip().lower()
        if '&' in text:
            splitted_text = text.split('&')
            return splitted_text[0].strip().upper(), splitted_text[1].strip().upper()
    except:
        pass
    return text.upper(), ''

def delete_invalid_keys(people):
    """
    Deletes keys that not required from class

    Args:
        people (class): People
    """
    try:
        del people.Alcohol_Use_Suspected
        del people.Marijuana_Use_Suspected
        del people.Drug_Use_Suspected
        del people.Contributing_Circumstances_Person
        del people.Non_Motorist_Actions_At_Time_Of_Crash
        del people.Safety_Equipment_Restraint
        del people.Safety_Equipment_Available_Or_Used
        del people.Safety_Equipment_Helmet
        del people.Ejection
    except:
        pass

def get_vin(text):
    """
    Returns filtered vin

    Args:
        text (str): unfiltered vin text

    Returns:
        str: filtered vin text
    """
    vin=''
    try:
        vin=text.upper().replace("VIN","").replace(":","").replace(" ","")
        return vin.strip()
    except:
        pass
    return ''

def get_make(text):
    """
    Returns filtered make

    Args:
        text (str): unfiltered make text

    Returns:
        str: filtered make text
    """
    make=''
    try:
        make=text.upper().replace("MAKE","").replace(":","")
        return make.strip()
    except:
        pass
    return ''

def get_model_year(text):
    """
    Returns filtered model year

    Args:
        text (str): unfiltered model year text

    Returns:
        str: filtered model year text
    """
    model_year=''
    try:
        model_year=text.upper().replace("VEHICLE","").replace("YEAR","").replace(":","")
        return model_year.strip()
    except:
        pass
    return ''

def get_license_plate(text):
    """
    Returns filtered license_plate

    Args:
        text (str): unfiltered license_plate text

    Returns:
        str: filtered license_plate text
    """
    license_plate=''
    try:
        license_plate=text.upper().replace("LICENSE","").replace("PLATE","").replace(":","")
        return license_plate.strip()
    except:
        pass
    return ''

def get_license_state(text):
    """
    Returns filtered license_state

    Args:
        text (str): unfiltered license_state text

    Returns:
        str: filtered license_state text
    """
    license_state=''
    try:
        license_state=text.upper().replace("STATE","").replace(":","")
        return license_state.strip()
    except:
        pass
    return ''

def get_model(text):
    """
    Returns filtered model

    Args:
        text (str): unfiltered model text

    Returns:
        str: filtered model text
    """
    model=''
    try:
        model=text.upper().replace("MODEL","").replace(":","")
        return model.strip()
    except:
        pass
    return ''


