"""
Created on 21/04/2023

@author: e408118: Supriya Raj
"""

import sys

from COLORADO.form_3 import co_form_3_postprocess as postprocessor

class Incident():
    """
    Class defining Incident Report
    """
    def __init__(self, case_identifier='', crash_date='', loss_street='', crash_time='',
        loss_cross_street = '', crash_city=''):
        """
        Initialize the Incident Report's objects

        Args:
            case_identifier (str, optional): case_identifier. Defaults to ''.
            crash_date (str, optional): crash_date. Defaults to ''.
            loss_street (str, optional): loss_street. Defaults to ''.
            crash_time (str, optional): crash_time. Defaults to ''.
            loss_cross_street (str, optional): loss_cross_street. Defaults to ''.
            crash_city (str, optional): crash_city. Defaults to ''.
        """
        self.Case_Identifier = case_identifier
        self.State_Report_Number = ''
        self.Crash_Date = crash_date
        self.Crash_Time = crash_time
        self.Loss_State_Abbr = 'CO'
        self.Crash_City = crash_city
        self.Report_Type_Id = ''
        self.Loss_Street = loss_street
        self.Loss_Cross_Street = loss_cross_street
        self.Latitude = ''
        self.Longitude = ''
        self.Gps_Other = ''
        self.Weather_Condition = ''
        self.Road_Surface_Condition = ''

def incident_extraction(data_frame,city_lookup_path):
    """
    Passes Incident Report data to the Incident Class

    Args:
        data_frame (DataFrame): Predicted DataFrame
        city_lookup_path (str): city_lookup_path

    Returns:
        List : Incident Report List
    """
    try:
        case_identifier = postprocessor.get_case_identifier(postprocessor.get_df_value(
            data_frame, 'Case_Identifier'))
        crash_date, crash_time = postprocessor.get_crash_date(
            postprocessor.get_df_value(data_frame, 'Crash_Date_Time'))
        crash_location=postprocessor.get_df_value(data_frame, 'Crash_Location')
        crash_location_dict = postprocessor.address_split_using_lookup(
            crash_location, city_lookup_path)
        city = crash_location_dict['city']
        loss_street, loss_cross_street = postprocessor.get_street(
            crash_location_dict['address'])
        incident_report = Incident(
                            case_identifier = case_identifier,
                            crash_date = crash_date,
                            loss_street = loss_street,
                            loss_cross_street = loss_cross_street,
                            crash_city = city,
                            crash_time = crash_time
                            )
        return incident_report
    except:
        pass
    return []

class People():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', person_type='', first_name='',
        middle_name='', last_name='', suffix='', address='', state='', city='', zip_code='',
        date_of_birth='', home_phone='', driver_license_number=''):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.
            person_type (str, optional): person_type. Defaults to ''.
            first_name (str, optional): first_name. Defaults to ''.
            middle_name (str, optional): middle_name. Defaults to ''.
            last_name (str, optional): last_name. Defaults to ''.
            suffix (str, optional): suffix. Defaults to ''.
            address (str, optional): address. Defaults to ''.
            state (str, optional): state. Defaults to ''.
            city (str, optional): city. Defaults to ''.
            zip_code (str, optional): zip_code. Defaults to ''.
            date_of_birth (str, optional): date_of_birth. Defaults to ''.
            home_phone (str, optional): home_phone. Defaults to ''.
            driver_license_number (str, optional): driver_license_number. Defaults to ''.
        """
        self.Party_Id = party_id
        self.Person_Type = person_type
        self.Unit_Number = unit_number
        self.First_Name = first_name
        self.Middle_Name = middle_name
        self.Last_Name = last_name
        self.Name_Suffix = suffix
        self.Address = address
        self.Address2 = ''
        self.State = state
        self.City = city
        self.Zip_Code = zip_code
        self.Home_Phone = home_phone
        self.Date_Of_Birth = date_of_birth
        self.Drivers_License_Number = driver_license_number
        self.Drivers_License_Jurisdiction = ''
        self.Injury_Status = ''
        self.Alcohol_Use_Suspected = ''
        self.Marijuana_Use_Suspected = ''
        self.Drug_Use_Suspected = ''
        self.Contributing_Circumstances_Person = ''
        self.Non_Motorist_Actions_At_Time_Of_Crash = ''
        self.Safety_Equipment_Restraint = ''
        self.Safety_Equipment_Available_Or_Used = ''
        self.Safety_Equipment_Helmet = ''
        self.Ejection = ''

def get_people(d_frame, index, person_type='', party_id='', unit_number='',driver_exist=False,flag=False):
    """
    Return People class

    Args:
        d_frame (dataframe): Predicted Dataframe
        index (int): index
        person_type (str): Person Type
        party_id (int): party_id
        unit_number (str, optional): unit_number
        driver_exist (bool,optional): if driver details is present then true else false.
        flag (bool,optional): if vehicle owner detail present in owner list but not in
                                vehicle owner list then True else False

    Returns:
        class: People
    """
    person = People()
    try:
        if person_type == 'VEHICLE OWNER' and flag is False:
            first_name, middle_name, last_name, suffix = postprocessor.filter_name(
                postprocessor.get_df_value(
                    d_frame, 'Vehicle_Owner_First_Name', index),postprocessor.get_df_value(
                    d_frame, 'Vehicle_Owner_Mid_Name', index), postprocessor.get_df_value(
                        d_frame, 'Vehicle_Owner_Last_Name', index))
            address = postprocessor.get_address(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner_Address', index))
            phone = postprocessor.get_phone(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner_Home_Phone', index))
            city,state,zipcode=  postprocessor.get_city_state_zip(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner_City_State_Zip', index))
            dob = postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner_DOB', index))
            license_number =  postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Vehicle_Owner_License', index))
        elif person_type == 'VEHICLE OWNER' and flag is True:
            first_name, middle_name, last_name, suffix = postprocessor.filter_name(
                postprocessor.get_df_value(
                    d_frame, 'Victim_First_Name', index),postprocessor.get_df_value(
                    d_frame, 'Victim_Mid_Name', index), postprocessor.get_df_value(
                        d_frame, 'Victim_Last_Name', index))
            address = postprocessor.get_address(
                postprocessor.get_df_value(d_frame, 'Victim_Address', index))
            phone = postprocessor.get_phone(
                postprocessor.get_df_value(d_frame, 'Victim_Home_Phone', index))
            city,state,zipcode=  postprocessor.get_city_state_zip(
                postprocessor.get_df_value(d_frame, 'Victim_City_State_Zip', index))
            dob = postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Victim_DOB', index))
            license_number =  postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Victim_License', index))
        elif person_type == 'DRIVER':
            if driver_exist is True:
                first_name, middle_name, last_name, suffix = postprocessor.filter_name(
                    postprocessor.get_df_value(
                        d_frame, 'Victim_First_Name', index),postprocessor.get_df_value(
                        d_frame, 'Victim_Mid_Name', index), postprocessor.get_df_value(
                            d_frame, 'Victim_Last_Name', index))
                address = postprocessor.get_address(
                    postprocessor.get_df_value(d_frame, 'Victim_Address', index))
                phone = postprocessor.get_phone(
                    postprocessor.get_df_value(d_frame, 'Victim_Home_Phone', index))
                city,state,zipcode=  postprocessor.get_city_state_zip(
                    postprocessor.get_df_value(d_frame, 'Victim_City_State_Zip', index))
                dob = postprocessor.get_dob(
                    postprocessor.get_df_value(d_frame, 'Victim_DOB', index))
                license_number =  postprocessor.get_dob(
                    postprocessor.get_df_value(d_frame, 'Victim_License', index))
            else:
                first_name=''
                middle_name=''
                last_name=''
                suffix = ''
                address=''
                phone=''
                city,state,zipcode='','',''
                dob=''
                license_number=''
        else:
            first_name, middle_name, last_name,suffix = postprocessor.filter_name(
                    postprocessor.get_df_value(
                        d_frame, 'Victim_First_Name', index),postprocessor.get_df_value(
                        d_frame, 'Victim_Mid_Name', index), postprocessor.get_df_value(
                            d_frame, 'Victim_Last_Name', index))
            address = postprocessor.get_address(
                postprocessor.get_df_value(d_frame, 'Victim_Address', index))
            phone = postprocessor.get_phone(
                postprocessor.get_df_value(d_frame, 'Victim_Home_Phone', index))
            city,state,zipcode=  postprocessor.get_city_state_zip(
                postprocessor.get_df_value(d_frame, 'Victim_City_State_Zip', index))
            dob = postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Victim_DOB', index))
            license_number =  postprocessor.get_dob(
                postprocessor.get_df_value(d_frame, 'Victim_License', index))
        person = People(party_id = str(party_id),
                    unit_number = str(unit_number),
                    person_type = person_type,
                    first_name = first_name,
                    middle_name = middle_name,
                    last_name = last_name,
                    suffix = suffix,
                    address = address,
                    state = state,
                    city = city,
                    zip_code = zipcode,
                    home_phone = phone,
                    date_of_birth = dob,
                    driver_license_number = license_number
                    )
    except:
        pass
    return person

def people_extraction(d_frame):
    """
    Passes People data to the People Class

    Args:
        d_frame (DataFrame): Predicted DataFrame

    Returns:
        List : People List
    """
    try:
        party_id = 1
        unit_number = 1
        people_list = []
        vehicle_owner_list = postprocessor.get_vehicle_owner(d_frame)
        owner_count = postprocessor.get_count(d_frame, 'owner')
        driver_count = postprocessor.get_count(d_frame, 'driver')
        driver_index,other_index,owner_index= postprocessor.get_index(
            d_frame,driver_count,vehicle_owner_list)
        for index in range(owner_count):
            if index+1>len(driver_index):
                driver_exist=False
                d_index= -1
            else:
                driver_exist=True
                d_index=driver_index[index]
            owner = get_people(d_frame=d_frame, index=index, person_type='VEHICLE OWNER',
                        party_id=party_id, unit_number=unit_number)
            driver = get_people(d_frame=d_frame, index=d_index, person_type='DRIVER',
                        party_id=party_id+1, unit_number=unit_number,driver_exist=driver_exist)
            postprocessor.delete_invalid_keys(owner)
            party_id += 2
            unit_number += 1
            people_list.extend([owner, driver])
        if len(owner_index)!=0:
            for index in owner_index:
                owner = get_people(d_frame=d_frame, index=index, person_type='VEHICLE OWNER',
                            party_id=party_id, unit_number=unit_number,flag=True)
                driver = get_people(d_frame=d_frame, index=d_index, person_type='DRIVER',
                            party_id=party_id+1, unit_number=unit_number,driver_exist=False)
                postprocessor.delete_invalid_keys(owner)
                party_id += 2
                unit_number += 1
                people_list.extend([owner, driver])

        for index in other_index:
            person_type =  postprocessor.get_p_type(
                postprocessor.get_df_value(d_frame, 'Victim_Offender_Type', index))
            other = get_people(d_frame=d_frame, index=index, person_type=person_type,
                        party_id=party_id)
            party_id += 1
            people_list.append(other)

        if not people_list:
            owner = People(party_id = str(1), person_type='VEHICLE OWNER')
            postprocessor.delete_invalid_keys(owner)
            driver = People(party_id = str(2), person_type='DRIVER')
            people_list.extend([owner, driver])
        return people_list
    except:
        pass
    return []

class Vehicle():
    """
    Class defining Vehicle
    """
    def __init__(self, unit_number='', make='', vin = '', model_year='', model='',
        license_plate='', registration_state=''):
        """
        Initialize the Vehicle objects

        Args:
            unit_number (str, optional): unit_number. Defaults to ''.
            make (str, optional): make. Defaults to ''.
            vin (str, optional): vin. Defaults to ''.
            model_year (str, optional): model_year. Defaults to ''.
            model (str, optional): model. Defaults to ''.
            license_plate (str, optional): license_plate. Defaults to ''.
            registration_state (str, optional): registration_state. Defaults to ''.
        """
        self.Unit_Number = unit_number
        self.License_Plate = license_plate
        self.Registration_State = registration_state
        self.VIN = vin
        self.VinValidation_VinStatus = ''
        self.Model_Year = model_year
        self.Make = make
        self.Model = model
        self.Insurance_Company = ''
        self.Insurance_Policy_Number = ''
        self.Insurance_Expiration_Date = ''
        self.Vehicle_Towed = ''
        self.Air_Bag_Deployed = ''
        self.Damaged_Areas = ''
        self.Contributing_Circumstances_Vehicle = ''
        self.Posted_Statutory_SpeedLimit = ''

def vehicle_extraction(d_frame):
    """
    Passes Vehicle data to the Vehicle Class

    Args:
        d_frame (DataFrame): Predicted DataFrame

    Returns:
        List : Vehicle List
    """
    try:
        vehicle_list = []
        vehicle_count = postprocessor.get_count(d_frame, 'vehicle')
        for index in range(vehicle_count):
            vin = postprocessor.get_vin(postprocessor.get_df_value(d_frame, 'VIN', index))
            make = postprocessor.get_make(postprocessor.get_df_value(d_frame, 'Make', index))
            model = postprocessor.get_model(postprocessor.get_df_value(d_frame, 'Model', index))
            model_year = postprocessor.get_model_year(
                postprocessor.get_df_value(d_frame, 'Year', index))
            license_plate = postprocessor.get_license_plate(
                postprocessor.get_df_value(d_frame, 'License_Plate', index))
            registration_state = postprocessor.get_license_state(
                postprocessor.get_df_value(d_frame, 'License_State',index))
            vehicle = Vehicle(
                        unit_number = str(index+1),
                        vin = vin,
                        make = make,
                        model_year = model_year,
                        model = model,
                        license_plate = license_plate,
                        registration_state = registration_state,
                        )
            vehicle_list.append(vehicle)
        if not vehicle_list:
            vehicle_list.append(Vehicle(unit_number = '1'))
        return vehicle_list
    except:
        pass
    return []

class Report():
    """
    Class defining Report
    """
    def __init__(self, form_name, count_keyed, incident, people, vehicles, citations, form_type):
        """
        Initialize the Report objects

        Args:
            form_name (str): form_name
            count_keyed (str): count_keyed
            incident (List): incident
            people (List): people
            vehicles (List): vehicles
            citations (List): citations
        """
        self.FormName = form_name
        self.CountKeyed = count_keyed
        self.Incident = incident
        self.People = people
        self.Vehicles = vehicles
        self.Citations = citations
        self.Form_Type = form_type

class MainCls():
    """
    Class: Defines MainCls
    """
    def __init__(self, report):
        """
        Initialize the MainCls objects

        Args:
            report (class): report
        """
        self.Report = report

def json_convertion(text_extracted_df, form_type, city_lookup_path):
    """
    Function to form json from the predicted DataFrame

    Args:
        text_extracted_df (DataFrame): Predicted DataFrame
        city_lookup_path (str): city_lookup_path

    Returns:
        JSON: Json data created from predicted DataFrame
    """
    try:
        incident_report = incident_extraction(text_extracted_df, city_lookup_path)

        people_list = people_extraction(text_extracted_df)

        vehicle_list = vehicle_extraction(text_extracted_df)

        if (incident_report or people_list or vehicle_list):
            tif_name = (text_extracted_df['path'][0].split("_")[0]) + '_CO.tif'
            report = Report(form_name = 'Universal',
                            count_keyed = '',
                            incident = incident_report,
                            people = people_list,
                            vehicles = vehicle_list,
                            citations = [],
                            form_type = ('CO_'+ form_type))
            main_cls = MainCls(report = report)
            return main_cls, tif_name
    except:
        pass
    return sys.exc_info(), 'error'
