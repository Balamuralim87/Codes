# -*- coding: utf-8 -*-
"""
Created on Mon Jul 27 20:16:01 2020

@author: 206011
"""

import pandas as pd
import numpy as np
from fuzzywuzzy import process


def get_match_text(temp_dict, text):
    match_text = process.extractOne(text, temp_dict.keys())[0]
    temp_var = temp_dict.get(match_text)
    return temp_var, match_text

def assign_desc_code(row, temp_var, desc_list):
    if (temp_var != None):
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_desc', temp_var))
    else:
        desc_list.append((row.path, row.page_no, row.xmin, row.ymin, row.xmax, row.ymax,
                          row.label + '_desc', ''))
    return desc_list

def code2desc(df, code_description_lookup_path):
    list_df = pd.read_csv(code_description_lookup_path)
    col_list = list(list_df.columns)
    code_map_dict = {x: {} for x in col_list}

    for key in code_map_dict.keys():
        code_map_dict[key] = {x.split("=")[0].strip(' '): x.split("=")[1].upper().strip(' ') for x in
                                list(list_df[key].values) if (type(x) == str)}

    label_dict = {'J': 'Weather_Condition', 'G': 'Road_Surface_Condition',
                  'R1': 'Contributing_Circumstances_Person',
                  'R2': 'Contributing_Circumstances_Person',
                  'S1': 'Non_Motorist_Actions_At_Time_Of_Crash',
                  'S2': 'Non_Motorist_Actions_At_Time_Of_Crash',
                  'T1': 'Contributing_Circumstances_Vehicle',
                  'T2': 'Contributing_Circumstances_Vehicle'
                  }
    for item in range(1, 9):
        new_dec = {
            'SafetyEquip1_' + str(item): 'Safety_Equipment_Restraint',
            'SafetyEquip2_' + str(item): 'Safety_Equipment_Available_Or_Used',
            'SafetyEquip3_' + str(item): 'Safety_Equipment_Helmet',
            'Eject' + str(item): 'Ejection',
            'Alco' + str(item): 'Alcohol_Use_Suspected',
            'Drug' + str(item): 'Drug_Use_Suspected'
            }
        label_dict.update(new_dec)

    desc_list = []
    for ind,row in df.iterrows():
        temp_desc = ''

        if(row.label in list(label_dict.keys()) and len(str(row.text)) != 0):
            text = row.text
            if (text != ''):
                label_name = label_dict.get(row.label)
                label_code_dict = code_map_dict.get(label_name)
                temp_desc, match_text = get_match_text(label_code_dict, text)

            if (temp_desc != None):
                desc_list = assign_desc_code(row, temp_desc, desc_list)
            else:
                desc_list = assign_desc_code(row, '', desc_list)

    desc_df = pd.DataFrame(desc_list,columns=['path','page_no','xmin','ymin','xmax','ymax','label','text'])
    # df = df.append(desc_df)
    df = pd.concat([df,desc_df])

    df['new_index'] = np.arange(len(df))
    df.set_index('new_index', inplace=True)
    df.sort_values(by=['page_no','ymin','xmin'],inplace=True)
    return df