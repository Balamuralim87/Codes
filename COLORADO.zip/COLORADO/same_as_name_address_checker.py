from fuzzywuzzy import fuzz
import re

def copy_driver_to_owner(owner_list, driver_list,owner_list_coord, driver_list_coord):
    try:
        if (len(owner_list) > 0 and len(driver_list) > 0):
            for i in range(len(owner_list)):
                for j in range(len(driver_list)):
                    owner_name = owner_list[i].First_Name + ' ' + owner_list[i].Middle_Name + ' ' + owner_list[
                        i].Last_Name + ' ' + owner_list[i].Name_Suffix
                    driver_name = driver_list[j].First_Name + ' ' + driver_list[j].Middle_Name + ' ' + driver_list[
                        j].Last_Name + ' ' + driver_list[j].Name_Suffix
                    owner_name = re.sub('\s+', ' ', owner_name)
                    if (re.match('[a-zA-Z]+', owner_name) == False):
                        owner_name = ''
                    fuzzy_ratio = fuzz.ratio(owner_name, driver_name)
                    if (fuzzy_ratio >= 90 and int(owner_list[i].Unit_Number) == int(driver_list[j].Unit_Number)):
                        if (len(owner_list[i].Address) < 3 or owner_list[i].Address == ''):
                            owner_list[i].Address = driver_list[j].Address
                            # changes===========================
                            owner_list_coord[i].Address = driver_list_coord[j].Address
                            # ==================================
                        if (len(owner_list[i].Address2) < 3 or owner_list[i].Address2 == ''):
                            owner_list[i].Address2 = driver_list[j].Address2
                            # changes===========================
                            owner_list_coord[i].Address2 = driver_list_coord[j].Address2
                            # ==================================
                        if (len(owner_list[i].City) < 3 or owner_list[i].City == ''):
                            owner_list[i].City = driver_list[j].City
                            # changes============================
                            owner_list_coord[i].City = driver_list_coord[j].City
                            # ===================================
                        if (owner_list[i].State == ''):
                            owner_list[i].State = driver_list[j].State
                            # changes============================
                            owner_list_coord[i].State = driver_list_coord[j].State
                            # ===================================
                        if (len(owner_list[i].Zip_Code) < 3 or owner_list[i].Zip_Code == ''):
                            owner_list[i].Zip_Code = driver_list[j].Zip_Code
                            # changes============================
                            owner_list_coord[i].Zip_Code = driver_list_coord[j].Zip_Code
                            # ===================================
                        if (len(owner_list[i].Home_Phone) < 3 or owner_list[i].Home_Phone == ''):
                            owner_list[i].Home_Phone = driver_list[j].Home_Phone
                            # changes============================
                            owner_list_coord[i].Home_Phone = driver_list_coord[j].Home_Phone
                            # ===================================
                        owner_list[i].Date_Of_Birth = driver_list[j].Date_Of_Birth
                        owner_list[i].Drivers_License_Number = driver_list[j].Drivers_License_Number
                        owner_list[i].Drivers_License_Jurisdiction = driver_list[j].Drivers_License_Jurisdiction
                        owner_list[i].Injury_Status = driver_list[j].Injury_Status
                        driver_list[j].Same_as_Driver_GUI = 'Y'
                        # changes=================================
                        owner_list_coord[i].Date_Of_Birth = driver_list_coord[j].Date_Of_Birth
                        owner_list_coord[i].Drivers_License_Number = driver_list_coord[j].Drivers_License_Number
                        owner_list_coord[i].Drivers_License_Jurisdiction = driver_list_coord[j].Drivers_License_Jurisdiction
                        owner_list_coord[i].Injury_Status = driver_list_coord[j].Injury_Status
                        driver_list_coord[j].Same_as_Driver_GUI = 'Y'
                        # ========================================
                        # owner_list[i].Address_Same_as_Driver_GUI = 'Y'
                        
                    elif (fuzz.ratio(owner_list[i].Address, driver_list[j].Address) >= 90 and owner_list[
                        i].Address != ''
                          and int(owner_list[i].Unit_Number) == int(driver_list[j].Unit_Number)):
                        owner_list[i].Address_Same_as_Driver_GUI = 'Y'
                        owner_list_coord[i].Address_Same_as_Driver_GUI = 'Y'

        return owner_list, driver_list , owner_list_coord, driver_list_coord
    except:
        return owner_list, driver_list , owner_list_coord, driver_list_coord


def compare_owner_other_party(owner_list, other_list,
                              owner_list_coord, other_list_coord):
    try:
        if (len(owner_list) > 0 and len(other_list) > 0):
            for i in range(len(owner_list)):
                for j in range(len(other_list)):
                    fuzzy_ratio = fuzz.ratio(owner_list[i].Address, other_list[j].Address)
                    if (fuzzy_ratio >= 90 and owner_list[i].Address != '' and
                            int(owner_list[i].Unit_Number) == int(other_list[j].Unit_Number)):
                        other_list[j].Address_Same_as_Owner_GUI = 'Y'
                        other_list_coord[j].Address_Same_as_Owner_GUI = 'Y'

        return other_list , other_list_coord
    except:
        return other_list , other_list_coord



def compare_driver_other_party(driver_list, other_list,
                               driver_list_coord, other_list_coord):
    try:
        if (len(driver_list) > 0 and len(other_list) > 0):
            for i in range(len(driver_list)):
                for j in range(len(other_list)):
                    fuzzy_ratio = fuzz.ratio(driver_list[i].Address, other_list[j].Address)
                    if (fuzzy_ratio >= 90 and driver_list[i].Address != '' and
                            int(driver_list[i].Unit_Number) == int(other_list[j].Unit_Number)):
                        other_list[j].Address_Same_as_Driver_GUI = 'Y'
                        other_list_coord[j].Address_Same_as_Driver_GUI = 'Y'

        return other_list , other_list_coord
    except:
        return other_list , other_list_coord


def same_as_name_addrs_checker(owner_list, driver_list, other_list,
                               owner_list_coord, driver_list_coord, other_list_coord):
    if (len(owner_list) > 0 and len(driver_list) > 0):
        owner_list, driver_list , owner_list_coord, driver_list_coord = copy_driver_to_owner(owner_list, driver_list,
                                                                                             owner_list_coord, driver_list_coord)
    if (len(owner_list) > 0 and len(other_list) > 0):
        other_list , other_list_coord = compare_owner_other_party(owner_list, other_list , owner_list_coord, other_list_coord)
    if (len(driver_list) > 0 and len(other_list) > 0):
        other_list , other_list_coord = compare_driver_other_party(driver_list, other_list , driver_list_coord, other_list_coord)

    # Append all people list
    if (len(owner_list) > 0):
        for i in range(len(owner_list)):
            if (owner_list[i].Address_Same_as_Driver_GUI == ''):
                del owner_list[i].Address_Same_as_Driver_GUI
                del owner_list_coord[i].Address_Same_as_Driver_GUI

            else:
                owner_list[i].Address_Same_as_Driver_GUI = ''
                owner_list_coord[i].Address_Same_as_Driver_GUI = ''


    if (len(driver_list) > 0):
        for i in range(len(driver_list)):
            if (driver_list[i].Same_as_Driver_GUI == ''):

                del driver_list[i].Same_as_Driver_GUI
                del driver_list_coord[i].Same_as_Driver_GUI


    if (len(other_list) > 0):
        for i in range(len(other_list)):
            if (other_list[i].Address_Same_as_Owner_GUI == 'Y' and other_list[i].Address_Same_as_Driver_GUI == 'Y'):
                del other_list[i].Address_Same_as_Owner_GUI
                del other_list_coord[i].Address_Same_as_Owner_GUI

                # other_list[i].Address_Same_as_Driver_GUI = ''
            elif (other_list[i].Address_Same_as_Owner_GUI == 'Y'):
                other_list[i].Address_Same_as_Owner_GUI = ''
                other_list_coord[i].Address_Same_as_Owner_GUI = ''

            elif (other_list[i].Address_Same_as_Owner_GUI == ''):
                del other_list[i].Address_Same_as_Owner_GUI
                del other_list_coord[i].Address_Same_as_Owner_GUI

            else:
                pass
            if (other_list[i].Address_Same_as_Driver_GUI == 'Y'):
                other_list[i].Address_Same_as_Driver_GUI = ''
                other_list_coord[i].Address_Same_as_Driver_GUI = ''

            else:
                del other_list[i].Address_Same_as_Driver_GUI
                del other_list_coord[i].Address_Same_as_Driver_GUI

