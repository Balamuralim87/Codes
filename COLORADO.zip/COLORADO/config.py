class Config:

    STATE_LIST = [
        'CA', 'NC', 'TX', 'NJ', 'FL', 'NY', 'IL', 'PA', 'OH', 'NM', 'GA', 'MD', 'MI',
        'LA', 'MN', 'WI', 'KS', 'OK', 'IA', 'NV', 'UT', 'MS', 'OR', 'KY', 'TN', 'NH',
        'HI', 'NE', 'WV', 'DE', 'ID', 'IN', 'DC', 'SD', 'RI', 'AK', 'VT', 'ME', 'WY',
        'ND', 'PR', 'BC', 'VI', 'GU', 'ON', 'PQ', 'AB', 'NS', 'YT', 'MB', 'NF', 'WA', 'MO',
        'Florida', 'Texas', 'California','Ca California', 'New York', 'Pennsylvania', 'Ohio',
        'Tennessee', 'Wisconsin', 'Missouri', 'Michigan', 'New Jersey', 'Georgia',
        'Minnesota', 'Mississippi', 'Louisiana', 'Alabama', 'Maryland', 'Connecticut',
        'Oklahoma', 'Oregon', 'Arkansas', 'Massachusetts', 'West Virginia', 'Iowa', 'New Mexico',
        'Nebraska', 'Virginia', 'Delaware', 'New Hampshire', 'Arizona', 'Washington', 'Kansas',
        'Montana', 'Maine', 'Nevada', 'Kentucky', 'Vermont', 'Rhode Island', 'Hawaii', 'Colorado',
        'Dis Of Columbia', 'Alaska', 'Wyoming', 'North Dakota', 'South Carolina', 'North Carolina',
        'Illinois', 'Idaho', 'Virgin Island', 'Indiana', 'South Dakota', 'Guam', 'New Brunswick',
        'Puerto Rico', 'Washington', 'Yukon', 'Utah', 'British Columbia', 'CT', 'AL', 'AR', 'AZ',
        'CO', 'MA', 'MT', 'NB', 'PE', 'SC', 'VA', 'Dist.Of Columbia', 'Nova Scotia', 'Ontario',
        'Prince Edward', 'Quebec'
    ]

    STATE_WITH_CODE = {
        'ALABAMA' : 'AL', 'ALASKA' : 'AK', 'ARIZONA' : 'AZ', 'ARKANSAS' : 'AR', 'CALIFORNIA' : 'CA',
        'COLORADO' : 'CO', 'CONNECTICUT' : 'CT', 'DELAWARE' : 'DE', 'DISTRICT OF COLUMBIA' : 'DC',
        'FLORIDA' : 'FL', 'GEORGIA' : 'GA', 'HAWAII' : 'HI', 'IDAHO' : 'ID', 'ILLINOIS' : 'IL',
        'INDIANA': 'IN', 'IOWA' : 'IA', 'KANSAS' : 'KS', 'KENTUCKY' : 'KY', 'LOUISIANA' : 'LA',
        'MAINE' : 'ME', 'MARYLAND' : 'MD', 'MASSACHUSETTS' : 'MA', 'MICHIGAN' : 'MI',
        'MINNESOTA' : 'MN', 'MISSISSIPPI' : 'MS', 'MISSOURI' : 'MO', 'MONTANA' : 'MT',
        'NEBRASKA' : 'NE', 'NEVADA' : 'NV', 'NEW HAMPSHIRE' : 'NH', 'NEWJERSEY' : 'NJ',
        'NEWMEXICO' : 'NM', 'NEWYORK' : 'NY', 'NORTH CAROLINA' : 'NC', 'NORTH_DAKOTA' : 'ND',
        'OHIO' : 'OH', 'OKLAHOMA' : 'OK', 'OREGON' : 'OR', 'PENNSYLVANIA' : 'PA',
        'RHODE ISLAND' : 'RI', 'SOUTH CAROLINA' : 'SC', 'SOUTH DAKOTA' : 'SD',
        'TENNESSEE' : 'TN', 'TEXAS' : 'TX', 'UTAH' : 'UT', 'VERMONT' : 'VT', 'VIRGINIA' : 'VA',
        'WASHINGTON' : 'WA', 'WEST VIRGINIA' : 'WV', 'WISCONSIN' : 'WI', 'WYOMING' : 'WY'
        }
    
    MONTH_DICT = {
        'jan': '01',
        'feb': '02',
        'mar': '03',
        'apr': '04',
        'may': '05',
        'jun': '06',
        'jul': '07',
        'aug': '08',
        'sep': '09',
        'oct': '10',
        'nov': '11',
        'dec': '12'
    }
    
    FORM_2_WEATHER_CONDITION = {
        '0': 'CLEAR',
        '1': 'RAIN',
        '2': 'SLEET OR HAIL',
        '3': 'FOG',
        '4': 'DUST',
        '5': 'WIND',
        '6': 'CLOUDY',
        '7': 'FREEZING RAIN OR FREEZING DRIZZLE',
        '8': 'SNOW',
        '9': 'BLOWING SNOW',
    }

    FORM_2_ROAD_SURFACE_CONDITION = {
        '1': 'DRY',
        '2': 'WET',
        '3': 'MUDDY',
        '4': 'SNOWY',
        '5': 'ICY',
        '6': 'SLUSHY',
        '7': 'FOREIGN MATERIAL',
        '8': 'DRY W/VISIBLE ICY ROAD TREATMENT',
        '9': 'WET W/VISIBLE ICY ROAD TREATMENT',
        '10': 'SNOWY W/VISIBLE ICY ROAD TREATMENT',
        '11': 'ICY W/VISIBLE ICY ROAD TREATMENT',
        '12': 'SLUSHY W/VISIBLE ICY ROAD TREATMENT',
        '13': 'SAND/GRAVEL',
        '14': 'ROTO-MILLED'
    }

    FORM_2_VEHICLE_TOWED = {
        '0': '0',
        '1': '1',
    }

    FORM_2_CONTRIBUTING_CIRCUMSTANCES_VEHICLE = {
        '0': 'NO VEHICLE DEFECTS',
        '1': 'DEFECTIVE HEAD LIGHT(S)',
        '2': 'DEFECTIVE BRAKE/TAIL LIGHT(S)',
        '3': 'DEFECTIVE SIGNALING DEVICE',
        '4': 'BRAKES DEFECTIVE/OUT OF ADJUSTMENT',
        '5': 'DEFECTIVE TIRES',
        '6': 'SUDDEN TIRE FAILURE',
        '7': 'IMPROPER TIRES FOR CONDITION',
        '8': 'MECHANICAL FAILURE',
        '9': 'OBSTRUCTED WINDOW(S)',
        '10': 'IMPROPER LOAD',
        '11': 'SPILLED LOAD - COMMERCIAL AGGREGATE',
        '12': 'SPILLED LOAD - COMMERCIAL NON-AGGREGATE',
        '13': 'SPILLED LOAD - OTHER',
        '14': 'PARKING VIOLATION',
        '15': 'OTHER DEFECT(S)',
        '16': 'CARGO/EQUIPMENT LOSS OR SPILL',
        '17': 'CARGO/EQUIPMENT SHIFT'
    }

    FORM_2_ALCOHOL_SUSPECTED = {
        '1': 'PRELIMINARY BREATH TEST - YES',
        '2': 'SFST - YES',
        '3': 'OBSERVED',
        '5': 'OTHER METHOD',
        '6': 'PRELIMINARY BREATH TEST',
        '7': 'SFST',
        '8': 'OBSERVED - NO',
        '10': 'OTHER METHOD'
    }

    FORM_2_MARIJUANA_SUSPECTED = {
        '0': 'MARIJUANA NOT SUSPECTED',
        '1': 'MARIJUANA SUSPECTED',
        '2': 'UNKNOWN'
    }

    FORM_2_DRUG_SUSPECTED = {
        '1': 'PRELIMINARY BREATH TEST - YES',
        '2': 'SFST - YES',
        '3': 'OBSERVED',
        '4': 'OTHER METHOD',
        '5': 'DRUG RECOGNITION EXPERT',
        '6': 'SFST',
        '7': 'OBSERVED - NO',
        '8': 'OTHER METHOD'
    }

    FORM_2_SAFETY_EQUIPMENT_RESTRAINT = {
        'A': 'NONE',
        'B': 'SHOULDER AND LAP BELT',
        'C': 'SHOULDER BELT ONLY',
        'D': 'LAP BELT ONLY',
        'F': 'N/A (E.G. MOTORCYCLE)',
        'H': 'CHILD RESTRAINT - FORWARD FACING',
        'I': 'CHILD RESTRAINT - REAR FACING',
        'J': 'CHILD RESTRAINT - TYPE UNKNOWN',
        'K': 'BOOSTER SEAT'
    }

    FORM_2_SAFETY_EQUIPMENT_AVAILABLE_OR_USED = {
        '0': 'NOT USED',
        '1': 'PROPERLY USED',
        '2': 'IMPROPERLY USED',
        '3': 'UNKNOWN'
    }

    FORM_2_SAFETY_EQUIPMENT_HELMET = {
        'A': 'N/A (CARS/TRUCKS)'
    }

    FORM_2_INJURY = {
        '0': '0',
        '1': '1',
        '2': '2',
        '3': '3',
        '4': '4'
    }

    FORM_2_CONTRIBUTING_CIRCUMSTANCES_PERSON = {
        '00':'NO APPARENT CONTRIBUTING FACTOR',
        '01':'ASLEEP OR FATIGUED',
        '03': 'MEDICAL',
        '04': 'DRIVER INEXPERIENCE',
        '05': 'AGGRESSIVE DRIVING',
        '06': 'DRIVER UNFAMILIAR WITH AREA',
        '07': 'DRIVER EMOTIONALLY UPSET',
        '08': 'EVADING LAW ENFORCEMENT OFFICER',
        '09': 'PHYSICAL DISABILITY',
        '11': 'DISTRACTED/OTHER OCCUPANT',
        '15': 'OTHER FACTOR (DESCRIBED IN NARRATIVE)',
        '16': 'AGE/DRIVER ABILITY',
        '17': 'LOOKED/DID NOT SEE',
        '18': 'TALKING ON PHONE/HOLDING',
        '19': 'TALKING ON PHONE/HANDS FREE',
        '20': 'MANIPULATING ELECTRONIC DEVICE',
        '21': 'DISTRACTED EATING/DRINKING',
        '22': 'DISTRACTED/SMOKING',
        '23': 'DISTRACTED/MANIPULATING VEHICLE CONTROL',
        '24': 'DISTRACTED/OTHER INTERIOR',
        '25': 'DISTRACTED/OTHER EXTERIOR',
        '26': 'SUN GLARE',
        '27': 'NOT OBSERVED',
        '28': 'ILLNESS',

    }

    FORM_2_DAMAGE_CODE = {
        "1" : "SLIGHT",
        "2" : "MODERATE",
        "3" :"SEVERE"

    }

    FORM_2_DAMAGED_AREAS = {
    "1" : "FRONT",
    "2" : "SIDE",
    "3" :"BACK"

    }

    AIR_BAG_DEPLOYED = {
        '0': '0',
        '1': '1'
    }

    FORM_2_EJECTION = {
        '0': 'NO',
        '1': 'YES - PARTIAL',
        '2': 'YES - FULL',
        '3': 'EXTRICATED'
    }

    FORM_2_PREDEFINED_LABELS = {
        'incident_report': [
            'Crash_Date', 'Case_Identifier', 'City', 'Loss_Street'
            ],
        'people': [
            'Driver_Last_Name', 'Driver_First_Name', 'Driver_Street_Address','Driver_State','Driver_Zipcode',
             'V_Owner_Last_Name', 'V_Owner_First_Name', 'V_Owner_Address', 'V_Owner_State'
            ],
        'vehicle': [
            'Year', 'Make', 'Model', 'License_Plate', 'License_State', 'VIN'
            ],
        'property': [
            'Owner_Last_Name', 'Owner_First_Name', 'Owner_Middle_Name',
            'Owner_Address', 'Owner_City'
            ],
        'citation': [
            'primary_violation','violation_code','citation_number'
        ]
    }

    FORM_3_PREDEFINED_LABELS = {
        'incident_report': [
            'Crash_Date_Time', 'Case_Identifier', 'Crash_Location'
            ],
        'type' : [
            'Description' , 'Relation' , 'Type'
            ],
        'vehicle_owner' : [
            'Vehicle_Owner_Mid_Name', 'Vehicle_Owner_First_Name','Vehicle_Owner_Last_Name'
            ],        
        'owner': [
            'Vehicle_Owner_Mid_Name', 'Vehicle_Owner_First_Name','Vehicle_Owner_Last_Name',
            'Vehicle_Owner_DOB','Vehicle_Owner_Address','Vehicle_Owner_City_State_Zip',
            'Vehicle_Owner_Home_Phone'
            ],
        'driver': [
            'Victim_Mid_Name','Victim_First_Name', 'Victim_Last_Name',
            'Victim_DOB','Victim_Address','Victim_City_State_Zip',
            'Victim_Home_Phone','Victim_Offender_Type'
            ],
        'vehicle': [
            'Year', 'Make','Model', 'License_Plate', 'License_State', 'VIN'
            ]
    }

    FORM_4_PREDEFINED_LABELS = {
        'incident_report': [
            'Case_Identifier', 'Crash_Date_Time', 'Location_of_occurance', 'Crash_City'
            ],
        'people': [
            'Person_Name', 'Date_Of_Birth', 'Address', 'City_State_Zip', 'Home_Phone',
            'Apartment'
            ],
        'business person': [
            'Business_Name', 'Business_Address', 'Business_City_State_Zip'
            ],
        'vehicle': [
            'Vehicle', 'Vehicle_Towed', 'Vehicle_Owner', 'License_Plate', 'Registration_State',
            'VIN', 'Make_Model', 'Model_Year'
            ]
    }

    FORM_5_PREDEFINED_LABELS = {
        'incident_report': [
            'Case_Identifier', 'Crash_City', 'Location_of_occurance', 'Crash_Time',
            'Crash_Date'
            ],
        'people': [
            'Person_Type', 'Name', 'Address', 'City', 'State', 'Zipcode',
            'Home_Phone'
            ],
        'vehicle': [
            'Vehicle', 'Model', 'Make', 'Model_Year', 'VIN', 'License_Plate'
            ],
    }