import os
import sys
import pandas as pd
import json

import COLORADO.preproceesor as preproceesor
import COLORADO.common_util as common_util

import COLORADO.colorado_text_extractor as colorado_text_extractor
import COLORADO.colorado_text_extractor_extended as colorado_text_extractor_extended

import COLORADO.colorado_json_convertor as colorado_json_convertor
from COLORADO.form_2 import co_form_2_json_conversion, co_form_2_json_coordinates
from COLORADO.form_3 import co_form_3_json_conversion, co_form_3_json_coordinates
from COLORADO.form_4 import co_form_4_json_conversion, co_form_4_json_coordinates
from COLORADO.form_5 import co_form_5_json_conversion, co_form_5_json_coordinates
from COLORADO.form_6 import co_form_6_json_conversion, co_form_6_json_coordinates

import COLORADO.CO_clean_narratives as co_clean_narratives
import generic_utility.extract_narrative as extract_narrative

look_up_address_split = os.path.join(os.getcwd(), "COLORADO", "CityList.txt")
look_up_business_name = os.path.join(os.getcwd(), "COLORADO", "Business_Name.csv")
code_description_lookup_path = os.path.join(os.getcwd(), "COLORADO", "CO_CodeDesc.csv")
required_field_lookup_path = os.path.join(os.getcwd(), "COLORADO", "CO_RequiredLabels.txt")


def Process(csv_file_path, temp_path, check_box_model):
    csv_file_name = str(os.path.basename(csv_file_path).split('.')[0])
    predicted_df = pd.read_csv(csv_file_path)
    predicted_df.rename({'classes':'label'}, inplace=True)
    tif_file_name = str(csv_file_path.split('.')[0]) + '.tif'
    
    form_type = preproceesor.form_type_detection_df(csv_file_path)

    try:
        if (form_type != 'invalid'):
            try:
                print("Process : PDF Content Extraction" )
                if form_type == 'form_type_1':
                    text_extracted_df = colorado_text_extractor.content_extraction(
                                        predicted_df, os.path.join(temp_path, csv_file_name),
                                        check_box_model, tif_file_name, look_up_address_split,
                                        look_up_business_name, code_description_lookup_path,
                                        required_field_lookup_path)
                else:
                    text_extracted_df = colorado_text_extractor_extended.content_extraction(
                                        predicted_df, os.path.join(temp_path, csv_file_name),
                                        form_type, tif_file_name, check_box_model)
                
            except:
                print("Error : Error occurred during PDF Content Extraction" )
                return sys.exc_info(),"error", '', ''
            
            print('Form Type: ', form_type)

            try:
                narrative = ""
                data_coord = ""
                json_data_coord = ""
                print("Process : JSON Conversion")
                if form_type == 'form_type_1':
                    data, tif_name, data_coord = colorado_json_convertor.json_convertion(text_extracted_df,
                                    os.path.join(temp_path, csv_file_name), form_type)
                    narrative = co_clean_narratives.CO_clean_narrative(text_extracted_df,
                                                                       'narrative_new', form_type)
                elif form_type == 'form_type_2':
                    # SOC TRAFFIC CRASH REPORT
                    data, tif_name = co_form_2_json_conversion.json_convertion(text_extracted_df,
                                    form_type, look_up_business_name, look_up_address_split)
                    data_coord, tif_name = co_form_2_json_coordinates.json_convertion_coordinate(
                        text_extracted_df, form_type, look_up_business_name, look_up_address_split)
                    narrative = co_clean_narratives.CO_clean_narrative(text_extracted_df,
                                                                       'narrative_new', form_type)
                elif form_type == 'form_type_3':
                    # OFFICER REPORT INCIDENT FORM
                    data, tif_name = co_form_3_json_conversion.json_convertion(text_extracted_df,
                                    form_type, look_up_address_split)
                    data_coord, tif_name = co_form_3_json_coordinates.json_convertion_coordinate(
                        text_extracted_df, form_type, look_up_address_split)
                    narrative = extract_narrative.generate_narrative(text_extracted_df, 'narrative_new')
                elif form_type == 'form_type_4':
                    # GENERAL FORM
                    data, tif_name = co_form_4_json_conversion.json_convertion(text_extracted_df,
                                    form_type, look_up_business_name, look_up_address_split)
                    data_coord, tif_name = co_form_4_json_coordinates.json_convertion_coordinate(
                        text_extracted_df, form_type, look_up_business_name, look_up_address_split)
                elif form_type == 'form_type_5':
                    # EVENT INFO INCIDENT REPORT
                    data, tif_name = co_form_5_json_conversion.json_convertion(text_extracted_df,
                                    form_type, look_up_business_name)
                    data_coord, tif_name = co_form_5_json_coordinates.json_convertion_coordinate(
                        text_extracted_df, form_type, look_up_business_name)
                    narrative = extract_narrative.generate_narrative(text_extracted_df, 'narrative_new')
                elif form_type == 'form_type_6':
                    # EVENT DETAIL REPORT
                    data, tif_name = co_form_6_json_conversion.json_convertion(text_extracted_df,
                                    form_type, look_up_business_name)
                    data_coord, tif_name = co_form_6_json_coordinates.json_convertion_coordinate(
                        text_extracted_df, form_type, look_up_business_name)
                
                if (tif_name not in ['error', 'invalid']):
                    if common_util.valid_json(data):
                        json_data = json.dumps(data, default = lambda o : o.__dict__, indent = 4)
                        if data_coord:
                            json_data_coord = json.dumps(data_coord, default = lambda o : o.__dict__, indent = 4)
                        return json_data, tif_name, json_data_coord, narrative
                    return sys.exc_info(), 'invalid', '', ''
                return data, tif_name, data_coord, narrative
            except:
                print("Error : Error occurred during JSON Conversion")
                return sys.exc_info(), "error", '', ''
        else:
            print('Invalid Form')
            return '', 'invalid', '', ''
    except:
        print("Error : Error occurred during JSON Conversion")
        return sys.exc_info(), "error", '', ''

