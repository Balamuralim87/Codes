import re

def fix_home_phone(people):
    """
    Fixes the phone number

    Args:
        people (class): People class
    """
    try:
        if (people.Home_Phone != ''):
            ph_number = re.sub('[^A-Za-z0-9 ]', ' ', people.Home_Phone)
            ph_number = '-'.join([i.strip() for i in ph_number.split(' ') if (i.strip() != '')])
            people.Home_Phone = ph_number
    except:
        pass

def fix_city(people):
    """
    Fixes the City

    Args:
        people (class): People class
    """
    try:
        people.City = people.City.upper()
    except:
        pass

def fix_ejection(people):
    """
    Fixes the Ejection

    Args:
        people (class): People class
    """
    try:
        value = {
            'Code': '',
            'Description': ''
        }
        code = people.Ejection
        if ('2' in code):
            value['Code'] = code
            value['Description'] = 'Yes - Full'
        else:
            value['Code'] = '00'
            value['Description'] = 'No'
        people.Ejection = value
    except:
        pass

def fix_injury_status(people):
    """
    Fixes injury status

    Args:
        people (class): People class
    """
    try:
        injury = people.Injury_Status
        if ((len(injury) > 1) and (injury.startswith('0'))):
            people.Injury_Status = injury[1]
    except:
        pass

def fix_alcohol_suspected(people):
    """
    Fixes Alcohol suspected

    Args:
        people (class): People class
    """
    try:
        alcohol = people.Alcohol_Use_Suspected
        description = alcohol[0].Description
        if (description.lower() == 'no'):
            alcohol[0].Description = 'No'
    except:
        pass

def fix_drug_suspected(people):
    """
    Fixes Drug suspected

    Args:
        people (class): People class
    """
    try:
        drug = people.Drug_Use_Suspected
        description = drug[0].Description
        if (description.lower() == 'no'):
            drug[0].Description = 'No'
    except:
        pass

def fix_latitude_longitude(text):
    """
    Fixes Latitude / Longitude

    Args:
        text (string): Latitude / Longitude
    """
    try:
        if (text != ''):
            split_txt = text.split('.')
            before_dot = split_txt[0]
            result = ' '.join([before_dot[i:i+2] for i in range(0, len(before_dot), 2)])
            if (len(split_txt) > 1):
                return result + '.' + split_txt[1]
            else:
                return result + '.' + '00'
    except:
        pass
    return text

def fix_safety_equipment_available_or_used(people):
    """
    Fixes Safety_Equipment_Available_Or_Usede

    Args:
        people (class): People class
    """
    try:
        safty_eq = people.Safety_Equipment_Available_Or_Used
        description = safty_eq[0].Description.title()
        if ((description.lower() == 'not used') or (description.lower() == 'properly used')):
            safty_eq[0].Description = 'Properly Used'
        else:
            safty_eq[0].Description = description
    except:
        pass

def fix_safety_equipment_helmet(people):
    """
    Fixes Safety_Equipment_Helmet

    Args:
        people (class): People class
    """
    try:
        safty_eq = people.Safety_Equipment_Helmet
        description = safty_eq[0].Description.title()
        if (description.lower() == 'n/a (cars/trucks)'):
            safty_eq[0].Description = 'N/A (cars/trucks)'
        else:
            safty_eq[0].Description = description
    except:
        pass

def fix_safety_equipment_restraint(people):
    """
    Fixes Safety_Equipment_Restraint

    Args:
        people (class): People class
    """
    try:
        safty_eq = people.Safety_Equipment_Restraint
        description = safty_eq[0].Description.title()
        if ('shoulder' in description.lower()):
            safty_eq[0].Description = 'Shoulder and Lap Belt'
        elif (description.lower() == 'none'):
            safty_eq[0].Description = ''
        else:
            safty_eq[0].Description = description
    except:
        pass

def patch_incident_data(incident):
    """
    Passes incident data to respective functions

    Args:
        incident (class): Incident Class
    """
    incident.Latitude = fix_latitude_longitude(incident.Latitude)
    incident.Longitude = fix_latitude_longitude(incident.Longitude)

def patch_people_data(people_list):
    """
    Passes people data to respective functions

    Args:
        people_list (list): List  of Peoples Class
    """
    for people in people_list:
        fix_home_phone(people)
        fix_city(people)
        fix_ejection(people)
        fix_injury_status(people)
        fix_alcohol_suspected(people)
        fix_drug_suspected(people)
        fix_safety_equipment_available_or_used(people)
        fix_safety_equipment_helmet(people)
        fix_safety_equipment_restraint(people)