import os
import time
import cv2
import pandas as pd
import xml.etree.ElementTree as ET
import re
from tqdm import tqdm

import COLORADO.name_address_split as name_address_split
import COLORADO.common_util as common_util
import COLORADO.text_extract as text_extract
import COLORADO.preproceesor as preproceesor
import COLORADO.code2description_converter as code2description_converter
import COLORADO.CO_rule_layer as CO_rule_layer


"""----------------------------- TEXT EXTRACTION - START --------------------------------"""


"""
Identify whether the particular word in the XML present within the predicted bounding box.
Args:
df: DataFrame 
    DataFrame containing the image name, label name(object) and their coordinates obtained after applying the developed model on the images.
csv_path: String
          Path where the output csv in the following format ('path','xmin','ymin','xmax','ymax','label','text') has to be created.
model_path: string
            Path where the model to identify whether the given checkbox is checked or unchecked.
Returns:
Extracted text for each predicted bounding box is calculated and saved in the csv file where the input image are present.
"""
def content_extraction(df, xml_out_path, checkbox_model, tif_file_name, look_up_address_split, look_up_business_name,
                       code_description_lookup_path, required_field_lookup_path):
    df.rename(columns={'label': 'classes'}, inplace=True)
    df['image_path'] = df['filename'].apply(lambda x: x.split('.')[0] + '_' + x.split('_')[-1] + '.jpg')
    df['x1'] = df['xmin'] * df['img_width']
    df['y1'] = df['ymin'] * df['img_height']
    df['x2'] = df['xmax'] * df['img_width']
    df['y2'] = df['ymax'] * df['img_height']

    temptext_df = pd.DataFrame()
    overall_list = []
    data_list = []
    img_list = df['image_path'].unique().tolist()
    img_list.sort()  # 28 July 2020
    group_df = df.groupby('image_path')
    page_occur_count = 0

    # ===============================
    # Checkbox model - TIF to JPG
    output_jpg_dir = os.path.join(xml_out_path ,'jpg')
    if not os.path.exists(output_jpg_dir):
        os.makedirs(output_jpg_dir)
    preproceesor.tiff_to_jpg(tif_file_name, output_jpg_dir)
    # ===============================

    for img in tqdm(img_list):
        page_occur_count += 1
        csv_name = os.path.join(xml_out_path, img.split('.')[0] + '_final.csv')
        temp_df = group_df.get_group(img)
        #temp_df = temp_df.sort_values(by='y1')
        temp_df = temp_df.sort_values(by=['y1', 'x1'])
        img_height = df['img_height'][0]
        xml_path = os.path.join(xml_out_path, str(img.split('.')[0]) + '.xml')
        xml_path = xml_path.replace('_CO', '_co')
        if os.path.exists(xml_path) == False:
            continue

        xml_str = open(xml_path, 'r', encoding='utf-8').read()

        upd_xml_str = common_util.str_replace_xml(xml_str)

        xml_tree = ET.XML(upd_xml_str)
        sort_lines_ymin = sort_lines(xml_tree)

        page_list = xml_tree.findall('.//page')
        page_height = page_list[0].attrib['height']
        c = round(img_height / float(page_height), 2)

        image = cv2.imread(os.path.join(output_jpg_dir, img))

        req_field_file = open(required_field_lookup_path, "r")
        req_field_list = req_field_file.readlines()
        req_field_list = [x.replace('\n', '').strip() for x in req_field_list]

        for i, row1 in temp_df.iterrows():
            if not (row1.classes in req_field_list):
                continue
            text_list = []
            bb_xmin = int(row1.x1)
            bb_ymin = int(row1.y1)
            bb_xmax = int(row1.x2)
            bb_ymax = int(row1.y2)
            bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)

            if re.search(r'^(UnitNum[0-9])$', row1.classes) and page_occur_count == 1:
                text = row1.classes.replace('UnitNum', '')
                text_list.append(text)

            elif row1.classes == 'narrative_new':
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
                add_list = text_extract.find_text(xml_tree,bb_coord,c,True)
                add_list = sorted(add_list, key=lambda x: (x[1], x[0]))
                text_list = [x[2] for x in add_list]

            elif 'TowedDriven' in row1.classes or 'OwnerSameAsDriver' in row1.classes or 'OwnerAddressSameAsDriver' in row1.classes\
                    or 'Veh1' == row1.classes or 'Veh2' == row1.classes or 'Parked' in row1.classes or 'Bicycle' in row1.classes or 'Pedestrain'\
                    in row1.classes or 'NonVehicle' in row1.classes or 'NonContractVeh' in row1.classes or \
                    'PhotosTaken' in row1.classes:
                checked_status = common_util.detect_check_box(image, bb_xmin, bb_ymin, bb_xmax, bb_ymax,checkbox_model)
                text_list.append(checked_status)

            elif 'DriverState' in row1.classes or 'OwnerState' in row1.classes or 'LicenseState' in row1.classes or \
                    'DriverLicenseState' in row1.classes:
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                add_list = sorted(add_list, key=lambda x: x[0])
                text_list = [x[1] for x in add_list]
                text = ' '.join(text_list)
                text = re.sub(r'^(([A-Z]{2})(.*?))$', r'\2', text)
                state_abbr = common_util.state_abbr_convertor(text)
                data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, state_abbr))

            elif 'NameAddress' in row1.classes:
                add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix': '', 'name': ''}
                text =''
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
                add_list = text_extract.extract_text(sort_lines_ymin, bb_coord, c)
                if len(add_list) > 0:
                    text_list = [x[2] for x in add_list]
                    text = ' '.join(text_list)
                    text = text.strip()
                    text = text.strip(',')
                    text = text.strip()
                    text = re.sub('\\bas\\b', '', text)
                    text = re.sub('(\s?\/)', '', text)
                    add_dict = name_address_split.name_address_split_using_lookup(text, look_up_address_split, True)
                    add_dict = name_address_split.name_split_using_pattern(add_dict.get('names'), look_up_business_name)

                if (add_dict is not None):
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_first_name', add_dict.get('first_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_middle_name', add_dict.get('middle_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_last_name', add_dict.get('last_name')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_suffix',
                                      add_dict.get('suffix')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_name',
                                      add_dict.get('name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_first_name', add_dict.get('first_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_middle_name', add_dict.get('middle_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2,
                                      row1.classes + '_last_name', add_dict.get('last_name')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_suffix',
                                      add_dict.get('suffix')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_name',
                                      add_dict.get('name')))
            
            else:
                add_list = text_extract.find_text(xml_tree, bb_coord, c)
                add_list = sorted(add_list, key=lambda x: x[0])
                text_list = [x[1] for x in add_list]

            if 'NameAddress' in row1.classes:
                bb_coord = (bb_xmin, bb_ymin, bb_xmax, bb_ymax)
                text = ''
                # line_list = name_address_split.find_text_lines_new(xml_tree, bb_coord, c)
                add_list = text_extract.extract_text(sort_lines_ymin, bb_coord, c)

                if len(add_list) > 0:
                    # if len(text_list) > 0: text = ' '.join([str(elem) for elem in text_list])
                    # if len(line_list) > 0: text = ' '.join(line_list)
                    text_list = [x[2] for x in add_list]
                    text = ' '.join(text_list)
                    text = text.strip()
                    text = text.strip(',')
                    text = text.strip()
                    text = re.sub('(-)$', '', text, re.IGNORECASE)
                    text = re.sub('^(Street)$', '', text, re.IGNORECASE)
                    text = re.sub('(\s?--\s?)', '', text, re.IGNORECASE)
                    text = re.sub('(\s?\/)', '', text)
                add_dict = name_address_split.name_address_split_using_lookup(text, look_up_address_split, True)

                if add_dict is None:
                    add_dict = name_address_split.name_address_split_using_pattern(text)

                if (add_dict is not None):
                    state_abbr = common_util.state_abbr_convertor(add_dict.get('state'))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      add_dict.get('address')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_city',
                                      add_dict.get('city')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_state',
                                      state_abbr))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_zipcode',
                                      add_dict.get('zipcode')))
                    data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_phone_no',
                                      add_dict.get('phone_no')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_address',
                                      add_dict.get('address')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_city',
                                      add_dict.get('city')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_state',
                                      state_abbr))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_zipcode',
                                      add_dict.get('zipcode')))
                    overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes + '_phone_no',
                                      add_dict.get('phone_no')))
            try:

                text = ' '.join(text_list)
                text = common_util.cleaning(text)
                if 'SafetyEquip1_' in row1.classes:
                    text = re.sub(r'[^A-Za-z\.\(\)\/]', '', text)
                    text = re.sub(r'^(I?([A-Za-z])I?)$', r'\2', text)
                elif 'Eject' in row1.classes or 'T1' == row1.classes or 'T2' == row1.classes \
                        or 'G' == row1.classes or 'R1' == row1.classes or 'R2' == row1.classes:
                    text = re.sub(r'[^0-9]', '', text)
                elif 'SafetyEquip2_' in row1.classes or 'AirBag1_' in row1.classes:
                    text = re.sub(r'[^0-9]', '', text)
                    text = re.sub(r'^(1?([0-9]{1,2})1?)$', r'\2', text)
                elif 'SafetyEquip3_' in row1.classes:
                    text = re.sub(r'[^A-Z]', '', text)
                    text = text.replace('I', '')
                elif 'J' == row1.classes:
                    text = re.sub('(\s?J\s?)', '', text)
                elif 'Latitude' ==  row1.classes:
                    text = re.sub(r'(Latitude)', '', text)
                elif 'LocationRouteSt2' ==  row1.classes:
                    text = re.sub(r'^((LIAt:)|(At)|(AI))', '', text)
                elif 'PolicyNumber' in  row1.classes:
                    text = re.sub(r'(Policy Number )', '', text)

            except TypeError:
                text = ''
            data_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            overall_list.append((row1.image_path, row1.x1, row1.y1, row1.x2, row1.y2, row1.classes, text))
            ex2 = time.time()

        temptext_df = pd.DataFrame(data_list, columns=['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])
        temptext_df['text'] = temptext_df['text'].apply(lambda x: common_util.cleaning(x))
        temptext_df['page_no'] = temptext_df['path'].apply(lambda x: os.path.basename(x).split('.')[0].split('_')[-1])
        temptext_df = temptext_df[['path', 'page_no', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text']]
        temptext_df = code2description_converter.code2desc(temptext_df, code_description_lookup_path)
        temptext_df = CO_rule_layer.rule_layer_main(temptext_df)
        # temptext_df.to_csv(csv_name, index=False)
    #     new_df = new_df.append(temptext_df)
    #
    # temp_df = pd.DataFrame(overall_list, columns=['path', 'xmin', 'ymin', 'xmax', 'ymax', 'label', 'text'])

    # temptext_df.to_csv(os.path.join(xml_out_path, 'overall_extracted.csv'), index=False)


    return temptext_df


"""----------------------------- TEXT EXTRACTION - END --------------------------------"""


def sort_lines(xml_tree):

    for k in range(10):
        sorted_lines = sorted([trans for trans in xml_tree.iter('line') if
                               float(trans.attrib['yMin']) >= 0],
                              key=lambda x: float(x.attrib['yMin']))

        for l in range(len(sorted_lines)):
            if l == len(sorted_lines)-1: continue
            first_line = sorted_lines[l]
            second_line = sorted_lines[l+1]

            first_words = [x for x in first_line.iter('word')]
            if len(first_words) == 0: continue

            if abs(int(first_line.attrib['yMin'].split('.')[0]) - int(second_line.attrib['yMin'].split('.')[0])) < 5:
                second_words = [x for x in second_line.iter('word')]
                for word in reversed(second_words):
                    first_line.append(word)

                    second_line.remove(word)

                second_line.tag = 'remove'

    sorted_lines = sorted([trans for trans in xml_tree.iter('line') if float(trans.attrib['yMin']) >= 0], key=lambda x: float(x.attrib['yMin']))

    for line in sorted_lines:
        order_words = sorted([trans for trans in line.iter('word') if float(trans.attrib['xMin']) >= 0], key=lambda x: float(x.attrib['xMin']))
        for child in list(line):
            line.remove(child)
        for word in order_words:
            line.append(word)


    sorted_lines = sorted([trans for trans in xml_tree.iter('line') if float(trans.attrib['yMin']) >= 0], key=lambda x: float(x.attrib['yMin']))

    return sorted_lines