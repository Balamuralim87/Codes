"""
Created on 27/01/2023

@author: e406679: Srikandan Raju
"""

import re
from datetime import datetime

import pandas as pd
from fuzzywuzzy import fuzz

from COLORADO.config import Config
from COLORADO.name_address_split import name_split_using_pattern

def get_predefined_labels(key):
    """
    Function holds predefined labels for Incident, People and Vehicle

    Args:
        key (str): Key of predefined_labels

    Returns:
        List: Value of predefined_labels
    """
    try:
        return Config.FORM_2_PREDEFINED_LABELS[key]
    except:
        pass
    return []

def get_df_value(d_frame, label_name, index=0):
    """
    Function retrive value from df (predicted dataframe) based on label_name and index

    Args:
        d_frame (DataFrame): Predicted DataFrame
        label_name (str): Used to retrive value from df (predicted dataframe)
        index (int, optional): Index Value. Defaults to 0.

    Returns:
        str: Value from df (predicted dataframe)
    """
    try:
        group_df = d_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])

        data_df = data_df.loc[data_df['label'].str.lower()==(label_name.lower()),
            ['label', 'text']]

        if len(data_df) > 0:
            value = data_df['text'].iloc[index]
            if str(value) != 'nan':
                return value.strip()
    except:
        pass
    return ''

def get_case_identifier(text):
    """
    Process the case Identifier

    Args:
        text (str): case Identifier

    Returns:
        str: case Identifier
    """
    try:
        if text.strip():
            text = text.replace('.', '-')
            text = ''.join(re.sub('[^0-9a-zA-Z]+', ' ', text).strip().split())
            return text
    except:
        pass
    return ''

def process_crash_address(text):
    """
    Process the crash address

    Args:
        text (str): crash address

    Returns:
        str: crash address
    """
    try:
        text = text.lower().replace('(c)', '').strip()
        text = ' '.join([i.strip() for i in text.split() if i != 'c']).strip()
    except:
        pass
    return text.upper()

def address_split_using_lookup(address_text, city_lookup_path, is_incident=False):
    """
    splits Address, City, State, Zipcode from text

    Args:
        address_text (str): address_text
        city_lookup_path (str): location of Cities
        is_incident (boolean, optional): is_incident

    Returns:
        dict: add_dict
    """
    add_dict = {'address': '', 'city': '', 'state': '', 'zipcode': ''}
    if address_text:
        try:
            city = ''
            state = ''
            zipcode = ''

            address_text = address_text.lower()
            address_text = address_text.replace('address', '').rsplit(':', 1)[-1]
            address_text = ' '.join(address_text.split()).strip()

            if address_text.find('los angeles') != -1:
                city = 'los angeles'
                address_text = address_text.replace(city, '').strip()

            zipcode = address_text.split()[-1]
            address_text = address_text.replace(zipcode, '').strip()
            zipcode = re.sub('[^0-9]+', ' ', zipcode)

            address_text = re.sub('[^a-zA-Z0-9/]+', ' ', address_text)

            with open(city_lookup_path, encoding='utf-8', errors='ignore') as file:
                city_lookup = file.readlines()
                city_lookup = [x.encode('ascii', 'ignore').decode().strip() for x in city_lookup]
            file.close()

            cities = '|'.join([i.lower() for i in city_lookup])

            states = '|'.join([i.lower() for i in Config.STATE_LIST])
            state_match = re.search(r'((\s|,)(' + states + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if state_match:
                state_match = state_match.group(3)
                if 'ca california' in state_match:
                    state = 'CA'
                else:
                    state = state_match
                address_text = re.sub(r'\s+'+state_match, '', address_text).strip()
            city_match = re.search(r'((\s|,)(' + cities + r')(\s|,)?)$', address_text,
                re.IGNORECASE)
            if city_match:
                city = city_match.group(3)
                address_text = re.sub(r'\s+'+city, '', address_text).strip()

            if is_incident:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z/]+', ' ', address_text).strip().split())
            else:
                address_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', address_text).strip().split())

            add_dict.update({'address': address_text.upper()})
            add_dict.update({'city': city.upper()})
            add_dict.update({'state': state.upper()})
            add_dict.update({'zipcode': zipcode})
        except:
            pass
    return add_dict

def get_total_vehcile_count(d_frame):
    total_vehicle = 0
    try:
        total_vehicle = get_df_value(d_frame, 'Total_Vehicle')
        total_vehicle = ''.join(re.sub('[^0-9]+', ' ', total_vehicle).split()).strip()
        total_vehicle = int(total_vehicle)
    except:
        pass
    return total_vehicle

def get_count(d_frame, key):
    """
    Returns count of the given key

    Args:
        d_frame (dataframe): d_frame
        key (str): key

    Returns:
        int: Total count
    """
    max_count = 0
    try:
        labels = get_predefined_labels(key)
        for label in labels:
            count = len(d_frame.loc[(d_frame['label'].str.lower() ==
                (label.lower())) & (d_frame['text'].str.strip()), 'label'])
            max_count = max(max_count, count)
    except:
        pass
    return max_count

def get_business_name(text, business_name_lookup_path):
    """
    Check given name is business name or not

    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path

    Returns:
        bool: business name or not
    """
    try:
        business_name_text = ' '.join(re.sub('[^0-9a-zA-Z]+', ' ', text).split())
        with open(business_name_lookup_path,encoding='utf-8', errors='ignore') as file:
            business_name_lookup = file.readlines()
            business_name_lookup = [x.strip() for x in business_name_lookup]
        file.close()
        business_names = '|'.join(business_name_lookup)
        business_name_match = re.search(r'((\s|,)(' + business_names + r')(\s|,)?)$',
            business_name_text, re.IGNORECASE)
        if business_name_match:
            return True
    except:
        pass
    return False

def process_name(text, business_name_lookup_path):
    """
    Returns Person Name

    Args:
        text (str): text
        business_name_lookup_path (str): business_name_lookup_path

    Returns:
        str: Person Name
    """
    add_dict = {'first_name': '', 'middle_name': '', 'last_name': '', 'suffix':'', 'name': ''}
    try:
        text = text.replace('0', 'O')
        text = text.replace('.', '')
        text = text.lower().replace('name', '').split(':')[-1].strip()
        is_business_name = get_business_name(text, business_name_lookup_path)
        if not is_business_name:
            add_dict = name_split_using_pattern(text, business_name_lookup_path)
            add_dict['first_name'] = add_dict['first_name'].upper()
            add_dict['middle_name'] = add_dict['middle_name'].upper()
            add_dict['last_name'] = add_dict['last_name'].upper()
            add_dict['suffix'] = add_dict['suffix'].upper()
        else:
            text = text.replace(',', '')
            add_dict['last_name'] = text.upper()
    except:
        pass
    return add_dict

def get_crash_date(text):
    """
    Extracts the crash date and time

    Args:
        text (str): crash date and time

    Returns:
        str, str: crash date and time
    """
    try:
        date = re.findall(r'\s*(\d{1,2})\s*(\w{3})\s*(\d{4})', text, re.IGNORECASE)
        if date:
            date = [i.strip() for i in date[0]]
            date = clean_date(date)
        else:
            date = ''
        try:
           time = re.findall(r'\s*\d{1,2}\s*:\s*\d{2}\s*', text, re.IGNORECASE)
           if time:
               time = time[0].strip()
        except:
            time = ''
            pass
        return date.strip(), time.strip()
    except:
        pass
    return '', ''

def clean_date(text):
    """
    Cleans the date

    Args:
        text (str): text

    Returns:
        str: updated text
    """
    try:
        if len(text) > 1:
            if len(text[0]) < 2:
                text[0] = '0' + text[0]
            if len(text[0]) == 3:
                text[0] = text[0][1:]
            if len(text[2]) < 3:
                if int(text[2]) > int(str(datetime.today().year)[-2:]):
                    text[2] = '19' + text[2]
                else:
                    text[2] = '20' + text[2]
            text[1] = Config.MONTH_DICT.get(text[1].lower(), '00')
            return '/'.join([text[1], text[0], text[2]])
    except:
        pass
    return ''

def get_street(text):
    """
    Splits the Loss street and Loss Cross street from text

    Args:
        text (str): text

    Returns:
        str, str: Loss street and Loss Cross street from text
    """
    try:
        text = text.strip().lower()
        if 'and' in text:
            splitted_text = text.split('and')
            return splitted_text[0].strip().upper(), splitted_text[1].strip().upper()
        elif '/' in text:
            splitted_text = text.split('/')
            return splitted_text[0].strip().upper(), splitted_text[1].strip().upper()
    except:
        pass
    return text.upper(), ''

def get_damaged_area(d_frame, index):
    try:
        text_list = []
        for key, value in Config.FORM_2_DAMAGE_AREAS.items():
            text = get_df_value(d_frame, key, index)
            if len(text_list) > 1:
                return 'MULTIPLE'
            if text:
                text_list.append(value)
        if text_list:
            return text_list[0]
    except:
        pass
    return ''

def remove_extra_space(text):
    """
    Removes extra whitespace

    Args:
        text (str): text

    Returns:
        str: text
    """
    try:
        text = ''.join([i.strip() for i in text.split()])
    except:
        pass
    return text

def is_same_owner(d_frame, index):
    """
    Returns True if Owner and driver same else False

    Args:
        d_frame (Dataframe): d_frame
        index (int): row index

    Returns:
        boolean: True if Owner and driver same else False
    """
    try:
        driver_name = get_df_value(d_frame, 'Person_Name', index).strip()
        owner_name = get_df_value(d_frame, 'Vehicle_Owner_Name', index).strip()
        if fuzz.ratio(driver_name, owner_name) > 90:
            return True
    except:
        pass
    return False

def is_hit_and_run(data_frame):
    try:
        group_df = data_frame.sort_values(['ymin']).groupby('page_no')
        data_df = pd.DataFrame()
        for page in list(group_df.groups.keys()):
            data_df = pd.concat([data_df, group_df.get_group(page)[['label', 'text']]])
        data_df = data_df.loc[data_df['label'].str.lower()==('hit_and_run'),
            ['label', 'text']]
        values = list(data_df['text'])
        for value in values:
            if value.lower() in ['checked']:
                return True
    except:
        pass
    return False

def get_code_description(text, key):
    try:
        if text.strip():
            code_dict = {}
            key = key.lower()
            if key == 'weather_condition':
                code_dict = Config.FORM_2_WEATHER_CONDITION
            elif key == 'road_surface_condition':
                code_dict = Config.FORM_2_ROAD_SURFACE_CONDITION
            elif key == 'vehicle_towed':
                code_dict = Config.FORM_2_VEHICLE_TOWED
            elif key == 'contributing_circumstances_vehicle':
                code_dict = Config.FORM_2_CONTRIBUTING_CIRCUMSTANCES_VEHICLE
                
            if code_dict:
                text = text.split()
                code = text[0] + '' + text[len(text) - 1]
                return [{'Code': code, 'Description': code_dict[str(int(code))]}]
    except:
        pass
    return ''

def get_geo_data(text):
    try:
        text = text.replace('o', u'\u00b0')
        text = text.replace(' ', '')
        text = text.replace('--', '-')
    except:
        pass
    return text

def get_speed_limit(text):
    try:
        text = ''.join(re.sub('[^0-9]+', ' ', text).split()).strip()
        if text:
            return [{'Code': '', 'Description': text}]
    except:
        pass
    return [{'Code': '', 'Description': '0'}]

def clean_home_phone(text):
    """
    Cleans the Home phone text

    Args:
        text (str): text

    Returns:
        str: updated text
    """
    try:
        text = '-'.join(re.sub('[^0-9]+', ' ', text).split())
    except:
        pass
    return text

def delete_invalid_keys(people):
    """
    Deletes keys that not required from class

    Args:
        people (class): People
    """
    try:
        del people.Alcohol_Use_Suspected
        del people.Marijuana_Use_Suspected
        del people.Drug_Use_Suspected
        del people.Contributing_Circumstances_Person
        del people.Non_Motorist_Actions_At_Time_Of_Crash
        del people.Safety_Equipment_Restraint
        del people.Safety_Equipment_Available_Or_Used
        del people.Safety_Equipment_Helmet
        del people.Ejection
    except:
        pass
