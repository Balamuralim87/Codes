"""
Created on 27/01/2023

@author: e406679: Srikandan Raju
"""

import sys
import copy

from COLORADO.form_6 import co_form_6_postprocess as postprocessor

class Incident():
    """
    Class defining Incident Report
    """
    def __init__(self, case_identifier='', crash_date='', loss_street='', crash_time='',
        loss_cross_street = '', crash_city='', latitude='', longitude='', weather_condition='',
        road_surface_condition=''):
        """
        Initialize the Incident Report's objects

        Args:
            case_identifier (str, optional): case_identifier. Defaults to ''.
            crash_date (str, optional): crash_date. Defaults to ''.
            loss_street (str, optional): loss_street. Defaults to ''.
            crash_time (str, optional): crash_time. Defaults to ''.
            loss_cross_street (str, optional): loss_cross_street. Defaults to ''.
            crash_city (str, optional): crash_city. Defaults to ''.
        """
        self.Case_Identifier = case_identifier
        self.State_Report_Number = ''
        self.Crash_Date = crash_date
        self.Crash_Time = crash_time
        self.Loss_State_Abbr = 'CO'
        self.Crash_City = crash_city
        self.Report_Type_Id = ''
        self.Loss_Street = loss_street
        self.Loss_Cross_Street = loss_cross_street
        self.Latitude = latitude
        self.Longitude = longitude
        self.Gps_Other = ''
        self.Weather_Condition = weather_condition
        self.Road_Surface_Condition = road_surface_condition

def incident_extraction(data_frame):
    """
    Passes Incident Report data to the Incident Class

    Args:
        data_frame (DataFrame): Predicted DataFrame

    Returns:
        List : Incident Report List
    """
    try:
        case_identifier = postprocessor.get_case_identifier(postprocessor.get_df_value(
            data_frame, 'Case_Identifier'))
        crash_date, crash_time = postprocessor.get_crash_date(
            postprocessor.get_df_value(data_frame, 'Crash_Date_Time'))
        loss_street, loss_cross_street = postprocessor.get_street(
            postprocessor.get_df_value(data_frame, 'Location_of_occurance'))
        incident_report = Incident(
                            case_identifier = case_identifier,
                            crash_date = crash_date,
                            loss_street = loss_street,
                            loss_cross_street = loss_cross_street,
                            crash_time = crash_time
                            )
        return incident_report
    except:
        pass
    return []

class People():
    """
    Class defining People
    """
    def __init__(self, party_id='', unit_number='', person_type='', first_name='',
        middle_name='', last_name='', suffix='', address='', state='', city='', zip_code='',
        date_of_birth='', home_phone='', driver_license_number='', driver_jurisdiction=''):
        """
        Initialize the People objects

        Args:
            party_id (str, optional): party_id. Defaults to ''.
            unit_number (str, optional): unit_number. Defaults to ''.
            person_type (str, optional): person_type. Defaults to ''.
            first_name (str, optional): first_name. Defaults to ''.
            middle_name (str, optional): middle_name. Defaults to ''.
            last_name (str, optional): last_name. Defaults to ''.
            suffix (str, optional): suffix. Defaults to ''.
            address (str, optional): address. Defaults to ''.
            state (str, optional): state. Defaults to ''.
            city (str, optional): city. Defaults to ''.
            zip_code (str, optional): zip_code. Defaults to ''.
            date_of_birth (str, optional): date_of_birth. Defaults to ''.
            home_phone (str, optional): home_phone. Defaults to ''.
            driver_license_number (str, optional): driver_license_number. Defaults to ''.
            driver_jurisdiction (str, optional): driver_jurisdiction. Defaults to ''.
        """
        self.Party_Id = party_id
        self.Person_Type = person_type
        self.Unit_Number = unit_number
        self.First_Name = first_name
        self.Middle_Name = middle_name
        self.Last_Name = last_name
        self.Name_Suffix = suffix
        self.Address = address
        self.Address2 = ''
        self.State = state
        self.City = city
        self.Zip_Code = zip_code
        self.Home_Phone = home_phone
        self.Date_Of_Birth = date_of_birth
        self.Drivers_License_Number = driver_license_number
        self.Drivers_License_Jurisdiction = driver_jurisdiction
        self.Injury_Status = ''
        self.Alcohol_Use_Suspected = ''
        self.Marijuana_Use_Suspected = ''
        self.Drug_Use_Suspected = ''
        self.Contributing_Circumstances_Person = ''
        self.Non_Motorist_Actions_At_Time_Of_Crash = ''
        self.Safety_Equipment_Restraint = ''
        self.Safety_Equipment_Available_Or_Used = ''
        self.Safety_Equipment_Helmet = ''
        self.Ejection = ''

def people_extraction():
    """
    Returns people list 

    Returns:
        List : People List
    """
    try:
        people_list = []
        owner = People(party_id = str(1), person_type='VEHICLE OWNER')
        postprocessor.delete_invalid_keys(owner)
        driver = People(party_id = str(2), person_type='DRIVER')
        people_list.extend([owner, driver])
        return people_list
    except:
        pass
    return []

def witness_extraction(people_list, d_frame, business_name_lookup_path):
    """
    Returns people list 

    Returns:
        List : People List
    """
    try:
        person_name = postprocessor.get_df_value(d_frame, 'Witness_Name')
        if person_name:
            person_name = postprocessor.process_name(person_name, business_name_lookup_path)
            home_phone = postprocessor.clean_home_phone(
                postprocessor.get_df_value(d_frame, 'Witness_Phone_Number'))
            witness = People(party_id = '3',
                        unit_number = '',
                        person_type = 'WITNESS',
                        first_name = person_name['first_name'],
                        middle_name = person_name['middle_name'],
                        last_name = person_name['last_name'],
                        home_phone=home_phone
                        )
            people_list.append(witness)
    except:
        pass
    return people_list

class Vehicle():
    """
    Class defining Vehicle
    """
    def __init__(self, unit_number='', make='', vin = '', model_year='', model='',
        license_plate='', registration_state='', insurance_company='', damaged_areas='',
        police_number = '', expiration_date='', vehicle_towed='', speed_limit='',
        circumstance_vehicle=''):
        """
        Initialize the Vehicle objects

        Args:
            unit_number (str, optional): unit_number. Defaults to ''.
            make (str, optional): make. Defaults to ''.
            vin (str, optional): vin. Defaults to ''.
            model_year (str, optional): model_year. Defaults to ''.
            license_plate (str, optional): license_plate. Defaults to ''.
            registration_state (str, optional): registration_state. Defaults to ''.
            insurance_company (str, optional): insurance_company. Defaults to ''.
            damaged_areas (str, optional): damaged_areas. Defaults to ''.
        """
        self.Unit_Number = unit_number
        self.License_Plate = license_plate
        self.Registration_State = registration_state
        self.VIN = vin
        self.VinValidation_VinStatus = ''
        self.Model_Year = model_year
        self.Make = make
        self.Model = model
        self.Insurance_Company = insurance_company
        self.Insurance_Policy_Number = police_number
        self.Insurance_Expiration_Date = expiration_date
        self.Vehicle_Towed = vehicle_towed
        self.Air_Bag_Deployed = ''
        self.Damaged_Areas = damaged_areas
        self.Contributing_Circumstances_Vehicle = circumstance_vehicle
        self.Posted_Statutory_SpeedLimit = speed_limit

def vehicle_extraction():
    """
    Return vehicle list

    Returns:
        List : Vehicle List
    """
    try:
        vehicle_list = [Vehicle(unit_number = '1')]
        return vehicle_list
    except:
        pass
    return []

class Report():
    """
    Class defining Report
    """
    def __init__(self, form_name, count_keyed, incident, people, vehicles, citations, form_type):
        """
        Initialize the Report objects

        Args:
            form_name (str): form_name
            count_keyed (str): count_keyed
            incident (List): incident
            people (List): people
            vehicles (List): vehicles
            citations (List): citations
        """
        self.FormName = form_name
        self.CountKeyed = count_keyed
        self.Incident = incident
        self.People = people
        self.Vehicles = vehicles
        self.Citations = citations
        self.Form_Type = form_type

class MainCls():
    """
    Class: Defines MainCls
    """
    def __init__(self, report):
        """
        Initialize the MainCls objects

        Args:
            report (class): report
        """
        self.Report = report

def json_convertion(text_extracted_df, form_type, business_name_lookup_path):
    """
    Function to form json from the predicted DataFrame

    Args:
        text_extracted_df (DataFrame): Predicted DataFrame
        business_name_lookup_path (str): business_name_lookup_path
        city_lookup_path (str): city_lookup_path

    Returns:
        JSON: Json data created from predicted DataFrame
    """
    try:
        incident_report = incident_extraction(text_extracted_df)

        people_list = people_extraction()

        people_list = witness_extraction(people_list, text_extracted_df, business_name_lookup_path)

        vehicle_list = vehicle_extraction()

        if (incident_report or people_list or vehicle_list):
            tif_name = (text_extracted_df['path'][0].split("_")[0]) + '_CO.tif'
            report = Report(form_name = 'Universal',
                            count_keyed = '',
                            incident = incident_report,
                            people = people_list,
                            vehicles = vehicle_list,
                            citations = [],
                            form_type = ('CO_'+ form_type))
            main_cls = MainCls(report = report)
            return main_cls, tif_name
    except:
        pass
    return sys.exc_info(), 'error'
