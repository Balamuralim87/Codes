import glob
import pandas as pd
import xml.etree.ElementTree as ET
import COLORADO.common_util as common_util
import COLORADO.text_extract as text_extract

class patch_xml():

    def initialize_required_fields(self):
        """
        Initializes the fields
        """
        self.last_name = 'LastName'
        self.owner_last_name = 'VehicleOwnerLastName'
        self.owner_x_last_name = 'VehicleOwnerLastNamexSame'
        self.mi = 'MI'
        self.first = 'First'
        self.zip = 'ZIP'
        self.personal_phone = 'PersonalPhone'
        self.bus_phone = 'Bus.Phone'
        self.location_route = 'LocationRoute'
        self.location_route_street = 'LocationRoute.Street,Road'
        self.location_route_street_road = 'LocationRoute,Street,Road'
        self.state_country = 'StateorCountry'
        self.ex_data = 'Exp.Date'
        self.ex_data_space = 'ExpDate'
        self.ins_company = 'InsuranceCompany'
        self.inj_sev = 'SEV.'
        self.driver_state = 'State'
        self.city = 'City'
        self.address_street = 'StreetAddress'
        self.address_same = 'AddressxSame'
        self.address_same_space = 'AddressSame'
        self.address_same_I = 'AddressISame'
        self.address_same_II = 'AddressIISame'
        self.eject = 'EJECT'
        self.make = 'Make'
        self.model = 'Model'
        self.driver_license_state = 'DriverLicenseNumber'
        self.alcohol = 'ALCO'
        self.drug = 'DRUG'

        self.required_fields = [
            self.last_name, self.owner_last_name, self.owner_x_last_name, self.mi, self.first,
            self.zip, self.personal_phone, self.bus_phone, self.location_route,
            self.location_route_street, self.location_route_street_road, self.state_country,
            self.ex_data, self.ex_data_space, self.ins_company, self.inj_sev, self.driver_state,
            self.city, self.address_street, self.address_same, self.address_same_space, 
            self.address_same_I, self.address_same_II, self.eject, self.make, self.model,
            self.driver_license_state, self.alcohol, self.drug
        ]
        
        for field in self.required_fields:
            self.extracted_data[field] = {}

    def initialize_coordinates(self):
        """
        Initializes the target Bounding boxes
        """
        self.BB_CORDINATES = {
            self.last_name: [0, 5, 70, 10],
            self.mi: [0, 5, 20, 10],
            self.first: [0, 5, 70, 10],
            self.zip: [0, 5, 30, 10],
            self.personal_phone: [0, 5, 30, 10],
            self.bus_phone: [0, 5, 30, 10],
            self.location_route: [0, 10, 120, 15],
            self.state_country: [0, 5, 20, 10],
            self.ex_data: [0, 5, 30, 10],
            self.ins_company: [0, 5, 70, 10],
            self.inj_sev: [30, 10, 10, 100],
            self.driver_state: [0, 5, 15, 10],
            self.city: [-5, 5, 60, 10],
            self.address_street: [0, 5, 70, 10],
            self.eject: [0, 10, 10, 100],
            self.make: [0, 5, 65, 10],
            self.model: [0, 5, 65, 10],
            self.driver_license_state: [150, 5, 115, 10],
            self.alcohol: [0, 10, -30, 100],
            self.drug: [20, 10, -20, 100]
        }

    def update_line_content(self, line_content):
        """
        Replaces the line_content with required content

        Args:
            line_content (string): line_content

        Returns:
            (string): line_content
        """
        if (self.owner_last_name.lower() in line_content.lower()):
            line_content = self.last_name
        elif (self.location_route.lower() in line_content.lower()):
            line_content = self.location_route
        elif (self.ex_data_space.lower() in line_content.lower()):
            line_content = self.ex_data
        elif (self.ins_company.lower() in line_content.lower()):
            line_content = self.ins_company
        elif (self.inj_sev.lower() in line_content.lower()):
            line_content = self.inj_sev
        elif (('address' in line_content.lower()) and 'same' in line_content.lower()):
            line_content = self.address_street
        return line_content

    def get_text(self, line, line_content):
        """
        Retrives text based on Bounding box

        Args:
            line (string): xml line
            line_content (string): line to find required text

        Returns:
            string: required text
        """
        try:
            line_L = int(line.attrib['xMin'].split('.')[0])
            line_T = int(line.attrib['yMin'].split('.')[0])
            line_R = int(line.attrib['xMax'].split('.')[0])
            line_B = int(line.attrib['yMax'].split('.')[0])

            coord = self.BB_CORDINATES.get(line_content, [])
            if (coord):
                bb_coord = (int(line_L + coord[0]), int(line_T + coord[1]), \
                    (line_R + coord[2]), int(line_B + coord[3]))
                add_list = text_extract.find_text(self.xml_tree, bb_coord, 1)
                add_list = sorted(add_list, key = lambda x: x[0])
                text_list = [x[1].strip() for x in add_list]
                text = ' '.join(text_list).strip()
                return text, int(line_L + coord[0]), int(line_T + coord[1])
            else:
                return '', 0
        except:
            pass
        return '', 0

    def bb_preprocess(self, line, line_content, page_no):
        """
        Bounding Box preprocessing

        Args:
            line (string): xml line
            line_content (string): line to find required text
            page_no (string): xml page number
        """
        try:
            result_text, up_xmin, up_ymin = self.get_text(line, line_content)
            if (self.extracted_data[line_content].get(page_no, {}) == {}):
                self.extracted_data[line_content][page_no] = {}
            key = str(up_xmin) + '_' + str(up_ymin)
            self.extracted_data[line_content][page_no][key] = result_text
        except:
            pass

    def read_xml_page(self, page_no):
        """
        Reads the xml page

        Args:
            page_no (string): xml page number
        """
        try:
            for line in self.pdftree.iter('line'):
                try:
                    words = [x for x in line.iter('word')]
                    line_content = ''.join(['' if w.text == None else w.text for w in words]).strip()
                    # print(line_content)
                    if (self.alcohol in line_content):
                        self.bb_preprocess(line, self.alcohol, page_no)
                    if (self.drug in line_content):
                        self.bb_preprocess(line, self.drug, page_no)
                    if (self.inj_sev in line_content):
                        self.bb_preprocess(line, self.inj_sev, page_no)
                    if ((line_content in self.required_fields) or (self.ins_company in line_content)):
                        line_content = self.update_line_content(line_content)
                        self.bb_preprocess(line, line_content, page_no)
                except Exception as ex:
                    pass
        except:
            print('Error during XML Patch XML-Read')

    def create_extracted_df(self):
        """
        Creates the DataFrame for extracted Data
        """
        try:
            label = []
            x_min = []
            y_min = []
            page_no = []
            text = []
            for key, value in self.extracted_data.items():
                for inner_key, inner_value in value.items():
                    x_min.extend([int(i.split('_')[0]) for i in inner_value.keys()])
                    y_min.extend([int(i.split('_')[1]) for i in inner_value.keys()])
                    text.extend([i for i in inner_value.values()])
                    page_no.extend([inner_key]*len(inner_value))
                    label.extend([key]*len(inner_value))

            self.extracted_df = pd.DataFrame({
                'label': label,
                'page': page_no,
                'x_min': x_min,
                'y_min': y_min,
                'text': text
            })
            self.extracted_df.sort_values(['page', 'x_min', 'y_min'], ascending = [True, True, True], \
                inplace=True)
            self.extracted_df.reset_index(drop=True, inplace=True)
        except:
            print('Error during XML Patch DataFrame creation')

    def get_incident_data(self, key):
        """
        Retrives incident data from DataFrame

        Args:
            key (string): lable to extract text

        Returns:
            string: required text
        """
        try:
            data = self.extracted_df
            return data.loc[(data['label']==key)].iloc[0].text
        except:
            pass
        return '' 

    def insert_incident_data(self):
        """
        Passes incident keys, to extract the required text
        """
        incident = self.report.Incident
        if (incident.Loss_Street == ''):
            incident.Loss_Street = self.get_incident_data(self.location_route)

    def get_data(self, key, party_id, person_type=None):
        """
        Retrives requird text

        Args:
            key (string): lable to extract text
            party_id (string): Party ID
            person_type (string, optional): Denotes Owner or Driver

        Returns:
            string: required text
        """
        try:
            data = self.extracted_df
            mid_pt = self.approx_page_midpoint
            if (int(party_id) % 2 == 0):
                xmin_cond = (data['x_min'] >= mid_pt)
            else:
                xmin_cond = (data['x_min'] < mid_pt)

            page_location = 0
            for i in range(1000):
                difference = abs(int(party_id) - (i+1))
                if ((difference == 0) or (difference == 1)):
                    page_location = i
                    break
            page_cond = (data['page'] == list(set(data['page']))[page_location])

            result = data.loc[(data['label']==key) & (page_cond) & (xmin_cond)]
            if (person_type != None):
                result = result.iloc[person_type].text
            else:
                result = result.iloc[0].text

            return result
        except:
            pass
        return ''

    def get_specific_data(self, key, unit):
        """
        Retrives requird text

        Args:
            key (string): lable to extract text
            unit (string): Unit Number
            person_type (string, optional): Denotes Owner or Driver

        Returns:
            string: required text
        """
        try:
            data = self.extracted_df
            if ((key == self.inj_sev) or (key == self.eject)):
                try:
                    result = data.loc[(data['label']==key)].iloc[0].text
                    result = [i.strip() for i in result.split(' ') if (i.strip() != '')]
                    return result[int(unit)-1]
                except:
                    pass
                return '00'
            elif ((key == self.alcohol) or (key == self.drug)):
                try:
                    result = data.loc[(data['label']==key)].iloc[0].text
                    result = [i.strip() for i in result.split(' ') if (i.strip() != '')]
                    result = result[int(unit)-1]
                    description = 'No' if (int(result) == 0) else 'UNKNOWN'
                    result = {
                        'Code': result,
                        'Description': description
                    }
                    return result
                except:
                    pass
                return []
        except:
            pass
        return ''

    def insert_people_data(self):
        """
        Passes people keys, to extract the required text
        """
        person_type_value = 0
        peoples = self.report.People
        is_passenger_present = False
        for people in peoples:
            try:
                party_id = (str(int(people.Party_Id) - 1) if is_passenger_present else people.Party_Id)
                if (people.Person_Type != 'PASSENGER' and party_id != ''):
                    if (people.Person_Type == 'VEHICLE OWNER'):
                        person_type_value = 1
                    if (people.Last_Name == ''):
                        people.Last_Name = self.get_data(self.last_name, party_id, person_type_value)
                    if (people.Middle_Name == ''):
                        people.Middle_Name = self.get_data(self.mi, party_id, person_type_value)
                    if (people.First_Name == ''):
                        people.First_Name = self.get_data(self.first, party_id, person_type_value)
                    if (people.Zip_Code == ''):
                        people.Zip_Code = self.get_data(self.zip, party_id, person_type_value)
                    if (people.Home_Phone == ''):
                        people.Home_Phone = self.get_data(self.personal_phone, party_id, \
                            person_type_value)
                    if (people.Home_Phone == ''):
                        people.Home_Phone = self.get_data(self.bus_phone, party_id, person_type_value)
                    if (people.Injury_Status == ''):
                        people.Injury_Status = self.get_specific_data(self.inj_sev, people.Unit_Number)
                    if (people.Alcohol_Use_Suspected == ''):
                        people.Alcohol_Use_Suspected = self.get_specific_data(self.alcohol, \
                            people.Unit_Number)
                    if (people.Drug_Use_Suspected == ''):
                        people.Drug_Use_Suspected = self.get_specific_data(self.drug, people.Unit_Number)
                    if (people.State == ''):
                        people.State = self.get_data(self.driver_state, party_id, person_type_value)
                    if (people.City == ''):
                        people.City = self.get_data(self.city, party_id, person_type_value)
                    if (people.Address == ''):
                        people.Address = self.get_data(self.address_street, party_id, person_type_value)
                    if (people.Ejection == ''):
                        people.Ejection = self.get_specific_data(self.eject, party_id)
                    if (people.Drivers_License_Jurisdiction == ''):
                        people.Drivers_License_Jurisdiction = self.get_data(self.driver_license_state, \
                            party_id, person_type_value)
                if (people.Person_Type == 'PASSENGER'):
                    is_passenger_present = True
            except:
                pass

    def insert_vehicle_data(self):
        """
        Passes vehicle keys, to extract the required text
        """
        vehicles = self.report.Vehicles
        for vehicle in vehicles:
            try:
                unit_number = vehicle.Unit_Number
                if (unit_number != ''):
                    if (vehicle.Registration_State == ''):
                        vehicle.Registration_State = self.get_data(self.state_country, unit_number)
                    if (vehicle.Insurance_Expiration_Date == ''):
                        vehicle.Insurance_Expiration_Date = self.get_data(self.ex_data, unit_number)
                    if (vehicle.Insurance_Company == ''):
                        vehicle.Insurance_Company = self.get_data(self.ins_company, unit_number)
                    if (vehicle.Make == ''):
                        vehicle.Make = self.get_data(self.make, unit_number)
                    if (vehicle.Model == ''):
                        vehicle.Model = self.get_data(self.model, unit_number)
            except:
                pass

    def __init__(self, xml_path, report):
        """
        Initializes the XML extraction process

        Args:
            xml_path (string): xml path
            report (class): Report Class
        """
        try:
            self.extracted_data = {}
            self.approx_page_midpoint = 300
            self.initialize_required_fields()
            self.initialize_coordinates()
            self.report = report

            self.xml_files = glob.glob(xml_path + '/*.xml')
            for page_no, xml_file in enumerate(self.xml_files):
                xml_str = open(xml_file, 'r', encoding='utf-8').read()
                upd_xml_str = common_util.str_replace_xml(xml_str)
                self.pdftree = ET.fromstring(upd_xml_str)
                self.xml_tree = ET.XML(upd_xml_str)
                self.read_xml_page(page_no+1)

            self.create_extracted_df()
            self.insert_incident_data()
            self.insert_people_data()
            self.insert_vehicle_data()
        except Exception as ex:
            print(ex)
            pass