def CO_clean_narrative(d_frame, label_name, form_type):    
    narrative = ''
    try:
        data_cols = list(d_frame.columns)
        for col in data_cols:
            if col in ['path', 'filename', 'image_name']:
                d_frame.rename({col: 'path'}, axis=1, inplace=True)
            if col in ['classes', 'label']:
                d_frame.rename({col: 'label'}, axis=1, inplace=True)
            if col in ['extracted_text', 'values', 'value', 'text']:
                d_frame.rename({col: 'text'}, axis=1, inplace=True)
        d_frame['path'] = d_frame['path'].apply(lambda x: x.replace('.jpg', ''))
        d_frame['page_no_int'] = (d_frame['path'].apply(lambda x: x.split('_')[-1])).astype(int)
        d_frame.sort_values(['page_no_int'], inplace=True)
        
        # Function to count the number of words in a given text
        def count_words(text):
            return len(text.split())

        data_df = d_frame.loc[d_frame['label'].str.lower()==(label_name.lower()),
                                                        ['label', 'text', 'page_no_int']]
        
         # Apply the function to create a new column 'word_count'
        data_df['word_count'] = data_df['text'].apply(count_words)
        # Filter the DataFrame based on the condition (word count greater than 3)
        df_filtered = data_df[data_df['word_count'] > 3]

        # dropping ALL duplicate values 
        df_filtered.drop_duplicates(subset="text",  keep='first', inplace=True)

        if form_type == 'form_type_1':
            #remove page no 1 for narratives for form_type_1
            df_filtered = df_filtered[df_filtered['page_no_int'] != 1]
        
        elif form_type == 'form_type_2':
            # Given list of words to match
            words_to_match = ['justice', 'records', 'released', 'lexisnexis', 'copy',
                      'date', 'public', 'exemptions', 'response', 'documents',
                      'enclosed', 'following', 'information', 'provided', 'review',
                      'non-motorist', 'crosswalk', 'unmarked', 'clothing', 'lighting',
                      'island', 'emotionally', 'manipulating']
            # Function to count the number of matching words in a given text
            def count_matching_words(text):
                return sum(word in text.lower() for word in words_to_match)
            # Apply the function to create a new column 'matching_word_count'
            df_filtered['matching_word_count'] = df_filtered['text'].apply(count_matching_words)
            # Filter the DataFrame based on the condition (matching word count less than 4)
            df_filtered = df_filtered[df_filtered['matching_word_count'] < 5]    
        
        if len(df_filtered) == 1:
            value = df_filtered['text'].iloc[0]
            if str(value) != 'nan':
                narrative = str(value)
        elif len(df_filtered) > 1:
            narrative = ' '.join(df_filtered["text"].astype(str))
    except:
        pass
    print(narrative)
    return narrative.strip()